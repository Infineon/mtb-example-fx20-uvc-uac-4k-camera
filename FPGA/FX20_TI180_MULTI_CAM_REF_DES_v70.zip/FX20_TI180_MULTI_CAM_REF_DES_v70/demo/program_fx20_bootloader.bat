@echo:
@echo OFF
cd openocd
echo [32mProgramming FX20 Bootloader[0m
timeout 2 >nul
openocd_fx20.exe -s scripts/ -f interface/kitprog3.cfg -f target/fx3g2.cfg -c "program ../fx20_bootloader_hex/fx3g2_bl_cm0p.hex verify reset exit"
PAUSE
