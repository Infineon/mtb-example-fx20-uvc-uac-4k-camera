@echo OFF
REM Update FX device bootloader over DFU
REM Usage: Double-click on the batch script to update bootloader.
REM Ensure the file specified in FILENAME is present in the same folder

echo FX Bootloader updater

setlocal

SET FILENAME=fx_bootloader_v2.bin
SET READBACK_FILE=readback_temp.bin
SET TIMEOUT_DURATION=5

IF NOT EXIST %FILENAME% (
    echo ERROR:File %FILENAME% does not exist.Please ensure %FILENAME% is present in same folder.
    PAUSE
    EXIT /B 1
)


echo ****************************************CRITICAL WARNING*********************************************
echo Any interruption during bootloader update WILL cause subsequent device boot failure.
echo Only a bootloader refresh using SWD programmer (eg: MiniProg) WILL recover the device for further use.
echo *****************************************************************************************************

SET /P AREYOUSURE=Do you want to continue? (Y/N)
IF /I "%AREYOUSURE%" NEQ "Y" GOTO END


echo *****************************************
echo STEP 0: DOWNLOAD BL Updater
echo *****************************************

FwDownload fx_boot_updater.hex

IF %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to download Bootloader updater firmware. Please check if FX bootloader is enumerated and close other WinUSB-based applications [eg: FX Control Center]
    PAUSE
    EXIT /B 1
)

echo INFO: Using local bootloader file [%FILENAME%]

REM Waiting for BL Updater to enumerate
("%systemroot%\System32\timeout.exe" /t %TIMEOUT_DURATION% /nobreak)>nul

echo *****************************************
echo STEP 1: DOWNLOAD FILE: %FILENAME% 
echo *****************************************

dfu-util -D %FILENAME% -S FX-BOOT-UPDATER

IF errorlevel 1 (
    echo ERROR: Firmware download via dfu-util failed. Rerun the script again WITHOUT a device reset.
    PAUSE
    EXIT /B 1
)

IF EXIST  %READBACK_FILE% (
    echo Deleting %READBACK_FILE% ..
    del %READBACK_FILE%
)

REM Waiting for device to re-enumerate
("%systemroot%\System32\timeout.exe" /t %TIMEOUT_DURATION% /nobreak)>nul

echo ****************************
echo STEP 2: READ BACK AND VERIFY
echo ****************************

dfu-util -U %READBACK_FILE% -S FX-BOOT-UPDATER

fc /b %FILENAME% %READBACK_FILE%

IF EXIST  %READBACK_FILE% (
    echo Cleaning up readback file: %READBACK_FILE% ..
    del %READBACK_FILE%
)
echo ***************************************************
IF errorlevel 1 (
    echo ERROR:Firmware verify failed. Please retry.
) else (
    echo SUCCESS:Firmware download and verify completed.
)
echo **************************************************

:END
PAUSE
