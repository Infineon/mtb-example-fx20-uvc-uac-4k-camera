# FX20 Ti180 Multi Camera Reference Design
## Overview
The goal of this reference design is to capture uncompressed 4K@30 fps video from four different camera sensors over MIPI and transmit to the Host PC over USB using FX20.
## Applications Supported
- [x] 4 Sony IMX715 sensors, each simultaneously streaming at 4K@30fps (RAW12 Format).
- [x] 4 THine (THSCG101) sensors, each simultaneously streaming at 4K@30fps (YUV422 Format).
- [x] 4 Internal Colorbar, each simultaneously streaming at 4K@30fps.

Refer to  __EZ-USB™ FX10/FX20 DVK/SDK Multi Camera stream using Ti180 FPGA KBA__ to validate the above mentioned applications.
 - Procedure for hardware modifications, programming FPGA, FX10/FX20 and stream video.

Refer to  __FPGA_Design_Details.xlsx__ for basic overview about the project.
 - Block Diagram.
 - Project Hierarchy
 - LVDS control byte encoding
 - I2C registers

Since pin mappings are different for DVK ( Ti180 DVK and FX20 DVK ) and DEMO_FX20_MIPI_KIT ( 4 MIPI solution demo kit (SDK) ), there are some design files that needs
to be modified based on application. There are two different ways for updating the design files based on kit: One through batch(.bat) file and other via executable(.exe) file.

## Via Batch(.bat) file
>**Note**:
Batch file support both LVCMOS and LVDS modes for both kits, either SDK or DVK. 

1. By default, the project is for DVK.
2. To make project for DEMO_FX20_MIPI_KIT(SDK), close the EFINITY project if it is already opened.
3. Open the config_migration.bat by double-clicking on it.
4. Choose SDK or DVK based on application.
5. Choose the appropriate Interface LVDS or LVCMOS based on your application.
5. Design files will get updated based on selection of Kit.
6. Now, project is ready to open in EFINITY tool.

## Via Executable(.exe) file
>**Note**:
Executable has only LVDS mode support for either SDK or DVK.

1. By default, the project is for DVK.
2. To make project for DEMO_FX20_MIPI_KIT, close the EFINITY project if it is already opened.
3. Open the fpga_config_migratior.exe application available inside (fxn_ti180_multi_cam_ref_des folder) by double-clicking it.
4. Choose DEMO_FX20_MIPI_KIT or KIT_FX20_FMC_001-FX20 DVK based on application.
5. Design files will get updated based on selection of Kit.
6. Now, project is ready to open in EFINITY tool.

---
>**Note**:
During the process of updating the project to a newer version of the tool, it is essential to ensure that if we need to update the IP, the project utilize some parameters to maintain modularity.Thus, we must be vigilant while updating the IP.
Additionally, for any other changes in the project, user has to open the respective project in EFINITY tool and update accordingly.
---

## Basic FPGA project Build Example:

#### PRE BUILD ( NO MODIFICATION )
##### Supports internal colorbar, Sony sensor(RAW image) , THine sensor streaming based on I2C registers, Use frame buffer (LPDDR4) to store the image data.

#### TESTING MAX THROUGHOUT ( 120 FPS )
##### To enable maximum throughput using internal colorbar ( Sony sensor and THine sensor will not be able to stream with this configuration )

- Modify in user_define_pkg.sv
    > FV_LV_GENERATION = "TRUE";

    > INTERNAL_TEST_PATTERN_DATA_WIDTH = 256;

#### DISABLE FRAME BUFFER (LPDDR4) AND USE ONCHIP BUFFER (FIFO)
##### To disable DDR and use onchip buffer to store the image data. ( Not recommended for higher throughput ).

- Modify in fbh_define_pkg.sv
    > DDR_AXI0 = "FALSE";

    > DDR_AXI1 = "FALSE";

#### GPIF MODE AND LINK TYPE

---
>**Note**:
The GPIF MASTER MODE parameter is responsible for handling RTL side modifications for LVDS, LVCMOS_DDR and LVCMOS_SDR mode. User has to update pin mappings manually, while switching between LVDS, LVCMOS DDR and LVCMOS SDR mode.
---

##### For LVDS Widelink mode

- Modify in user_define_pkg.sv
    > GPIF_MASTER_MODE = "LVDS";

    > GPIF_LINK_TYPE = "WIDE";

##### For LVDS Narrow link P0 mode

- Modify in user_define_pkg.sv
    > GPIF_MASTER_MODE = "LVDS";

    > GPIF_LINK_TYPE = "NARROW_PORT_0";

##### For LVDS Narrow link P1 mode

- Modify in user_define_pkg.sv
    > GPIF_MASTER_MODE = "LVDS";

    > GPIF_LINK_TYPE = "NARROW_PORT_1";

##### For LVCMOS DDR Widelink mode

- Modify in user_define_pkg.sv
    > GPIF_MASTER_MODE = "LVCMOS_DDR";

    > GPIF_LINK_TYPE = "WIDE";

##### For LVCMOS DDR Narrow link P0 mode

- Modify in user_define_pkg.sv
    > GPIF_MASTER_MODE = "LVCMOS_DDR";

    > GPIF_LINK_TYPE = "NARROW_PORT_0";

##### For LVCMOS DDR Narrow link P1 mode

- Modify in user_define_pkg.sv
    > GPIF_MASTER_MODE = "LVCMOS_DDR";

    > GPIF_LINK_TYPE = "NARROW_PORT_1";

##### For LVCMOS SDR Widelink mode

- Modify in user_define_pkg.sv
    > GPIF_MASTER_MODE = "LVCMOS_SDR";

    > GPIF_LINK_TYPE = "WIDE";

##### For LVCMOS SDR Narrow link P0 mode

- Modify in user_define_pkg.sv
    > GPIF_MASTER_MODE = "LVCMOS_SDR";

    > GPIF_LINK_TYPE = "NARROW_PORT_0";

##### For LVCMOS SDR Narrow link P1 mode

- Modify in user_define_pkg.sv
    > GPIF_MASTER_MODE = "LVCMOS_SDR";

    > GPIF_LINK_TYPE = "NARROW_PORT_1";

#### INCREMENTAL PATTERN
##### FV LV Generation with Incremental Pattern

- Modify in user_define_pkg.sv
    > FV_LV_GENERATION = "TRUE";

    > INCREMENTAL_DATA_PATTERN = "TRUE";

#### MOVING BLOCK ENABLE
##### Enabling moving block with FV LV generation

- Modify in user_define_pkg.sv
    > FV_LV_GENERATION = "TRUE";

    > MOVING_BLOCK_EN = "TRUE";


#### NOTE:
- User can configure FPGA project build as per their requirement.
































