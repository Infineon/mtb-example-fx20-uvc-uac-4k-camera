//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fv_lv_generator
// Target Devices: All
//
// Description: This module generates the frame and line valid (FV and LV) signals
//              along with the colorbar data based on the requested resolution
//              and frame rate. It supports fixed or maximum possible frame rate
//              options. In maximum frame rate options, based on the blanking
//              values, it generates the maximum possible frame data whereas in
//              fixed frame rate option, it generates the fixed frames per second.
//
//////////////////////////////////////////////////////////////////////////////////

// Include the package file
`include "package/user_define_pkg.sv"

module fv_lv_generator
  #
  (
   // Input Clock Value
   parameter REF_CLK_PULSES_IN_S_I  = 32'd75_000_000,

   // Whether to generate fixed FPS data or
   // based on clock (dynamic).
   // Possible Values are "FIXED_FPS" or "MAX_FPS".
   parameter MODE_I = "MAX_FPS",

   // Incremental pattern enable.
   // If TRUE, it is enabled otherwise disabled.
   // Possible Values are "TRUE" or "FALSE".
   parameter INCREMENTAL_DATA_PATTERN = "FALSE",

   // Moving square block enable.
   // If TRUE, it is enabled otherwise disabled.
   // Possible Values are "TRUE" or "FALSE".
   parameter MOVING_BLOCK_EN_I = "TRUE",

   // Moving square block color in hex in VYUY format
   // Try to keep value different than bars.
   parameter MOVING_BLOCK_COLOR_VYUY_VALUE_I = 32'h8010_C010,

   // Moving square block color in RGB format
   parameter MOVING_BLOCK_COLOR_RGB_VALUE_I = 24'h10_00_81,

   // Frame Blanking Interval in terms of
   // number of lines
   parameter NO_OF_LINES_IN_FRAME_BLANKING_I = 40,

   // Data Width in bits
   // It must not be lesser than the pixel width.
   parameter DATA_WIDTH_I = 64
  )
  (
   input               clk,
   input               reset_n,

   input        [15:0] image_width_i,
   input        [15:0] image_height_i,
   input        [ 7:0] image_fps_i,
   input        [ 7:0] image_pixel_width_i,
   input               rgb_mode_i,
   input        [15:0] line_blanking_clk_pulses_i,
   input               start_colourbar_gen_req_i,
   input               pause_colourbar_gen_req_i,
   input               colour_bar_sel_i,

   output logic        fv_o,
   output logic        lv_o,
   output logic [(DATA_WIDTH_I-1):0] data_o
  );

//----------------------------------
//
// Local Parameters
//
//----------------------------------

  // High Value
  localparam HIGH = 1'b1;

  // Low Value
  localparam LOW  = 1'b0;

/************  VYUY color format Hex values   **********/

  // White Colour
  localparam VYUY_WHITE  = 32'h80ff80ff;

  // Yellow
  localparam VYUY_YELLOW = 32'h94ff00ff;

  // Blue
  localparam VYUY_BLUE   = 32'h1ac8bfc8;

  // Green
  localparam VYUY_GREEN  = 32'h4aca55ca;

  // Pink
  localparam VYUY_PINK   = 32'hf3969f96;

  // Red
  localparam VYUY_RED    = 32'hff4c544c;

  // Violet
  localparam VYUY_VIOLET = 32'h9e40d340;

  // Black
  localparam VYUY_BLACK  = 32'h80008000;

/************  RGB color format Hex values   **********/

  // White Colour
  localparam RGB_WHITE  = 24'hFF_FF_FF;

  // Yellow
  localparam RGB_YELLOW = 24'hFF_FF_18;

  // Blue
  localparam RGB_BLUE   = 24'h38_FB_FF;

  // Green
  localparam RGB_GREEN  = 24'h7D_FF_7D;

  // Pink
  localparam RGB_PINK   = 24'hFF_38_CD;

  // Red
  localparam RGB_RED    = 24'hFE_00_00;

  // Violet
  localparam RGB_VIOLET = 24'h6A_0D_D3;

  // Black
  localparam RGB_BLACK  = 24'h00_00_00;

  // Number of clock pulses in FV for 5 FPS
  localparam FV_CLK_PULSES_5_FPS = ( REF_CLK_PULSES_IN_S_I / 5 );

  // Number of clock pulses in FV for 10 FPS
  localparam FV_CLK_PULSES_10_FPS = ( REF_CLK_PULSES_IN_S_I / 10 );

  // Number of clock pulses in FV for 15 FPS
  localparam FV_CLK_PULSES_15_FPS = ( REF_CLK_PULSES_IN_S_I / 15 );

  // Number of clock pulses in FV for 30 FPS
  localparam FV_CLK_PULSES_30_FPS = ( REF_CLK_PULSES_IN_S_I / 30 );

  // Number of clock pulses in FV for 35 FPS
  localparam FV_CLK_PULSES_35_FPS = ( REF_CLK_PULSES_IN_S_I / 35 );

  // Number of clock pulses in FV for 40 FPS
  localparam FV_CLK_PULSES_40_FPS = ( REF_CLK_PULSES_IN_S_I / 40 );

  // Number of clock pulses in FV for 45 FPS
  localparam FV_CLK_PULSES_45_FPS = ( REF_CLK_PULSES_IN_S_I / 45 );

  // Number of clock pulses in FV for 50 FPS
  localparam FV_CLK_PULSES_50_FPS = ( REF_CLK_PULSES_IN_S_I / 50 );

  // Number of clock pulses in FV for 55 FPS
  localparam FV_CLK_PULSES_55_FPS = ( REF_CLK_PULSES_IN_S_I / 55 );

  // Number of clock pulses in FV for 58 FPS
  localparam FV_CLK_PULSES_58_FPS = ( REF_CLK_PULSES_IN_S_I / 58 );

  // Number of clock pulses in FV for 60 FPS
  localparam FV_CLK_PULSES_60_FPS = ( REF_CLK_PULSES_IN_S_I / 60 );
  
  // Number of clock pulses in FV for 65 FPS
  localparam FV_CLK_PULSES_65_FPS = ( REF_CLK_PULSES_IN_S_I / 65 );
  
  // Number of clock pulses in FV for 75 FPS
  localparam FV_CLK_PULSES_75_FPS = ( REF_CLK_PULSES_IN_S_I / 75 );

  // Number of clock pulses in FV for 90 FPS
  localparam FV_CLK_PULSES_90_FPS = ( REF_CLK_PULSES_IN_S_I / 90 );

  // Number of clock pulses in FV for 100 FPS
  localparam FV_CLK_PULSES_100_FPS = ( REF_CLK_PULSES_IN_S_I / 100 );

  // Number of clock pulses in FV for 110 FPS
  localparam FV_CLK_PULSES_110_FPS = ( REF_CLK_PULSES_IN_S_I / 110 );

  // Number of clock pulses in FV for 120 FPS
  localparam FV_CLK_PULSES_120_FPS = ( REF_CLK_PULSES_IN_S_I / 120 );

  // Number of clock pulses in FV for 125 FPS
  localparam FV_CLK_PULSES_125_FPS = ( REF_CLK_PULSES_IN_S_I / 125 );

  // Number of clock pulses in FV for 130 FPS
  localparam FV_CLK_PULSES_130_FPS = ( REF_CLK_PULSES_IN_S_I / 130 );

  // Number of clock pulses in FV for 135 FPS
  localparam FV_CLK_PULSES_135_FPS = ( REF_CLK_PULSES_IN_S_I / 135 );

  // Number of clock pulses in FV for 140 FPS
  localparam FV_CLK_PULSES_140_FPS = ( REF_CLK_PULSES_IN_S_I / 140 );

  // Number of clock pulses in FV for 145 FPS
  localparam FV_CLK_PULSES_145_FPS = ( REF_CLK_PULSES_IN_S_I / 145 );

  // Number of clock pulses in FV for 150 FPS
  localparam FV_CLK_PULSES_150_FPS = ( REF_CLK_PULSES_IN_S_I / 150 );

  // Moving square block width Value
  localparam MOVING_BLOCK_START_WIDTH  = 16'd80;

  // Moving square block height Value
  localparam MOVING_BLOCK_START_HEIGHT = 16'd180;

  // Moving square block constant value
  localparam MOVING_BLOCK_CONSTANT = 8'd12;

  // Moving square block x ratio
  localparam MOVING_BLOCK_X_RATIO_CONSTANT = 8'd4;

  // Moving square block y ratio
  localparam MOVING_BLOCK_Y_RATIO_CONSTANT = 8'd9;

  // Moving square block speed
  localparam MOVING_BLOCK_SPEED = 8'd2;

  // Factor. How many times, data needs to be repeated
  localparam DATA_REPEAT_FACTOR = ( DATA_WIDTH_I / 32 );
  
  // Number of bytes in Data width
  localparam NUM_BYTES = ( DATA_WIDTH_I / 8 );

  // No of States
  localparam NO_OF_FSM_STATES = 4'd5;

//----------------------------------
//
// Local Variables
//
//----------------------------------

  logic         pixel_counter_type;
  logic  [31:0] pixel_counter;        // No. of Pixels per line -> Image Width
  logic  [15:0] colour_band_counter;  // Color Band counter
  logic  [ 2:0] colour_band;

  logic         fv_counter_type;
  logic  [31:0] fv_counter;           // No. of Frames per second -> fps
  logic  [15:0] line_counter;         // No. of lines per frame -> Image height
  logic  [31:0] no_of_clk_pulses_in_fv_high_time; // No. of clock pulses during a frame
  logic  [31:0] no_of_clk_pulses_in_fv_low_time;
  logic         lv_f1;
  logic         lv_f2;
  logic         start_colourbar_gen_req_f1;
  logic         start_colourbar_gen_req_f2;
  logic         start_colourbar_gen_pl;
  logic  [15:0] image_height;
  logic  [15:0] image_width;
  logic  [ 7:0] image_fps;

  logic         lv_ne_pl;      // Neg Edge of  lv
  logic  [15:0] colour_band_counter_max_value;

  // Block Position
  logic  [15:0] x;
  logic  [15:0] y;

  // Block Direction
  logic         forwards;
  logic         backwards;
  logic         bottoms;
  logic         tops;

  logic         block_en;
  logic         fv_f1;
  logic         fv_f2;
  logic         fv_ris;
  logic         start_colourbar_gen_pl_f1;
  logic         start_colourbar_gen_pl_f2;
  logic [15:0]  moving_block_width;
  logic [15:0]  moving_block_height;
  logic [ 7:0]  image_pixel_width_div;

  logic  [(DATA_WIDTH_I-1):0] incremental_data_pattern;
  logic  [(DATA_WIDTH_I-1):0] cb_white;
  logic  [(DATA_WIDTH_I-1):0] cb_yellow;
  logic  [(DATA_WIDTH_I-1):0] cb_blue;
  logic  [(DATA_WIDTH_I-1):0] cb_green;
  logic  [(DATA_WIDTH_I-1):0] cb_pink;
  logic  [(DATA_WIDTH_I-1):0] cb_red;
  logic  [(DATA_WIDTH_I-1):0] cb_violet;
  logic  [(DATA_WIDTH_I-1):0] cb_black;
  logic  [(DATA_WIDTH_I-1):0] moving_block_clr;
  logic         msb_byte_detect;


  // FSM regarding direction of Block
  enum logic [(NO_OF_FSM_STATES-1):0] {
    IDLE                                = 5'h1,
    FORWARD                             = 5'h2,
    BACKWARD                            = 5'h4,
    BOTTOM                              = 5'h8,
    TOP                                 = 5'h10
  } block_cs, block_ns;

//----------------------------------
//
// Image Resolution
//
//----------------------------------

  // Whenever FV is LOW, "start_colourbar_gen_req_i" is sampled.
  // It means, "start_colourbar_gen_req_i" will not get changed
  // when FV is HIGH otherwise it may be possible that in between
  // frame data generation, "start_colourbar_gen_req_i" may go LOW
  // and DDR operation gets interrupted as Write FSM reads data
  // from Y FIFO only if 1 full burst is available.
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          start_colourbar_gen_req_f1 <= 1'b0;
          start_colourbar_gen_req_f2 <= 1'b0;
        end
      else if ( fv_o == 1'b0 )
        begin
          start_colourbar_gen_req_f1 <= start_colourbar_gen_req_i;
          start_colourbar_gen_req_f2 <= start_colourbar_gen_req_f1;
        end
    end

  // Rising Edge of "start_colourbar_gen_req_i"
  // It will not create any problem as it is already
  // taken care in I2C Register module.
  // When "start_colourbar_gen_req_i" goes HIGH means FV is LOW only.
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          start_colourbar_gen_pl     <= 1'b0;

        end
      else
        begin
          start_colourbar_gen_pl     <= (start_colourbar_gen_req_i & ~start_colourbar_gen_req_f1);
        end
    end

  // Image Height, FPS and Pixel Width
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          image_height <= 8'b0;
          image_fps    <= 8'b0;
        end
      else if ( start_colourbar_gen_pl )
        begin
          image_height <= image_height_i;
          image_fps         <= image_fps_i;
        end
    end

  // Image Pixel Width
      always_ff @ ( posedge clk )
        begin
          if ( ~reset_n )
            begin
              image_pixel_width_div <= 8'd2;
            end
          else if (start_colourbar_gen_req_i & ~start_colourbar_gen_req_f1)
            begin
              unique case (image_pixel_width_i)

                8'd8  : image_pixel_width_div <= (DATA_WIDTH_I >> 8'd3);
   
            8'd12,
            8'd16 : image_pixel_width_div <= (DATA_WIDTH_I >> 8'd4);
   
                8'd32,
                8'd24 : image_pixel_width_div <= (DATA_WIDTH_I >> 8'd5);
              
                default : image_pixel_width_div <= (DATA_WIDTH_I >> 8'd4);
              
              endcase

        end
    end

// Image Width
   always_ff @ ( posedge clk )
     begin
       if ( ~reset_n )
         begin
           image_width <= 'b0;
         end
      else if ( start_colourbar_gen_pl )
         begin
          // image_width <= (image_width_i / image_pixel_width_div);

              case (image_pixel_width_div)

                8'd0    : image_width <= ( image_width_i << 8'd1 );  // For data width 8 bit
    
                8'd1    : image_width <= image_width_i;

                8'd2    : image_width <= ( image_width_i >> 8'd1 );

                8'd4    : image_width <= ( image_width_i >> 8'd2 );

                8'd8    : image_width <= ( image_width_i >> 8'd3 );

                8'd16   : image_width <= ( image_width_i >> 8'd4 );

                8'd32   : image_width <= ( image_width_i >> 8'd5 );
    
                default : image_width <= image_width_i;

           endcase
         end
     end


//----------------------------------
//
// LV Counter Type
//
//----------------------------------

  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          pixel_counter_type <= LOW;
        end
      else if ( ~fv_o )
        begin
          pixel_counter_type <= LOW;
        end
      else if ( ( pixel_counter_type == HIGH ) & ( pixel_counter == image_width - 1'b1 ) )
        begin
          pixel_counter_type <= LOW;
        end
      else if ( ( pixel_counter_type == LOW ) & ( pixel_counter == line_blanking_clk_pulses_i - 1'b1 ) )
        begin
          pixel_counter_type <= HIGH;
        end
    end


//----------------------------------
//
// LV Counter
//
//----------------------------------

  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          pixel_counter <= 32'h0;
        end
      else if ( ~fv_o )
        begin
          pixel_counter <= 32'h0;
        end
      else if ( pause_colourbar_gen_req_i == 1'b0 )
        begin
          if ( ( ( pixel_counter_type == HIGH ) & ( pixel_counter == image_width - 1'b1 ) ) | //1'b1
               ( ( pixel_counter_type == LOW  ) & ( pixel_counter == line_blanking_clk_pulses_i - 1'b1  ) ) //2'd2
             )
            begin
              pixel_counter <= 32'h0;
            end
          else
            begin
              pixel_counter <= ( pixel_counter + 1'b1 ); //1'b1
            end
        end
    end

//----------------------------------
//
// LV
//
//----------------------------------

  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          lv_o <= 1'h0;
        end
      else if ( ~fv_o )
        begin
          lv_o <= 1'h0;
        end
      else if ( ( ( ( pixel_counter_type == HIGH ) & ( pixel_counter == image_width - 1'b1  ) ) | //1'b1
                  ( ( pixel_counter_type == LOW  ) & ( pixel_counter == line_blanking_clk_pulses_i - 1'b1  ) )
                ) &
               ( pause_colourbar_gen_req_i == 1'b0 )
              )
        begin
          lv_o <= ~lv_o;
        end
    end

  // Flop of LV
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          lv_f1 <= 1'h0;
          lv_f2 <= 1'h0;
        end
      else
        begin
          lv_f1 <= lv_o;
          lv_f2 <= lv_f1;
        end
    end

  // Falling Edge of LV.
  assign lv_ne_pl = ( ( ~lv_f1 ) & ( lv_f2 ) );

  // Counter for number of lines
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          line_counter <= 16'h0;
        end
      else if ( ~fv_o )
        begin
          line_counter <= 16'h0;
        end
      else if ( ( lv_ne_pl == 1'b1 ) & ( pause_colourbar_gen_req_i == 1'b0 ) )
        begin
          line_counter <= line_counter + 1'b1;
        end
    end


//----------------------------------
//
// FV High Time
//
//----------------------------------

  // How many number of clock cycles are in FV High time?
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          no_of_clk_pulses_in_fv_high_time <= 32'h0;
        end
      else if ( ( colour_bar_sel_i == LOW ) | ( start_colourbar_gen_req_f2 == LOW ) )
        begin
          no_of_clk_pulses_in_fv_high_time <= 32'h0;
        end
      else if (
                ( fv_counter_type == HIGH ) &
                ( pixel_counter   == image_width  - 1'b1 ) & //1'b1
                ( pixel_counter_type == HIGH ) &
                ( line_counter    == image_height - 1'b1 )
              )
        begin
          no_of_clk_pulses_in_fv_high_time <= fv_counter;
        end
    end

  generate
    if ( MODE_I == "FIXED_FPS" )
      begin
        // Declaration
        logic  [31:0] no_of_clk_pulses_in_fv;

        // How many number of clock cycles are in FV cycle? -> ((REF_CLK_PULSES_IN_S_I)/(fps))
        always_ff @ ( posedge clk )
          begin
            if ( ~reset_n )
              begin
                no_of_clk_pulses_in_fv <= 32'b0;
              end
            else
              begin

                case ( image_fps )

                  8'd5   : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_5_FPS;
                  
                  8'd10  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_10_FPS;

                  8'd15  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_15_FPS;

                  8'd30  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_30_FPS;

                  8'd35  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_35_FPS;

                  8'd40  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_40_FPS;

                  8'd45  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_45_FPS;

                  8'd50  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_50_FPS;

                  8'd55  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_55_FPS;

                  8'd58  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_58_FPS;

                  8'd60  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_60_FPS;

                  8'd65  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_65_FPS;

                  8'd75  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_75_FPS;

                  8'd90  : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_90_FPS;

                  8'd100 : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_100_FPS;

                  8'd110 : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_110_FPS;

                  8'd120 : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_120_FPS;

                  8'd125 : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_125_FPS;

                  8'd130 : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_130_FPS;

                  8'd135 : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_135_FPS;

                  8'd140 : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_140_FPS;

                  8'd145 : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_145_FPS;

                  8'd150 : no_of_clk_pulses_in_fv  <= FV_CLK_PULSES_150_FPS;

                  default : no_of_clk_pulses_in_fv <= FV_CLK_PULSES_60_FPS;

                endcase

              end
          end

        // How many number of clock cycles are in FV Low time?
        always_ff @ ( posedge clk )
          begin
            if ( ~reset_n )
              begin
                no_of_clk_pulses_in_fv_low_time <= 32'b0;
              end
            else
              begin
                no_of_clk_pulses_in_fv_low_time <= ( no_of_clk_pulses_in_fv - no_of_clk_pulses_in_fv_high_time );
              end
          end
      end
    else
      begin

        // How many number of clock cycles are in FV Low time?
        always_ff @ ( posedge clk )
          begin
            if ( ~reset_n )
              begin
                no_of_clk_pulses_in_fv_low_time <= 32'b0;
              end
            else
              begin
                no_of_clk_pulses_in_fv_low_time <= ( image_width + line_blanking_clk_pulses_i) * NO_OF_LINES_IN_FRAME_BLANKING_I;
              end
          end

      end
  endgenerate



//----------------------------------
//
// FV Counter Type
//
//----------------------------------

  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fv_counter_type <= LOW;
        end
      else if ( ( colour_bar_sel_i == LOW ) | ( start_colourbar_gen_req_f2 == LOW ) )
        begin
          fv_counter_type <= LOW;
        end
      else if ( ( fv_counter_type == HIGH ) &
                ( pixel_counter   == image_width  - 1'b1 ) & //1'b1
                ( pixel_counter_type == HIGH ) &
                ( line_counter    == image_height - 1'b1 )
              )
        begin
          fv_counter_type <= LOW;
        end
      else if ( ( fv_counter_type == LOW ) & ( fv_counter == no_of_clk_pulses_in_fv_low_time - 1'b1 ) )
        begin
          fv_counter_type <= HIGH;
        end
    end

//----------------------------------
//
// FV Counter
//
//----------------------------------

  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fv_counter <= 32'h0;
        end
      else if ( ( colour_bar_sel_i == LOW ) | ( start_colourbar_gen_req_f2 == LOW ) )
        begin
          fv_counter <= 32'h0;
        end
      else if ( pause_colourbar_gen_req_i == 1'b0 )
        begin
          if ( ( ( fv_counter_type == HIGH ) &
                 ( pixel_counter   == image_width  - 1'b1 ) & //1'b1
                 ( pixel_counter_type == HIGH ) &
                 ( line_counter    == image_height - 1'b1 )
               )   |
               ( ( fv_counter_type == LOW  ) & ( fv_counter == no_of_clk_pulses_in_fv_low_time - 1'b1  ) )
             )
            begin
              fv_counter <= 32'h0;
            end
          else
            begin
              fv_counter <= ( fv_counter + 1'b1 );
            end
        end
    end


//----------------------------------
//
// FV
//
//----------------------------------

  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fv_o <= 1'b0;
        end
      else if ( ( colour_bar_sel_i == LOW ) | ( start_colourbar_gen_req_f2 == LOW ) )
        begin
          fv_o <= 1'b0;
        end
      else if ( ( ( ( fv_counter_type == HIGH ) &
                    ( pixel_counter   == image_width  - 1'b1 ) & //1'b1
                    ( pixel_counter_type == HIGH ) &
                    ( line_counter    == image_height - 1'b1 )
                  )   |
                  ( ( fv_counter_type == LOW  ) & ( fv_counter == no_of_clk_pulses_in_fv_low_time - 1'b1  ) )
                ) & ( pause_colourbar_gen_req_i == 1'b0 )
              )
        begin
          fv_o <= ~fv_o;
        end
    end


//----------------------------------
//
// Colour Band Counter
//
//----------------------------------

  // Maximum value of colour band counter
  assign colour_band_counter_max_value = ( image_width >> 2'd3 );

  // Colour band counter
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          colour_band_counter <= 16'h0;
        end
      else if ( ~lv_o )
        begin
          colour_band_counter <= 16'h0;
        end
      else if ( pause_colourbar_gen_req_i == 1'b0 )
        begin
          if ( colour_band_counter == ( colour_band_counter_max_value - 1'b1 ) )//1'b1
            begin
              colour_band_counter <= 16'h0;
            end
          else
            begin
              colour_band_counter <= colour_band_counter + 1'b1; //1'b1;
            end
        end
    end


  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          colour_band <= 3'h0;
        end
      else if ( ~lv_o )
        begin
          colour_band <= 3'h0;
        end
      else if ( colour_band_counter == ( colour_band_counter_max_value - 2'd2 ) )
        begin
          colour_band <= colour_band + 1'b1;
        end
    end


  // assign colour_band_counter_full_o = ( colour_band_counter == colour_band_counter_max_value - 1);

//----------------------------------
//
// FV Rising edge pulse
//
//----------------------------------

  always_ff @ ( posedge clk )
    begin
      if( ~reset_n )
        begin
          fv_f1 <= 1'b0;
          fv_f2 <= 1'b0;
        end
      else
        begin
          fv_f1 <= fv_o;
          fv_f2 <= fv_f1;
        end
    end

  assign fv_ris = ( ( fv_f1 ) & ~( fv_f2 ) );

//----------------------------------
//
// 2 FFs delay for colorbar gen pulse
//
//----------------------------------

always_ff @ ( posedge clk )
  begin
    if( ~reset_n )
      begin
        start_colourbar_gen_pl_f1 <= 1'b0;
        start_colourbar_gen_pl_f2 <= 1'b0;
      end
    else
      begin
        start_colourbar_gen_pl_f1 <= start_colourbar_gen_pl;
        start_colourbar_gen_pl_f2 <= start_colourbar_gen_pl_f1;
      end
  end

  // Moving block width and height
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          moving_block_width  <= MOVING_BLOCK_START_WIDTH;
          moving_block_height <= MOVING_BLOCK_START_HEIGHT;
        end
      else if ( start_colourbar_gen_pl_f1 )
        begin
          moving_block_width   <= ( image_width  / MOVING_BLOCK_CONSTANT );
          moving_block_height  <= ( image_height / MOVING_BLOCK_CONSTANT );
        end
    end

//----------------------------------
//
// Updating Block Position
//
//----------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        x <= 16'd420;
        y <= 16'd0;
      end
    else if ( start_colourbar_gen_pl_f2 )
      begin
        x <= ( image_width  >> 1'b1 ) - moving_block_width;
        y <= 16'd0;
      end
    else if ( fv_ris )
      begin
        if ( forwards == 1'b1 )
          begin
            x <= x + ( MOVING_BLOCK_X_RATIO_CONSTANT*MOVING_BLOCK_SPEED );
            y <= y + ( MOVING_BLOCK_Y_RATIO_CONSTANT*MOVING_BLOCK_SPEED );
          end
        else if ( backwards == 1'b1 )
          begin
            x <= x - ( MOVING_BLOCK_X_RATIO_CONSTANT*MOVING_BLOCK_SPEED );
            y <= y + ( MOVING_BLOCK_Y_RATIO_CONSTANT*MOVING_BLOCK_SPEED );
          end
        else if ( bottoms == 1'b1 )
          begin
            x <= x + ( MOVING_BLOCK_X_RATIO_CONSTANT*MOVING_BLOCK_SPEED );
            y <= y - ( MOVING_BLOCK_Y_RATIO_CONSTANT*MOVING_BLOCK_SPEED );
          end
        else if ( tops == 1'b1 )
          begin
            x <= x - ( MOVING_BLOCK_X_RATIO_CONSTANT*MOVING_BLOCK_SPEED );
            y <= y - ( MOVING_BLOCK_Y_RATIO_CONSTANT*MOVING_BLOCK_SPEED );
          end
      end
  end

//----------------------------------
//
// To enable Moving Block
//
//----------------------------------

generate
  if ( MOVING_BLOCK_EN_I == "TRUE" )
    begin
      always_ff @ ( posedge clk )
        begin
         if ( ~reset_n )
           begin
             block_en <= 1'b0;
           end
         else if ( ~lv_o )
           begin
             block_en <= 1'b0;
           end
         else if ( ( line_counter >= y ) && ( line_counter <= ( y + moving_block_height ) ) )
           begin
             if ( ( pixel_counter >= x ) && ( pixel_counter <= ( x + moving_block_width ) ) )
               begin
                 block_en <= 1'b1;
               end
             else
               begin
                 block_en <= 1'b0;
               end
           end
         else
           begin
             block_en <= 1'b0;
           end
        end
    end
  else
    begin
      assign block_en = 1'b0;
    end
endgenerate

//------------------------------------------
//
// FSM to update the Moving Block Direction
//
//------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        block_cs <= IDLE;
      end
    else
      begin
        block_cs <= block_ns;
      end
  end


always_comb
  begin
    block_ns <= IDLE;
    unique case ( block_cs )
      IDLE:
        begin
          if( ( x < ( image_width - moving_block_width ) ) && ( y < ( image_height - moving_block_height ) ) )
            begin
              block_ns <= FORWARD;
            end
          else if( ( x >= ( image_width - moving_block_width ) ) && ( y < ( image_height - moving_block_height ) ) )
            begin
              block_ns <= BACKWARD;
            end
          else if( ( x < ( image_width - moving_block_width ) ) && ( y >= ( image_height - moving_block_height ) ) )
            begin
              block_ns <= BOTTOM;
            end
          else if( ( x >= ( image_width - moving_block_width ) ) && ( y >= ( image_height - moving_block_height ) ) )
            begin
              block_ns <= TOP;
            end
        end

      FORWARD:
        begin
          if( ( x < ( image_width - moving_block_width ) ) && ( y < ( image_height - moving_block_height ) ) )
            begin
              block_ns <= FORWARD;
            end
          else
            begin
              block_ns <= BACKWARD;
            end
        end

      BACKWARD:
        begin
          if( ( x > 0 /*moving_block_width*/ ) && ( y < ( image_height - moving_block_height ) ) )
            begin
              block_ns <= BACKWARD;
            end
          else
            begin
              block_ns <= TOP; //IDLE
            end
        end

      BOTTOM:
        begin
          if( ( x < ( image_width - moving_block_width ) ) && ( y > 0 /*moving_block_height*/ ) )
            begin
              block_ns <= BOTTOM;
            end
          else
            begin
              block_ns <= FORWARD; //TOP BACKWARD
            end
        end

      TOP:
        begin
          if( ( x > 0 /*moving_block_width*/ ) && ( y >= moving_block_height ) )
            begin
              block_ns <= TOP;
            end
          else
            begin
              block_ns <= BOTTOM;
            end
        end
    endcase
 end


always_comb
  begin
    forwards  <= 1'b0;
    backwards <= 1'b0;
    tops      <= 1'b0;
    bottoms   <= 1'b0;

    unique case ( block_cs )
      IDLE:
        begin

        end

      FORWARD:
        begin
         forwards <= 1'b1;
        end

      BACKWARD:
        begin
          backwards <= 1'b1;
        end

      BOTTOM:
        begin
          bottoms <= 1'b1;
        end

      TOP:
        begin
          tops <= 1'b1;
        end
    endcase
  end


  // Initial Pattern 
  function automatic logic [(DATA_WIDTH_I-1) : 0] init_pattern();
    logic [(DATA_WIDTH_I-1):0] value;
      for (int i = 0; i < NUM_BYTES; i = i+1 )
        begin
          value[i*8 +: 8] = 8'(i);
            end
      return value;
   endfunction
   

  // Increment Pattern 
  function automatic logic [(DATA_WIDTH_I-1) : 0] incr_pattern();
    logic [(DATA_WIDTH_I-1):0] value;
      for (int i = 0; i < NUM_BYTES; i = i+1 )
        begin
          value[i*8 +: 8] = 8'(NUM_BYTES);
            end
      return value;
   endfunction
   
   
   localparam [(DATA_WIDTH_I-1) : 0] INIT_VAL = init_pattern();
   
   localparam [(DATA_WIDTH_I-1) : 0] INCR_VAL = incr_pattern();
   
   // MSB byte wrap around   
   assign msb_byte_detect = ( incremental_data_pattern[(DATA_WIDTH_I-1) -: 8] == 8'hFF );


  // Incremental data pattern generation
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          incremental_data_pattern  <= INIT_VAL;
        end
      else if ( ( fv_o == 1'b0 ) | ( msb_byte_detect == 1'b1 ) )
        begin
          incremental_data_pattern  <= INIT_VAL;
        end
      else if ( lv_o & fv_o )
        begin
          incremental_data_pattern <= incremental_data_pattern + INCR_VAL;
        end
    end

//-----------------------------------------
//
// Colour Bar Data or Incremental Pattern
//
//-----------------------------------------

  // RGB or VYUY?
 always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          cb_white         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_WHITE}});
          cb_yellow        <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_YELLOW}});
          cb_blue          <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_BLUE}});
          cb_green         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_GREEN}});
          cb_pink          <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_PINK}});
          cb_red           <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_RED}});
          cb_violet        <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_VIOLET}});
          cb_black         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_BLACK}});
          moving_block_clr <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{MOVING_BLOCK_COLOR_VYUY_VALUE_I}});
        end
      else if ( ( image_pixel_width_i == 24 ) & ( rgb_mode_i == 1 ) )
        begin
          cb_white         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{RGB_WHITE[23:0]}});
          cb_yellow        <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{RGB_YELLOW[23:0]}});
          cb_blue          <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{RGB_BLUE[23:0]}});
          cb_green         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{RGB_GREEN[23:0]}});
          cb_pink          <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{RGB_PINK[23:0]}});
          cb_red           <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{RGB_RED[23:0]}});
          cb_violet        <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{RGB_VIOLET[23:0]}});
          cb_black         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{RGB_BLACK[23:0]}});
          moving_block_clr <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{MOVING_BLOCK_COLOR_RGB_VALUE_I[23:0]}});
        end
      else if ( ( image_pixel_width_i == 32 ) & ( rgb_mode_i == 1 ) )
        begin
          cb_white         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{8'hFF,RGB_WHITE[23:0]}});
          cb_yellow        <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{8'hFF,RGB_YELLOW[23:0]}});
          cb_blue          <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{8'hFF,RGB_BLUE[23:0]}});
          cb_green         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{8'hFF,RGB_GREEN[23:0]}});
          cb_pink          <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{8'hFF,RGB_PINK[23:0]}});
          cb_red           <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{8'hFF,RGB_RED[23:0]}});
          cb_violet        <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{8'hFF,RGB_VIOLET[23:0]}});
          cb_black         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{8'hFF,RGB_BLACK[23:0]}});
          moving_block_clr <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{8'hFF,MOVING_BLOCK_COLOR_RGB_VALUE_I[23:0]}});
        end
      else
        begin
          cb_white         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_WHITE}});
          cb_yellow        <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_YELLOW}});
          cb_blue          <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_BLUE}});
          cb_green         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_GREEN}});
          cb_pink          <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_PINK}});
          cb_red           <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_RED}});
          cb_violet        <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_VIOLET}});
          cb_black         <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{VYUY_BLACK}});
          moving_block_clr <= (DATA_WIDTH_I)'({DATA_REPEAT_FACTOR{MOVING_BLOCK_COLOR_VYUY_VALUE_I}});
        end
    end

  // Final data
  generate
    if ( INCREMENTAL_DATA_PATTERN == "FALSE" )
      begin
        if ( DATA_WIDTH_I == 8 ) // For 8 bit data width. Valid for only VYUY data
          begin
            always_ff @ ( posedge clk )
               begin
                 if ( ~reset_n )
                   begin
                    data_o <= VYUY_WHITE[7:0];
                   end
                 else if ( block_en == 1'b1 ) // Overwrite with Block
                   begin
                     unique case ( colour_band_counter[1:0] )

                       2'd0 : data_o <= MOVING_BLOCK_COLOR_VYUY_VALUE_I[15:8];
                       2'd1 : data_o <= MOVING_BLOCK_COLOR_VYUY_VALUE_I[7:0];
                       2'd2 : data_o <= MOVING_BLOCK_COLOR_VYUY_VALUE_I[31:24];
                       2'd3 : data_o <= MOVING_BLOCK_COLOR_VYUY_VALUE_I[23:16];

                     endcase
                   end
                 else
                   begin
                     case ( colour_band )

                       3'd0 :
                       begin

                         unique case ( colour_band_counter[1:0] )

                           2'd0 : data_o <= VYUY_WHITE[15:8];
                           2'd1 : data_o <= VYUY_WHITE[7:0];
                           2'd2 : data_o <= VYUY_WHITE[31:24];
                           2'd3 : data_o <= VYUY_WHITE[23:16];

                         endcase
                       end

                       3'd1 :
                       begin

                         unique case ( colour_band_counter[1:0] )

                           2'd0 : data_o <= VYUY_YELLOW[15:8];
                           2'd1 : data_o <= VYUY_YELLOW[7:0];
                           2'd2 : data_o <= VYUY_YELLOW[31:24];
                           2'd3 : data_o <= VYUY_YELLOW[23:16];

                         endcase
                       end

                       3'd2 :
                       begin

                         unique case ( colour_band_counter[1:0] )

                           2'd0 : data_o <= VYUY_BLUE[15:8];
                           2'd1 : data_o <= VYUY_BLUE[7:0];
                           2'd2 : data_o <= VYUY_BLUE[31:24];
                           2'd3 : data_o <= VYUY_BLUE[23:16];

                     endcase
                   end

                      3'd3 :
          begin

                         unique case ( colour_band_counter[1:0] )

                           2'd0 : data_o <= VYUY_GREEN[15:8];
                           2'd1 : data_o <= VYUY_GREEN[7:0];
                           2'd2 : data_o <= VYUY_GREEN[31:24];
                           2'd3 : data_o <= VYUY_GREEN[23:16];

                         endcase
                   end

                      3'd4 :
                   begin

                         unique case ( colour_band_counter[1:0] )

                           2'd0 : data_o <= VYUY_PINK[15:8];
                           2'd1 : data_o <= VYUY_PINK[7:0];
                           2'd2 : data_o <= VYUY_PINK[31:24];
                           2'd3 : data_o <= VYUY_PINK[23:16];

                         endcase
                       end

                      3'd5 :
                       begin

                         unique case ( colour_band_counter[1:0] )

                           2'd0 : data_o <= VYUY_RED[15:8];
                           2'd1 : data_o <= VYUY_RED[7:0];
                           2'd2 : data_o <= VYUY_RED[31:24];
                           2'd3 : data_o <= VYUY_RED[23:16];

                     endcase
                   end

                      3'd6 : //9e40d340
          begin

                         unique case ( colour_band_counter[1:0] )

                           2'd0 : data_o <= VYUY_VIOLET[15:8];
                           2'd1 : data_o <= VYUY_VIOLET[7:0];
                           2'd2 : data_o <= VYUY_VIOLET[31:24];
                           2'd3 : data_o <= VYUY_VIOLET[23:16];

                         endcase
                       end

                      3'd7 :
                       begin

                         unique case ( colour_band_counter[1:0] )

                           2'd0 : data_o <= VYUY_BLACK[15:8];
                           2'd1 : data_o <= VYUY_BLACK[7:0];
                           2'd2 : data_o <= VYUY_BLACK[31:24];
                           2'd3 : data_o <= VYUY_BLACK[23:16];

                         endcase
                       end

                     endcase
                   end
               end
          end
        // For 16 bit data width. Valid for only VYUY data
        else if ( DATA_WIDTH_I == 16 )
          begin
        // 16 bit colour bar generation
            always_ff @ ( posedge clk )
              begin
                if ( ~reset_n )
                  begin
                    data_o <= VYUY_WHITE[15:0]; // First 2 bytes are same as last
                  end
                 else if ( block_en == 1'b1 ) // Overwrite with Block
                   begin
                     data_o <= MOVING_BLOCK_COLOR_VYUY_VALUE_I[15:0];
                   end
                else
                  begin
                    unique case ( colour_band )

                      3'd0 : data_o <= VYUY_WHITE[15:0];

                      3'd1 :
                        begin
                          if (!colour_band_counter[0])
                            data_o <= VYUY_YELLOW[31:16];
                          else
                            data_o <= VYUY_YELLOW[15:0];
                        end

                      3'd2 :
                        begin
                          if (!colour_band_counter[0])
                            data_o <= VYUY_BLUE[31:16];
                          else
                            data_o <= VYUY_BLUE[15:0];
                        end

                      3'd3 :
                        begin
                          if (!colour_band_counter[0])
                            data_o <= VYUY_GREEN[31:16];
                          else
                            data_o <= VYUY_GREEN[15:0];
                        end

                      3'd4 :
                        begin
                          if (!colour_band_counter[0])
                            data_o <= VYUY_PINK[31:16];
                          else
                            data_o <= VYUY_PINK[15:0];
                        end

                      3'd5 :
                        begin
                          if (!colour_band_counter[0])
                            data_o <= VYUY_RED[31:16];
                          else
                            data_o <= VYUY_RED[15:0];
                        end

                      3'd6 :
                        begin
                          if (!colour_band_counter[0])
                            data_o <= VYUY_VIOLET[31:16];
                          else
                            data_o <= VYUY_VIOLET[15:0];
                        end

                      3'd7 : data_o <= VYUY_BLACK[15:0]; // First 2 bytes are same as last

                    endcase
                  end
              end
          end
        else
          begin
            // For 32/64/128/256 bit data width
            always_ff @ ( posedge clk )
              begin
                if ( ~reset_n )
                  begin
                    data_o <= cb_white;
                  end
                else if ( block_en == 1'b1 ) // Overwrite with Block
                  begin
                    data_o <= moving_block_clr;
                  end
                else
                  begin
                    case ( colour_band )

                      3'd0 : data_o <= cb_white;
                      3'd1 : data_o <= cb_yellow;
                      3'd2 : data_o <= cb_blue;
                      3'd3 : data_o <= cb_green;
                      3'd4 : data_o <= cb_pink;
                      3'd5 : data_o <= cb_red;
                      3'd6 : data_o <= cb_violet;
                      3'd7 : data_o <= cb_black;

                    endcase
                  end
              end
          end
      end

    else        // Incremental Pattern
      begin
        always_ff @ ( posedge clk )
          begin
            data_o <= incremental_data_pattern;
          end
      end

  endgenerate

endmodule
