//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fxn_slfifo_rx_master
// Target Devices: T120 and Ti180
//
// Description: This module acts as a read master of LVCMOS slave FIFO interface
//              of FX10 or FX20.
//
//////////////////////////////////////////////////////////////////////////////////

// Include the package file
`include "package/user_define_pkg.sv"

module fxn_slfifo_rx_master
  #
  (
   // Slave FIFO Data Width in Bits
   parameter DATA_WIDTH_IN_BITS_I = 32,

   // GPIF Master Mode: LVDS or LVCMOS
   parameter GPIF_MASTER_MODE_I = "LVCMOS_DDR",

   // Number of address bits
   parameter NO_OF_ADDRESS_BITS_I = 2
  )
 (
  input                clk,
  input                reset_n,

  // Outputs
  output logic         slf_m_rd_req_n_o,
  output logic         slf_m_cs_n_o,
  output logic         slf_m_oe_n_o,
  output logic         change_thread_addr_pl_o,
  // output logic         l_zlp_sent_o,
  output logic         fifo_reset_req_o,
  output logic         buffer_data_rd_completed_pl_o,
  output logic [(NO_OF_ADDRESS_BITS_I-1):0] slf_m_addr_o,
  output logic [(DATA_WIDTH_IN_BITS_I-1):0] fifo_wr_data_o,
  output logic         fifo_wr_req_o,

  // Inputs
  input                start_serving_device_pl_i,
  input                slf_m_par_flag_i,
  input                slf_m_full_flag_i,
  input                fifo_almost_full_i,
  // input                fifo_full_i,

  // Registers
  input                sel_reset_or_stop_stream_req_i,
  input                new_thread_addr_available_pl_i,
  input        [(DATA_WIDTH_IN_BITS_I-1):0] slf_m_rd_data_i,
  input        [(SEL_DEV_NUM_BITS-1):0]  sel_device_num_i,

  input common_reg_info_st_t common_reg_info_i,    // Common Register Information
  input dev_reg_info_st_t    sel_d_reg_info_st_i   // Device Specific Register Information

 );

// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // No of States
  localparam NO_OF_FSM_STATES = 8'd8;

  // Number of bytes in a transfer
  localparam NO_OF_BYTES_PER_XFER = DATA_WIDTH_IN_BITS_I / 8;

  // Thread switching delay in terms of clock cycles
  localparam NO_OF_THREAD_SWITCH_DELAY_CLOCKS = 4;

  // FSM States
  enum logic [(NO_OF_FSM_STATES-1):0] {

    IDLE                      = 8'h1,
    WAIT_BOTH_FLAGS_ASSERTED  = 8'h2,
    START_RX_DATA             = 8'h4,
    WAIT_DATA_READ            = 8'h8,
    WAIT_FULL_FLAG_DEASSERTED = 8'h10,
    IS_NEW_ADDR_REQUIRED      = 8'h20,
    INCR_THREAD_ADDR          = 8'h40,
    INFORM_FULL_BUFR_READ     = 8'h80

  } slf_rx_cs, slf_rx_ns;

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

logic [15:0] data_byte_counter;
logic [ 2:0] thread_sw_count;
logic        change_thread_addr_pl;
logic        inform_buffer_rd_pl;
logic        incr_thread_sw_count;
logic        slf_m_rd_req_n;
logic        slf_m_rd_req_n_f1;
logic        slf_m_rd_req_n_f2;
logic        slf_m_rd_req_n_f3;
logic        slf_m_rd_req_n_f4;
logic        slf_m_rd_data_valid;
logic        slf_m_cs_n;
logic        slf_m_oe_n;

// ------------------------------------------
//
// Main Data FSM
//
// ------------------------------------------

// Current State
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        slf_rx_cs <= IDLE;
      end
    else if ( sel_reset_or_stop_stream_req_i )
      begin
        slf_rx_cs <= IDLE;
      end
    else
      begin
        slf_rx_cs <= slf_rx_ns;
      end
  end

// Next State
always_comb
  begin
    case ( slf_rx_cs )

      // Wait until ready and partial flags are HIGH.
      IDLE :
        begin
          if ( start_serving_device_pl_i )
            begin
              slf_rx_ns <= WAIT_BOTH_FLAGS_ASSERTED;
            end
          else
            begin
              slf_rx_ns <= IDLE;
            end
        end

      // Wait until ready and partial flags are HIGH after
      // thread switching delay.
      WAIT_BOTH_FLAGS_ASSERTED :
        begin
          if ( ( slf_m_full_flag_i ) &
               ( slf_m_par_flag_i  ) &
               ( thread_sw_count == NO_OF_THREAD_SWITCH_DELAY_CLOCKS )
             )
            begin
              slf_rx_ns <= START_RX_DATA;
            end
          else
            begin
              slf_rx_ns <= WAIT_BOTH_FLAGS_ASSERTED;
            end
        end

      // Start reading data
      START_RX_DATA :
        begin
          if ( fifo_almost_full_i == 1'b0 )
            begin
              slf_rx_ns <= WAIT_DATA_READ;
            end
          else
            begin
              slf_rx_ns <= START_RX_DATA;
            end
        end

      // Wait until data bytes are sent.
      WAIT_DATA_READ :
        begin
          if ( ( ( data_byte_counter >= (sel_d_reg_info_st_i.buffer_size_info - NO_OF_BYTES_PER_XFER) ) & ( slf_m_rd_req_n == 1'b0 ) ) |
               ( slf_m_full_flag_i == 1'b0 )
             )
            begin
              slf_rx_ns <= WAIT_FULL_FLAG_DEASSERTED;
            end
          else
            begin
              slf_rx_ns <= WAIT_DATA_READ;
            end
        end

      // Wait until Full flag is de-asserted
      WAIT_FULL_FLAG_DEASSERTED :
        begin
          if ( slf_m_full_flag_i == 1'b0 )
            begin
              slf_rx_ns <= IS_NEW_ADDR_REQUIRED;
            end
          else
            begin
              slf_rx_ns <= WAIT_FULL_FLAG_DEASSERTED;
            end
        end

      // Does EP support multiple threads?
      IS_NEW_ADDR_REQUIRED :
        begin
          if ( sel_d_reg_info_st_i.active_thread == 2'd2 ) // Multiple threads for an EP
            begin
              slf_rx_ns <= INCR_THREAD_ADDR;
            end
          else
            begin
              slf_rx_ns <= INFORM_FULL_BUFR_READ;
            end
        end

      // Change to next thread
      INCR_THREAD_ADDR :
        begin
          slf_rx_ns <= INFORM_FULL_BUFR_READ;
        end

      // Inform that full buffer is read
      INFORM_FULL_BUFR_READ :
        begin
          slf_rx_ns <= IDLE;
        end

    endcase
  end


// Next State
always_comb
  begin

    change_thread_addr_pl <= 1'b0;
    inform_buffer_rd_pl   <= 1'b0;
    incr_thread_sw_count  <= 1'b0;
    slf_m_rd_req_n        <= 1'b1;
    slf_m_cs_n            <= 1'b1;
    slf_m_oe_n            <= 1'b1;

    case ( slf_rx_cs )

      // Wait until ready and partial flags are HIGH.
      IDLE :
        begin

        end

      // Wait until ready and partial flags are HIGH.
      WAIT_BOTH_FLAGS_ASSERTED :
        begin
          incr_thread_sw_count <= 1'b1;
          slf_m_cs_n           <= 1'b0;
          slf_m_oe_n           <= 1'b0;
        end

      // Start reading data
      START_RX_DATA :
        begin
          slf_m_cs_n <= 1'b0;
          slf_m_oe_n <= 1'b0;
        end

      // Wait until data bytes are sent.
      WAIT_DATA_READ :
        begin
          slf_m_rd_req_n <= ( ( fifo_almost_full_i == 1'b1 ) | ( slf_m_full_flag_i == 1'b0 ));
          slf_m_cs_n     <= 1'b0;
          slf_m_oe_n     <= 1'b0;
        end

      // Wait until Full flag is de-asserted
      WAIT_FULL_FLAG_DEASSERTED :
        begin
          slf_m_cs_n <= 1'b0;
          slf_m_oe_n <= 1'b0;
        end

      // Does EP support multiple threads?
      IS_NEW_ADDR_REQUIRED :
        begin
          slf_m_cs_n <= 1'b0;
          slf_m_oe_n <= 1'b0;
        end

      // Change to next thread
      INCR_THREAD_ADDR :
        begin
          change_thread_addr_pl <= 1'b1;
          slf_m_cs_n            <= 1'b0;
          slf_m_oe_n            <= 1'b0;
        end

      // Inform that full buffer is read
      INFORM_FULL_BUFR_READ :
        begin
          inform_buffer_rd_pl <= 1'b1;
          slf_m_cs_n          <= 1'b0;
          slf_m_oe_n          <= 1'b0;
        end

    endcase
  end


// ------------------------------------------
//
// Register Outputs
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        buffer_data_rd_completed_pl_o <= 1'b0;
        change_thread_addr_pl_o       <= 1'b0;
        slf_m_rd_req_n_o              <= 1'b1;
        slf_m_cs_n_o                  <= 1'b1;
        slf_m_oe_n_o                  <= 1'b1;
      end
    else
      begin
        buffer_data_rd_completed_pl_o <= inform_buffer_rd_pl;
        change_thread_addr_pl_o       <= change_thread_addr_pl;
        slf_m_rd_req_n_o              <= slf_m_rd_req_n;
        slf_m_cs_n_o                  <= slf_m_cs_n;
        slf_m_oe_n_o                  <= slf_m_oe_n;
      end
  end

// ------------------------------------------
//
// Read Data Valid from FX10
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        slf_m_rd_req_n_f1 <= 1'b0;
        slf_m_rd_req_n_f2 <= 1'b0;
        slf_m_rd_req_n_f3 <= 1'b0;
        slf_m_rd_req_n_f4 <= 1'b0;
      end
    else
      begin
        slf_m_rd_req_n_f1 <= slf_m_rd_req_n_o;
        slf_m_rd_req_n_f2 <= slf_m_rd_req_n_f1;
        slf_m_rd_req_n_f3 <= slf_m_rd_req_n_f2;
        slf_m_rd_req_n_f4 <= slf_m_rd_req_n_f2;
      end
  end

// Data Valid
assign slf_m_rd_data_valid = slf_m_rd_req_n_f4;

// ------------------------------------------
//
// Thread Address
//
// ------------------------------------------

// Thread address
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        slf_m_addr_o <= 2'd0;
      end
    else
      begin
        slf_m_addr_o <= sel_d_reg_info_st_i.thread_addr;
      end
  end

// ------------------------------------------
//
// Thread Address Switching Delay
//
// ------------------------------------------

// FX10 requires a 3 or 4 clock cycles to assert FLAGA
// in response to thread address.

// Here, when "start_serving_device_pl_i" is HIGH, next
// clock, new address is available on address bus.
// Hence, in "WAIT_BOTH_FLAGS_ASSERTED" state, FSM waits
// for 4 or 5 clock cycles to make sure that flag status
// are correctly sampled.
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        thread_sw_count <= 3'd0;
      end
    else if ( incr_thread_sw_count == 1'b0 )
      begin
        thread_sw_count <= 3'd0;
      end
    else if ( thread_sw_count == NO_OF_THREAD_SWITCH_DELAY_CLOCKS )
      begin
        thread_sw_count <= thread_sw_count;
      end
    else
      begin
        thread_sw_count <= thread_sw_count + 1'b1;
      end
  end


// ------------------------------------------
//
// FIFO Write Request and Data
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fifo_wr_req_o  <= 1'b0;
        fifo_wr_data_o <= '0;
      end
    else
      begin
        fifo_wr_req_o  <= slf_m_rd_data_valid;
        fifo_wr_data_o <= slf_m_rd_data_i;
      end
  end

// ------------------------------------------
//
// Data Counter
//
// ------------------------------------------

// Read data counter
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        data_byte_counter <= 16'd0;
      end
    else if ( ( ( data_byte_counter >= (sel_d_reg_info_st_i.buffer_size_info - NO_OF_BYTES_PER_XFER) ) &
                ( slf_m_rd_req_n == 1'b0 ) ) |
                ( start_serving_device_pl_i )
            )
      begin
        data_byte_counter <= 16'd0;
      end
    else if ( slf_m_rd_req_n == 1'b0 )
      begin
        data_byte_counter <= data_byte_counter + NO_OF_BYTES_PER_XFER;
      end
  end

logic [15:0] rd_counter;
// counter
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        rd_counter <= 16'd0;
      end
    else if ( slf_m_full_flag_i == 1'b0 )
      begin
        rd_counter <= 16'd0;
      end
    else if ( slf_m_rd_req_n == 1'b0 )
      begin
        rd_counter <= rd_counter + 1'b1;
      end
  end
























endmodule