//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    frame_manager_fsm
// Target Devices: All
//
// Description: On power up, this module trains FX10/20 LVDS PHY and link. It serves
//              the connected devices in a round robin manner based on Active
//              Device map. Here, device means peripheral link connected with FPGA
//              from which FPGA needs to receive data and transmit to FX10/20. If
//              single device supports audio and video both, it is treated as
//              different devices.
//
//              Low power modes are not supported as of now.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module frame_manager_fsm
  #
  (
   // Address to be managed by FPGA or not
   parameter ADDR_MANAGED_BY_FPGA_I = "TRUE",

   // No. of devices/ FIFOs needed
   parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
   parameter SEL_DEV_NUM_BITS_I = 3


  )
 (
  input               clk,
  input               reset_n,

  // Outputs
  output logic        tx_thread_init_seq_pl_o,
  output logic        tx_frame_header_info_pl_o,
  output logic        tx_data_pkt_pl_o,
  output logic        tx_frame_end_seq_pl_o,
  output logic        full_frame_sent_pl_o,
  output logic        data_pkt_sent_pl_o,
  output logic        slfifo_reset_req_o,
  output logic [ 7:0] fm_ctrl_byte_o,
  output logic        fm_ctrl_byte_valid_o,

  // Inputs
  input               init_thread_seq_completed_pl_i,        // From Thread Initialization Module
  input               start_serving_device_pl_i,             // From Device Selection Module
  input               frame_header_info_sent_pl_i,
  input               frame_data_sent_pl_i,
  input               data_packet_sent_pl_i,
  input               frame_end_seq_sent_pl_i,
  input               fxn_buffer_ready_i,
  input               slfifo_almost_empty_i,

  input        [(NO_OF_SUPPORTED_DEV_I-1):0][31:0] no_of_frame_bytes_yet_to_be_sent_i,

  // From Device Selection FSM
  input        [(SEL_DEV_NUM_BITS_I-1):0] sel_device_num_i,

  // Registers
  input               sel_d_reset_or_stop_stream_req_i,
  input        [31:0] sel_d_frame_size_in_bytes_i,

  input common_reg_info_st_t common_reg_info_i,
  input dev_reg_info_st_t    sel_d_reg_info_st_i

 );

// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // Parity bit initial value
  localparam [0:0] PARITY_BIT = 1'b0;

  // LSbit of Control Byte
  localparam [0:0] CONTROL_BYTE_LS_BIT = 1'b1;

  // IDLE Control Byte
  localparam [7:0] IDLE_CONTROL_BYTE = 8'd1;

  // Set Thread Address
  localparam [3:0] THREAD_ADDR_CONTROL_BYTE = 4'b0001;

  // Set Socket Address
  localparam [2:0] SOCKET_ADDR_CONTROL_BYTE = 3'b001;

  // Adress to FLAGA assertion delay
  // Why 10 clocks?
  // After sending thread and socket address from
  // this FSM, it takes around 4 clocks to be on
  // control lane. And after that it may take 3
  // clocks to update FLAGA status. For safer side,
  // here, it is taken 10.
  localparam ADDR_TO_FLAGA_DELAY_CLK = 50;

  // No of States
  localparam NO_OF_FSM_STATES = 8'd14;

  enum logic [(NO_OF_FSM_STATES-1):0] {
    IDLE                           = 14'h1,
    IS_SEL_DEV_ALREADY_SERVED      = 14'h2,
    SET_THREAD_ADDR                = 14'h4,
    SET_SOCKET_ADDR                = 14'h8,
    WAIT_BUFFER_AVAILABLE          = 14'h10,
    INIT_THREAD_SEQ                = 14'h20,
    WAIT_INIT_THREAD_SEQ_COMPLETED = 14'h40,
    TX_FRAME_HEADER_INFO           = 14'h80,
    WAIT_FRAME_HEADER_INFO_SENT    = 14'h100,
    TX_DATA_PKT                    = 14'h200,
    WAIT_DATA_PKT_SENT             = 14'h400,
    TX_FRAME_END_SEQ               = 14'h800,
    WAIT_FRAME_END_SEQ_SENT        = 14'h1000,
    FULL_FRAME_COMPLETED           = 14'h2000
  } fr_m_cs, fr_m_ns;

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic        skip_thread_init_seq;
  logic        skip_frame_header_info;
  logic        skip_frame_end_seq;
  logic [ 7:0] init_dev_map;
  logic [ 7:0] flaga_sample_count;
  logic        tx_thread_init_seq_pl;
  logic        tx_frame_header_info_pl;
  logic        tx_data_pkt_pl;
  logic        tx_frame_end_seq_pl;
  logic        full_frame_sent_pl;
  logic        data_pkt_sent_pl;
  logic        slfifo_reset_req;
  logic        tx_thead_addr_pl;
  logic        tx_socket_addr_pl;
  logic        incr_flaga_sample_count;
  logic [ 3:0] bit_counter;

// ------------------------------------------
//
// FSM
//
// ------------------------------------------

// Current State
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fr_m_cs <= IDLE;
      end
    else if ( sel_d_reset_or_stop_stream_req_i )
      begin
        fr_m_cs <= IDLE;
      end
    else
      begin
        fr_m_cs <= fr_m_ns;
      end
  end

// Next State
always_comb
  begin
   fr_m_ns <= IDLE;
    unique case ( fr_m_cs )

      // Wait until Device Selection FSM informs to start serving
      IDLE :
        begin
          if ( /* ( lvds_phy_n_link_training_done == 1'b1 ) & */
               ( start_serving_device_pl_i == 1'b1 )
             )
            begin
              fr_m_ns <= IS_SEL_DEV_ALREADY_SERVED;
            end
          else
            begin
              fr_m_ns <= IDLE;
            end
        end

      // If selected device is already initialized,
      // skip thread initialization sequence.
      IS_SEL_DEV_ALREADY_SERVED :
        begin
          if ( init_dev_map[sel_device_num_i] == 1'b1 )
            begin 
                  fr_m_ns <= SET_THREAD_ADDR;
            end
          else
            begin
              fr_m_ns <= INIT_THREAD_SEQ;
            end
        end

      // Send thread address for selected device
      SET_THREAD_ADDR :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          fr_m_ns <= SET_SOCKET_ADDR;
        end
          else
            begin
              fr_m_ns <= SET_THREAD_ADDR;
            end
        end

      // Initialize socket address
      // No need to wait until READY flag is de-asserted
      // as FW is intializing GPIF SM that's why READY flag is toggling
      SET_SOCKET_ADDR :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          fr_m_ns <= WAIT_BUFFER_AVAILABLE;
        end
          else
            begin
              fr_m_ns <= SET_SOCKET_ADDR;
            end
        end

      // Wait for "ADDR_TO_FLAGA_DELAY_CLK" clocks to sample FLAGA
      WAIT_BUFFER_AVAILABLE :
        begin
          if ( flaga_sample_count == ADDR_TO_FLAGA_DELAY_CLK )
            begin
              if ( fxn_buffer_ready_i & !slfifo_almost_empty_i )
                begin
              fr_m_ns <= TX_FRAME_HEADER_INFO;
            end
              else // No need to serve selected device. Move to next device.
                begin
                  fr_m_ns <= FULL_FRAME_COMPLETED;
                end
            end
          else
            begin
              fr_m_ns <= WAIT_BUFFER_AVAILABLE;
            end
        end

      // Initialize thread/socket address and parameters.
      INIT_THREAD_SEQ :
        begin
          if ( skip_thread_init_seq )
            begin
              fr_m_ns <= TX_FRAME_HEADER_INFO;
            end
          else
            begin
              fr_m_ns <= WAIT_INIT_THREAD_SEQ_COMPLETED;
            end
        end

      // Wait until thread initialization is completed.
      WAIT_INIT_THREAD_SEQ_COMPLETED :
        begin
          if ( init_thread_seq_completed_pl_i == 1'b1 )
            begin
              fr_m_ns <= TX_FRAME_HEADER_INFO;
            end
          else
            begin
              fr_m_ns <= WAIT_INIT_THREAD_SEQ_COMPLETED;
            end
        end

      // Transmit frame header information.
      TX_FRAME_HEADER_INFO :
        begin
          if ( skip_frame_header_info )
            begin
              fr_m_ns <= TX_DATA_PKT;
            end
          else
            begin
              fr_m_ns <= WAIT_FRAME_HEADER_INFO_SENT;
            end
        end

      // Wait until frame header information is sent.
      WAIT_FRAME_HEADER_INFO_SENT :
        begin
          if ( frame_header_info_sent_pl_i == 1'b1 )
            begin
              fr_m_ns <= TX_DATA_PKT;
            end
          else
            begin
              fr_m_ns <= WAIT_FRAME_HEADER_INFO_SENT;
            end
        end

      // Transmit data packets
      TX_DATA_PKT :
        begin
          fr_m_ns <= WAIT_DATA_PKT_SENT;
        end

      // Wait until full frame is sent
      WAIT_DATA_PKT_SENT :
        begin
          if ( frame_data_sent_pl_i )
            begin
              fr_m_ns <= TX_FRAME_END_SEQ;
            end
          else if ( data_packet_sent_pl_i )
            begin
              fr_m_ns <= FULL_FRAME_COMPLETED;
            end
          else
            begin
              fr_m_ns <= WAIT_DATA_PKT_SENT;
            end
        end

      // Transmit frame end sequence
      TX_FRAME_END_SEQ :
        begin
          if ( skip_frame_end_seq == 1'b1 )
            begin
              fr_m_ns <= FULL_FRAME_COMPLETED;
            end
          else
            begin
              fr_m_ns <= WAIT_FRAME_END_SEQ_SENT;
            end
        end

      // Wait until frame end sequence is sent
      WAIT_FRAME_END_SEQ_SENT :
        begin
          if ( frame_end_seq_sent_pl_i == 1'b1 )
            begin
              fr_m_ns <= FULL_FRAME_COMPLETED;
            end
          else
            begin
              fr_m_ns <= WAIT_FRAME_END_SEQ_SENT;
            end
        end

      // Current device is served. Move to next device.
      FULL_FRAME_COMPLETED :
        begin
          fr_m_ns <= IDLE;
        end

    endcase
  end


// Next State Signals
always_comb
  begin

    tx_thread_init_seq_pl   <= 1'b0;
    tx_frame_header_info_pl <= 1'b0;
    tx_data_pkt_pl          <= 1'b0;
    tx_frame_end_seq_pl     <= 1'b0;
    full_frame_sent_pl      <= 1'b0;
    slfifo_reset_req        <= 1'b0;
    data_pkt_sent_pl        <= 1'b0;
    tx_thead_addr_pl        <= 1'b0;
    tx_socket_addr_pl       <= 1'b0;
    incr_flaga_sample_count <= 1'b0;

    unique case ( fr_m_cs )

      // Wait until LVDS PHY and link is trained.
      IDLE :
        begin

        end

      // If selected device is already initialized,
      // skip thread initialization sequence.
      IS_SEL_DEV_ALREADY_SERVED :
        begin

        end

      // Initialize thread address
      SET_THREAD_ADDR :
        begin
          tx_thead_addr_pl <= (bit_counter == 1'b0);
        end

      // Initialize socket address
      SET_SOCKET_ADDR :
        begin
          tx_socket_addr_pl <= (bit_counter == 1'b0);
        end

      // Wait for "ADDR_TO_FLAGA_DELAY_CLK" clocks to sample FLAGA
      WAIT_BUFFER_AVAILABLE :
        begin
          incr_flaga_sample_count <= 1'b1;
        end

      // Initialize thread/socket address and parameters.
      INIT_THREAD_SEQ :
        begin
          tx_thread_init_seq_pl <= ~skip_thread_init_seq;
        end

      // Wait until thread initialization is completed.
      WAIT_INIT_THREAD_SEQ_COMPLETED :
        begin

        end

      // Transmit frame header information.
      TX_FRAME_HEADER_INFO :
        begin
          tx_frame_header_info_pl <= ~skip_frame_header_info;
        end

      // Wait until frame header information is sent.
      WAIT_FRAME_HEADER_INFO_SENT :
        begin

        end

      // Transmit data packets
      TX_DATA_PKT :
        begin
          tx_data_pkt_pl <= 1'b1;
        end

      // Wait until full frame is sent
      WAIT_DATA_PKT_SENT :
        begin

        end

      // Transmit frame end sequence
      TX_FRAME_END_SEQ :
        begin
          tx_frame_end_seq_pl <= ~skip_frame_end_seq;
          slfifo_reset_req    <= 1'b1;
        end

      // Wait until frame end sequence is sent
      WAIT_FRAME_END_SEQ_SENT :
        begin
          slfifo_reset_req    <= 1'b1;
        end

      // Current device is served. Move to next device.
      FULL_FRAME_COMPLETED :
        begin
          full_frame_sent_pl <= ( no_of_frame_bytes_yet_to_be_sent_i[sel_device_num_i] == sel_d_frame_size_in_bytes_i );
          data_pkt_sent_pl   <= ( no_of_frame_bytes_yet_to_be_sent_i[sel_device_num_i] < sel_d_frame_size_in_bytes_i );
          slfifo_reset_req   <= 1'b1;
        end

    endcase
  end

// ------------------------------------------
//
// Register Outputs
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        tx_thread_init_seq_pl_o   <= 1'b0;
        tx_frame_header_info_pl_o <= 1'b0;
        tx_data_pkt_pl_o          <= 3'd0;
        tx_frame_end_seq_pl_o     <= 1'b0;
        full_frame_sent_pl_o      <= 1'b0;
        slfifo_reset_req_o        <= 1'b0;
      end
    else
      begin
        tx_thread_init_seq_pl_o   <= tx_thread_init_seq_pl;
        tx_frame_header_info_pl_o <= tx_frame_header_info_pl;
        tx_data_pkt_pl_o          <= tx_data_pkt_pl;
        tx_frame_end_seq_pl_o     <= tx_frame_end_seq_pl;
        full_frame_sent_pl_o      <= full_frame_sent_pl;
        data_pkt_sent_pl_o        <= data_pkt_sent_pl;
        slfifo_reset_req_o        <= slfifo_reset_req;
      end
  end

// ----------------------------------------------
//
// Wait before sampling FLAGA
//
// ----------------------------------------------

// FLAGA may take 3 or 4 clocks to get updated
// once new address is available. Here, after
// 10 clock cycles, FLAGA will be sampled.
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        flaga_sample_count <= 8'd0;
      end
    else if ( incr_flaga_sample_count == 1'b0 )
      begin
        flaga_sample_count <= 8'd0;
      end
    else
      begin
        flaga_sample_count <= flaga_sample_count + 1'b1;
      end
  end

// ------------------------------------------
//
// Is training completed?
//
// ------------------------------------------

// always_ff @ ( posedge clk )
//   begin
//     if ( !reset_n )
//       begin
//         lvds_phy_n_link_training_done <= 1'b0;
//       end
//     else
//       begin
//         lvds_phy_n_link_training_done <= (
//                                            fxn_rx_p0_link_training_completed_i |
//                                            fxn_rx_p1_link_training_completed_i |
//                                            fxn_lvds_phy_n_link_training_done_i
//                                          );
//       end
//   end

// ---------------------------------------------------
//
// Whether to skip thread initialization or not
//
// ---------------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        skip_thread_init_seq <= 1'b0;
      end
    else
      begin
        skip_thread_init_seq <= (
                                 ( ADDR_MANAGED_BY_FPGA_I == "FALSE" ) &
                                 ( sel_d_reg_info_st_i.c_n_crc_info[1:0] == 2'd0 ) &
                                 ( common_reg_info_i.tx_header_info_as_metadata == 1'b0 ) &
                                 ( sel_d_reg_info_st_i.c_n_crc_info[2] == 1'b0 )
                                );
      end
  end


// ---------------------------------------------------
//
// Whether to skip frame header or not
//
// ---------------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        skip_frame_header_info <= 1'b0;
      end
    else
      begin // Add logic to skip frame header after transmitting 1 packet
        skip_frame_header_info <= (
                                   ( ( common_reg_info_i.tx_header_info_as_metadata == 1'b0 ) & ( sel_d_reg_info_st_i.flag_info == 1'd0) ) |
                                   ( no_of_frame_bytes_yet_to_be_sent_i[sel_device_num_i] < sel_d_frame_size_in_bytes_i )
                                  );
      end
  end


// ---------------------------------------------------
//
// Whether to skip frame end sequence or not
//
// ---------------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        skip_frame_end_seq <= 1'b0;
      end
    else
      begin  // add logic to skip frame end seq after sending 1 packet
        skip_frame_end_seq <= (
                               ( sel_d_reg_info_st_i.c_n_crc_info[1:0] == 2'd0 ) &
                               ( sel_d_reg_info_st_i.flag_info == 4'd0 )
                              );
      end
  end

// ---------------------------------------------------
//
// Is device previously served or not?
//
// ---------------------------------------------------

// Initialized device map
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        init_dev_map <= 8'h0;
      end
    else if ( sel_d_reset_or_stop_stream_req_i )
      begin
        init_dev_map[sel_device_num_i] <= 1'b0;
      end
    else if ( init_thread_seq_completed_pl_i )
      begin
        init_dev_map[sel_device_num_i] <= 1'b1;
      end
  end


// ------------------------------------------
//
// Control Byte and Valid Signal
//
// ------------------------------------------

// Control Byte
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fm_ctrl_byte_o <= 8'd0;
      end
    else
      begin
        case ( 1'b1 ) // Parallel case. All conditions are mutually exclusive.

          tx_thead_addr_pl  : fm_ctrl_byte_o <= { PARITY_BIT, THREAD_ADDR_CONTROL_BYTE, sel_d_reg_info_st_i.thread_addr, CONTROL_BYTE_LS_BIT };

          tx_socket_addr_pl : fm_ctrl_byte_o <= { PARITY_BIT, SOCKET_ADDR_CONTROL_BYTE, sel_d_reg_info_st_i.socket_addr, CONTROL_BYTE_LS_BIT };

          default           : fm_ctrl_byte_o <= IDLE_CONTROL_BYTE;

        endcase
      end
  end

// Control Byte Valid
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fm_ctrl_byte_valid_o <= 1'b0;
      end
    else
      begin
        fm_ctrl_byte_valid_o <= ( tx_thead_addr_pl | tx_socket_addr_pl );
      end
  end

// Bit Counter
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        bit_counter <= 3'd0;
      end
    else if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
      begin
        bit_counter <= 3'd0;
      end
    else if ( ( tx_thead_addr_pl | tx_socket_addr_pl ) |
              ( bit_counter != 1'b0 )
            )
      begin
        bit_counter <= bit_counter + 1'b1;
      end
  end

endmodule