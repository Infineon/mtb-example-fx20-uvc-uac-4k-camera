//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fxn_lvds_tx_wrapper
// Target Devices: All
//
// Description: This is a wrapper which includes following modules,
//
//                  1. LVDS TX IP Top
//                  2. I2C Slave Register
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module fxn_lvds_tx_wrapper
  #
  (
   // Address to be managed by FPGA or not
   parameter ADDR_MANAGED_BY_FPGA_I = "TRUE",

   // Clock Value
   parameter GPIF_M_CLK_VALUE_I = 75_000_000,

   // GPIF Master Mode: LVDS or LVCMOS
   parameter GPIF_MASTER_MODE_I = "LVDS",

   // LVDS PHY Training Interval in micro seconds
   parameter LVDS_PHY_TS_TIME_IN_US_I = 50,

   // Gear Ratio for LVDS
   parameter LVDS_TX_GEAR_RATIO_I = 4'd8,

   // LVDS Data Lanes
   parameter TOTAL_DATA_LANES_I = 16,

   // Active LVDS Data Lane Mask MSBit
   parameter ACTIVE_LVDS_DATA_LANE_MASK_MSB_I = 15,

   // Active LVDS Data Lane Mask LSBit
   parameter ACTIVE_LVDS_DATA_LANE_MASK_LSB_I = 0,

   // FPGA Serializer needs LSBit first and FX10 needs MSBit first
   parameter TX_SERIALIZER_LSB_FIRST_I = 1,

   // No. of devices/ FIFOs needed
   parameter NO_OF_SUPPORTED_DEV_I = 8,

   // No. of devices/ FIFOs needed
   parameter NO_OF_SUPPORTED_DEV_BY_EACH_AXI_I = 4,

   // Sel device num Data Width in Bits
   parameter SEL_DEV_NUM_BITS_I = 3,

   // No. of fxn master I2C
   parameter NO_OF_FXN_MASTER_I2C_I = 1,

   // No. of devices supported by fxn master I2C bus
   parameter NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I = 4,

   // No. of devices supported by each fxn master I2C bus
   parameter NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C_I = 2,

   // I2C Slave Address
   parameter [6:0] I2C_SLAVE_ADDR_I = 7'b000_1101

  )
  (
   input              clk,
   input              reset_n,

   // Outputs
   output             tx_eop_control_byte_pl_n_o,
   output     [(SEL_DEV_NUM_BITS_I-1):0] sel_device_num_o,
   output             l_zlp_sent_o,
   output             full_buffer_sent_o,
   output             wait_for_new_buffer_o,
   output             fxn_l3_lp_mode_en_o,
   output             fxn_gpif_m_wr_data_oe_o,
   output             fxn_gpif_m_ctrl_data_oe_o,
   output             fxn_gpif_m_clk_oe_o,
   output             fxn_gpif_m_wr_data_rst_n_o,
   output             fxn_gpif_m_ctrl_data_rst_n_o,
   output             fxn_gpif_m_clk_rst_n_o,
   output             sel_d_reset_or_stop_stream_req_o,
   output     [(LVDS_TX_GEAR_RATIO_I-1):0] ctrl_byte_o,
   output     [15:0][(LVDS_TX_GEAR_RATIO_I-1):0]  wr_data_o,
   output slfifo_ctrl_req_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] slfifo_ctrl_req_st_arr_o,
   output dev_reg_info_st_t       sel_d_reg_info_st_o,
   output dev_reg_info_st_t    [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_o,

   output i2c_bus_out_st_t     [(NO_OF_FXN_MASTER_I2C_I-1):0] i2c_bus_out_st_arr_o,
   output cam_i2c_bus_out_st_t [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I-1):0] cam_i2c_bus_out_st_arr_o,
   output common_reg_info_st_t        common_reg_info_o,



   // Inputs
   input              fxn_lvds_rx_link_ready_i,
//   input              enter_l1_mode_i,
//   input              enter_l3_mode_i,
//   input              exit_l1_mode_i,
//   input              exit_l3_mode_i,
   input              fxn_buffer_ready_i,
   input              cam_config_done_i,

   input              ddr_ctrl_data_path_idle_i,
   input              ddr_ctrl_cmd_queue_almost_full_i,
   input              ddr_ctrl_busy_i,
   input              ddr_cfg_done_i,
   input              sw_i,


   input  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [14:0] mipi_status_reg_i,
   input  [(NO_OF_SUPPORTED_DEV_I-1):0] vsync_i,
   input  [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_wr_completed_i,
   input  [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_rd_completed_i,
   input  [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_empty_i,
   input  [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_full_i,

   input  slfifo_data_nd_status_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] slfifo_data_nd_status_st_arr_i,
   input i2c_bus_in_st_t     [(NO_OF_FXN_MASTER_I2C_I-1):0] i2c_bus_in_st_arr_i,
   input cam_i2c_bus_in_st_t [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I-1):0] cam_i2c_bus_in_st_arr_i
  );

// --------------------------
//
// Local Variables
//
// --------------------------
// Type Defined
// common_reg_info_st_t common_reg_info;

// logic                            sel_d_reset_or_stop_stream_req;
logic                            change_thread_addr_pl;
logic                            new_thread_addr_available_pl;

// --------------------------
//
// LVDS TX IP
//
// --------------------------

fxn_lvds_tx_top
  #
  (
   // Parameters
   .ADDR_MANAGED_BY_FPGA_I                (ADDR_MANAGED_BY_FPGA_I),
   .GPIF_M_CLK_VALUE_I                    (GPIF_M_CLK_VALUE_I),
   .GPIF_MASTER_MODE_I                    (GPIF_MASTER_MODE_I),
   .LVDS_PHY_TS_TIME_IN_US_I              (LVDS_PHY_TS_TIME_IN_US_I),
   .LVDS_TX_GEAR_RATIO_I                  (LVDS_TX_GEAR_RATIO_I),
   .TOTAL_DATA_LANES_I                    (TOTAL_DATA_LANES_I),
   .ACTIVE_LVDS_DATA_LANE_MASK_MSB_I      (ACTIVE_LVDS_DATA_LANE_MASK_MSB_I),
   .ACTIVE_LVDS_DATA_LANE_MASK_LSB_I      (ACTIVE_LVDS_DATA_LANE_MASK_LSB_I),
   .TX_SERIALIZER_LSB_FIRST_I             (TX_SERIALIZER_LSB_FIRST_I),
   .NO_OF_SUPPORTED_DEV_I                 (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I                    (SEL_DEV_NUM_BITS_I)
  )
  fltt
    (
     // Outputs
     .change_thread_addr_pl_o              (change_thread_addr_pl),
     .tx_eop_control_byte_pl_n_o           (tx_eop_control_byte_pl_n_o), // Active low PKTEND
     .sel_device_num_o                     (sel_device_num_o),
     .sel_d_reset_or_stop_stream_req_o     (sel_d_reset_or_stop_stream_req_o),
     .ctrl_byte_o                          (ctrl_byte_o),
     .wr_data_o                            (wr_data_o),
     .l_zlp_sent_o                         (l_zlp_sent_o),
     .full_buffer_sent_o                   (full_buffer_sent_o),
     .wait_for_new_buffer_o                (wait_for_new_buffer_o),
     .fxn_l3_lp_mode_en_o                  (fxn_l3_lp_mode_en_o),
     .fxn_gpif_m_wr_data_oe_o              (fxn_gpif_m_wr_data_oe_o),
     .fxn_gpif_m_ctrl_data_oe_o            (fxn_gpif_m_ctrl_data_oe_o),
     .fxn_gpif_m_clk_oe_o                  (fxn_gpif_m_clk_oe_o),
     .fxn_gpif_m_wr_data_rst_n_o           (fxn_gpif_m_wr_data_rst_n_o),
     .fxn_gpif_m_ctrl_data_rst_n_o         (fxn_gpif_m_ctrl_data_rst_n_o),
     .fxn_gpif_m_clk_rst_n_o               (fxn_gpif_m_clk_rst_n_o),

     // Inputs
     .clk                                  (clk),
     .reset_n                              (reset_n),
     .fxn_lvds_rx_link_ready_i             (fxn_lvds_rx_link_ready_i),
//     .enter_l1_mode_i                      (enter_l1_mode_i),
//     .enter_l3_mode_i                      (enter_l3_mode_i),
//     .exit_l1_mode_i                       (exit_l1_mode_i),
//     .exit_l3_mode_i                       (exit_l3_mode_i),
     .fxn_buffer_ready_i                   (fxn_buffer_ready_i),
     .cam_config_done_i                    (cam_config_done_i),
     .new_thread_addr_available_pl_i       (new_thread_addr_available_pl),
     .vsync_i                              (vsync_i[(NO_OF_SUPPORTED_DEV_I-1):0]),
     .sw_i                                 (sw_i),
     .common_reg_info_i                    (common_reg_info_o),
     .dev_reg_info_st_arr_i                (dev_reg_info_st_arr_o[(NO_OF_SUPPORTED_DEV_I-1):0]),
     .slfifo_data_nd_status_st_arr_i       (slfifo_data_nd_status_st_arr_i),
     .slfifo_ctrl_req_st_arr_o             (slfifo_ctrl_req_st_arr_o),
     .sel_d_reg_info_st_o                  (sel_d_reg_info_st_o)
    );

// --------------------------
//
// I2C Register Interface
//
// --------------------------

// Currently only one master FXn I2c is enabled and it can handle max 4 different cameras
// All should have different slave address.

fxn_i2c_reg_intr
  #
  (
   // Parameters
   .I2C_SLAVE_ADDR_I                         ( I2C_SLAVE_ADDR_I ),
   .NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I  ( NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C_I ),
   .NO_OF_SUPPORTED_DEV_I                    ( NO_OF_SUPPORTED_DEV_I ),
   .SEL_DEV_NUM_BITS_I                       ( SEL_DEV_NUM_BITS_I )
  )
  lvds_tx_firi
    (
      // Outputs
      .i2c_bus_out_st_arr_o               (i2c_bus_out_st_arr_o[0]),
      .cam_i2c_bus_out_st_arr_o           (cam_i2c_bus_out_st_arr_o[(NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C_I-1):0]),
      .new_thread_addr_available_pl_o     (new_thread_addr_available_pl),
      .common_reg_o                       (common_reg_info_o),
      .dev_reg_info_st_arr_o              (dev_reg_info_st_arr_o),
      // Inputs
      .clk                                (clk),
      .reset_n                            (reset_n),
      .vsync_i                            (vsync_i[(NO_OF_SUPPORTED_DEV_I-1):0]),
      .i2c_bus_in_st_arr_i                (i2c_bus_in_st_arr_i[0]),
      .sel_device_num_i                   (sel_device_num_o),
      .sel_d_reset_or_stop_stream_req_i   (sel_d_reset_or_stop_stream_req_o),
      .change_thread_addr_pl_i            (change_thread_addr_pl),
      .y_data_bufr_empty_i                (y_data_bufr_empty_i),
      .y_data_bufr_full_i                 (y_data_bufr_full_i),
      .fxn_gpif_m_full_flag_i             (fxn_buffer_ready_i),
      .mipi_status_reg_i                  (mipi_status_reg_i),
      .slfifo_data_nd_status_st_arr_i     (slfifo_data_nd_status_st_arr_i),
      .cam_i2c_bus_in_st_arr_i            (cam_i2c_bus_in_st_arr_i[(NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C_I-1):0]),
      .ddr_ctrl_data_path_idle_i          (ddr_ctrl_data_path_idle_i),
      .ddr_ctrl_cmd_queue_almost_full_i   (ddr_ctrl_cmd_queue_almost_full_i),
      .ddr_ctrl_busy_i                    (ddr_ctrl_busy_i),
      .ddr_cfg_done_i                     (ddr_cfg_done_i),
      .full_frame_wr_completed_i          (full_frame_wr_completed_i),
      .full_frame_rd_completed_i          (full_frame_rd_completed_i)
     );

// -----------------------------
//
// I2C Register Interface - N
//
// -----------------------------

// Logic for handle FXn master I2C if we had enabled more than 2 Fxn master I2C.
// Currently we are not using any other Master I2C interface.
// It will segregate no. of cameras between the enabled FXn master I2C.
// If all 4 cameras didn't had different slave address we had to segragate cameras
// between different FXn master I2Cs and changes the slave address of camera accordingly.

genvar i2c_bus;

generate

  for (i2c_bus=1; i2c_bus < NO_OF_FXN_MASTER_I2C_I; i2c_bus = i2c_bus + 1 )
    begin

fxn_i2c_reg_intr
  #
  (
   // Parameters
   .I2C_SLAVE_ADDR_I                         ( I2C_SLAVE_ADDR_I ),
   .NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I  ( NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C_I ),
   .NO_OF_SUPPORTED_DEV_I                    ( NO_OF_SUPPORTED_DEV_I ),
   .SEL_DEV_NUM_BITS_I                       ( SEL_DEV_NUM_BITS_I )
  )
  lvds_tx_firi_1
    (
      // Outputs
      .i2c_bus_out_st_arr_o               (i2c_bus_out_st_arr_o[i2c_bus]),
      .cam_i2c_bus_out_st_arr_o           (cam_i2c_bus_out_st_arr_o[(i2c_bus*(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I)-1):(i2c_bus*NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C_I)]),
      .new_thread_addr_available_pl_o     (),
      .common_reg_o                       (),
      .dev_reg_info_st_arr_o              (),
      // Inputs
      .clk                                (clk),
      .reset_n                            (reset_n),
      .vsync_i                            (vsync_i[(NO_OF_SUPPORTED_DEV_I-1):0]),
      .i2c_bus_in_st_arr_i                (i2c_bus_out_st_arr_o[i2c_bus]),
      .sel_device_num_i                   (sel_device_num_o),
      .sel_d_reset_or_stop_stream_req_i   (sel_d_reset_or_stop_stream_req_o),
      .change_thread_addr_pl_i            (change_thread_addr_pl),
      .y_data_bufr_empty_i                (y_data_bufr_empty_i),
      .y_data_bufr_full_i                 (y_data_bufr_full_i),
      .fxn_gpif_m_full_flag_i             (fxn_buffer_ready_i),
      .mipi_status_reg_i                  (mipi_status_reg_i),
      .slfifo_data_nd_status_st_arr_i     (slfifo_data_nd_status_st_arr_i),
      .cam_i2c_bus_in_st_arr_i            (cam_i2c_bus_in_st_arr_i[(i2c_bus*(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I)-1):(i2c_bus*NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C_I)]),
      .ddr_ctrl_data_path_idle_i          (ddr_ctrl_data_path_idle_i),
      .ddr_ctrl_cmd_queue_almost_full_i   (ddr_ctrl_cmd_queue_almost_full_i),
      .ddr_ctrl_busy_i                    (ddr_ctrl_busy_i),
      .ddr_cfg_done_i                     (ddr_cfg_done_i),
      .full_frame_wr_completed_i          (full_frame_wr_completed_i),
      .full_frame_rd_completed_i          (full_frame_rd_completed_i)
     );

    end
endgenerate


endmodule