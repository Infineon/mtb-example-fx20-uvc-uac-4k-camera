//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    lvds_phy_n_link_training_fsm
// Target Devices: All
//
// Description: This module trains the FXn LVDS PHY and link. Initially, it
//              transmits Training Sequence Pattern (TS_Pattern) for 50 us
//              (TS_Time) on all lanes once FXn asserts LINK READY signal. After
//              this, it transmits P0 to P4 bytes to train link. Link training is
//              required in LVCMOS DDR mode also.
//
//////////////////////////////////////////////////////////////////////////////////

// Include the package file
`include "package/user_define_pkg.sv"


module lvds_phy_n_link_training_fsm
  #
  (
   // Clock Value
   parameter GPIF_M_CLK_VALUE_I = 75_000_000,

   // Address to be managed by FPGA or not
   parameter ADDR_MANAGED_BY_FPGA_I = "TRUE",

   // GPIF Master Mode: LVDS or LVCMOS
   parameter GPIF_MASTER_MODE_I = "LVCMOS_DDR",

   // Slave FIFO Data Width in Bits
   parameter DATA_WIDTH_IN_BITS_I = 32,

   // LVDS PHY Training Interval in micro seconds
   parameter LVDS_PHY_TS_TIME_IN_US_I = 50,

   // No of Link Training Count
   parameter LINK_TRAINING_COUNT_I = 10,

   // IDLE Interval in micro seconds after training completes
   parameter IDLE_TIME_AFTER_TRAINING_IN_US_I = 3
  )
 (
  input               clk,
  input               reset_n,

  // Outputs
  output       [ 7:0] pnl_ctrl_byte_o,
  output logic [ 7:0] pnl_data_byte_o,
  output logic [(DATA_WIDTH_IN_BITS_I-1):0] pnl_slf_wr_data_o,
  output logic        pnl_ctrl_byte_valid_o,
  output logic        pnl_data_byte_valid_o,
  output logic        pnl_slf_data_valid_o,

  output logic        lvds_phy_training_completed_o,
  output logic        lvds_phy_n_link_training_done_pl_o,

  // Inputs
  input               start_lvds_phy_n_link_training_pl_i,
  input               exit_l3_lp_mode_req_pl_i,

  // Registers
  input common_reg_info_st_t common_reg_info_i
 );

// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // Clock in MHz
  localparam       GPIF_M_CLK_VALUE_IN_MHZ = GPIF_M_CLK_VALUE_I / 1000_000;

  // PHY Training Counter Maximum Value
  localparam       LVDS_PHY_TS_COUNTER_MAX_VALUE = GPIF_M_CLK_VALUE_IN_MHZ * LVDS_PHY_TS_TIME_IN_US_I;

  // Link Training Counter Maximum Value
  localparam       LVDS_LINK_TRAINING_COUNTER_MAX_VALUE = LINK_TRAINING_COUNT_I * 4;

  // Number of IDLE conrol bytes required after training
  localparam       NO_OF_IDLE_CONTROL_BYTES_REQ_AFTER_TRAINING = GPIF_M_CLK_VALUE_IN_MHZ * IDLE_TIME_AFTER_TRAINING_IN_US_I;

   // L3 mode exit interval in micro seconds ( 5ms )
  localparam       NO_OF_L3_MODE_EXIT_TIME_IN_US_I = 5000;
  
  // Number of L3 exit clocks
  localparam       NO_OF_L3_MODE_EXIT_CLKS = GPIF_M_CLK_VALUE_IN_MHZ * NO_OF_L3_MODE_EXIT_TIME_IN_US_I;

  // IDLE Control Byte
  localparam       IDLE_CONTROL_BYTE = 8'd1;

  // No of States
  localparam       NO_OF_FSM_STATES = 8'd5;

  // FSM States
  enum logic [(NO_OF_FSM_STATES-1):0] {

    IDLE                             = 5'h1,
    START_LVDS_PHY_TRAINING          = 5'h2,
    START_LINK_TRAINING              = 5'h4,
    TX_IDLE_CTRL_BYTES               = 5'h8,
    INFORM_TRAINING_COMPLETED        = 5'h10

  } pnl_m_cs, pnl_m_ns;


// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic          phy_ts_counter_en;
  logic          link_training_counter_en;
  logic          lvds_phy_n_link_training_done_pl;
  logic          tx_idle_control_byte;
  logic          pnl_data_wr_en;
  logic  [ 32:0] lvds_phy_counter;
  logic  [ 32:0] lvds_phy_counter_max_value;
  logic  [  7:0] link_training_counter;
  logic  [ 15:0] idle_ctrl_byte_counter;
  logic  [  3:0] pnl_data_wr_count;

// ------------------------------------------
//
// FSM
//
// ------------------------------------------

// Current State
always_ff @ ( posedge clk or negedge reset_n )
  begin
    if ( !reset_n )
      begin
        pnl_m_cs <= IDLE;
      end
    else
      begin
        pnl_m_cs <= pnl_m_ns;
      end
  end

// Next State
always_comb
  begin
    case ( pnl_m_cs )

      // Device Selection FSM asks to start training.
      IDLE :
        begin
          if ( start_lvds_phy_n_link_training_pl_i == 1'b1 )
            begin
              if ( ( GPIF_MASTER_MODE_I == "LVDS" ) &
                   ( common_reg_info_i.lvds_phy_training_en == 1'b1 )
                 )
                begin
                  pnl_m_ns <= START_LVDS_PHY_TRAINING;
                end
              else
                begin
                  pnl_m_ns <= START_LINK_TRAINING;
                end
            end
          else
            begin
              pnl_m_ns <= IDLE;
            end
        end

      // Wait until PHY training is completed
      START_LVDS_PHY_TRAINING :
        begin
          if ( ( ( lvds_phy_counter == ( lvds_phy_counter_max_value - 1'b1 ) )  | ( common_reg_info_i.phy_training_completed == 1'b1 ) ) & phy_ts_counter_en )              
            begin
              pnl_m_ns <= START_LINK_TRAINING;
            end
          else
            begin
              pnl_m_ns <= START_LVDS_PHY_TRAINING;
        end
        end

      // Wait until link training is completed
      START_LINK_TRAINING :
        begin
          if ( ( link_training_counter == ( LVDS_LINK_TRAINING_COUNTER_MAX_VALUE - 1'b1 ) ) & link_training_counter_en )
            begin
              pnl_m_ns <= TX_IDLE_CTRL_BYTES;
            end
          else
            begin
              pnl_m_ns <= START_LINK_TRAINING;
            end
        end

      // Send IDLEs after completion of training.
      TX_IDLE_CTRL_BYTES :
        begin
          if ( ( idle_ctrl_byte_counter == ( NO_OF_IDLE_CONTROL_BYTES_REQ_AFTER_TRAINING - 1'b1 ) ) & tx_idle_control_byte )
            begin
              pnl_m_ns <= INFORM_TRAINING_COMPLETED;
            end
          else
            begin
              pnl_m_ns <= TX_IDLE_CTRL_BYTES;
            end
        end

      // Training is completed
      INFORM_TRAINING_COMPLETED :
        begin
          pnl_m_ns <= IDLE;
        end
    endcase
  end


// Next State Signals
always_comb
  begin

    phy_ts_counter_en                <= 1'b0;
    link_training_counter_en         <= 1'b0;
    lvds_phy_n_link_training_done_pl <= 1'b0;
    tx_idle_control_byte             <= 1'b0;

    case ( pnl_m_cs )

      // Device Selection FSM asks to start training.
      IDLE :
        begin

        end

      // Start LVDS PHY Training
      START_LVDS_PHY_TRAINING :
        begin
          phy_ts_counter_en <= ( ~( ( pnl_data_wr_count < ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) ) & ( pnl_data_wr_en ) ) );
        end

      // Start Link Training
      START_LINK_TRAINING :
        begin
          link_training_counter_en <= ( ~( ( pnl_data_wr_count < ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) ) & ( pnl_data_wr_en ) ) );
        end

      TX_IDLE_CTRL_BYTES :
        begin
          tx_idle_control_byte <= ( ~( ( pnl_data_wr_count < ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) ) & ( pnl_data_wr_en ) ) );
        end

      // Training is completed
      INFORM_TRAINING_COMPLETED :
        begin
          lvds_phy_n_link_training_done_pl <= 1'b1;
        end
    endcase
  end



// ------------------------------------------
//
// PHY Training Counter
//
// ------------------------------------------

// PHY training counter's maximum value
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        lvds_phy_counter_max_value <= LVDS_PHY_TS_COUNTER_MAX_VALUE;
      end
    else if ( exit_l3_lp_mode_req_pl_i )
      begin
        lvds_phy_counter_max_value <= NO_OF_L3_MODE_EXIT_CLKS;
      end
    else if ( ( ( lvds_phy_counter == ( lvds_phy_counter_max_value - 1'b1 ) ) & phy_ts_counter_en ) |
               ( common_reg_info_i.phy_training_completed == 1'b1 ) )
      begin
        lvds_phy_counter_max_value <= LVDS_PHY_TS_COUNTER_MAX_VALUE;
      end
  end
  
// PHY training counter
always_ff @ ( posedge clk or negedge reset_n )
  begin
    if ( !reset_n )
      begin
        lvds_phy_counter <= 32'd0;
      end
    else if ( ( ( lvds_phy_counter == ( lvds_phy_counter_max_value - 1'b1 ) )  | ( common_reg_info_i.phy_training_completed == 1'b1 ) ) & phy_ts_counter_en )
      begin
        lvds_phy_counter <= 32'd0;
      end
    else if ( phy_ts_counter_en == 1'b1 )
      begin
        lvds_phy_counter <= lvds_phy_counter + 1'b1;
      end
  end
  
// PHY training is completed used for l3 control signal
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        lvds_phy_training_completed_o <= 1'b0;
      end
    else if ( ( start_lvds_phy_n_link_training_pl_i == 1'b1 ) | ( common_reg_info_i.l3_lp_mode_en == 1'b1 ) )
      begin
        lvds_phy_training_completed_o <= 1'b0;
      end
    else if ( ( ( lvds_phy_counter == ( lvds_phy_counter_max_value - 1'b1 ) )  | ( common_reg_info_i.phy_training_completed == 1'b1 ) ) & phy_ts_counter_en )
      begin
        lvds_phy_training_completed_o <= 1'b1;
      end
  end

// ------------------------------------------
//
// IDLE Control Bytes
//
// ------------------------------------------

always_ff @ ( posedge clk or negedge reset_n )
  begin
    if ( !reset_n )
      begin
        idle_ctrl_byte_counter <= 16'd0;
      end
    else if ( ( idle_ctrl_byte_counter == ( NO_OF_IDLE_CONTROL_BYTES_REQ_AFTER_TRAINING - 1'b1 ) ) & tx_idle_control_byte )
      begin
        idle_ctrl_byte_counter <= 16'd0;
      end
    else if ( tx_idle_control_byte == 1'b1 )
      begin
        idle_ctrl_byte_counter <= idle_ctrl_byte_counter + 1'b1;
      end
  end

// ------------------------------------------
//
// Link Training Counter
//
// ------------------------------------------

always_ff @ ( posedge clk or negedge reset_n )
  begin
    if ( !reset_n )
      begin
        link_training_counter <= 8'd0;
      end
    else if ( ( link_training_counter == ( LVDS_LINK_TRAINING_COUNTER_MAX_VALUE - 1'b1 ) ) & link_training_counter_en )
      begin
        link_training_counter <= 8'd0;
      end
    else if ( link_training_counter_en == 1'b1 )
      begin
        link_training_counter <= link_training_counter + 1'b1;
      end
  end


// Link training is completed &
// PHY training is going on
always_ff @ ( posedge clk or negedge reset_n )
  begin
    if ( !reset_n )
      begin
        lvds_phy_n_link_training_done_pl_o <= 1'b0;
        // lvds_phy_training_ongoing_o        <= 1'b0;
      end
    else
      begin
        lvds_phy_n_link_training_done_pl_o <= lvds_phy_n_link_training_done_pl;
        // lvds_phy_training_ongoing_o        <= phy_ts_counter_en;
      end
  end


// ------------------------------------------
//
// Control Byte and Valid Signal
//
// ------------------------------------------

generate
  if ( GPIF_MASTER_MODE_I == "LVDS" )
    begin : LVDS_BLK

      // In PHY and Link Training, data lane(s) and control lane have same value.
      assign pnl_ctrl_byte_o = pnl_data_byte_o;

      // Control Byte Valid
      always_ff @ ( posedge clk or negedge reset_n )
        begin
          if ( !reset_n )
            begin
              pnl_ctrl_byte_valid_o <= 1'b0;
            end
          else
            begin
              pnl_ctrl_byte_valid_o <= (
                                        phy_ts_counter_en        |
                                        link_training_counter_en |
                                        tx_idle_control_byte
                                       );
            end
        end

      // ------------------------------------------
      //
      // Data Byte and Valid Signal
      //
      // ------------------------------------------

      // Data Byte
      always_ff @ ( posedge clk or negedge reset_n )
        begin
          if ( !reset_n )
            begin
              pnl_data_byte_o <= 8'd0;
            end
          else if ( phy_ts_counter_en )
            begin
              pnl_data_byte_o <= common_reg_info_i.lvds_phy_training_seq;
            end
          else if ( link_training_counter_en )
            begin
              case ( link_training_counter[1:0] )

                2'd0 : pnl_data_byte_o <= common_reg_info_i.training_block_seq_p0;

                2'd1 : pnl_data_byte_o <= common_reg_info_i.training_block_seq_p1;

                2'd2 : pnl_data_byte_o <= common_reg_info_i.training_block_seq_p2;

                2'd3 : pnl_data_byte_o <= common_reg_info_i.training_block_seq_p3;

              endcase
            end
          else
            begin
              pnl_data_byte_o <= IDLE_CONTROL_BYTE;
            end
        end

      // Data Byte Valid
      always_ff @ ( posedge clk or negedge reset_n )
        begin
          if ( !reset_n )
            begin
              pnl_data_byte_valid_o <= 1'b0;
            end
          else
            begin
              pnl_data_byte_valid_o <= (
                                        phy_ts_counter_en |
                                        link_training_counter_en
                                       );
            end
        end

      // These 2 signals are not used in this mode
      // assign pnl_slf_wr_data_o = 64'b0;
      // assign pnl_slf_data_valid_o = 1'b0;

    end
  else
    begin : LVCMOS_BLK

      // logic pnl_slf_data_valid_o;
      // logic [(DATA_WIDTH_IN_BITS_I-1):0] pnl_slf_wr_data_o;

      always_ff @ ( posedge clk or negedge reset_n )
        begin
          if ( !reset_n )
            begin
              pnl_slf_wr_data_o <= 64'd0;
            end
          else if ( link_training_counter_en )
            begin
              case ( link_training_counter[1:0] )

                2'd0 : pnl_slf_wr_data_o <= {8{common_reg_info_i.training_block_seq_p0}};

                2'd1 : pnl_slf_wr_data_o <= {8{common_reg_info_i.training_block_seq_p1}};

                2'd2 : pnl_slf_wr_data_o <= {8{common_reg_info_i.training_block_seq_p2}};

                2'd3 : pnl_slf_wr_data_o <= {8{common_reg_info_i.training_block_seq_p3}};

              endcase
            end
          else
            begin
              pnl_slf_wr_data_o <= {8{IDLE_CONTROL_BYTE}};
            end
        end

      // Data Byte Valid
      always_ff @ ( posedge clk or negedge reset_n )
        begin
          if ( !reset_n )
            begin
              pnl_slf_data_valid_o <= 1'b0;
            end
          else
            begin
              pnl_slf_data_valid_o <= link_training_counter_en;
            end
        end

      // These 2 signals are not used in this mode
      // wire [7:0] pnl_ctrl_byte_o;
      // wire [7:0] pnl_data_byte_o;
      // wire       pnl_ctrl_byte_valid_o;
      // wire       pnl_data_byte_valid_o;

      // assign pnl_ctrl_byte_o = 8'h0;
      // assign pnl_data_byte_o = 8'h0;
      // assign pnl_ctrl_byte_valid_o = 1'b0;
      // assign pnl_data_byte_valid_o = 1'b0;

    end
endgenerate


// ----------------------------------------------
//
// Gear Ratio Counter
//
// ----------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        pnl_data_wr_en <= 1'b0;
      end
    else if ( phy_ts_counter_en | link_training_counter_en | tx_idle_control_byte )
      begin
        pnl_data_wr_en <= 1'b1;
      end
    else if ( pnl_data_wr_count == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
      begin
        pnl_data_wr_en <= 1'b0;
      end
  end

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        pnl_data_wr_count <= 3'd0;
      end
    else if ( phy_ts_counter_en | link_training_counter_en | tx_idle_control_byte )
      begin
        pnl_data_wr_count <= 3'b0;
      end
    else if ( pnl_data_wr_en == 1'b1 )
      begin
        pnl_data_wr_count <= pnl_data_wr_count + 1'b1;
      end
  end


endmodule