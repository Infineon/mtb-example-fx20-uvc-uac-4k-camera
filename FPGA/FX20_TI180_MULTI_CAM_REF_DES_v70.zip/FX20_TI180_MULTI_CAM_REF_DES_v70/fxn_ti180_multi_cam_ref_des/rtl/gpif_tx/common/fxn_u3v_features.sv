//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fxn_u3v_features
// Target Devices: All
//
// Description: This module holds all the u3v features implemented in U3V standard which works for
//              FXn.
//
//////////////////////////////////////////////////////////////////////////////////

// Include the package file
`include "package/user_define_pkg.sv"


`timescale 1ns/100ps

module fxn_u3v_features
  #
  (
   // LVDS Data Lanes
   parameter CHUNK_DATA_WIDTH_I = 64
  )
 (
     input         clk,
     input         reset_n,

     input         full_frame_sent_pl_i,
     input         sel_reset_or_stop_stream_req_i,
     input         u3v_chunk_start_i,
     input common_reg_info_st_t common_reg_info_i,    // Common Register Information
     input dev_reg_info_st_t    sel_d_reg_info_st_i,   // Device Specific Register Information

     // U3V Trigger
     input         sw_i,

     output logic         u3v_stream_en_o,
     output logic [(CHUNK_DATA_WIDTH_I)-1:0]  u3v_chunk_data_out_o_1,
     output logic         u3v_chunk_data_out_vld_o_1,
     output logic [(CHUNK_DATA_WIDTH_I)-1:0]  u3v_chunk_data_out_o_2,
     output logic         u3v_chunk_data_out_vld_o_2,
     output logic         u3v_chunk_data_end_o
 );

// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  logic [7:0] u3v_stream_mode;
  logic [7:0] u3v_stream_count;
  logic       trigger_pe;
  logic       u3v_stream_multi_frame_cap;
  logic       temp;
  logic       temp_sw;

  logic [63:0] count;
  logic [63:0] trigger_count;
  logic        trigger_r1;
  logic        trigger_r2;
  logic        trigger;
  logic        trigger_r;

  logic [(CHUNK_DATA_WIDTH_I)-1:0] u3v_chunk_data_out_o;
  logic        u3v_chunk_data_out_vld_o;

//  logic [(TOTAL_LVDS_DATA_LANES_I * 8)-1:0] u3v_chunk_data_out_o_2;
//  logic        u3v_chunk_data_out_vld_o_2;


// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // No of States
  localparam NO_OF_TRIG_FSM_STATES   = 8'd8;
  localparam NO_OF_CHUNK_FSM_STATES  = 8'd11;


// -----------------------------------------
//
// Trigger Mode FSM params for U3V
//
// ------------------------------------------

  enum logic [(NO_OF_TRIG_FSM_STATES-1):0] {
    TRIGGER_IDLE                            = 8'h1,
    TRIGGER_HARDWARE                        = 8'h2,
    TRIGGER_SOFTWARE                        = 8'h4,
    TRIGGER_HARDWARE_0                      = 8'h8,
    TRIGGER_HARDWARE_1                      = 8'h10,
    TRIGGER_HARDWARE_2                      = 8'h20,
    TRIGGER_HARDWARE_3                      = 8'h40,
    TRIGGER_END                             = 8'h80
  } trigger_cs, trigger_ns;


// -----------------------------------------
//
// Chunk Data Mode FSM params for U3V
//
// ------------------------------------------

  enum logic [(NO_OF_CHUNK_FSM_STATES-1):0] {
    CHUNK_DATA_IDLE                           = 11'h1,
    CHUNK_DATA_PAYLOAD                        = 11'h2,
    CHUNK_DATA_PAYLOAD_SIZE_ID                = 11'h4,
    CHUNK_DATA_FRAME_NO                       = 11'h8,
    CHUNK_DATA_FRAME_NO_MSB_LSB               = 11'h10,
    CHUNK_DATA_FRAME_NO_SIZE_ID               = 11'h20,
    CHUNK_DATA_TIME_STAMP                     = 11'h40,
    CHUNK_DATA_TIME_STAMP_MSB_LSB             = 11'h80,
    CHUNK_DATA_TIME_STAMP_SIZE_ID             = 11'h100,
    CHUNK_DATA_END                            = 11'h200,
    WAIT_CHUNK_DATA_START                     = 11'h400
  } chunk_data_cs, chunk_data_ns;

// ------------------------------------------
//
// Debouncing logic for Hardware Trigger
//
// ------------------------------------------


     debouncer_mod dbm_hw
     (
        .clk                  (clk),
        .btn                  (sw_i),
        .out                  (temp)
     );

// ------------------------------------------
//
// Debouncing logic for Software Trigger
//
// ------------------------------------------


     debouncer_mod dbm_sw
     (
        .clk                  (clk),
        .btn                  (sel_d_reg_info_st_i.u3v_sw_trigger),
        .out                  (temp_sw)
     );

// ------------------------------------------
//
// Trigger Detection
//
// ------------------------------------------

 always_ff @ (posedge clk)
  begin
   if((sel_d_reg_info_st_i.u3v_sw_trigger) && (sel_d_reg_info_st_i.u3v_trigger_type== 1'b0))
       begin
       trigger <= (sel_d_reg_info_st_i.u3v_sw_trigger); //sel_d_u3v_sw_trigger;
     end
   else if((sel_d_reg_info_st_i.u3v_sw_trigger) && (sel_d_reg_info_st_i.u3v_trigger_type== 1'b1))
       begin
       trigger <= temp_sw;
       end
   else if (sel_d_reg_info_st_i.u3v_hw_trigger != 4'd0)
    begin
    if ( sel_d_reg_info_st_i.u3v_trigger_type== 1'b1 )
      begin
        trigger <= temp;
      end
    else if(sel_d_reg_info_st_i.u3v_trigger_type== 1'b0 && (~sw_i))// Acquisition  Start
      begin
        trigger <= 1'd1;
      end
    else
        begin
         trigger  <= 1'd0;
        end
    end
   else
     begin
       trigger  <= 1'd0;
     end
 end

// ------------------------------------------
//
// Trigger Pos Edge Detection
//
// ------------------------------------------
always_ff @(posedge clk)
 begin
  trigger_r1 <= trigger;
  trigger_r2 <= trigger_r1;
 end

assign trigger_pe = trigger_r1 && !trigger_r2;




// ------------------------------------------
//
// Trigger Mode FSM
//
// ------------------------------------------

// Current State
always_ff @ (posedge clk )
begin
  if(!reset_n)
  begin
    trigger_cs <= TRIGGER_IDLE;
  end
  else if((sel_d_reg_info_st_i.u3v_trigger_mode_en== 1'b0) || (u3v_stream_multi_frame_cap==1'b0))
  begin
    trigger_cs <= TRIGGER_IDLE;
  end
  else
  begin
    trigger_cs <= trigger_ns;
  end
end

// Trigger Mode Next State for U3V
always_comb
  begin
    trigger_ns <= TRIGGER_IDLE;
    unique case ( trigger_cs )

    TRIGGER_IDLE: begin
       if(sel_d_reg_info_st_i.u3v_sw_trigger== 1'b1)
       begin
         trigger_ns <= TRIGGER_SOFTWARE;
       end
       else
       begin
         trigger_ns <= TRIGGER_HARDWARE;
       end
    end
    TRIGGER_HARDWARE: begin
       if(sel_d_reg_info_st_i.u3v_hw_trigger == 4'd1)
       begin
         trigger_ns <= TRIGGER_HARDWARE_0;
       end
       else if(sel_d_reg_info_st_i.u3v_hw_trigger == 4'd2)
       begin
         trigger_ns <= TRIGGER_HARDWARE_1;
       end
       else if(sel_d_reg_info_st_i.u3v_hw_trigger == 4'd3)
       begin
         trigger_ns <= TRIGGER_HARDWARE_2;
       end
       else if(sel_d_reg_info_st_i.u3v_hw_trigger == 4'd4)
       begin
         trigger_ns <= TRIGGER_HARDWARE_3;
       end
       else
       begin
         trigger_ns <= TRIGGER_HARDWARE_0;
       end
    end
    TRIGGER_HARDWARE_0: begin
       trigger_ns <= TRIGGER_END;
     end
    TRIGGER_HARDWARE_1: begin
       trigger_ns <= TRIGGER_END;
     end
    TRIGGER_HARDWARE_2: begin
       trigger_ns <= TRIGGER_END;
     end
     TRIGGER_HARDWARE_3: begin
       trigger_ns <= TRIGGER_END;
     end
     TRIGGER_SOFTWARE: begin
     if(trigger_r == 1'b1)
        begin
        trigger_ns <= TRIGGER_END;
        end
     else
        begin
        trigger_ns <= TRIGGER_SOFTWARE;
        end
     end
     TRIGGER_END: begin
     trigger_ns <= TRIGGER_IDLE;
   /*   if(full_frame_sent_pl_i)
       begin
        trigger_ns <= TRIGGER_IDLE;
       end
      else
       begin
        trigger_ns <= TRIGGER_END;
       end */
     end
    endcase
end


// Trigger Mode Next State signals

always_comb
  begin
    trigger_r <= 1'b0;
    unique case (trigger_cs)
    TRIGGER_IDLE: trigger_r <= 1'b0;
    TRIGGER_HARDWARE: trigger_r <= 1'b0;
    TRIGGER_HARDWARE_0:
    begin
        if((sel_d_reg_info_st_i.u3v_trigger_type== 1'b1)&& (trigger_pe && trigger_count< 64'd1)) begin
         trigger_r <= 1'b1;
        end
        else if((sel_d_reg_info_st_i.u3v_trigger_type== 1'b0)&& trigger) begin
         trigger_r <= 1'b1;
        end
        else begin
         trigger_r  <= 1'b0;
        end
    end
    TRIGGER_HARDWARE_1: trigger_r <= 1'b1;
    TRIGGER_HARDWARE_2: trigger_r <= 1'b1;
    TRIGGER_HARDWARE_3: trigger_r <= 1'b1;
    TRIGGER_SOFTWARE:
        begin
        if((sel_d_reg_info_st_i.u3v_trigger_type== 1'b1)&& (trigger_pe && trigger_count< 64'd1)) begin
         trigger_r <= 1'b1;
        end
        else if((sel_d_reg_info_st_i.u3v_trigger_type== 1'b0)&& (trigger)) begin
         trigger_r <= 1'b1;
        end
        else begin
         trigger_r  <= 1'b0;
        end
    end
    TRIGGER_END:    ;
   endcase
end

assign u3v_stream_multi_frame_cap = (((sel_d_reg_info_st_i.u3v_single_frame_mode) && (count<= 64'd1) ) || ((sel_d_reg_info_st_i.u3v_multi_frame_mode) && (count<= sel_d_reg_info_st_i.u3v_no_of_frame_in_multi_frame_mode))  ||(sel_d_reg_info_st_i.u3v_continuous_mode));

// U3V streaming Enable
always_ff @ (posedge clk )
begin
  if(!reset_n)
   begin
    u3v_stream_en_o <= 1'b0;
   end

  else if(u3v_stream_multi_frame_cap)
  begin
    if((sel_d_reg_info_st_i.u3v_trigger_mode_en==1'd1) &&(trigger_r==1'b1)) // Trigger Enabled
     begin
      u3v_stream_en_o <= 1'b1;
     end
    else if (sel_d_reg_info_st_i.u3v_trigger_mode_en==1'd0)  // Trigger is not Enabled
     begin
      u3v_stream_en_o <= 1'b1;
     end
    else
     begin
      u3v_stream_en_o <= 1'b0;
     end
  end

  else
   begin
    u3v_stream_en_o <= 1'b0;
   end

end

// count and trigger_count

always_ff @ (posedge clk) begin
    if ( !reset_n )
      begin
        count <= 64'd1;
        trigger_count <= 64'd0;
      end
    else if(sel_reset_or_stop_stream_req_i)
     begin
      count <= 64'd1;
      trigger_count <= 64'd0;
     end

    else if(full_frame_sent_pl_i)
     begin
      count <= count+1'd1; // Incrementing Count for every Frame end
      trigger_count <= trigger_count + 1'd1;
     end

    if((trigger_cs == TRIGGER_HARDWARE)||(trigger_cs == TRIGGER_SOFTWARE))
     begin
      trigger_count <= 64'd0;
     end
end


// ------------------------------------------
//
// Chunk Mode FSM
//
// ------------------------------------------

// Current State
always_ff @ (posedge clk )
begin
  if(!reset_n)
  begin
    chunk_data_cs <= CHUNK_DATA_IDLE;
  end
  else if((sel_d_reg_info_st_i.u3v_chunk_mode_en== 1'b0) || (u3v_stream_multi_frame_cap==1'b0))
  begin
    chunk_data_cs <= CHUNK_DATA_IDLE;
  end
  else
  begin
    chunk_data_cs <= chunk_data_ns;
  end
end

// Chunk Data Mode Next State for U3V
always_comb
  begin
    chunk_data_ns <= CHUNK_DATA_IDLE;
    unique case ( chunk_data_cs )

    CHUNK_DATA_IDLE:
     begin
      if(sel_d_reg_info_st_i.u3v_chunk_mode_en== 1'b1)
       begin
        chunk_data_ns <= WAIT_CHUNK_DATA_START;
       end
      else
       begin
        chunk_data_ns <= CHUNK_DATA_IDLE;
       end
     end

     WAIT_CHUNK_DATA_START:
     begin
      if(u3v_chunk_start_i== 1'b1)
       begin
        chunk_data_ns <= CHUNK_DATA_PAYLOAD;
       end
      else if(sel_d_reg_info_st_i.u3v_chunk_mode_en== 1'b0)
        begin
        chunk_data_ns <= CHUNK_DATA_IDLE;
        end
      else
       begin
        chunk_data_ns <= WAIT_CHUNK_DATA_START;
       end
     end

     CHUNK_DATA_PAYLOAD:
     begin
      chunk_data_ns <= CHUNK_DATA_PAYLOAD_SIZE_ID;
     end

     CHUNK_DATA_PAYLOAD_SIZE_ID:
     begin
      if(sel_d_reg_info_st_i.u3v_frame_id_chunk_type)
       begin
        chunk_data_ns <= CHUNK_DATA_FRAME_NO;
       end

       else if(sel_d_reg_info_st_i.u3v_time_stamp_chunk_type)
        begin
        chunk_data_ns <= CHUNK_DATA_TIME_STAMP;
        end

       else
        begin
        chunk_data_ns <= CHUNK_DATA_END;
        end
     end


     CHUNK_DATA_FRAME_NO:
     begin
      chunk_data_ns <= CHUNK_DATA_FRAME_NO_MSB_LSB;
     end

     CHUNK_DATA_FRAME_NO_MSB_LSB:
     begin
      chunk_data_ns <= CHUNK_DATA_FRAME_NO_SIZE_ID;
     end


     CHUNK_DATA_FRAME_NO_SIZE_ID:
     begin

      if(sel_d_reg_info_st_i.u3v_time_stamp_chunk_type)
        begin
        chunk_data_ns <= CHUNK_DATA_TIME_STAMP;
        end

       else
        begin
        chunk_data_ns <= CHUNK_DATA_END;
        end
     end


     CHUNK_DATA_TIME_STAMP:
     begin
      chunk_data_ns <= CHUNK_DATA_TIME_STAMP_MSB_LSB;
     end

     CHUNK_DATA_TIME_STAMP_MSB_LSB:
     begin
      chunk_data_ns <= CHUNK_DATA_TIME_STAMP_SIZE_ID;
     end

     CHUNK_DATA_TIME_STAMP_SIZE_ID:
     begin
      chunk_data_ns <= CHUNK_DATA_END;
     end

     CHUNK_DATA_END:
     begin
        if(full_frame_sent_pl_i== 1'b1)
        begin
           chunk_data_ns <= CHUNK_DATA_IDLE;
        end
        else
        begin
            chunk_data_ns <= CHUNK_DATA_END;
        end
     end

    endcase
  end

// Trigger Mode Next State signals

always_comb
  begin
    u3v_chunk_data_out_vld_o <= 1'b0;
    u3v_chunk_data_end_o <= 1'b0;
    unique case (chunk_data_cs)

    CHUNK_DATA_IDLE:     u3v_chunk_data_end_o <= 1'b1; //u3v_chunk_data_end_o <= 1'b0;

    WAIT_CHUNK_DATA_START: ;

    CHUNK_DATA_PAYLOAD:
    begin
      if(sel_d_reg_info_st_i.u3v_frame_id_chunk_type)
       begin
        u3v_chunk_data_end_o <= 1'b0;
       end

       else if(sel_d_reg_info_st_i.u3v_time_stamp_chunk_type)
        begin
        u3v_chunk_data_end_o <= 1'b0;
        end

       else
        begin
        u3v_chunk_data_end_o <= 1'b1;
        end
    end

    CHUNK_DATA_PAYLOAD_SIZE_ID:
     begin
      u3v_chunk_data_out_o <= { 32'h00FD2000, 32'h00000001 }; // changed the order
      //u3v_chunk_data_out_o <= { 32'h00000001, 32'h00FD2000 }; // changed the order
      u3v_chunk_data_out_vld_o <= 1'b1;

     end

    CHUNK_DATA_FRAME_NO: ;

    CHUNK_DATA_FRAME_NO_MSB_LSB:
     begin
      u3v_chunk_data_out_o <= {   count[63:32], count[31:0]};
      //u3v_chunk_data_out_o <= {   count[31:0], count[63:32] };
      u3v_chunk_data_out_vld_o <= 1'b1;

      if(sel_d_reg_info_st_i.u3v_time_stamp_chunk_type)
        begin
        u3v_chunk_data_end_o <= 1'b0;
        end
       else
        begin
        u3v_chunk_data_end_o <= 1'b1;
        end

     end

    CHUNK_DATA_FRAME_NO_SIZE_ID:
     begin
      u3v_chunk_data_out_o <= {  32'h00000008, 32'h05040003};
      //u3v_chunk_data_out_o <= {  32'h05040003, 32'h00000008};
      u3v_chunk_data_out_vld_o <= 1'b1;


     end

    CHUNK_DATA_TIME_STAMP: ;
    CHUNK_DATA_TIME_STAMP_MSB_LSB:
     begin
      u3v_chunk_data_out_o <= { 32'h00001234, 32'h0000ABCD};
      //u3v_chunk_data_out_o <= { 32'h0000ABCD, 32'h00001234};
      u3v_chunk_data_out_vld_o <= 1'b1;

      u3v_chunk_data_end_o <= 1'b1;

     end

    CHUNK_DATA_TIME_STAMP_SIZE_ID:
     begin
      u3v_chunk_data_out_o <= { 32'h00000008, 32'h0508000E};
      //u3v_chunk_data_out_o <= { 32'h0508000E, 32'h00000008};
      u3v_chunk_data_out_vld_o <= 1'b1;
     end

    CHUNK_DATA_END:
    begin
      u3v_chunk_data_end_o <= 1'b1;
    end
   endcase
end

// -----------------------------------------------------
//
// Delaying Chunk Data by 2 cycles to align with pktend
//
// ------------------------------------------------------

always_ff @ (posedge clk)
begin
    u3v_chunk_data_out_o_1 <= u3v_chunk_data_out_o;
    u3v_chunk_data_out_o_2 <= u3v_chunk_data_out_o_1;
    u3v_chunk_data_out_vld_o_1 <= u3v_chunk_data_out_vld_o;
    u3v_chunk_data_out_vld_o_2  <= u3v_chunk_data_out_vld_o_1;
end


endmodule

