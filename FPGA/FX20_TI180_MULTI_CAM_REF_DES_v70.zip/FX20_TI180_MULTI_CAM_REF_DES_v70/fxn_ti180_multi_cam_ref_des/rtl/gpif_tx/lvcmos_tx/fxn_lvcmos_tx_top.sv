//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fxn_lvcmos_tx_top
// Target Devices: All
//
// Description: This is a top module which includes following modules,
//
//                 1. Device Selection FSM
//                 2. LVDS PHY and Link Training FSM
//                 3. LVCMOS Slave FIFO Master
//                 4. SDR DDR Manager
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module fxn_lvcmos_tx_top
  #
  (
   // Clock Value
   parameter GPIF_M_CLK_VALUE_I = 75_000_000,

   // GPIF Master Mode: LVDS or LVCMOS
   parameter GPIF_MASTER_MODE_I = "LVCMOS_DDR",

   // LVDS PHY Training Interval in micro seconds
   parameter LVDS_PHY_TS_TIME_IN_US_I = 50,

   // Data Lanes in LVCMOS Mode
   parameter TOTAL_DATA_LANES_I = 32,

   // Number of address bits
   parameter NO_OF_ADDRESS_BITS_I = 2,

   // No. of devices/ FIFOs needed
   parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
   parameter SEL_DEV_NUM_BITS_I = 3,

   // Slave FIFO Data Width. In case of DDR, it is double.
   localparam SLFIFO_RD_DATA_WIDTH_IN_BITS = ( ( GPIF_MASTER_MODE_I == "LVCMOS_DDR" ) ?
                                               ( TOTAL_DATA_LANES_I * 2 ) :
                                               ( TOTAL_DATA_LANES_I ) )
  )
 (
  input              clk,
  input              reset_n,

  // Outputs
  output             slf_m_wr_req_n_o,
  output             slf_m_pktend_n_o,
  output             slf_m_cs_n_o,
  output             slf_m_epswitch_n_o,
  output             change_thread_addr_pl_o,
  output             l_zlp_sent_o,
  output             sel_d_reset_or_stop_stream_req_o,
  output     [(SEL_DEV_NUM_BITS_I-1):0]  sel_device_num_o,
  output     [(NO_OF_ADDRESS_BITS_I-1):0]   slf_m_addr_o,
  output     [(TOTAL_DATA_LANES_I-1):0] slf_wr_data_pe_o,
  output     [(TOTAL_DATA_LANES_I-1):0] slf_wr_data_ne_o,

  output dev_reg_info_st_t       sel_d_reg_info_st_o,
  output slfifo_ctrl_req_st_t       [(NO_OF_SUPPORTED_DEV_I-1):0] slfifo_ctrl_req_st_arr_o,

  // Inputs
  input              fxn_buffer_ready_i,
  input              fxn_buffer_partial_i,
  input              fxn_lvds_rx_link_ready_i,

  input              new_thread_addr_available_pl_i,
  input              sw_i,
  input  common_reg_info_st_t    common_reg_info_i,
  input  dev_reg_info_st_t          [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_i,
  input  slfifo_data_nd_status_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] slfifo_data_nd_status_st_arr_i
 );

// ------------------------------------------
//
// Local Parameter
//
// ------------------------------------------

  // IDLE Interval in micro seconds after training completes
  localparam IDLE_TIME_AFTER_TRAINING_IN_US = 3;

  // No of Link Training Count
  localparam LINK_TRAINING_COUNT = 1;

  // Address to be managed by FPGA or not
  localparam ADDR_MANAGED_BY_FPGA = "FALSE";

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic          start_lvds_phy_n_link_training_pl;
  logic          start_serving_device_pl;
  logic          lvds_phy_n_link_training_done_pl;
  logic          full_frame_sent_pl;
  logic          slf_m_wr_req_n;
  logic          slf_m_pktend_n;
  logic          slf_m_cs_n;
  logic          slf_m_epswitch_n;
  logic          pnl_slf_data_valid;

  logic          u3v_chunk_data_end;
  logic [63:0]   u3v_chunk_data_out;
  logic          u3v_chunk_data_out_vld;
  logic          u3v_chunk_start;
  logic          u3v_stream_en;

  logic [(NO_OF_ADDRESS_BITS_I-1):0] slf_m_addr;
  logic [(SLFIFO_RD_DATA_WIDTH_IN_BITS-1):0] pnl_slf_wr_data;
  logic [(SLFIFO_RD_DATA_WIDTH_IN_BITS-1):0] slf_wr_data;

  logic          data_pkt_sent_pl;
  logic [31:0]   sel_d_frame_size_in_bytes;


// ------------------------------------------
//
// Device Selection FSM
//
// ------------------------------------------

dev_selection_fsm
  #
  (
   // Parameters
   .GPIF_MASTER_MODE_I                    (GPIF_MASTER_MODE_I),
   .TOTAL_DATA_LANES_I                    (TOTAL_DATA_LANES_I),
   .NO_OF_SUPPORTED_DEV_I                 (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I                    (SEL_DEV_NUM_BITS_I)
   )
  dsf
   (
    // Outputs
    .start_lvds_phy_n_link_training_pl_o  (start_lvds_phy_n_link_training_pl),
    .start_serving_device_pl_o            (start_serving_device_pl),
    .sel_device_num_o                     (sel_device_num_o[(SEL_DEV_NUM_BITS_I-1):0]),

    .sel_d_reset_or_stop_stream_req_o     (sel_d_reset_or_stop_stream_req_o),
    .sel_d_frame_size_in_bytes_o          (sel_d_frame_size_in_bytes),
    .sel_d_reg_info_st_o                  (sel_d_reg_info_st_o),

    // Inputs
    .clk                                  (clk),
    .reset_n                              (reset_n),
    .fxn_lvds_rx_link_ready_i             (fxn_lvds_rx_link_ready_i),
    .fxn_buffer_ready_i                   (fxn_buffer_ready_i),
    .lvds_phy_n_link_training_done_pl_i   (lvds_phy_n_link_training_done_pl),

    .full_frame_sent_pl_i                 (full_frame_sent_pl),
    .data_pkt_sent_pl_i                   (data_pkt_sent_pl),
    .common_reg_info_i                    (common_reg_info_i),
    .slfifo_data_nd_status_st_arr_i       (slfifo_data_nd_status_st_arr_i),
    .dev_reg_info_st_arr_i                (dev_reg_info_st_arr_i[(NO_OF_SUPPORTED_DEV_I-1):0])

    );


// ------------------------------------------
//
// PHY and Link Training
//
// ------------------------------------------

lvds_phy_n_link_training_fsm
  #
  (
   // Parameters
   .GPIF_M_CLK_VALUE_I                  (GPIF_M_CLK_VALUE_I),
   .ADDR_MANAGED_BY_FPGA_I              (ADDR_MANAGED_BY_FPGA),
   .GPIF_MASTER_MODE_I                  (GPIF_MASTER_MODE_I),
   .LVDS_PHY_TS_TIME_IN_US_I            (LVDS_PHY_TS_TIME_IN_US_I),
   .LINK_TRAINING_COUNT_I               (LINK_TRAINING_COUNT),
   .IDLE_TIME_AFTER_TRAINING_IN_US_I    (IDLE_TIME_AFTER_TRAINING_IN_US),
   .DATA_WIDTH_IN_BITS_I                (SLFIFO_RD_DATA_WIDTH_IN_BITS))
  lpnltf
   (
    // Outputs
    .pnl_ctrl_byte_o                     (),
    .pnl_data_byte_o                     (),
    .pnl_slf_wr_data_o                   (pnl_slf_wr_data),
    .pnl_ctrl_byte_valid_o               (),
    .pnl_data_byte_valid_o               (),
    .pnl_slf_data_valid_o                (pnl_slf_data_valid),
    .lvds_phy_n_link_training_done_pl_o  (lvds_phy_n_link_training_done_pl),
//    .lvds_phy_training_ongoing_o         (lvds_phy_training_ongoing),

    // Inputs
    .clk                                 (clk),
    .reset_n                             (reset_n),
    .start_lvds_phy_n_link_training_pl_i (start_lvds_phy_n_link_training_pl),
    .common_reg_info_i                   (common_reg_info_i));


// ------------------------------------------
//
// Slave FIFO FSM
//
// ------------------------------------------

fxn_slfifo_tx_master
  #
  (
   // Parameters
   .DATA_WIDTH_IN_BITS_I           (SLFIFO_RD_DATA_WIDTH_IN_BITS),
   .NO_OF_ADDRESS_BITS_I           (NO_OF_ADDRESS_BITS_I),
   .NO_OF_SUPPORTED_DEV_I          (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I             (SEL_DEV_NUM_BITS_I),
   .GPIF_MASTER_MODE_I             (GPIF_MASTER_MODE_I))
  fsm
  (
   // Outputs
   .slfifo_rd_req_o                (slfifo_ctrl_req_st_arr_o[sel_device_num_o].rd_req),
   .slf_m_wr_req_n_o               (slf_m_wr_req_n),
   .slf_m_pktend_n_o               (slf_m_pktend_n),
   .slf_m_cs_n_o                   (slf_m_cs_n),
   .slf_m_epswitch_n_o             (slf_m_epswitch_n),
   .change_thread_addr_pl_o        (change_thread_addr_pl_o),
   .l_zlp_sent_o                   (l_zlp_sent_o),
   .slfifo_reset_req_o             (slfifo_ctrl_req_st_arr_o[sel_device_num_o].reset_req),
   .frame_data_sent_pl_o           (full_frame_sent_pl),
   .slf_m_addr_o                   (slf_m_addr),
   .slf_wr_data_o                  (slf_wr_data),
   .data_pkt_sent_pl_o             (data_pkt_sent_pl),

   // Inputs
   .clk                            (clk),
   .reset_n                        (reset_n),
   .start_serving_device_pl_i      (start_serving_device_pl),
   .slf_m_par_flag_i               (fxn_buffer_partial_i),
   .slf_m_full_flag_i              (fxn_buffer_ready_i),
   .slfifo_rd_data_valid_i         (slfifo_data_nd_status_st_arr_i[sel_device_num_o].rd_data_valid),
   .slfifo_almost_empty_i          (slfifo_data_nd_status_st_arr_i[sel_device_num_o].almost_empty),
   .slfifo_rd_data_i               (slfifo_data_nd_status_st_arr_i[sel_device_num_o].rd_data),
   .sel_reset_or_stop_stream_req_i (sel_d_reset_or_stop_stream_req_o),
   .frame_size_info_i              (sel_d_frame_size_in_bytes),

   .u3v_stream_en_i                (u3v_stream_en),
   .u3v_chunk_data_out_i           (u3v_chunk_data_out) ,
   .u3v_chunk_data_out_vld_i       (u3v_chunk_data_out_vld),
   .u3v_chunk_data_end_i           (u3v_chunk_data_end),
   .u3v_chunk_start                (u3v_chunk_start),
   .sel_device_num_i               (sel_device_num_o),

    .common_reg_info_i             (common_reg_info_i),
    .sel_d_reg_info_st_i           (sel_d_reg_info_st_o)
  );


// ------------------------------------------
//
// SDR to DDR Converter
//
// ------------------------------------------

sdr_ddr_manager
  #
  (
   // Parameters
   .DATA_WIDTH_IN_BITS_I           (SLFIFO_RD_DATA_WIDTH_IN_BITS),
   .GPIF_MASTER_MODE_I             (GPIF_MASTER_MODE_I),
   .NO_OF_ADDRESS_BITS_I           (NO_OF_ADDRESS_BITS_I))
  sdm
  (
   // Outputs
   .slf_m_wr_req_n_o               (slf_m_wr_req_n_o),
   .slf_m_pktend_n_o               (slf_m_pktend_n_o),
   .slf_m_cs_n_o                   (slf_m_cs_n_o),
   .slf_m_epswitch_n_o             (slf_m_epswitch_n_o),
   .slf_m_addr_o                   (slf_m_addr_o),
   .slf_wr_data_pe_o               (slf_wr_data_pe_o),
   .slf_wr_data_ne_o               (slf_wr_data_ne_o),

   // Inputs
   .clk                            (clk),
   .reset_n                        (reset_n),
   .slf_wr_data_i                  (slf_wr_data),
   .pnl_slf_wr_data_i              (pnl_slf_wr_data),
   .slf_m_addr_i                   (slf_m_addr),
   .slf_m_wr_req_n_i               (slf_m_wr_req_n),
   .slf_m_pktend_n_i               (slf_m_pktend_n),
   .pnl_slf_data_valid_i           (pnl_slf_data_valid),
   .slf_m_cs_n_i                   (slf_m_cs_n),
   .slf_m_epswitch_n_i             (slf_m_epswitch_n)
  );



// ------------------------------------------
//
// FX10 U3V Features
//
// ------------------------------------------


fxn_u3v_features
  #
  (
   // Parameters
   .CHUNK_DATA_WIDTH_I        (64))
 fuv
 (
   .clk                            (clk),
   .reset_n                        (reset_n),

   .full_frame_sent_pl_i           (full_frame_sent_pl),
   .sel_reset_or_stop_stream_req_i (sel_d_reset_or_stop_stream_req_o),
   .u3v_chunk_start_i              (u3v_chunk_start),
   .sw_i                           (sw_i),
   .common_reg_info_i              (common_reg_info_i),
   .sel_d_reg_info_st_i            (sel_d_reg_info_st_o),

   .u3v_stream_en_o                (u3v_stream_en),
   .u3v_chunk_data_out_o_1         (u3v_chunk_data_out) ,
   .u3v_chunk_data_out_vld_o_1     (u3v_chunk_data_out_vld),
   .u3v_chunk_data_end_o           (u3v_chunk_data_end)


 );





endmodule
