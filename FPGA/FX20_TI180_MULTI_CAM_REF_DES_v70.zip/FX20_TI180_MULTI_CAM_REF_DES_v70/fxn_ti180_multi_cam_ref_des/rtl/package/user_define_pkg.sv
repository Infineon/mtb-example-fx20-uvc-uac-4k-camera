//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    user_define_pkg
// Target Devices: All
//
// Description: This is the package file and it contains the user defined or
//              global variables, structures or functions which may be used by
//              all the modules. To access all the defined variables, this
//              package must be included in respective module.
//
//////////////////////////////////////////////////////////////////////////////////

// If this package is not defined, it will be defined here.
`ifndef user_define_pkg

  `define user_define_pkg

// User defined Parameters.
package user_define_pkg;

//----------------------------------------------------
//
//  Parameters for FV LV (Test Pattern) Generator
//
//----------------------------------------------------

// Parameter for adding FV LV Generator module.
// Possible Values are "TRUE" or "FALSE".
parameter FV_LV_GENERATION = "TRUE";

// Whether to generate incremental data pattern or
// regular colorbar data.
// Possible Values are "TRUE" or "FALSE".
parameter INCREMENTAL_DATA_PATTERN = "FALSE";

// Clock Value For FV LV Generator in Hz.
parameter INTERNAL_TEST_PATTERN_CLOCK_VALUE = 156_000_000;

// Whether to generate fixed FPS data or
// based on clock (dynamic).
// Possible Values are "FIXED_FPS" or "MAX_FPS".
parameter FV_LV_GENERATION_MODE = "FIXED_FPS";

// Whether to generate moving block data or not
// Possible Values are "TRUE" or "FALSE".
parameter MOVING_BLOCK_EN = "FALSE";

// Moving square block colors in hex in VYUY and RGB format.
// Try to keep values different than bars.
parameter VYUY_NAVY = 32'h8010_C010;

parameter RGB_NAVY  = 24'h10_00_81;

parameter VYUY_MUSTARD = 32'hA0A0_40A0;

parameter RGB_MUSTARD  = 24'hCD_9F_2E;

parameter VYUY_LIME = 32'h40C0_20C0;

parameter RGB_LIME  = 24'h65_FF_15;

parameter VYUY_FUSHCIA = 32'hF060_E060;

parameter RGB_FUSHCIA  = 24'hFD_00_FF;

parameter VYUY_FOREST = 32'h6040_6040;

parameter RGB_FOREST  = 24'h12_61_07;

parameter VYUY_GREY = 32'h8060_8060;

parameter RGB_GREY  = 24'h60_60_60;

parameter [NO_OF_SUPPORTED_DEV-1:0] [31:0] MOVING_BLOCK_COLOR_VYUY_VALUE = {VYUY_NAVY, VYUY_MUSTARD, VYUY_FOREST, VYUY_GREY};

parameter [NO_OF_SUPPORTED_DEV-1:0] [31:0] MOVING_BLOCK_COLOR_RGB_VALUE  = {RGB_NAVY, RGB_MUSTARD, RGB_FOREST, RGB_GREY};

// Frame Blanking Interval in terms of
// number of lines.
parameter NO_OF_LINES_IN_FRAME_BLANKING = 40;

// Number of Line Blanking clock cycles.
parameter TEST_PATTERN_LINE_BLANK_CLOCK_CYCLES = 140;

// FV LV Generator Data Width.
parameter INTERNAL_TEST_PATTERN_DATA_WIDTH = 64;


//----------------------------------------------------
//
//  Parameters for GPIF TX IP
//
//----------------------------------------------------

// GPIF Clock in Hz.
parameter GPIF_M_CLK_VALUE = 148_500_000;

// GPIF Master Mode: LVDS or LVCMOS.
// Posible Values: "LVCMOS_SDR", "LVCMOS_DDR" or "LVDS".
parameter GPIF_MASTER_MODE = "LVDS";

// Parameter to select the GPIF link type.
// Possible values "WIDE", "NARROW_PORT_0" or "NARROW_PORT_1".
parameter GPIF_LINK_TYPE = "WIDE";

// Parameter to choose 2BIT or 5BIT SlaveFIFO.
// Possible Values are "2BIT" or "5BIT" or "FV_LV"
parameter LVCMOS_SLFIFO_MODE = "2BIT";

// LVDS PHY Training Interval in micro seconds.
parameter LVDS_PHY_TS_TIME_IN_US = 10000;   // 10 ms

// LVDS Gear Ratio.
parameter LVDS_TX_GEAR_RATIO = 8;

// Supported Data Lanes in LVCMOS or LVDS mode.
// In LVDS wide link, it is 16. In narrow link, it is 8.
// In LVCMOS wide link, it is 32. In narrow link, it is 16.
// "GPIF_DATA_WIDTH_IN_BITS" parameter will take care of LVCMOS SDR or DDR mode.
parameter TOTAL_DATA_LANES = ( ( GPIF_MASTER_MODE == "LVDS" ) ? ( ( GPIF_LINK_TYPE == "WIDE" ) ? 16 : 8 ) : ( ( GPIF_LINK_TYPE == "WIDE" ) ? 32 : 16 ) );

// Active LVDS Data Lane MSBit value.
parameter ACTIVE_LVDS_DATA_LANE_MASK_MSB = ( ( GPIF_LINK_TYPE == "NARROW_PORT_0" ) ? 7 : 15 );

// Active LVDS Data Lane LSBit value.
parameter ACTIVE_LVDS_DATA_LANE_MASK_LSB = ( ( GPIF_LINK_TYPE == "NARROW_PORT_1" ) ? 8 : 0 );

// FPGA Serializer needs LSBit first and FX10 needs MSBit first.
// 1 = LSBit first.
// 0 = MSBit first.
parameter TX_SERIALIZER_LSB_FIRST = 1;

// GPIF Data Width in bits.
parameter GPIF_DATA_WIDTH_IN_BITS = ( ( GPIF_MASTER_MODE == "LVDS" ) ? ( TOTAL_DATA_LANES * 8 ) : TOTAL_DATA_LANES );

// FXn Address Management.
parameter ADDR_MANAGED_BY_FPGA = "TRUE";

// Number of address bits in 2 BIT and 5 BIT.
parameter NO_OF_ADDRESS_BITS = ( ( LVCMOS_SLFIFO_MODE == "5BIT" ) ? 5 : 2 );

// Slave FIFO Data Width. In case of DDR, it is double.
parameter SLFIFO_RD_DATA_WIDTH_IN_BITS = ( ( GPIF_MASTER_MODE == "LVCMOS_DDR" ) ?
                                            ( GPIF_DATA_WIDTH_IN_BITS * 2 ) :
                                            ( GPIF_DATA_WIDTH_IN_BITS )
                                          );

// Number of bytes in a single GPIF transfer.
parameter NO_OF_BYTES_PER_GPIF_XFER = SLFIFO_RD_DATA_WIDTH_IN_BITS / 8;


// ------------------------------------------
//
// I2C Slave Address and RTL Version
//
// ------------------------------------------

// Slave Address.
parameter [6:0] I2C_SLAVE_ADDR    = 7'b000_1101;

// Register Address.
parameter [3:0] RTL_MAJOR_VERSION = 4'h7;
parameter [3:0] RTL_MINOR_VERSION = 4'h0;

// ----------------------------------------------
//
// Total Number of Devices Supported by
// GPIF TX IP, I2C and Frame Buffer Handler
//
// ----------------------------------------------

// Number of Devices/FIFOs used.
parameter NO_OF_SUPPORTED_DEV = 4;

// No. of devices supported by FXn master I2C bus.
parameter NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C = NO_OF_SUPPORTED_DEV;

// No. of FXn master I2C.
// Currently we are using single FXn I2C master
// And it can support 4 different devices.
parameter NO_OF_FXN_MASTER_I2C = 1;

// Number of Devices/FIFOs used by DDR's each AXI Master
parameter NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M = ( ( ( NO_OF_SUPPORTED_DEV % 2 ) == 1'b0 ) ? ( NO_OF_SUPPORTED_DEV/2 ) : ( (NO_OF_SUPPORTED_DEV + 1)/2 ) );

// Width of Device Number
parameter SEL_DEV_NUM_BITS = ( (NO_OF_SUPPORTED_DEV == 1) ? 1 : $clog2(NO_OF_SUPPORTED_DEV) );

// Width of Devices supported by DDR's each AXI Master
parameter SEL_DEV_NUM_BITS_BY_EACH_AXI_M = ( (NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M == 1) ? 1 : $clog2(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M) );

// No. of devices supported by each FXn Master I2C bus
parameter NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C = ( NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C / NO_OF_FXN_MASTER_I2C);


// -------------------------------------------------------
//
// In multi device design, uncomment this macro
// to switch device after sending full frame.
// Comment it to switch device after sending each buffer
//
// -------------------------------------------------------

`define DEVICE_SEL_BASED_ON_FRAME

// -------------------------------------------------------
//
// Macros for adding MIPI based input sensors
//
// -------------------------------------------------------

// Number of MIPIs Instance used.
// Maximum value of MIPI here is 4
parameter NO_OF_SUPPORTED_DEV_BY_MIPI = 4;

// Parameter for selecting MIPI Data Format.
// Possible Values are "RAW12" or "RAW10".
parameter MIPI_DATA_FORMAT = "RAW12";

`define ACTIVE_DATA_EN
`define CSI_RX_4LANES          //Default 2 lanes
`define CSI_RX_LANE_DATAWIDTH   16


// -------------------------------------------------------
//
// Macros for adding HDMI based input
//
// -------------------------------------------------------

// `define HDMI_RX


endpackage

`endif

// Import this package here.
import user_define_pkg::*;

// Include Frame Buffer Handler package
 `include "fbh_define_pkg.sv"

// Include GPIF TX IP package
 `include "gpif_tx_ip_define_pkg.sv"