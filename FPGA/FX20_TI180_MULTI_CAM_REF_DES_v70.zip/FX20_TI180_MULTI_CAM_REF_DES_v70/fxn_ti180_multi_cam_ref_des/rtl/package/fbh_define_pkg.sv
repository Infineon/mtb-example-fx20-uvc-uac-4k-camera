//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fbh_define_pkg
// Target Devices: All
//
// Description: This is the package file and it contains the user defined or
//              global variables, structures or functions which may be used by
//              all the modules. To access all the defined variables, this
//              package must be included in respective module.
//
//////////////////////////////////////////////////////////////////////////////////

// If this package is not defined, it will be defined here.
`ifndef fbh_define_pkg

  `define fbh_define_pkg

package fbh_define_pkg;

// Import User Define package
import user_define_pkg::*;

// ------------------------------------------
//
// Local Parameter
//
// ------------------------------------------

// Slave FIFO Depth
parameter Y_DATA_FIFO_DEPTH_IN_WORDS = 8192;

// Slave FIFO Depth
parameter SLFIFO_DEPTH_IN_WORDS = 1024;

// Intermediate FIFO Write Data Width
parameter INTERMEDIATE_FIFO_WR_DATA_WIDTH_IN_BITS = INTERNAL_TEST_PATTERN_DATA_WIDTH;

// AXI Master Burst Size
parameter MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES = 3840;

// AXI Master Write Channel Data Width
parameter AXI_M0_WR_DATA_WIDTH_IN_BITS = 512;

// AXI Master Read Channel Data Width
parameter AXI_M0_RD_DATA_WIDTH_IN_BITS = 256;

// AXI Master Write Channel Data Width
parameter AXI_M1_WR_DATA_WIDTH_IN_BITS = 512;

// AXI Master Read Channel Data Width
parameter AXI_M1_RD_DATA_WIDTH_IN_BITS = 256;

// FIRST_BUFFER_START_ADDR for AXI0
parameter FIRST_BUFFER_START_ADDR_AXI0 = 32'h0000_0000;

// BUFFER_START_ADDR_DIFF_FOR_SAME_DEV for AXI0
// Used as address differnce between buffers for single device
parameter BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_AXI0 = 32'h0200_0000; // 32'h03F4_8000; //

// FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV for AXI0
// Used as address differnce between devices within each AXI
parameter FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_AXI0 = 32'h0800_0000; // 32'h1000_0000;

// FIRST_BUFFER_START_ADDR for AXI1
parameter FIRST_BUFFER_START_ADDR_AXI1 = 32'h1000_0000; // 32'h2000_0000;

// BUFFER_START_ADDR_DIFF_FOR_SAME_DEV for AXI1
// Used as address differnce between buffers for single device
parameter BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_AXI1  = 32'h0200_0000; // 32'h03F4_8000; //

// FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV for AXI1
// Used as address differnce between devices within each AXI
parameter FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_AXI1  = 32'h0800_0000; // 32'h1000_0000;

// Parameter for adding DDR instances. If both "FALSE"
// commented, onchip FIFO will be used as a buffer.
// Possible Values are "TRUE" or "FALSE"
parameter DDR_AXI0 = "TRUE";

// If only single device is enabled, no need for AXI1 interface.
parameter DDR_AXI1 = (NO_OF_SUPPORTED_DEV > 1) ? "TRUE" : "FALSE";

// Slave Write data count width
parameter SLFIFO_WR_COUNT_DATA_WIDTH = 16;

// Used for counters
parameter COUNTER_DATAWIDTH = 32;

// Used for Write / Read frame number data width
parameter DDR_FRAME_NUM_DATA_WIDTH = 3;

// Used for Write / Read frame number data width wrapper
parameter DDR_FRAME_NUM_DATA_WIDTH_WRAPPER = ( 2 ** DDR_FRAME_NUM_DATA_WIDTH );

// Number of bytes in a single transfer
// AXI supports up to 4K byte. Hence, it is 3840.
// For 4K, it is half line. For 1080p, it's full line.
parameter AXI_M0_XFER_LEN_IN_BYTES = MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES;

// AXI Master 0 read data width in bytes
parameter AXI_M0_RD_DATA_WIDTH_IN_BYTES  = ( AXI_M0_RD_DATA_WIDTH_IN_BITS / 8 );

// Total read burst length
parameter AXI_RD_BURST_LEN = ( AXI_M0_XFER_LEN_IN_BYTES / AXI_M0_RD_DATA_WIDTH_IN_BYTES );

// ASIZE for Master 1. 256 bits = 32 bytes
parameter [2:0] AXI_M0_ARSIZE  = 3'd5;

parameter [7:0] AXI_M0_ARLEN   = (AXI_RD_BURST_LEN - 1);

// AXI Master 0 Burst Length
parameter AXI_M0_RD_BURST_LEN = ( AXI_M0_ARLEN + 1 );

// Parameter to read DDR buffer
parameter DDR_BUFR_RD_CONSTANT = ( ( ( AXI_M0_RD_BURST_LEN ) * ( 2 ** AXI_M0_ARSIZE ) ) /* + 5'd16 */ );

// Parameter to calculate the byte address
parameter AXI_M0_RD_ADDR_INCR_FACTOR = ( 2 ** AXI_M0_ARSIZE );

// Burst type = Incremental
parameter [1:0] AXI_M0_ARBURST = 2'd1;

// Counter Increment Factor
parameter [7:0] INCR_DDR_RD_COUNT    = ( AXI_M0_RD_DATA_WIDTH_IN_BITS / 8 );

// NO OF DDR BUFFERS
parameter NO_OF_DDR_BUFFERS = 4'h4;

// NO OF DDR BUFFER DATA Width
parameter DDR_BUFFER_DW = $clog2(NO_OF_DDR_BUFFERS);

// -------------------------------------------------------------------------
//
// Structure for DDR FSM signals - Used between Read and Write FSM modules.
//
// -------------------------------------------------------------------------

  typedef struct packed {
//   logic                              frame_size_info_i;

   logic [(COUNTER_DATAWIDTH-1):0]   ddr_mem_rd_addr ;
   logic [(DDR_BUFFER_DW-1):0]       rd_frame_buf;   // AXI Read Buffer
   logic [(DDR_FRAME_NUM_DATA_WIDTH-1):0] rd_frame_num;
   logic                             ddr_mem_rd_complete;
   logic                             ddr_mem_rd_en;
   logic                             full_burst_rd_completed_o;
   logic                             full_frame_rd_completed_o;
   logic                             ddr_mem_burst_complete;

   logic [(COUNTER_DATAWIDTH-1):0]   no_of_ddr_rd_words;
   logic                             save_rdata_msw;

} fbh_rd_states_nd_ctrl_st_t;

// -------------------------------------------------------------------------
//
// Structure for DDR FSM signals - Used between Read and Write FSM modules.
//
// -------------------------------------------------------------------------
  typedef struct packed {
   // output from rd_dev_sel_fsm
   logic                             start_serving_device_pl;
   logic                             sel_rd_frame_buf;
   logic                             ddr_rd_start;  // Read DDR start
   logic                             bufr_already_selected;
} fbh_rd_dsf_flags_st_t;

// -------------------------------------------------------------------------
//
// Structure for DDR FSM signals - Used between Read and Write FSM modules.
//
// -------------------------------------------------------------------------

  typedef struct packed {
   logic [(DDR_FRAME_NUM_DATA_WIDTH-1):0] wr_frame_num;  // AXI Write Buffer Num
   logic [(DDR_BUFFER_DW-1):0]       wr_frame_buf;
   logic [32:0]                      axi_m0_awaddr; // AXI Write Buffer current Address
   logic [(COUNTER_DATAWIDTH-1):0]   ddr_mem_y_data_bufr_wr_addr;
} fbh_wr_addr_nd_ctrl_st_t;


// ------------------------------------------
//
// Structure for slFIFO signals.
//
// ------------------------------------------

  typedef struct packed {
   // SLFIFO OUT Signals
   logic                                      full;
   logic                                      almost_full;
   logic                                      almost_empty;
   logic                                      rd_data_valid;
   logic                                      reset_busy;

   logic [(SLFIFO_WR_COUNT_DATA_WIDTH-1):0]   rd_data_count;
   logic [(SLFIFO_WR_COUNT_DATA_WIDTH-1):0]   wr_data_count;
   logic [(SLFIFO_RD_DATA_WIDTH_IN_BITS-1):0] rd_data;
//   logic [(TOTAL_LVDS_DATA_LANES_I*LVDS_TX_GEAR_RATIO_I)-1:0] rd_data;

} slfifo_data_nd_status_st_t;

  typedef struct packed {
   // SLFIFO IN Signals
   logic                                        rd_req;
   logic                                        reset_req;
   logic                                        wr_en;
   logic [(AXI_M0_RD_DATA_WIDTH_IN_BITS-1):0]   wr_data;

} slfifo_ctrl_req_st_t;


endpackage

`endif

// Import this package here.
import fbh_define_pkg::*;