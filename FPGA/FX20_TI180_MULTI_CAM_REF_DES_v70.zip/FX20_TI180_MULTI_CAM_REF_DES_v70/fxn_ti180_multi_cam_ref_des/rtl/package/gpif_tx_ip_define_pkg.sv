//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10 Design
// Module Name:    gpif_tx_ip_define_pkg
// Target Devices: T120 and Ti180
//
// Description: This is the package file and it contains the user defined or
//              global variables, structures or functions which may be used by
//              all the modules. To access all the defined variables, this
//              package must be included in respective module.
//
//////////////////////////////////////////////////////////////////////////////////

// If this package is not defined, it will be defined here.
`ifndef gpif_tx_ip_define_pkg

  `define gpif_tx_ip_define_pkg

package gpif_tx_ip_define_pkg;

// Import User Define package
import user_define_pkg::*;

// Timescale
`timescale 1ns/100ps

// ------------------------------------------
//
// Local Parameter
//
// ------------------------------------------

// Number of clocks required to transmit a byte
parameter NO_OF_CLK_REQ_FOR_BYTE = ( 4'd8 / LVDS_TX_GEAR_RATIO );

// UVC Frame Header Length
parameter UVC_HEADER_LENGTH_IN_BYTES = 8'd32;

// UVC Frame Header Length with Event Counter as Event Counter is of 4 bytes
parameter UVC_HEADER_LEN_WITH_EVENT_COUNTERS = UVC_HEADER_LENGTH_IN_BYTES + 3'd4;

// Typedef structure for common registers' signals
typedef struct packed {

  logic         uvc_stream_mode_en;
  logic         tx_header_info_as_payload;
  logic         tx_header_info_as_metadata;
  logic [ 7:0]  lvds_phy_training_seq;
  logic [ 7:0]  training_block_seq_p0;
  logic [ 7:0]  training_block_seq_p1;
  logic [ 7:0]  training_block_seq_p2;
  logic [ 7:0]  training_block_seq_p3;
  logic [ (NO_OF_SUPPORTED_DEV-1):0]  acive_dev_mask;
  logic         l1_lp_mode_en;
  logic         l3_lp_mode_en;
  logic         lvds_phy_training_en;
  logic         link_training_en;
  logic         phy_training_completed;
  logic         p0_link_training_completed;
  logic         p1_link_training_completed;
  logic [ 7:0]  lvds_clk_selection;


} common_reg_info_st_t;


// Typedef structure for device specific registers - For i2c-slave Mod
typedef struct packed {

  logic [ 7:0] stream_en;
  logic [ 7:0] mode_en;
  logic [15:0] image_height_info;
  logic [15:0] image_width_info;
  logic [ 7:0] frame_rate_info;
  logic [ 7:0] image_pixel_width_info;
  logic [ 7:0] source_type_info;
  logic [ 7:0] status_info;
  logic [ 7:0] mipi_status_info;
  logic [ 7:0] hdmi_mipi_source_info;
  logic [ 7:0] u3v_stream_mode;
  logic [ 7:0] u3v_chunk_mode;
  logic [ 7:0] u3v_trigger_info;
  logic [ 7:0] active_thread_info;
  logic [ 7:0] thread_1_info;
  logic [ 7:0] thread_2_info;
  logic [ 7:0] thread_1_socket_info;
  logic [ 7:0] thread_2_socket_info;
  logic [ 7:0] c_n_crc_info;
  logic [ 7:0] flag_info;
  logic [ 7:0] counters_and_crc_info;
  logic [15:0] buffer_size_info;

} dev_reg_st_t;


// Typedef structure for device specific register signals
typedef struct packed {

  logic        vsync;
  logic        socket_addr_same_for_dev;
  // logic        reset_or_stop_stream_req;
  // logic        start_ddr_wr_xfer;
  // logic        start_stream_v;

  logic        fw_soft_reset;
  logic        start_stream;
  logic        stop_stream_immideate;

  logic        interleaved_mode_en;
  logic        still_capture_mode_en;
  logic        mono8_conversion_mode_en;
  logic        yuv422_420_conversion_mode_en;

  logic [15:0] image_height;
  logic [15:0] image_width;
  logic [ 7:0] image_fps;
  logic [ 7:0] image_pixel_width;

  logic        internal_tp_en;
  logic        hdmi_source_en;
  logic        mipi_source_en;

  logic        u3v_continuous_mode;
  logic        u3v_single_frame_mode;
  logic        u3v_multi_frame_mode;
  logic [ 4:0] u3v_no_of_frame_in_multi_frame_mode;

  logic        hdmi_source_connection;
  logic        hdmi_mode_rgb;
  logic        mipi_isp_en;
  logic        mipi_image_crop_en;
  logic        hdmi_channel_info;

  logic        u3v_chunk_mode_en;
  logic        u3v_frame_id_chunk_type;
  logic        u3v_time_stamp_chunk_type;

  logic        u3v_trigger_mode_en;
  logic        u3v_trigger_type;
  logic        u3v_sw_trigger;
  logic [ 3:0] u3v_hw_trigger;

  logic [ 1:0] active_thread;
  logic [ 1:0] thread_1_info;
  logic [ 1:0] thread_2_info;
  logic [ 4:0] c_n_crc_info;
  logic [ 2:0] thread_1_socket_info;
  logic [ 2:0] thread_2_socket_info;
  logic [ 3:0] flag_info;
  logic [ 1:0] thread_num;
  logic [ 1:0] thread_addr;
  logic [ 2:0] socket_addr;
  logic [15:0] buffer_size_info;

} dev_reg_info_st_t;

// Typedef structure for i2c related signals
  typedef struct packed {
   // Master I2C bus out signals
   logic                                        scl_o;
   logic                                        scl_en_o;
   logic                                        sda_o;
   logic                                        sda_en_o;

} i2c_bus_out_st_t;

 typedef struct packed {
   // Master I2C bus in signals
   logic                                        scl_i;
   logic                                        sda_i;

} i2c_bus_in_st_t;


  typedef struct packed {
   // Cam I2C bus out signals
   logic                                        scl_o;
   logic                                        scl_en_o;
   logic                                        sda_o;
   logic                                        sda_en_o;

} cam_i2c_bus_out_st_t;

 typedef struct packed {
   // Cam I2C bus in signals
   logic                                        sda_i;

} cam_i2c_bus_in_st_t;

  typedef struct packed {
   // Cam I2C bus temporary signals
   logic                                        sda;
   logic                                        oe;

} cam_i2c_bus_temp_var_st_t;

endpackage

`endif

// Import this package here.
import gpif_tx_ip_define_pkg::*;
