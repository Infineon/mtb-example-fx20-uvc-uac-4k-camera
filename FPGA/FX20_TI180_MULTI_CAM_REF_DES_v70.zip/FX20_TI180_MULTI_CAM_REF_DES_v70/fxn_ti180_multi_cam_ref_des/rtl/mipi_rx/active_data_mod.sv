//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    active_data_mod
// Target Devices: All
//
// Description: This module basically does cropping of active data from total.
//
//
//////////////////////////////////////////////////////////////////////////////////

// `define ADD_DEBUG

module active_data_mod
  #
  (
   // Data Width for Video Data
   parameter DATA_WIDTH_I = 8'd64,

   // MIPI Data format
   parameter MIPI_DATA_FORMAT_I = "RAW12"

  )
  (
   input                           clk_i,
   input                           rstn_i,

   input                           line_valid_i,
   input                           frame_valid_i,
   input                           data_enable_i,
   input  [(DATA_WIDTH_I-1) :0]    data_i,
   input  [ 5:0]                   data_type_i,
   input  [15:0]                   image_width_i,
   input  [15:0]                   image_height_i,
   input  [ 3:0]                   pixels_per_clock_i,

   output  logic                   frame_valid_o,
   output  logic                   data_valid_o,
   output  logic [(DATA_WIDTH_I-1) :0]  data_o


  );

//----------------------------------
//
// Local Variables
//
//----------------------------------

logic  [23:0]      count_de;
logic  [23:0]      count_lv;
logic  [23:0]      count_fv;
logic  [23:0]      line_counter;
logic  [23:0]      pixel_counter;
logic  [23:0]      embedded_pixel_counter;
logic  [23:0]      embedded_bytes_counter;
logic  [31:0]      fv_lv_generator_count;

logic  [23:0]      embedded_ob_counter;
logic  [23:0]      embedded_ob_counter_f1;
logic  [23:0]      embedded_ob_counter_f2;

logic  [(DATA_WIDTH_I-1) :0]    data_f1;
logic  [(DATA_WIDTH_I-1) :0]    data_f2;
logic  [(DATA_WIDTH_I-1) :0]    data_f3;
logic  [(DATA_WIDTH_I-1) :0]    data_f4;

logic  [ 5:0]      data_type_f1;
logic  [ 5:0]      data_type_f2;
logic  [ 5:0]      data_type_f3;
logic  [ 5:0]      data_type_f4;

logic  [ 3:0]      pixels_per_clock_f1;
logic  [ 3:0]      pixels_per_clock_f2;
logic  [ 3:0]      pixels_per_clock_f3;
logic  [ 3:0]      pixels_per_clock_f4;


logic              line_valid_f1;
logic              line_valid_f2;
logic              line_valid_pe;

logic              frame_valid_f1;
logic              frame_valid_f2;
logic              frame_valid_f3;

logic              data_enable_f1;
logic              data_enable_f2;
logic              data_enable_f3;
logic              data_enable_f4;


logic              active_lines_embedded = 1'd0;
logic              active_lines_embedded_f1 ;
logic              active_lines_embedded_f2 ;


logic              active_lines_ob = 1'd0;
logic              active_lines_ob_f1;
logic              active_lines_ob_f2;

logic              active_lines = 1'd0;
logic              active_lines_f1;
logic              active_lines_f2;

logic              active_pixels = 1'd0;

// Delayed by 2 FFs to match the final output data
always_ff @ ( posedge clk_i )
  begin

    embedded_ob_counter_f1 <= embedded_ob_counter;
    embedded_ob_counter_f2 <= embedded_ob_counter_f1;

  end

 // Delayed by 2 FFs for counting lines
always_ff @ ( posedge clk_i )
  begin

    line_valid_f1 <= line_valid_i;
    line_valid_f2 <= line_valid_f1;
    line_valid_pe <= line_valid_i && (!line_valid_f1);

  end

 // Delayed by 4 FFs to match the final output data
always_ff @ ( posedge clk_i )
  begin

    frame_valid_f1 <= frame_valid_i;
    frame_valid_f2 <= frame_valid_f1;
    frame_valid_f3 <= frame_valid_f2;
    frame_valid_o  <= frame_valid_f3;

  end

 // Delayed by 4 FFs to match the final output data
always_ff @ ( posedge clk_i )
  begin

    data_enable_f1 <= data_enable_i;
    data_enable_f2 <= data_enable_f1;
    data_enable_f3 <= data_enable_f2;
    data_enable_f4 <= data_enable_f3;

  end

 // Delaying the incoming data
always_ff @ ( posedge clk_i )
  begin

    data_f1 <= data_i;
    data_f2 <= data_f1;

    data_f4 <= data_f3;

  end

 // Taking care of data based on type of lines such as embedded, ob , active.
always_ff @ ( posedge clk_i )
  begin
    if ( ( active_lines_embedded || active_lines_ob ) && data_enable_f2 )
      begin
        data_f3[15:0]  <= data_f2[15:0]  ;
        data_f3[31:16] <= data_f2[31:16] ;
        data_f3[47:32] <= data_f2[47:32] ;
        data_f3[63:48] <= data_f2[63:48] ;
      end
    else if ( ( active_lines_embedded || active_lines_ob ) && (!data_enable_f2) && ( ( embedded_ob_counter >= 24'd8) && (embedded_ob_counter <= 24'd1928 ) ) )
      begin
        data_f3[15:0]  <= data_f2[15:0];
        data_f3[31:16] <= data_f2[31:16];
        data_f3[47:32] <= data_f2[47:32];
        data_f3[63:48] <= data_f2[63:48];
      end
    else if ( active_lines )
      begin
        if ( MIPI_DATA_FORMAT_I == "RAW10" )
          begin
            data_f3[15:0]  <= { data_f2[ 9:0 ], 6'h0} ;
            data_f3[31:16] <= { data_f2[19:10], 6'h0} ;
            data_f3[47:32] <= { data_f2[29:20], 6'h0} ;
            data_f3[63:48] <= { data_f2[39:30], 6'h0} ;
          end
        else
          begin
            data_f3[15:0]  <= { data_f2[11:0 ], 4'h0} ;
            data_f3[31:16] <= { data_f2[23:12], 4'h0} ;
            data_f3[47:32] <= { data_f2[35:24], 4'h0} ;
            data_f3[63:48] <= { data_f2[47:36], 4'h0} ;
          end
      end
    else
      data_f3 <= 64'hAAAABBBBCCCCDDDD;
  end

// Generating counter to add extra bytes in the blanking time of
// data enable to make total bytes same for all lines
// 4 clock cycle delay has been used for data_type
// because of differnce between pixel_per_clock and data_type
always_ff @ ( posedge clk_i )
  begin
    if ( ~rstn_i )
      begin
        embedded_ob_counter <= 24'd0;
      end
    else
      begin
        if ( ( data_type_f4 != data_type_f3 ) || line_valid_pe )       //line_valid_pe
          embedded_ob_counter <= 24'd0;
        else if ( ( active_lines_embedded || active_lines_ob ) && ( !data_enable_f2 ) && ( embedded_ob_counter <= 24'd1928 ) ) //(data_enable && line_valid_i) /
          embedded_ob_counter <= embedded_ob_counter + pixels_per_clock_f2;
        else
          embedded_ob_counter <= embedded_ob_counter;
      end
  end

// Using 4 FFs for data to align final data valid with data
always_ff @ ( posedge clk_i )
  begin

    data_type_f1 <= data_type_i;
    data_type_f2 <= data_type_f1;
    data_type_f3 <= data_type_f2;
    data_type_f4 <= data_type_f3;

  end

 // Delayed by 4 FFs to match the final output data
always_ff @ ( posedge clk_i )
  begin

    pixels_per_clock_f1 <= pixels_per_clock_i;
    pixels_per_clock_f2 <= pixels_per_clock_f1;
    pixels_per_clock_f3 <= pixels_per_clock_f2;
    pixels_per_clock_f4 <= pixels_per_clock_f3;

  end

// Counter to count the total bytes in one line

always_ff @ ( posedge clk_i )
  begin
    if ( line_valid_i )
      count_lv <= count_lv + 4'd6;
    else
      count_lv <= 24'd0;
  end


// Bytes in a Frame - Counter

always_ff @ ( posedge clk_i )
  begin
    if ( ~rstn_i )
      begin
        count_fv <= 24'd0;
      end
    else
      begin
        if ( frame_valid_i )
          begin
            if ( data_enable_i &&  line_valid_i )
              count_fv <= count_fv + 4'd6;
            else
              count_fv <= count_fv;
          end
        else
          count_fv <= 24'd0;
      end
  end

// Number of lines in a frame

always_ff @ ( posedge clk_i )
  begin

    if ( ~rstn_i )
      begin
        line_counter <= 24'd0;
      end
    else
      begin
        if ( frame_valid_i )
          begin
            if ( line_valid_i && ( !line_valid_f1 ) ) //(out_de && cmos_lv) /
              line_counter <= line_counter+1'd1;
            else
              line_counter <= line_counter;
          end
        else
          line_counter <= 24'd0;
      end

  end

//Generating the signal for embedded line based on counter and data_type

always_ff @ ( posedge clk_i )
  begin
    if ( ~rstn_i )
      begin
        active_lines_embedded <= 24'd0;
      end
    else
      begin
        if ( ( line_counter == 24'd0 ) && ( data_type_f4 == 5'h12 ) ) // 30 - 1109 //50 2225
          begin
            active_lines_embedded <= 1'd1;
          end
        else
          active_lines_embedded <= 1'd0;
      end
  end

// Delaying  active_lines_embedded by 2FFs to match the output data.
always_ff @ ( posedge clk_i )
  begin

    active_lines_embedded_f1 <= active_lines_embedded;
    active_lines_embedded_f2 <= active_lines_embedded_f1;

  end

//Generating the signal for optical black line based on line_counter
always_ff @ ( posedge clk_i )
  begin
    if ( ~rstn_i )
      begin
        active_lines_ob <= 24'd0;
      end
    else if ( image_height_i == 16'd1080 && image_width_i == 16'd1920 )
      begin
        if ( ( line_counter >= 24'd1 ) && ( line_counter <= 24'd18 ) ) // 30 - 1109 //50 2225
          begin
            active_lines_ob <= 1'd1;
          end
        else
          active_lines_ob <= 1'd0;
      end
    else
      begin
        if ( ( line_counter >= 24'd1 ) && ( line_counter <= 24'd36 ) ) // 30 - 1109 //50 2225
          begin
            active_lines_ob <= 1'd1;
          end
        else
          active_lines_ob <= 1'd0;
      end
  end

// Delaying  active_lines_ob by 2FFs to match the output data
always_ff @ ( posedge clk_i )
  begin

    active_lines_ob_f1 <= active_lines_ob;
    active_lines_ob_f2 <= active_lines_ob_f1;

  end

//Generating the signal for active lines based on line_counter
always_ff @ ( posedge clk_i )
  begin
    if ( ~rstn_i )
      begin
        active_lines <= 24'd0;
      end
    else if ( image_height_i == 16'd1080 && image_width_i == 16'd1920 )
      begin
        if ( ( line_counter >= 24'd31 ) && ( line_counter <= 24'd1110 ) ) // 31 - 1110 //59 2218
          begin
            active_lines <= 1'd1;
          end
        else
          active_lines <= 1'd0;
      end
    else
      begin
        if ( ( line_counter >= 24'd59 ) && ( line_counter <= 24'd2218 ) ) // 31 - 1110 //59 2218
          begin
            active_lines <= 1'd1;
          end
        else
          active_lines <= 1'd0;
      end
  end

// Delaying  active_lines by 2FFs to match the output data
always_ff @ ( posedge clk_i )
  begin

    active_lines_f1 <= active_lines;
    active_lines_f2 <= active_lines_f1;

  end


// Counter for counting pixels in embedded line

always_ff @ ( posedge clk_i )
  begin
    if ( ~rstn_i )
      begin
        embedded_pixel_counter <= 24'd0;
      end
    else
      begin
        if ( active_lines_embedded )
          begin
            if( data_enable_f2 )
              embedded_pixel_counter <= embedded_pixel_counter + pixels_per_clock_f2;
            else if ( ( !data_enable_f2 ) && ( ( embedded_ob_counter >= 24'd8 ) && ( embedded_ob_counter <= 24'd1928 ) ) )
              embedded_pixel_counter <= embedded_pixel_counter + pixels_per_clock_f2;
            else
              embedded_pixel_counter <= embedded_pixel_counter;
          end
        else
          embedded_pixel_counter <= 24'd0;
      end
  end

// Counting number of pixels in one line for ob lines and active lines.

always_ff @ ( posedge clk_i )
  begin
    if ( ~rstn_i )
      begin
        pixel_counter <= 24'd0;
      end
    else
      begin
        if ( line_valid_f2 )
          begin
            if ( active_lines_ob )
              begin
                if ( data_enable_f2 )
                  pixel_counter <= pixel_counter + pixels_per_clock_f2;
                else if ( ( !data_enable_f2 ) && ( ( embedded_ob_counter >= 24'd8 ) && ( embedded_ob_counter <= 24'd1928 ) ) )
                  pixel_counter <= pixel_counter + pixels_per_clock_f2;
                else
                  pixel_counter <= pixel_counter;
              end
        else if ( active_lines )
          begin
            if ( data_enable_f2 )
              pixel_counter <= pixel_counter + pixels_per_clock_f2;
            else
              pixel_counter <= pixel_counter;
          end
          end
        else
          pixel_counter <= 24'd0;
      end
  end

// Generating the active pixels signal based on pixel counter and active line signals

always_ff @ ( posedge clk_i )
  begin
    if ( ~rstn_i )
      begin
        active_pixels <= 24'd0;
      end
    else if ( active_lines_embedded_f1 )
      begin
        if ( ( embedded_pixel_counter > 24'd0 ) && ( embedded_pixel_counter <= 24'd7724 ) )
          begin
            active_pixels <= 1'd1;
          end
        else
          active_pixels <= 1'd0;
      end
    else if ( active_lines_ob_f1 )
      begin
        if ( ( pixel_counter > 24'd0 ) && ( pixel_counter <= 24'd7724 ) )
          begin
            active_pixels <= 1'd1;
          end
        else
          active_pixels <= 1'd0;
      end

    else if ( active_lines_f1 )
      begin
        if ( image_height_i == 16'd1080 && image_width_i == 16'd1920 )
          begin
            if ( ( pixel_counter > 24'd0 ) && ( pixel_counter <= 24'd1920 ) ) // 30 - 1109
              begin
                active_pixels <= 1'd1;
              end
            else
              active_pixels <= 1'd0;
          end
        else
          begin
            if ( ( pixel_counter > 24'd12 ) && ( pixel_counter <= 24'd3852 ) ) // 30 - 1109
              begin
                active_pixels <= 1'd1;
              end
            else
              active_pixels <= 1'd0;
          end
      end
  end

// Counter for counting total no. of bytes in one frame
always_ff @ ( posedge clk_i )
  begin
    if ( ~rstn_i )
      begin
        fv_lv_generator_count <= 32'd0;
      end
    if ( !frame_valid_o )
      begin
        fv_lv_generator_count <= 32'd0;
      end
    /*else if ( ( active_lines_embedded_f2 || active_lines_ob_f2 ) && data_enable_f4  && active_pixels )
      begin
        fv_lv_generator_count <= fv_lv_generator_count + pixels_per_clock_f4 ;
      end
    else if ( ( active_lines_embedded_f2 || active_lines_ob_f2 ) && (!data_enable_f4) && ( ( embedded_ob_counter_f2 >= 24'd8 ) && ( embedded_ob_counter_f2 <= 24'd1928 ) )   && active_pixels )
      begin
        fv_lv_generator_count <= fv_lv_generator_count + pixels_per_clock_f4 ;
      end*/
    else if ( active_lines_f2 && data_enable_f4  && active_pixels )
      begin
        fv_lv_generator_count <= fv_lv_generator_count + 4'd8 ;
      end
  end

// Generating final data valid signal
  assign data_valid_o = ( /*( ( active_lines_embedded_f2 || active_lines_ob_f2 ) &&
                              data_enable_f4  &&
                              active_pixels ) ||
                          ( ( active_lines_embedded_f2 || active_lines_ob_f2 ) &&
                            ( !data_enable_f4 ) &&
                            ( embedded_ob_counter_f2 >= 24'd8 ) && ( embedded_ob_counter_f2 <= 24'd1928 )   &&
                              active_pixels ) ||*/
                            ( active_lines_f2 &&
                              data_enable_f4  &&
                              active_pixels ) );

// Assigning the data output.
  assign data_o = data_f4;


endmodule
