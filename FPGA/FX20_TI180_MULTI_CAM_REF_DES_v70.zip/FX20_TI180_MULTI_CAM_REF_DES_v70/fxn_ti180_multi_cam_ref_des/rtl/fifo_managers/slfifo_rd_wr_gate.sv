//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    slfifo_rd_wr_gate
// Target Devices: Ti180
//
// Description: This module acts as a gate to read and write the data from/to
//              Slave FIFO.
//
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns/100ps

module slfifo_rd_wr_gate
  #
  (
   // Write data width is same as read data width of DDR
   parameter SLFIFO_WR_DATA_WIDTH_IN_BITS_I = 256,

   // Read data width
   parameter SLFIFO_RD_DATA_WIDTH_IN_BITS_I = 64,

   // Write count data width
   parameter SLFIFO_WR_COUNT_DATA_WIDTH_I = 16,

   // Maximum AXI Burst Length
   parameter MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I = 3840,

   // Depth of FIFO
   parameter SLFIFO_DEPTH_IN_WORDS_I = 512
  )
 (
  input              wr_clk,
  input              rd_reset_n,
  input              rd_clk,

  input              slfifo_reset_req_i,
  input              sel_d_reset_or_stop_stream_req_i,
  input              slfifo_wr_req_i,
  input              slfifo_rd_req_i,
  input      [(SLFIFO_WR_DATA_WIDTH_IN_BITS_I-1):0] slfifo_wr_data_i,

  output logic       slfifo_rd_data_valid_o,
  output             slfifo_almost_full_o,
  output             slfifo_empty_o,
  output             slfifo_full_o,
  output             slfifo_almost_empty_o,
  output             slfifo_reset_busy_o,
  output     [(SLFIFO_RD_DATA_WIDTH_IN_BITS_I-1):0] slfifo_rd_data_o,
  output     [(SLFIFO_WR_COUNT_DATA_WIDTH_I-1):0] slfifo_wr_data_count_o,
  output     [(SLFIFO_WR_COUNT_DATA_WIDTH_I-1):0] slfifo_rd_data_count_o

  // output             full_frame_rd_complete_wo_bufr_o

 );

// ------------------------------------------
//
// Variable
//
// ------------------------------------------

  logic slfifo_reset_req;

// ------------------------------------------
//
// Slave FIFO
//
// ------------------------------------------

// Asynchronous FIFO
// Write Data Width is 256
// Read Data Width is 32
// Depth is 512
// Almost empty flag: 11 and 10

slfifo_buffer
 #
 (
  // Parameters
  .WR_DATA_WIDTH_IN_BITS_I      ( SLFIFO_WR_DATA_WIDTH_IN_BITS_I ), // As of now, AXI0 is used
  .RD_DATA_WIDTH_IN_BITS_I      ( SLFIFO_RD_DATA_WIDTH_IN_BITS_I ),
  .SLFIFO_WR_COUNT_DATA_WIDTH_I ( SLFIFO_WR_COUNT_DATA_WIDTH_I ),
  .FIFO_DEPTH_IN_WORDS_I        ( SLFIFO_DEPTH_IN_WORDS_I ),
  .MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I (MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I)
 )
  u_slfifo_buffer
  (
   .almost_full_o    (  ),
   .prog_full_o      ( slfifo_almost_full_o ),
   .full_o           ( slfifo_full_o ),
   .overflow_o       (  ),
   .wr_ack_o         (  ),
   .empty_o          ( slfifo_empty_o ),
   .almost_empty_o   ( /*slfifo_almost_empty_o*/ ),
   .prog_empty_o     ( slfifo_almost_empty_o ), // Original Logic
   .underflow_o      (  ),
   .rd_valid_o       (  ),
   .rdata            ( slfifo_rd_data_o ),
   .wr_clk_i         ( wr_clk ),
   .rd_clk_i         ( rd_clk ),
   .wr_en_i          ( slfifo_wr_req_i ),
   .rd_en_i          ( slfifo_rd_req_i ),
   .wdata            ( slfifo_wr_data_i ),
   .wr_datacount_o   ( slfifo_wr_data_count_o ),
   .rd_datacount_o   ( slfifo_rd_data_count_o ),
   .a_rst_i          ( slfifo_reset_req ),
   .rst_busy         ( slfifo_reset_busy_o )
  );

// ------------------------------------------
//
// Slave FIFO Active High Reset
//
// ------------------------------------------

always_ff @ ( posedge rd_clk  )
  begin
    if ( !rd_reset_n )
      begin
        slfifo_reset_req <= 1'b1;
      end
    else
      begin
        slfifo_reset_req <= ( slfifo_reset_req_i | sel_d_reset_or_stop_stream_req_i );
      end
  end

// ------------------------------------------
//
// Read Data Valid
//
// ------------------------------------------

// The FIFO read data is not registered here. Hence, data valid
// is just a flop of read request.
always_ff @ ( posedge rd_clk  )
  begin
    if ( !rd_reset_n )
      begin
        slfifo_rd_data_valid_o <= 1'b0;
      end
    else
      begin
        slfifo_rd_data_valid_o <= slfifo_rd_req_i;
      end
  end

// -------------------------------------
//
// Debug
//
// -------------------------------------

// reg [31:0] sl_fifo_wr_count;
// reg [31:0] sl_fifo_rd_count;
// reg [31:0] sl_fifo_empty_counter;
//
// assign full_frame_rd_complete_wo_bufr_o = (sl_fifo_rd_count == 32'hFD_2000);
//
// always_ff @ ( posedge wr_clk )
//   begin
//     if ( slfifo_reset_req_i )
//       begin
//         sl_fifo_wr_count <= 32'd0;
//       end
//     else if ( slfifo_wr_req_i )
//       begin
//         sl_fifo_wr_count <= sl_fifo_wr_count + (SLFIFO_WR_DATA_WIDTH_IN_BITS_I/8);
//       end
//   end
//
// always_ff @ ( posedge rd_clk  )
//   begin
//     if ( ~rd_reset_n )
//       begin
//         sl_fifo_rd_count <= 32'd0;
//       end
//     else if ( slfifo_reset_req_i )
//       begin
//         sl_fifo_rd_count <= 32'd0;
//       end
//     else if ( slfifo_rd_req_i )
//       begin
//         sl_fifo_rd_count <= sl_fifo_rd_count + (SLFIFO_RD_DATA_WIDTH_IN_BITS_I/8);
//       end
//   end
//
// // Counter to find out not empty time
// always_ff @ ( posedge rd_clk  )
//   begin
//     if ( ~rd_reset_n )
//       begin
//         sl_fifo_empty_counter <= 32'd0;
//       end
//     else if ( slfifo_empty_o )
//       begin
//         sl_fifo_empty_counter <= 32'd0;
//       end
//     else
//       begin
//         sl_fifo_empty_counter <= sl_fifo_empty_counter + 1'd1;
//       end
//   end

endmodule