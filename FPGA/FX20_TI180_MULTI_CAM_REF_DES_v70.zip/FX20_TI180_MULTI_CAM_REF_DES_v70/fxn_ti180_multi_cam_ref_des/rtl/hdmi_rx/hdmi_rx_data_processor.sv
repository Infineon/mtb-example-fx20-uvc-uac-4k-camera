//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:  FX10/20 Design
// Module Name:  hdmi_rx_data_processor
// Target Devices: T120 and Ti180
//
// Description: In this module, HDMI data is sampled, converted into single edged
//              and re-aligned as per the data width requirement of FIFO in which
//              it is stored.
//
//////////////////////////////////////////////////////////////////////////////////

// Include the package file
`include "package/user_define_pkg.sv"

module hdmi_rx_data_processor
  #
  (
   // Data width of received data
   parameter HDMI_RX_DATA_WIDTH_I = 128
  )
  (
   // Inputs
   input          hdmi_clk,                         // 148.5 MHz PLL clock

   input          hdmi_reset_n,                     // Active Low Reset Sychronised to "hdmi_clk"
   input          hdmi_clk_lock_i,                  // HDMI Clock PLL Lock

   // input          hdmi_channel_info_hdmi_clk_i,
   // input          hdmi_mode_rgb,

   // HDMI rx input
   input  [  7:0] hdmi_y0_i,
   input  [  7:0] hdmi_y1_i,
   input  [  7:0] hdmi_cr0_i,
   input  [  7:0] hdmi_cr1_i,
   input  [  7:0] hdmi_cb0_i,
   input  [  7:0] hdmi_cb1_i,
   input          hdmi_vsync_n_i,                   // Active Low HDMI VSYNC
   input          hdmi_hsync_i,
   input          hdmi_de_i,

   input  dev_reg_info_st_t dev_reg_info_st_arr_i,

   // Outputs
   output         hdmi_reset_n_o,                   // Active Low HDMI Reset
   output         hdmi_hsync_o,                     // HDMI Data Valid
   output         hdmi_vsync_o,                     // Active High HDMI VSYNC

   output [(HDMI_RX_DATA_WIDTH_I-1):0] hdmi_data_o  // HDMI Data
  );


// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

logic  [(HDMI_RX_DATA_WIDTH_I-1):0] hdmi_sdr_data;
logic  [((HDMI_RX_DATA_WIDTH_I/2)-1):0] hdmi_ddr_data;

logic        hdmi_de;
logic  [7:0] hdmi_de_f;
logic  [7:0] hdmi_vsync_f;

// ------------------------------------------
//
// HDMI RX Data Converter
//
// ------------------------------------------

 // This module converts dual edged aligned data to single edged.

 // In input, Y and CB are interchanged. Normally, Y data must be at LSB.
 // And then, CB and Y data are swapped again. That's why, here, Y has been
 // put at MSB and no need to swap again.

 ddr_sdr_converter
   #
   (
    .IN_DATA_WIDTH_I            (HDMI_RX_DATA_WIDTH_I/2)
   )
   dsc
   (
    .clk                        (hdmi_clk),
    .reset_n                    (hdmi_reset_n),   // Active Low Reset

    // Outputs
    .sdr_data_o                 (hdmi_sdr_data),  // Rising Edge Sychronised Data

    // Inputs
    .ddr_data_i                 (hdmi_ddr_data),
    // .hdmi_mode_rgb           (dev_reg_info_st_arr_i.hdmi_mode_rgb),
    // .hdmi_rx_dual_channel_en_i  (dev_reg_info_st_arr_i.hdmi_channel_info)
    .dev_reg_info_st_arr_i      (dev_reg_info_st_arr_i)
   );


// ------------------------------------------
//
// Data Width Manager
//
// ------------------------------------------

 // This module realignes the input data according to the
 // data width of next stage FIFO

 data_width_manager
   #
   (
    .IN_DATA_WIDTH_I            (HDMI_RX_DATA_WIDTH_I)
   )
   dwm
   (
    .clk                        (hdmi_clk),
    .reset_n                    (hdmi_reset_n),  // Active Low Reset
    .hsync_i                    (hdmi_de),
    .sdr_data_i                 (hdmi_sdr_data),
    .dev_reg_info_st_arr_i      (dev_reg_info_st_arr_i),
    // .hdmi_rx_dual_channel_en_i  (hdmi_channel_info_hdmi_clk_i),
    .hsync_o                    (hdmi_hsync_o),
    .sdr_data_o                 (hdmi_data_o)  // Rising Edge Sychronised Data

   );


// ------------------------------------------
//
// YUV444 or YUV422?
//
// ------------------------------------------

always_comb
   begin
     if ( !hdmi_reset_n )
       begin
        hdmi_ddr_data <= '0;
       end
    else if ( dev_reg_info_st_arr_i.hdmi_mode_rgb == 1'b1 ) // RGB mode
       begin
         if ( dev_reg_info_st_arr_i.image_pixel_width == 8'd32 )
           begin
             hdmi_ddr_data <= {8'hFF, hdmi_cr1_i, hdmi_y1_i, hdmi_cb1_i, 8'hFF, hdmi_cr0_i, hdmi_y0_i, hdmi_cb0_i}; // RGB32
           end
         else // 24 bit
           begin
             hdmi_ddr_data <= {16'b0, hdmi_cr1_i, hdmi_y1_i, hdmi_cb1_i, hdmi_cr0_i, hdmi_y0_i, hdmi_cb0_i}; // RGB24
           end
       end
     else // YUV422
       begin
        hdmi_ddr_data <= {32'b0, hdmi_cr1_i, hdmi_y1_i, hdmi_cr0_i, hdmi_y0_i};
       end
   end

// ARGB
// assign hdmi_ddr_data = ( ( hdmi_mode_rgb == 1'b1 ) ? { 8'hFF, hdmi_cr1_i, hdmi_y1_i, hdmi_cb1_i, 8'hFF, hdmi_cr0_i, hdmi_y0_i, hdmi_cb0_i } : {32'b0, hdmi_cr1_i, hdmi_y1_i, hdmi_cr0_i, hdmi_y0_i} );
// RGB24
// assign hdmi_ddr_data = ( ( hdmi_mode_rgb == 1'b1 ) ? {16'b0, hdmi_cr1_i, hdmi_y1_i, hdmi_cb1_i, hdmi_cr0_i, hdmi_y0_i, hdmi_cb0_i} : {32'b0, hdmi_cr1_i, hdmi_y1_i, hdmi_cr0_i, hdmi_y0_i} );


// DDR to SDR Converter delays input data by 4 clocks in case of 4K @30 and 1080p.
// In case of 4K @60, it delays by 3 clock cycles.
always_ff @ ( posedge hdmi_clk )
  begin
    if ( ~hdmi_reset_n )
      begin
        hdmi_de <= 1'b0;
      end
    else if ( dev_reg_info_st_arr_i.hdmi_mode_rgb == 1'b1 ) // RGB444 or dual channel
      begin
        hdmi_de <= hdmi_de_f[1];
      end
    else
      begin
        hdmi_de <= hdmi_de_f[2];
      end
  end

// As 'ddr_sdr_converter' takes couple of clocks to
// convert data, 'hdmi_de_i' is passed through 2 FFs.
always_ff @ ( posedge hdmi_clk )
  begin
    if ( ~hdmi_reset_n )
      begin
        hdmi_de_f    <= 8'b0;
        hdmi_vsync_f <= 8'b0;
      end
    else
      begin
        hdmi_de_f    <= { hdmi_de_f[6:0], hdmi_de_i };
        hdmi_vsync_f <= { hdmi_vsync_f[6:0], ~hdmi_vsync_n_i };
      end
  end


// HDMI VSYNC
assign hdmi_vsync_o = hdmi_vsync_f[6];

// Active Low Reset
assign hdmi_reset_n_o = 1'b1;

endmodule