//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:  FX10/20 Design
// Module Name:  ddr_sdr_converter
// Target Devices: T120 and Ti180
//
// Description: This module converts the input data, synchronised with dual edge
//              of clock to rising edge of same clock only.
//
//////////////////////////////////////////////////////////////////////////////////

// Include the package file
`include "package/user_define_pkg.sv"

module ddr_sdr_converter
  #
  (
   // Parameter to define the data width of input data.
   parameter IN_DATA_WIDTH_I = 32,

   // Parameter to define the data width of output data.
   localparam OUT_DATA_WIDTH  = IN_DATA_WIDTH_I << 1'b1

  )

  (
   input                                clk,
   input                                reset_n,
   input        [(IN_DATA_WIDTH_I-1):0] ddr_data_i, // Dual edge synchronised input data
   input  dev_reg_info_st_t dev_reg_info_st_arr_i,

   output logic [(OUT_DATA_WIDTH-1):0]  sdr_data_o  // Rising edge synchronised output data

  );


// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic [(IN_DATA_WIDTH_I-1):0] data_pe;
  logic [(IN_DATA_WIDTH_I-1):0] data_ne;
  logic [(IN_DATA_WIDTH_I-1):0] data_pe_f1;
  logic [(IN_DATA_WIDTH_I-1):0] data_pe_f2;
  logic [(IN_DATA_WIDTH_I-1):0] data_pe_f3;
  logic [(IN_DATA_WIDTH_I-1):0] data_ne_f1;
  logic [(IN_DATA_WIDTH_I-1):0] data_ne_f2;
  logic [(IN_DATA_WIDTH_I-1):0] data_ne_f3;

// ------------------------------------------
//
// Input Data Sampling At Rising Edge
//
// ------------------------------------------

  // Input data sampling at positive edge of clock
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          data_pe    <= '0;
          data_pe_f1 <= '0;
          data_pe_f2 <= '0;
          data_pe_f3 <= '0;
        end
      else
        begin
          data_pe    <= ddr_data_i; // Data input from ITE
          data_pe_f1 <= data_pe;
          data_pe_f2 <= data_pe_f1;
          data_pe_f3 <= data_pe_f2;
        end
    end

// ------------------------------------------
//
// Input Data Sampling At Falling Edge
//
// ------------------------------------------

  always_ff @ ( negedge clk )
    begin
      if ( ~reset_n )
        begin
          data_ne <= '0;
        end
      else /* if (hdmi_de_i) */
        begin
          data_ne <= ddr_data_i;
        end
    end

  // Second flop. Synchronise at positive edge.
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          data_ne_f1 <= '0;
          data_ne_f2 <= '0;
          data_ne_f3 <= '0;
        end
      else
        begin
          data_ne_f1 <= data_ne;
          data_ne_f2 <= data_ne_f1;
          data_ne_f3 <= data_ne_f2;
        end
    end


// ------------------------------------------
//
// Output Data
//
// ------------------------------------------

  // Data width is same as 'OUT_DATA_WIDTH'
  // assign sdr_data_o = { data_pe_f2, data_ne_f2 } ;

  // assign sdr_data_o = { data_ne_f2, data_pe_f2 } ;

  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          sdr_data_o <= '0;
        end
      else if ( dev_reg_info_st_arr_i.hdmi_channel_info == 1'b0 ) // 1080p
        begin
          sdr_data_o <= { 32'h0, data_pe_f2[15:8], data_ne_f2[7:0], data_ne_f2[15:8], data_pe_f2[7:0] };
        end
      else if ( dev_reg_info_st_arr_i.hdmi_mode_rgb == 1'b1 )
        begin
          if ( dev_reg_info_st_arr_i.image_pixel_width == 8'd32 )
            begin
              sdr_data_o <= { data_ne_f1, data_pe_f1 }; // RGB32
            end
          else
            begin
              sdr_data_o <= { 32'd0, data_ne_f1[47:0], data_pe_f1[47:0] }; // RGB24
            end
        end
      else
        begin
          sdr_data_o <= { 64'd0, data_ne_f1[31:0], data_pe_f1[31:0] }; // YUV422
        end
    end

endmodule