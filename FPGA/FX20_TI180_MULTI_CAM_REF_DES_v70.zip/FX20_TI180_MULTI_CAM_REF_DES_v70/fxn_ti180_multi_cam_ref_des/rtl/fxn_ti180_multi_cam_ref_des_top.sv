//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:  FX10/20 Design
// Module Name:  fxn_ti180_multi_cam_ref_des_top
// Target Devices: T120 and Ti180
//
// Description: It is the top most module for 4K 60fps design. It receives the
//              input from Image Sensor and transmits the data over slave FIFO
//              interface of FX10/20. This design uses DDR4 as a frame buffer.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module fxn_ti180_multi_cam_ref_des_top
(
  input          fxn_gpif_m_clk,            // 74.25 or 148.5 MHz clock based on naarow or wide link. Generated from 74.25 MHz PLL
  input          axi_m_clk,                 // 132 MHz clock.   Generated from 74.25 MHz PLL
  input          mipi_pixel_clk,            // 156 MHz clock.   Generated from 16 MHz PLL
  input          reset_n,                   // Async active low reset
  input          mipi_cfg_clk,              // 96 MHz clock.   Generated from 16 MHz PLL

  input          lvds_fast_clk_148m,
  input          lvds_fast_clk_297m,
  input          lvds_fast_clk_594m,

  // PLL Lock and Reset
  input          pll_clk_74_25m_lock_i,     // 74.25 MHz PLL lock
  input          pll_clk_16m_lock_i,        // 16 MHz    PLL lock
  input          pll_ddr_clk_locked_i,      // 100 MHz PLL lock used for generating ddr_ref_clk
  input          lvds_clk_148m_lock_i,      // Lock generated for 148 MHz lvds fast clock
  input          lvds_clk_297m_lock_i,      // Lock generated for 297 MHz lvds fast clock
  input          lvds_clk_594m_lock_i,      // Lock generated for 594 MHz lvds fast clock

  output         pll_ddr_clk_reset_n_o,     // 100 MHz PLL reset used for generating ddr_ref_clk
  output         pll_clk_16m_reset_n_o,     // 50MHz    PLL reset
  output         pll_clk_74_25m_reset_n_o,  // 74.25MHz PLL reset
  output         lvds_clk_148m_reset_n_o,   // PLL reset for 148 MHz lvds fast clock
  output         lvds_clk_297m_reset_n_o,   // PLL reset for 297 MHz lvds fast clock
  output         lvds_clk_594m_reset_n_o,   // PLL reset for 594 MHz lvds fast clock

  output         lvds_ser_clk,

  // FX10 LVDS Interface

  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d0_o,      // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d1_o,      // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d2_o,      // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d3_o,      // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d4_o,      // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d5_o,      // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d6_o,      // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d7_o,      // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d8_o,      // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d9_o,      // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d10_o,     // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d11_o,     // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d12_o,     // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d13_o,     // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d14_o,     // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_wr_data_d15_o,     // Pixel Data Output
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_ctrl_data_p0_o,    // P0 Control Byte Data
  output logic [(LVDS_TX_GEAR_RATIO-1):0] fxn_gpif_m_ctrl_data_p1_o,    // P1 Control Byte Data
  
  output logic         fxn_p0_l3_mode_en_o,             // Enable/disable L3 mode
  output logic         fxn_p0_gpif_m_clk_oe_o,          // Clock mode output enable
  output logic         fxn_p0_gpif_m_ctrl_data_oe_o,    // Control data  output enable
  output logic  [7:0]  fxn_p0_gpif_m_wr_data_oe_o,      // Data bus output enable
  output logic         fxn_p0_gpif_m_clk_rst_n_o,       // Clock reset 
  output logic         fxn_p0_gpif_m_ctrl_data_rst_n_o, // Control data reset
  output logic  [7:0]  fxn_p0_gpif_m_wr_data_rst_n_o,   // Data bus reset
  
  output logic         fxn_p1_l3_mode_en_o,             // Enable/disable L3 mode
  output logic         fxn_p1_gpif_m_clk_oe_o,          // Clock mode output enable
  output logic         fxn_p1_gpif_m_ctrl_data_oe_o,    // Control data  output enable
  output logic  [7:0]  fxn_p1_gpif_m_wr_data_oe_o,      // Data bus output enable
  output logic         fxn_p1_gpif_m_clk_rst_n_o,       // Clock reset 
  output logic         fxn_p1_gpif_m_ctrl_data_rst_n_o, // Control data reset
  output logic  [7:0]  fxn_p1_gpif_m_wr_data_rst_n_o,   // Data bus reset

  input          fxn_p0_gpif_m_full_flag_i,    // DMA Full/Ready
  input          fxn_lvds_p0_rx_link_ready_i,  // Link Ready
  input          fxn_p1_gpif_m_full_flag_i,    // DMA Full/Ready
  input          fxn_lvds_p1_rx_link_ready_i,  // Link Ready
  
  // LVCMOS Interface
  output logic [15:0]  fxn_p0_gpif_m_wr_data_pe_o,    // Pixel data output on rising edge
  output logic [15:0]  fxn_p0_gpif_m_wr_data_ne_o,    // Pixel data output on falling edge
  output logic         fxn_p0_gpif_m_cs_n_o,          // CHIP SELECT
  output logic         fxn_p0_gpif_m_wr_req_n_o,      // SLAVE WRITE
  output logic         fxn_p0_gpif_m_oe_n_o,          // Reset pin, active low
  output logic         fxn_p0_gpif_m_pktend_n_o,      // PACKET END
  output logic [(NO_OF_ADDRESS_BITS-1):0]  fxn_p0_gpif_m_addr_o,          // Address
  output logic         fxn_p0_gpif_m_rd_req_n_o,      // Slave read
  output logic         fxn_p0_gpif_m_epswitch_n_o,

  output logic [15:0]  fxn_p1_gpif_m_wr_data_pe_o,    // Pixel data output on rising edge
  output logic [15:0]  fxn_p1_gpif_m_wr_data_ne_o,    // Pixel data output on falling edge
  output logic         fxn_p1_gpif_m_cs_n_o,          // CHIP SELECT
  output logic         fxn_p1_gpif_m_wr_req_n_o,      // SLAVE WRITE
  output logic         fxn_p1_gpif_m_oe_n_o,          // Reset pin, active low
  output logic         fxn_p1_gpif_m_pktend_n_o,      // PACKET END
  output logic [(NO_OF_ADDRESS_BITS-1):0] fxn_p1_gpif_m_addr_o,          // Address
  output logic         fxn_p1_gpif_m_rd_req_n_o,      // Slave read
  output logic         fxn_p1_gpif_m_epswitch_n_o,


  // LSB is main I2C MSB is P0I2C

  // FX10 I2C Interface
  output [1:0] fxn_i2c_sda_o,
  output [1:0] fxn_i2c_sda_en_o,
  output [1:0] fxn_i2c_scl_o,
  output [1:0] fxn_i2c_scl_en_o,

  input  [1:0] fxn_i2c_scl_i,
  input  [1:0] fxn_i2c_sda_i,


  // HDMI rx input

//  input  [  7:0] hdmi_y0_i,
//  input  [  7:0] hdmi_cb0_i,
//  input  [  7:0] hdmi_y1_i,
//  input  [  7:0] hdmi_cr0_i,
  input          hdmi_vsync_n_i,
  input          hdmi_hsync_i,
  input          hdmi_de_i,
  input          hdmi_clk,

  input  [  7:0] hdmi_y0_i,
  input  [  7:0] hdmi_y1_i,
  input  [  7:0] hdmi_cr0_i,
  input  [  7:0] hdmi_cr1_i,
  input  [  7:0] hdmi_cb0_i,
  input  [  7:0] hdmi_cb1_i,

  // DDR AXI0

  //Startup Sequencer Signals

  input          ddr_cfg_done_i,         //Indicates the controller configuration is done
  output         ddr_cfg_seq_start_o,    //Start the DDR configuration controller.
  output         ddr_cfg_seq_sel_o,      //To select whether to use internal DDR configuration controller or user register ports for configuration:
                                    //0: Use internal configuration controller.
                                    //1: Use register configuration ports (cfg_rst, cfg_start, cfg_done will be disabled).
  output         ddr_cfg_seq_rst_o,      //Active-high DDR configuration controller reset.
  output         axi_m0_arstn_o,

  // DDR Controller Status Signals
  input          ddr_ctrl_data_path_idle_i,
  input          ddr_ctrl_cmd_queue_almost_full_i,
  input          ddr_ctrl_busy_i,

  // LPDDR4X RAM interface
  //DDR AXI0 Write Address Channel

  input          axi_m0_awready_i, //Address ready. This signal indicates that the slave is ready to accept an address and associated control signals.
  output [ 32:0] axi_m0_awaddr_o,  //Write address. It gives the address of the first transfer in a burst transaction.
  output [  1:0] axi_m0_awburst_o, //Burst type. The burst type and the size determine how the address for each transfer within the burst is calculated.
  output [  5:0] axi_m0_awid_o,    //Address ID. This signal identifies the group of address signals.
  output [  7:0] axi_m0_awlen_o,   //Burst length. This signal indicates the number of transfers in a burst.
  output [  2:0] axi_m0_awsize_o,  //Burst size. This signal indicates the size of each transfer in the burst.
  output         axi_m0_awvalid_o, //Address valid. This signal indicates that the channel is signaling valid address and control information.
  output         axi_m0_awlock_o,  //Lock type. This signal provides additional information about the atomic characteristics of the transfer.
  output [  3:0] axi_m0_awcache_o,
  output         axi_m0_awqos_o,
  output         axi_m0_awallstrb_o,
  output         axi_m0_awapcmd_o,
  output         axi_m0_awcobuf_o,


   //DDR AXI 0 Read Address Channel

  input          axi_m0_arready_i,  //Address ready. This signal indicates that the slave is ready to accept an address and associated control signals.
  output [ 32:0] axi_m0_araddr_o,   //Read address. It gives the address of the first transfer in a burst transaction.
  output [  1:0] axi_m0_arburst_o,  //Burst type. The burst type and the size determine how the address for each transfer within the burst is calculated.
  output [  5:0] axi_m0_arid_o,     //Address ID. This signal identifies the group of address signals.
  output [  7:0] axi_m0_arlen_o,    //Burst length. This signal indicates the number of transfers in a burst.
  output [  2:0] axi_m0_arsize_o,   //Burst size. This signal indicates the size of each transfer in the burst.
  output         axi_m0_arvalid_o,  //Address valid. This signal indicates that the channel is signaling valid address and control information.
  output         axi_m0_arlock_o,   //Lock type. This signal provides additional information about the atomic characteristics of the transfer.
  output         axi_m0_arqos_o,
  output         axi_m0_arapcmd_o,
  //DDR AXI0 Write Data Channel Signals

  input          axi_m0_wready_i,   //Write ready. This signal indicates that the slave can accept the write data.
  output [511:0] axi_m0_wdata_o,    //Write data. AXI4 port 0 is 256, port 1 is 128.
  output         axi_m0_wlast_o,    //Write last. This signal indicates the last transfer in a write burst.
  output [ 63:0] axi_m0_wstrb_o,    //Write strobes. This signal indicates which byte lanes hold valid data. There is one write strobe bit for each eight bits of the write data bus.
  // output [  7:0] axi_m0_wid_o,      // Not used.
  output         axi_m0_wvalid_o,   //Write valid. This signal indicates that valid write data and strobes are available.

  //DDR AXI0 Read Data Channel

  input  [511:0] axi_m0_rdata_i,   //Read data.
  input  [  5:0] axi_m0_rid_i,     //Read ID tag. This signal is the identification tag for the read data group of signals generated by the slave.
  input          axi_m0_rlast_i,   //Read last. This signal indicates the last transfer in a read burst.
  input  [  1:0] axi_m0_rresp_i,   //Read response. This signal indicates the status of the read transfer.
  input          axi_m0_rvalid_i,  //Read valid. This signal indicates that the channel is signaling the required read data.
  output         axi_m0_rready_o,   //Read ready. This signal indicates that the master can accept the read data and response information.


  //DDR AXI0 Write Response Channel

  input  [  5:0] axi_m0_bid_i,    //Response ID tag. This signal is the ID tag of the write response.
  input          axi_m0_bvalid_i, //Write response valid. This signal indicates that the channel is signaling a valid write response.
  input  [  1:0] axi_m0_bresp_i,  //Write response
  output         axi_m0_bready_o, //Response ready. This signal indicates that the master can accept a write response.


  //DDR AXI1

  // AXI1 reset
  output         axi_m1_arstn_o,

  // LPDDR4X RAM interface
  //DDR AXI1 Write Address Channel

  input          axi_m1_awready_i, //Address ready. This signal indicates that the slave is ready to accept an address and associated control signals.
  output [ 32:0] axi_m1_awaddr_o,  //Write address. It gives the address of the first transfer in a burst transaction.
  output [  1:0] axi_m1_awburst_o, //Burst type. The burst type and the size determine how the address for each transfer within the burst is calculated.
  output [  5:0] axi_m1_awid_o,    //Address ID. This signal identifies the group of address signals.
  output [  7:0] axi_m1_awlen_o,   //Burst length. This signal indicates the number of transfers in a burst.
  output [  2:0] axi_m1_awsize_o,  //Burst size. This signal indicates the size of each transfer in the burst.
  output         axi_m1_awvalid_o, //Address valid. This signal indicates that the channel is signaling valid address and control information.
  output         axi_m1_awlock_o,  //Lock type. This signal provides additional information about the atomic characteristics of the transfer.
  output [  3:0] axi_m1_awcache_o,
  output         axi_m1_awqos_o,
  output         axi_m1_awallstrb_o,
  output         axi_m1_awapcmd_o,
  output         axi_m1_awcobuf_o,


   //DDR AXI1 Read Address Channel

  input          axi_m1_arready_i,  //Address ready. This signal indicates that the slave is ready to accept an address and associated control signals.
  output [ 32:0] axi_m1_araddr_o,   //Read address. It gives the address of the first transfer in a burst transaction.
  output [  1:0] axi_m1_arburst_o,  //Burst type. The burst type and the size determine how the address for each transfer within the burst is calculated.
  output [  5:0] axi_m1_arid_o,     //Address ID. This signal identifies the group of address signals.
  output [  7:0] axi_m1_arlen_o,    //Burst length. This signal indicates the number of transfers in a burst.
  output [  2:0] axi_m1_arsize_o,   //Burst size. This signal indicates the size of each transfer in the burst.
  output         axi_m1_arvalid_o,  //Address valid. This signal indicates that the channel is signaling valid address and control information.
  output         axi_m1_arlock_o,   //Lock type. This signal provides additional information about the atomic characteristics of the transfer.
  output         axi_m1_arqos_o,
  output         axi_m1_arapcmd_o,
  //DDR AXI1 Write Data Channel Signals

  input          axi_m1_wready_i,   //Write ready. This signal indicates that the slave can accept the write data.
  output [511:0] axi_m1_wdata_o,    //Write data. AXI4 port 0 is 256, port 1 is 128.
  output         axi_m1_wlast_o,    //Write last. This signal indicates the last transfer in a write burst.
  output [ 63:0] axi_m1_wstrb_o,    //Write strobes. This signal indicates which byte lanes hold valid data. There is one write strobe bit for each eight bits of the write data bus.
  // output [  7:0] axi_m1_wid_o,      // Not used.
  output         axi_m1_wvalid_o,   //Write valid. This signal indicates that valid write data and strobes are available.

  //DDR AXI1 Read Data Channel

  input  [511:0] axi_m1_rdata_i,   //Read data.
  input  [  5:0] axi_m1_rid_i,     //Read ID tag. This signal is the identification tag for the read data group of signals generated by the slave.
  input          axi_m1_rlast_i,   //Read last. This signal indicates the last transfer in a read burst.
  input  [  1:0] axi_m1_rresp_i,   //Read response. This signal indicates the status of the read transfer.
  input          axi_m1_rvalid_i,  //Read valid. This signal indicates that the channel is signaling the required read data.
  output         axi_m1_rready_o,  //Read ready. This signal indicates that the master can accept the read data and response information.


  //DDR AXI1 Write Response Channel

  input  [  5:0] axi_m1_bid_i,    //Response ID tag. This signal is the ID tag of the write response.
  input          axi_m1_bvalid_i, //Write response valid. This signal indicates that the channel is signaling a valid write response.
  input  [  1:0] axi_m1_bresp_i,  //Write response
  output         axi_m1_bready_o, //Response ready. This signal indicates that the master can accept a write response.

  output         led_ddr_o,

  //CSI RX Interface
  //MIPI DPHY RX0
  input          mipi_dphy_rx_inst1_WORD_CLKOUT_HS,

  output         mipi_dphy_rx_inst1_FORCE_RX_MODE,
  output         mipi_dphy_rx_inst1_RESET_N,
  output         mipi_dphy_rx_inst1_RST0_N,

  input          mipi_dphy_rx_inst1_ERR_CONTENTION_LP0,
  input          mipi_dphy_rx_inst1_ERR_CONTENTION_LP1,
  input          mipi_dphy_rx_inst1_ERR_CONTROL_LAN0,
  input          mipi_dphy_rx_inst1_ERR_CONTROL_LAN1,
  input          mipi_dphy_rx_inst1_ERR_ESC_LAN0,
  input          mipi_dphy_rx_inst1_ERR_ESC_LAN1,
  input          mipi_dphy_rx_inst1_ERR_SOT_HS_LAN0,
  input          mipi_dphy_rx_inst1_ERR_SOT_HS_LAN1,
  input          mipi_dphy_rx_inst1_ERR_SOT_SYNC_HS_LAN0,
  input          mipi_dphy_rx_inst1_ERR_SOT_SYNC_HS_LAN1,
  input          mipi_dphy_rx_inst1_LP_CLK,
  input          mipi_dphy_rx_inst1_RX_ACTIVE_HS_LAN0,
  input          mipi_dphy_rx_inst1_RX_ACTIVE_HS_LAN1,
  input          mipi_dphy_rx_inst1_RX_CLK_ACTIVE_HS,
  input          mipi_dphy_rx_inst1_ESC_LAN0_CLK,
  input          mipi_dphy_rx_inst1_ESC_LAN1_CLK,
  input [7:0]    mipi_dphy_rx_inst1_RX_DATA_ESC,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst1_RX_DATA_HS_LAN0,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst1_RX_DATA_HS_LAN1,
  input          mipi_dphy_rx_inst1_RX_LPDT_ESC,
  input          mipi_dphy_rx_inst1_RX_SKEW_CAL_HS_LAN0,
  input          mipi_dphy_rx_inst1_RX_SKEW_CAL_HS_LAN1,
  input          mipi_dphy_rx_inst1_RX_SYNC_HS_LAN0,
  input          mipi_dphy_rx_inst1_RX_SYNC_HS_LAN1,
  input [3:0]    mipi_dphy_rx_inst1_RX_TRIGGER_ESC,
  input          mipi_dphy_rx_inst1_RX_ULPS_ACTIVE_CLK_NOT,
  input          mipi_dphy_rx_inst1_RX_ULPS_ACTIVE_NOT_LAN0,
  input          mipi_dphy_rx_inst1_RX_ULPS_ACTIVE_NOT_LAN1,
  input          mipi_dphy_rx_inst1_RX_ULPS_CLK_NOT,
  input          mipi_dphy_rx_inst1_RX_ULPS_ESC_LAN0,
  input          mipi_dphy_rx_inst1_RX_ULPS_ESC_LAN1,
  input          mipi_dphy_rx_inst1_RX_VALID_ESC,
  input          mipi_dphy_rx_inst1_RX_VALID_HS_LAN0,
  input          mipi_dphy_rx_inst1_RX_VALID_HS_LAN1,
  input          mipi_dphy_rx_inst1_STOPSTATE_CLK,
  input          mipi_dphy_rx_inst1_STOPSTATE_LAN0,
  input          mipi_dphy_rx_inst1_STOPSTATE_LAN1,

  `ifdef CSI_RX_4LANES
  input          mipi_dphy_rx_inst1_ERR_CONTROL_LAN2,
  input          mipi_dphy_rx_inst1_ERR_CONTROL_LAN3,
  input          mipi_dphy_rx_inst1_ERR_ESC_LAN2,
  input          mipi_dphy_rx_inst1_ERR_ESC_LAN3,
  input          mipi_dphy_rx_inst1_ERR_SOT_HS_LAN2,
  input          mipi_dphy_rx_inst1_ERR_SOT_HS_LAN3,
  input          mipi_dphy_rx_inst1_ERR_SOT_SYNC_HS_LAN2,
  input          mipi_dphy_rx_inst1_ERR_SOT_SYNC_HS_LAN3,
  input          mipi_dphy_rx_inst1_RX_ACTIVE_HS_LAN2,
  input          mipi_dphy_rx_inst1_RX_ACTIVE_HS_LAN3,
  input          mipi_dphy_rx_inst1_ESC_LAN2_CLK,
  input          mipi_dphy_rx_inst1_ESC_LAN3_CLK,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst1_RX_DATA_HS_LAN2,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst1_RX_DATA_HS_LAN3,
  input          mipi_dphy_rx_inst1_RX_SKEW_CAL_HS_LAN2,
  input          mipi_dphy_rx_inst1_RX_SKEW_CAL_HS_LAN3,
  input          mipi_dphy_rx_inst1_RX_SYNC_HS_LAN2,
  input          mipi_dphy_rx_inst1_RX_SYNC_HS_LAN3,
  input          mipi_dphy_rx_inst1_RX_ULPS_ACTIVE_NOT_LAN2,
  input          mipi_dphy_rx_inst1_RX_ULPS_ACTIVE_NOT_LAN3,
  input          mipi_dphy_rx_inst1_RX_ULPS_ESC_LAN2,
  input          mipi_dphy_rx_inst1_RX_ULPS_ESC_LAN3,
  input          mipi_dphy_rx_inst1_RX_VALID_HS_LAN2,
  input          mipi_dphy_rx_inst1_RX_VALID_HS_LAN3,
  input          mipi_dphy_rx_inst1_STOPSTATE_LAN2,
  input          mipi_dphy_rx_inst1_STOPSTATE_LAN3,
  `endif

  //MIPI DPHY RX1
  input          mipi_dphy_rx_inst2_WORD_CLKOUT_HS,

  output         mipi_dphy_rx_inst2_FORCE_RX_MODE,
  output         mipi_dphy_rx_inst2_RESET_N,
  output         mipi_dphy_rx_inst2_RST0_N,

  input          mipi_dphy_rx_inst2_ERR_CONTENTION_LP0,
  input          mipi_dphy_rx_inst2_ERR_CONTENTION_LP1,
  input          mipi_dphy_rx_inst2_ERR_CONTROL_LAN0,
  input          mipi_dphy_rx_inst2_ERR_CONTROL_LAN1,
  input          mipi_dphy_rx_inst2_ERR_ESC_LAN0,
  input          mipi_dphy_rx_inst2_ERR_ESC_LAN1,
  input          mipi_dphy_rx_inst2_ERR_SOT_HS_LAN0,
  input          mipi_dphy_rx_inst2_ERR_SOT_HS_LAN1,
  input          mipi_dphy_rx_inst2_ERR_SOT_SYNC_HS_LAN0,
  input          mipi_dphy_rx_inst2_ERR_SOT_SYNC_HS_LAN1,
  input          mipi_dphy_rx_inst2_LP_CLK,
  input          mipi_dphy_rx_inst2_RX_ACTIVE_HS_LAN0,
  input          mipi_dphy_rx_inst2_RX_ACTIVE_HS_LAN1,
  input          mipi_dphy_rx_inst2_RX_CLK_ACTIVE_HS,
  input          mipi_dphy_rx_inst2_ESC_LAN0_CLK,
  input          mipi_dphy_rx_inst2_ESC_LAN1_CLK,
  input [7:0]    mipi_dphy_rx_inst2_RX_DATA_ESC,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst2_RX_DATA_HS_LAN0,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst2_RX_DATA_HS_LAN1,
  input          mipi_dphy_rx_inst2_RX_LPDT_ESC,
  input          mipi_dphy_rx_inst2_RX_SKEW_CAL_HS_LAN0,
  input          mipi_dphy_rx_inst2_RX_SKEW_CAL_HS_LAN1,
  input          mipi_dphy_rx_inst2_RX_SYNC_HS_LAN0,
  input          mipi_dphy_rx_inst2_RX_SYNC_HS_LAN1,
  input [3:0]    mipi_dphy_rx_inst2_RX_TRIGGER_ESC,
  input          mipi_dphy_rx_inst2_RX_ULPS_ACTIVE_CLK_NOT,
  input          mipi_dphy_rx_inst2_RX_ULPS_ACTIVE_NOT_LAN0,
  input          mipi_dphy_rx_inst2_RX_ULPS_ACTIVE_NOT_LAN1,
  input          mipi_dphy_rx_inst2_RX_ULPS_CLK_NOT,
  input          mipi_dphy_rx_inst2_RX_ULPS_ESC_LAN0,
  input          mipi_dphy_rx_inst2_RX_ULPS_ESC_LAN1,
  input          mipi_dphy_rx_inst2_RX_VALID_ESC,
  input          mipi_dphy_rx_inst2_RX_VALID_HS_LAN0,
  input          mipi_dphy_rx_inst2_RX_VALID_HS_LAN1,
  input          mipi_dphy_rx_inst2_STOPSTATE_CLK,
  input          mipi_dphy_rx_inst2_STOPSTATE_LAN0,
  input          mipi_dphy_rx_inst2_STOPSTATE_LAN1,

  `ifdef CSI_RX_4LANES
  input          mipi_dphy_rx_inst2_ERR_CONTROL_LAN2,
  input          mipi_dphy_rx_inst2_ERR_CONTROL_LAN3,
  input          mipi_dphy_rx_inst2_ERR_ESC_LAN2,
  input          mipi_dphy_rx_inst2_ERR_ESC_LAN3,
  input          mipi_dphy_rx_inst2_ERR_SOT_HS_LAN2,
  input          mipi_dphy_rx_inst2_ERR_SOT_HS_LAN3,
  input          mipi_dphy_rx_inst2_ERR_SOT_SYNC_HS_LAN2,
  input          mipi_dphy_rx_inst2_ERR_SOT_SYNC_HS_LAN3,
  input          mipi_dphy_rx_inst2_RX_ACTIVE_HS_LAN2,
  input          mipi_dphy_rx_inst2_RX_ACTIVE_HS_LAN3,
  input          mipi_dphy_rx_inst2_ESC_LAN2_CLK,
  input          mipi_dphy_rx_inst2_ESC_LAN3_CLK,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst2_RX_DATA_HS_LAN2,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst2_RX_DATA_HS_LAN3,
  input          mipi_dphy_rx_inst2_RX_SKEW_CAL_HS_LAN2,
  input          mipi_dphy_rx_inst2_RX_SKEW_CAL_HS_LAN3,
  input          mipi_dphy_rx_inst2_RX_SYNC_HS_LAN2,
  input          mipi_dphy_rx_inst2_RX_SYNC_HS_LAN3,
  input          mipi_dphy_rx_inst2_RX_ULPS_ACTIVE_NOT_LAN2,
  input          mipi_dphy_rx_inst2_RX_ULPS_ACTIVE_NOT_LAN3,
  input          mipi_dphy_rx_inst2_RX_ULPS_ESC_LAN2,
  input          mipi_dphy_rx_inst2_RX_ULPS_ESC_LAN3,
  input          mipi_dphy_rx_inst2_RX_VALID_HS_LAN2,
  input          mipi_dphy_rx_inst2_RX_VALID_HS_LAN3,
  input          mipi_dphy_rx_inst2_STOPSTATE_LAN2,
  input          mipi_dphy_rx_inst2_STOPSTATE_LAN3,
  `endif

  //MIPI DPHY RX2
  input          mipi_dphy_rx_inst3_WORD_CLKOUT_HS,

  output         mipi_dphy_rx_inst3_FORCE_RX_MODE,
  output         mipi_dphy_rx_inst3_RESET_N,
  output         mipi_dphy_rx_inst3_RST0_N,

  input          mipi_dphy_rx_inst3_ERR_CONTENTION_LP0,
  input          mipi_dphy_rx_inst3_ERR_CONTENTION_LP1,
  input          mipi_dphy_rx_inst3_ERR_CONTROL_LAN0,
  input          mipi_dphy_rx_inst3_ERR_CONTROL_LAN1,
  input          mipi_dphy_rx_inst3_ERR_ESC_LAN0,
  input          mipi_dphy_rx_inst3_ERR_ESC_LAN1,
  input          mipi_dphy_rx_inst3_ERR_SOT_HS_LAN0,
  input          mipi_dphy_rx_inst3_ERR_SOT_HS_LAN1,
  input          mipi_dphy_rx_inst3_ERR_SOT_SYNC_HS_LAN0,
  input          mipi_dphy_rx_inst3_ERR_SOT_SYNC_HS_LAN1,
  input          mipi_dphy_rx_inst3_LP_CLK,
  input          mipi_dphy_rx_inst3_RX_ACTIVE_HS_LAN0,
  input          mipi_dphy_rx_inst3_RX_ACTIVE_HS_LAN1,
  input          mipi_dphy_rx_inst3_RX_CLK_ACTIVE_HS,
  input          mipi_dphy_rx_inst3_ESC_LAN0_CLK,
  input          mipi_dphy_rx_inst3_ESC_LAN1_CLK,
  input [7:0]    mipi_dphy_rx_inst3_RX_DATA_ESC,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst3_RX_DATA_HS_LAN0,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst3_RX_DATA_HS_LAN1,
  input          mipi_dphy_rx_inst3_RX_LPDT_ESC,
  input          mipi_dphy_rx_inst3_RX_SKEW_CAL_HS_LAN0,
  input          mipi_dphy_rx_inst3_RX_SKEW_CAL_HS_LAN1,
  input          mipi_dphy_rx_inst3_RX_SYNC_HS_LAN0,
  input          mipi_dphy_rx_inst3_RX_SYNC_HS_LAN1,
  input [3:0]    mipi_dphy_rx_inst3_RX_TRIGGER_ESC,
  input          mipi_dphy_rx_inst3_RX_ULPS_ACTIVE_CLK_NOT,
  input          mipi_dphy_rx_inst3_RX_ULPS_ACTIVE_NOT_LAN0,
  input          mipi_dphy_rx_inst3_RX_ULPS_ACTIVE_NOT_LAN1,
  input          mipi_dphy_rx_inst3_RX_ULPS_CLK_NOT,
  input          mipi_dphy_rx_inst3_RX_ULPS_ESC_LAN0,
  input          mipi_dphy_rx_inst3_RX_ULPS_ESC_LAN1,
  input          mipi_dphy_rx_inst3_RX_VALID_ESC,
  input          mipi_dphy_rx_inst3_RX_VALID_HS_LAN0,
  input          mipi_dphy_rx_inst3_RX_VALID_HS_LAN1,
  input          mipi_dphy_rx_inst3_STOPSTATE_CLK,
  input          mipi_dphy_rx_inst3_STOPSTATE_LAN0,
  input          mipi_dphy_rx_inst3_STOPSTATE_LAN1,

  `ifdef CSI_RX_4LANES
  input          mipi_dphy_rx_inst3_ERR_CONTROL_LAN2,
  input          mipi_dphy_rx_inst3_ERR_CONTROL_LAN3,
  input          mipi_dphy_rx_inst3_ERR_ESC_LAN2,
  input          mipi_dphy_rx_inst3_ERR_ESC_LAN3,
  input          mipi_dphy_rx_inst3_ERR_SOT_HS_LAN2,
  input          mipi_dphy_rx_inst3_ERR_SOT_HS_LAN3,
  input          mipi_dphy_rx_inst3_ERR_SOT_SYNC_HS_LAN2,
  input          mipi_dphy_rx_inst3_ERR_SOT_SYNC_HS_LAN3,
  input          mipi_dphy_rx_inst3_RX_ACTIVE_HS_LAN2,
  input          mipi_dphy_rx_inst3_RX_ACTIVE_HS_LAN3,
  input          mipi_dphy_rx_inst3_ESC_LAN2_CLK,
  input          mipi_dphy_rx_inst3_ESC_LAN3_CLK,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst3_RX_DATA_HS_LAN2,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst3_RX_DATA_HS_LAN3,
  input          mipi_dphy_rx_inst3_RX_SKEW_CAL_HS_LAN2,
  input          mipi_dphy_rx_inst3_RX_SKEW_CAL_HS_LAN3,
  input          mipi_dphy_rx_inst3_RX_SYNC_HS_LAN2,
  input          mipi_dphy_rx_inst3_RX_SYNC_HS_LAN3,
  input          mipi_dphy_rx_inst3_RX_ULPS_ACTIVE_NOT_LAN2,
  input          mipi_dphy_rx_inst3_RX_ULPS_ACTIVE_NOT_LAN3,
  input          mipi_dphy_rx_inst3_RX_ULPS_ESC_LAN2,
  input          mipi_dphy_rx_inst3_RX_ULPS_ESC_LAN3,
  input          mipi_dphy_rx_inst3_RX_VALID_HS_LAN2,
  input          mipi_dphy_rx_inst3_RX_VALID_HS_LAN3,
  input          mipi_dphy_rx_inst3_STOPSTATE_LAN2,
  input          mipi_dphy_rx_inst3_STOPSTATE_LAN3,
  `endif

  //MIPI DPHY RX3
  input          mipi_dphy_rx_inst4_WORD_CLKOUT_HS,

  output         mipi_dphy_rx_inst4_FORCE_RX_MODE,
  output         mipi_dphy_rx_inst4_RESET_N,
  output         mipi_dphy_rx_inst4_RST0_N,

  input          mipi_dphy_rx_inst4_ERR_CONTENTION_LP0,
  input          mipi_dphy_rx_inst4_ERR_CONTENTION_LP1,
  input          mipi_dphy_rx_inst4_ERR_CONTROL_LAN0,
  input          mipi_dphy_rx_inst4_ERR_CONTROL_LAN1,
  input          mipi_dphy_rx_inst4_ERR_ESC_LAN0,
  input          mipi_dphy_rx_inst4_ERR_ESC_LAN1,
  input          mipi_dphy_rx_inst4_ERR_SOT_HS_LAN0,
  input          mipi_dphy_rx_inst4_ERR_SOT_HS_LAN1,
  input          mipi_dphy_rx_inst4_ERR_SOT_SYNC_HS_LAN0,
  input          mipi_dphy_rx_inst4_ERR_SOT_SYNC_HS_LAN1,
  input          mipi_dphy_rx_inst4_LP_CLK,
  input          mipi_dphy_rx_inst4_RX_ACTIVE_HS_LAN0,
  input          mipi_dphy_rx_inst4_RX_ACTIVE_HS_LAN1,
  input          mipi_dphy_rx_inst4_RX_CLK_ACTIVE_HS,
  input          mipi_dphy_rx_inst4_ESC_LAN0_CLK,
  input          mipi_dphy_rx_inst4_ESC_LAN1_CLK,
  input [7:0]    mipi_dphy_rx_inst4_RX_DATA_ESC,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst4_RX_DATA_HS_LAN0,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst4_RX_DATA_HS_LAN1,
  input          mipi_dphy_rx_inst4_RX_LPDT_ESC,
  input          mipi_dphy_rx_inst4_RX_SKEW_CAL_HS_LAN0,
  input          mipi_dphy_rx_inst4_RX_SKEW_CAL_HS_LAN1,
  input          mipi_dphy_rx_inst4_RX_SYNC_HS_LAN0,
  input          mipi_dphy_rx_inst4_RX_SYNC_HS_LAN1,
  input [3:0]    mipi_dphy_rx_inst4_RX_TRIGGER_ESC,
  input          mipi_dphy_rx_inst4_RX_ULPS_ACTIVE_CLK_NOT,
  input          mipi_dphy_rx_inst4_RX_ULPS_ACTIVE_NOT_LAN0,
  input          mipi_dphy_rx_inst4_RX_ULPS_ACTIVE_NOT_LAN1,
  input          mipi_dphy_rx_inst4_RX_ULPS_CLK_NOT,
  input          mipi_dphy_rx_inst4_RX_ULPS_ESC_LAN0,
  input          mipi_dphy_rx_inst4_RX_ULPS_ESC_LAN1,
  input          mipi_dphy_rx_inst4_RX_VALID_ESC,
  input          mipi_dphy_rx_inst4_RX_VALID_HS_LAN0,
  input          mipi_dphy_rx_inst4_RX_VALID_HS_LAN1,
  input          mipi_dphy_rx_inst4_STOPSTATE_CLK,
  input          mipi_dphy_rx_inst4_STOPSTATE_LAN0,
  input          mipi_dphy_rx_inst4_STOPSTATE_LAN1,

  `ifdef CSI_RX_4LANES
  input          mipi_dphy_rx_inst4_ERR_CONTROL_LAN2,
  input          mipi_dphy_rx_inst4_ERR_CONTROL_LAN3,
  input          mipi_dphy_rx_inst4_ERR_ESC_LAN2,
  input          mipi_dphy_rx_inst4_ERR_ESC_LAN3,
  input          mipi_dphy_rx_inst4_ERR_SOT_HS_LAN2,
  input          mipi_dphy_rx_inst4_ERR_SOT_HS_LAN3,
  input          mipi_dphy_rx_inst4_ERR_SOT_SYNC_HS_LAN2,
  input          mipi_dphy_rx_inst4_ERR_SOT_SYNC_HS_LAN3,
  input          mipi_dphy_rx_inst4_RX_ACTIVE_HS_LAN2,
  input          mipi_dphy_rx_inst4_RX_ACTIVE_HS_LAN3,
  input          mipi_dphy_rx_inst4_ESC_LAN2_CLK,
  input          mipi_dphy_rx_inst4_ESC_LAN3_CLK,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst4_RX_DATA_HS_LAN2,
  input [CSI_RX_DATA_WIDTH_LANE-1:0] mipi_dphy_rx_inst4_RX_DATA_HS_LAN3,
  input          mipi_dphy_rx_inst4_RX_SKEW_CAL_HS_LAN2,
  input          mipi_dphy_rx_inst4_RX_SKEW_CAL_HS_LAN3,
  input          mipi_dphy_rx_inst4_RX_SYNC_HS_LAN2,
  input          mipi_dphy_rx_inst4_RX_SYNC_HS_LAN3,
  input          mipi_dphy_rx_inst4_RX_ULPS_ACTIVE_NOT_LAN2,
  input          mipi_dphy_rx_inst4_RX_ULPS_ACTIVE_NOT_LAN3,
  input          mipi_dphy_rx_inst4_RX_ULPS_ESC_LAN2,
  input          mipi_dphy_rx_inst4_RX_ULPS_ESC_LAN3,
  input          mipi_dphy_rx_inst4_RX_VALID_HS_LAN2,
  input          mipi_dphy_rx_inst4_RX_VALID_HS_LAN3,
  input          mipi_dphy_rx_inst4_STOPSTATE_LAN2,
  input          mipi_dphy_rx_inst4_STOPSTATE_LAN3,
  `endif

// FPGA - Sensor i2C signals

  output [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C-1):0] fpga_cam_sda_o,
  output [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C-1):0] fpga_cam_sda_en_o,
  output [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C-1):0] fpga_cam_scl_o,
  output [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C-1):0] fpga_cam_scl_en_o,

  input  [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C-1):0] fpga_cam_scl_i,
  input  [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C-1):0] fpga_cam_sda_i,

  input          sw_i,

// For debugging purpose only
  output logic   o_led
 );


// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

logic  [(NO_OF_SUPPORTED_DEV-1) :0]  internal_tp_fv_hdmi_clk;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  internal_tp_lv_hdmi_clk;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  sel_vsync_hdmi_clk;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  sel_hsync_hdmi_clk;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  sel_vsync_hdmi_clk_f1;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  sel_vsync_hdmi_clk_f2;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  sel_vsync_hdmi_clk_pe_pl;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  sel_vsync_hdmi_clk_ne_pl;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  sel_vsync_axi_clk;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  sel_vsync_gpif_clk;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  sel_hsync_axi_clk;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  pause_colourbar_gen_req;



logic  [(NO_OF_SUPPORTED_DEV-1) :0]  y_data_bufr_empty;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  y_data_bufr_full;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  y_data_bufr_empty_gpif_clk;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  y_data_bufr_full_gpif_clk;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  y_data_bufr_almost_full;
// logic  [(NO_OF_SUPPORTED_DEV-1) :0]   y_data_bufr_overflow;

logic  [(NO_OF_SUPPORTED_DEV-1):0]   sel_d_start_stream_axi_clk;
logic  [(NO_OF_SUPPORTED_DEV-1) :0]  sel_d_start_stream_hdmi_clk;
logic                                l_zlp_sent;
logic                                l_zlp_sent_axi_clk;

logic                                fxn_gpif_m_clk_reset_n;
logic                                axi_m_clk_reset_n;
logic                                sys_clk_reset_n;
logic                                mipi_cfg_clk_reset_n;
logic                                mipi_pixel_clk_reset_n;
logic                                hdmi_clk_reset_n;
logic                                sys_clk;
logic                                sys_clk_lock;
logic                                fxn_gpif_m_pktend_axi_clk;
logic  [(NO_OF_SUPPORTED_DEV -1):0]  sel_d_reset_or_stop_stream_req;
logic  [(NO_OF_SUPPORTED_DEV -1):0]  sel_d_reset_or_stop_stream_req_axi_clk;
logic  [(NO_OF_SUPPORTED_DEV -1):0]  sel_d_reset_or_stop_stream_req_hdmi_clk;
logic                                sel_reset_or_stop_stream_req;

logic  [31:0]                        frame_size_info;
logic  [31:0]                        frame_size_info_hdmi_clk;
logic  [31:0]                        frame_size_info_axi_clk;

logic                                new_thread_addr_available_pl;
logic  [31:0]                        fxn_gpif_m_wr_data_pe;    // Pixel data output on rising edge
logic  [31:0]                        fxn_gpif_m_wr_data_ne;    // Pixel data output on falling edge
logic                                fxn_gpif_m_cs_n;          // CHIP SELECT
logic                                fxn_gpif_m_wr_req_n;      // SLAVE WRITE
logic                                fxn_gpif_m_pktend_n;      // PACKET END
logic  [(NO_OF_ADDRESS_BITS-1):0]    fxn_gpif_m_addr;          // Address
logic                                fxn_gpif_m_full_flag;
logic                                fxn_lvds_rx_link_ready;

logic  [(SEL_DEV_NUM_BITS-1):0]      sel_device_num;
logic                                change_thread_addr_pl;



// DDR config Manager
logic                        ddr_cfg_done;
logic                        ddr_cfg_done_gpif_clk;
logic                        ddr_ctrl_data_path_idle_gpif_clk;
logic                        ddr_ctrl_cmd_queue_almost_full_gpif_clk;
logic                        ddr_ctrl_busy_gpif_clk;

// Device based specific signals

logic [(NO_OF_SUPPORTED_DEV-1) :0] [(INTERNAL_TEST_PATTERN_DATA_WIDTH-1):0]        internal_tp_data_hdmi_clk;
logic [(NO_OF_SUPPORTED_DEV-1) :0] [(INTERMEDIATE_FIFO_WR_DATA_WIDTH_IN_BITS-1):0] sel_intr_fifo_wr_data_hdmi_clk;
logic [15:0][(LVDS_TX_GEAR_RATIO-1):0]   fxn_gpif_m_wr_data;


// Mipi decoder outputs

logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1) :0] w_rx_out_de;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1) :0] w_rx_out_vs;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1) :0] w_rx_out_hs;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1) :0] [63:0] w_rx_out_data;

logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1) :0] rx_frame_valid;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1) :0] rx_sensor_data_valid;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1) :0] [63:0] rx_sensor_data;

logic  [ 1:0]                sel_thread_addr;

logic [(NO_OF_SUPPORTED_DEV-1) :0] [(INTERNAL_TEST_PATTERN_DATA_WIDTH-1):0] hdmi_data;
logic                        sel_d_hdmi_channel_info_hdmi_clk;  // Change based on I2C
logic [(NO_OF_SUPPORTED_DEV-1) :0] hdmi_vsync;
logic [(NO_OF_SUPPORTED_DEV-1) :0] hdmi_hsync;
logic                        sel_d_hdmi_source_connection;
logic  [  7:0]               fxn_gpif_m_ctrl_data_p0;
logic                        tx_eop_control_byte_pl_n;
logic                        wait_for_new_buffer;
logic                        full_buffer_sent;
logic                        lvds_phy_n_link_training_done_pl;

// Low power mode support

logic                        fxn_l3_lp_mode_en;
logic                        fxn_gpif_m_clk_oe;
logic                        fxn_gpif_m_ctrl_data_oe;
logic                        fxn_gpif_m_wr_data_oe;
logic                        fxn_gpif_m_clk_rst_n;
logic                        fxn_gpif_m_ctrl_data_rst_n;
logic                        fxn_gpif_m_wr_data_rst_n;

// Misc..
logic  [31:0]                count ;
logic                        o_cam_rstn;
logic [(SEL_DEV_NUM_BITS-1):0]       fbh_rd_dsf_sel_device_num;

logic [(NO_OF_SUPPORTED_DEV-1):0]    ddr_wr_xfer_axi_clk_arr;
logic [(NO_OF_SUPPORTED_DEV-1):0]    ddr_wr_xfer_hdmi_clk_arr;
logic [(NO_OF_SUPPORTED_DEV-1):0]    full_frame_wr_completed_axi_clk_arr;
logic [(NO_OF_SUPPORTED_DEV-1):0]    full_frame_wr_completed_hdmi_clk_arr;
logic [(NO_OF_SUPPORTED_DEV-1):0]    full_frame_wr_completed_gpif_clk_arr;
logic [(NO_OF_SUPPORTED_DEV-1):0]    full_frame_rd_completed_axi_clk_arr;
logic [(NO_OF_SUPPORTED_DEV-1):0]    full_frame_rd_completed_gpif_clk_arr;


// Type defined structure
common_reg_info_st_t                               common_reg_info;
dev_reg_info_st_t    [(NO_OF_SUPPORTED_DEV-1):0]   dev_reg_info_st_arr;
dev_reg_info_st_t    [(NO_OF_SUPPORTED_DEV-1):0]   dev_reg_info_st_arr_axi_clk;
dev_reg_info_st_t    [(NO_OF_SUPPORTED_DEV-1):0]   dev_reg_info_st_arr_hdmi_clk;
dev_reg_info_st_t                                  sel_d_reg_info_st;

slfifo_data_nd_status_st_t   [(NO_OF_SUPPORTED_DEV-1):0]  slfifo_data_nd_status_st_arr;
slfifo_ctrl_req_st_t         [(NO_OF_SUPPORTED_DEV-1):0]  slfifo_ctrl_req_st_arr;
slfifo_ctrl_req_st_t         [(NO_OF_SUPPORTED_DEV-1):0]  slfifo_ctrl_req_st_arr_buf;

fbh_rd_states_nd_ctrl_st_t   [(NO_OF_SUPPORTED_DEV-1):0]  fbh_rd_states_nd_ctrl;
fbh_rd_dsf_flags_st_t        [(NO_OF_SUPPORTED_DEV-1):0]  fbh_rd_dsf_flags_arr;

i2c_bus_in_st_t             [(NO_OF_FXN_MASTER_I2C-1):0] i2c_bus_in_st_arr;
i2c_bus_out_st_t            [(NO_OF_FXN_MASTER_I2C-1):0] i2c_bus_out_st_arr;

cam_i2c_bus_in_st_t  [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C-1):0] cam_i2c_bus_in_st_arr;
cam_i2c_bus_out_st_t [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C-1):0] cam_i2c_bus_out_st_arr;

// --------------------------------------------------
//
//  User GPIOs for Input and Output for Debugging
//
// --------------------------------------------------


// ------------------------------------------------
//
// PLL's selection based on lvds_clk_selection reg
//
// ------------------------------------------------

// Since throughput in LVDS is LVDS_CLK x GEAR_RATIO
// Now throughout should be same throughout the
// pipeline. So 148.5 MHz x 8 = 297 MHz x 4 = 594 MHz x 2

assign lvds_ser_clk =  ( ( lvds_fast_clk_594m && lvds_clk_594m_lock_i ) || ( lvds_fast_clk_297m && lvds_clk_297m_lock_i ) || ( lvds_fast_clk_148m && lvds_clk_148m_lock_i ) ) ;

assign lvds_clk_148m_reset_n_o = (common_reg_info.lvds_clk_selection  == 8'd8) ? 1: 0;   // 8:1
assign lvds_clk_297m_reset_n_o = (common_reg_info.lvds_clk_selection  == 8'd4) ? 1: 0;   // 4:1
assign lvds_clk_594m_reset_n_o = ( (common_reg_info.lvds_clk_selection  == 8'd2) | (common_reg_info.lvds_clk_selection  == 8'd0) ) ? 1: 0; // 2:1

// ------------------------------------------
//
// Reset Synchronizer
//
// ------------------------------------------

// Reset bridges
reset_synchronizer
  reset_sys_clk
    (
     .clk            ( sys_clk ),
     .reset_n        ( reset_n & sys_clk_lock ),  // Active Low
     .sync_reset_n_o ( sys_clk_reset_n )
    );

// Reset bridge
reset_synchronizer
  reset_axi_clk
    (
     .clk            ( axi_m_clk ),
     .reset_n        ( reset_n & pll_clk_74_25m_lock_i ),  // Active Low
     .sync_reset_n_o ( axi_m_clk_reset_n )
    );

// Reset bridge
reset_synchronizer
  reset_fxn_gpif_m_clk
    (
     .clk            ( fxn_gpif_m_clk ),
     .reset_n        ( reset_n & pll_clk_74_25m_lock_i ),  // Active Low
     .sync_reset_n_o ( fxn_gpif_m_clk_reset_n )
    );

// Reset bridge
reset_synchronizer
  reset_mipi_cfg_clk
    (
     .clk            ( mipi_cfg_clk ),
     .reset_n        ( reset_n &  pll_clk_16m_lock_i ),  // Active Low
     .sync_reset_n_o ( mipi_cfg_clk_reset_n )
    );

// Reset bridge
reset_synchronizer
  reset_mipi_pixel_clk
    (
     .clk            ( mipi_pixel_clk ),
     .reset_n        ( reset_n &  pll_clk_16m_lock_i ),  // Active Low
     .sync_reset_n_o ( mipi_pixel_clk_reset_n )
    );

// Reset bridge
reset_synchronizer
  reset_hdmi_clk
    (
     .clk            ( hdmi_clk ),
     .reset_n        ( reset_n & dev_reg_info_st_arr[0].hdmi_source_connection ),  // Active Low
     .sync_reset_n_o ( hdmi_clk_reset_n )
    );

// PLL Reset
// Based on external reset, will reset PLLs as well.
assign pll_ddr_clk_reset_n_o        = reset_n;
assign pll_clk_16m_reset_n_o        = reset_n;
assign pll_clk_74_25m_reset_n_o     = reset_n;

// ------------------------------------------
//
// GPIF Signals: Default Value
//
// ------------------------------------------

// always_ff HIGH.
// As following signals are not used by Slave FIFO FSM,
// assigned its default value.
// assign  fxn_gpif_m_oe_n_o     = 1'b1;
// assign  fxn_gpif_m_rd_req_n_o = 1'b1;

// ------------------------------------------
//
// Internal Test Pattern Generator
//
// ------------------------------------------

genvar fv_lv_gen;

generate
  if ( FV_LV_GENERATION == "TRUE" )
    begin
      for ( fv_lv_gen = 0; fv_lv_gen < NO_OF_SUPPORTED_DEV; fv_lv_gen = fv_lv_gen + 1 )
    begin
   fv_lv_generator
   #
   (
     .REF_CLK_PULSES_IN_S_I           ( INTERNAL_TEST_PATTERN_CLOCK_VALUE ),
     .MODE_I                          ( FV_LV_GENERATION_MODE ),
     .INCREMENTAL_DATA_PATTERN        ( INCREMENTAL_DATA_PATTERN ),
     .MOVING_BLOCK_EN_I               ( MOVING_BLOCK_EN ),
     .MOVING_BLOCK_COLOR_VYUY_VALUE_I ( MOVING_BLOCK_COLOR_VYUY_VALUE[fv_lv_gen] ),
     .MOVING_BLOCK_COLOR_RGB_VALUE_I  ( MOVING_BLOCK_COLOR_RGB_VALUE[fv_lv_gen] ),
     .NO_OF_LINES_IN_FRAME_BLANKING_I ( NO_OF_LINES_IN_FRAME_BLANKING ),
     .DATA_WIDTH_I                    ( INTERNAL_TEST_PATTERN_DATA_WIDTH )
   )
   fv_lv_generator
   (
   // Inputs
     .clk                             ( sys_clk ),
     .reset_n                         ( sys_clk_reset_n ),
     .image_width_i                   ( dev_reg_info_st_arr[fv_lv_gen].image_width ),
     .image_height_i                  ( dev_reg_info_st_arr[fv_lv_gen].image_height ),
     .image_pixel_width_i             ( dev_reg_info_st_arr[fv_lv_gen].image_pixel_width ),
     .rgb_mode_i                      ( dev_reg_info_st_arr[fv_lv_gen].hdmi_mode_rgb ),
     .line_blanking_clk_pulses_i      ( TEST_PATTERN_LINE_BLANK_CLOCK_CYCLES ),
     .image_fps_i                     ( dev_reg_info_st_arr[fv_lv_gen].image_fps ),
     .start_colourbar_gen_req_i       ( dev_reg_info_st_arr_hdmi_clk[fv_lv_gen].start_stream  /*sel_d_start_stream_hdmi_clk[fv_lv_gen]*/ ),
     .pause_colourbar_gen_req_i       ( pause_colourbar_gen_req[fv_lv_gen] ),
     .colour_bar_sel_i                ( dev_reg_info_st_arr_hdmi_clk[fv_lv_gen].internal_tp_en ),
   // Outputs
     .fv_o                            ( internal_tp_fv_hdmi_clk[fv_lv_gen] ),
     .lv_o                            ( internal_tp_lv_hdmi_clk[fv_lv_gen] ),
     .data_o                          ( internal_tp_data_hdmi_clk[fv_lv_gen] )
   );

         assign pause_colourbar_gen_req[fv_lv_gen] = ( ( LVCMOS_SLFIFO_MODE == "FV_LV" ) ? 1'b0 : y_data_bufr_full[fv_lv_gen] );

   end
   end
endgenerate

// ------------------------------------------
//
// MIPI_RX0
//
// ------------------------------------------

genvar mipi_rx;

parameter NUM_CAM = 1;

`ifdef CSI_RX_4LANES
    localparam CSI_RX_NUM_DATA_LANE =4;
    localparam CSI_RX_DATA_WIDTH_LANE = `CSI_RX_LANE_DATAWIDTH;
`else
    localparam CSI_RX_NUM_DATA_LANE =2;
    localparam CSI_RX_DATA_WIDTH_LANE = `CSI_RX_LANE_DATAWIDTH;
`endif

// Mapping to DPHY RX

logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0]  rx_pclk;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0]  RxUlpsClkNot;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0]  RxUlpsActiveClkNot;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0]  rx_reset_byte_HS_n;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0]  resetb_rx;

logic  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [CSI_RX_NUM_DATA_LANE-1:0]   RxErrEsc;
logic  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [CSI_RX_NUM_DATA_LANE-1:0]   RxErrControl;
logic  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [CSI_RX_NUM_DATA_LANE-1:0]   RxErrSotSyncHS;
logic  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [CSI_RX_NUM_DATA_LANE-1:0]   RxClkEsc;
logic  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [CSI_RX_NUM_DATA_LANE-1:0]   RxUlpsEsc;
logic  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [CSI_RX_NUM_DATA_LANE-1:0]   RxUlpsActiveNot;
logic  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [CSI_RX_NUM_DATA_LANE-1:0]   RxSkewCalHS;
logic  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [CSI_RX_NUM_DATA_LANE-1:0]   RxStopState;
logic  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [CSI_RX_NUM_DATA_LANE-1:0]   RxValidHS;
logic  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [CSI_RX_NUM_DATA_LANE-1:0]   RxSyncHS;
logic  [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [CSI_RX_NUM_DATA_LANE-1:0] [CSI_RX_DATA_WIDTH_LANE-1:0] RxDataHS;

assign mipi_dphy_rx_inst1_RESET_N   = resetb_rx[0];
assign mipi_dphy_rx_inst1_RST0_N    = rx_reset_byte_HS_n[0];

assign mipi_dphy_rx_inst2_RESET_N   = resetb_rx[1];
assign mipi_dphy_rx_inst2_RST0_N    = rx_reset_byte_HS_n[1];

assign mipi_dphy_rx_inst3_RESET_N   = resetb_rx[2];
assign mipi_dphy_rx_inst3_RST0_N    = rx_reset_byte_HS_n[2];

assign mipi_dphy_rx_inst4_RESET_N   = resetb_rx[3];
assign mipi_dphy_rx_inst4_RST0_N    = rx_reset_byte_HS_n[3];

//assign check_rx_hs_clk    = mipi_dphy_rx_inst1_WORD_CLKOUT_HS;
assign rx_pclk[0]            = mipi_dphy_rx_inst1_WORD_CLKOUT_HS;
assign RxUlpsClkNot[0]       = mipi_dphy_rx_inst1_RX_ULPS_CLK_NOT;
assign RxUlpsActiveClkNot[0] = mipi_dphy_rx_inst1_RX_ULPS_ACTIVE_CLK_NOT;
assign RxErrEsc[0][0]        = mipi_dphy_rx_inst1_ERR_ESC_LAN0;
assign RxErrEsc[0][1]        = mipi_dphy_rx_inst1_ERR_ESC_LAN1;
assign RxErrControl[0][0]    = mipi_dphy_rx_inst1_ERR_CONTROL_LAN0;
assign RxErrControl[0][1]    = mipi_dphy_rx_inst1_ERR_CONTROL_LAN1;
assign RxErrSotSyncHS[0][0]  = mipi_dphy_rx_inst1_ERR_SOT_SYNC_HS_LAN0;
assign RxErrSotSyncHS[0][1]  = mipi_dphy_rx_inst1_ERR_SOT_SYNC_HS_LAN1;
assign RxUlpsEsc[0][0]       = mipi_dphy_rx_inst1_RX_ULPS_ESC_LAN0;
assign RxUlpsEsc[0][1]       = mipi_dphy_rx_inst1_RX_ULPS_ESC_LAN1;
assign RxClkEsc[0][0]        = mipi_dphy_rx_inst1_ESC_LAN0_CLK;
assign RxClkEsc[0][1]        = mipi_dphy_rx_inst1_ESC_LAN1_CLK;
assign RxUlpsActiveNot[0][0] = mipi_dphy_rx_inst1_RX_ULPS_ACTIVE_NOT_LAN0;
assign RxUlpsActiveNot[0][1] = mipi_dphy_rx_inst1_RX_ULPS_ACTIVE_NOT_LAN1;
assign RxSkewCalHS[0][0]     = mipi_dphy_rx_inst1_RX_SKEW_CAL_HS_LAN0;
assign RxSkewCalHS[0][1]     = mipi_dphy_rx_inst1_RX_SKEW_CAL_HS_LAN1;
assign RxStopState[0][0]     = mipi_dphy_rx_inst1_STOPSTATE_LAN0;
assign RxStopState[0][1]     = mipi_dphy_rx_inst1_STOPSTATE_LAN1;
assign RxValidHS[0][0]       = mipi_dphy_rx_inst1_RX_VALID_HS_LAN0;
assign RxValidHS[0][1]       = mipi_dphy_rx_inst1_RX_VALID_HS_LAN1;
assign RxSyncHS[0][0]        = mipi_dphy_rx_inst1_RX_SYNC_HS_LAN0;
assign RxSyncHS[0][1]        = mipi_dphy_rx_inst1_RX_SYNC_HS_LAN1;
assign RxDataHS[0][0]        = mipi_dphy_rx_inst1_RX_DATA_HS_LAN0;
assign RxDataHS[0][1]        = mipi_dphy_rx_inst1_RX_DATA_HS_LAN1;


`ifdef CSI_RX_4LANES
assign RxErrEsc[0][2]        = mipi_dphy_rx_inst1_ERR_ESC_LAN2;
assign RxErrEsc[0][3]        = mipi_dphy_rx_inst1_ERR_ESC_LAN3;
assign RxErrControl[0][2]    = mipi_dphy_rx_inst1_ERR_CONTROL_LAN2;
assign RxErrControl[0][3]    = mipi_dphy_rx_inst1_ERR_CONTROL_LAN3;
assign RxErrSotSyncHS[0][2]  = mipi_dphy_rx_inst1_ERR_SOT_SYNC_HS_LAN2;
assign RxErrSotSyncHS[0][3]  = mipi_dphy_rx_inst1_ERR_SOT_SYNC_HS_LAN3;
assign RxUlpsEsc[0][2]       = mipi_dphy_rx_inst1_RX_ULPS_ESC_LAN2;
assign RxUlpsEsc[0][3]       = mipi_dphy_rx_inst1_RX_ULPS_ESC_LAN3;
assign RxClkEsc[0][2]        = mipi_dphy_rx_inst1_ESC_LAN2_CLK;
assign RxClkEsc[0][3]        = mipi_dphy_rx_inst1_ESC_LAN3_CLK;
assign RxUlpsActiveNot[0][2] = mipi_dphy_rx_inst1_RX_ULPS_ACTIVE_NOT_LAN2;
assign RxUlpsActiveNot[0][3] = mipi_dphy_rx_inst1_RX_ULPS_ACTIVE_NOT_LAN3;
assign RxSkewCalHS[0][2]     = mipi_dphy_rx_inst1_RX_SKEW_CAL_HS_LAN2;
assign RxSkewCalHS[0][3]     = mipi_dphy_rx_inst1_RX_SKEW_CAL_HS_LAN3;
assign RxStopState[0][2]     = mipi_dphy_rx_inst1_STOPSTATE_LAN2;
assign RxStopState[0][3]     = mipi_dphy_rx_inst1_STOPSTATE_LAN3;
assign RxValidHS[0][2]       = mipi_dphy_rx_inst1_RX_VALID_HS_LAN2;
assign RxValidHS[0][3]       = mipi_dphy_rx_inst1_RX_VALID_HS_LAN3;
assign RxSyncHS[0][2]        = mipi_dphy_rx_inst1_RX_SYNC_HS_LAN2;
assign RxSyncHS[0][3]        = mipi_dphy_rx_inst1_RX_SYNC_HS_LAN3;
assign RxDataHS[0][2]        = mipi_dphy_rx_inst1_RX_DATA_HS_LAN2;
assign RxDataHS[0][3]        = mipi_dphy_rx_inst1_RX_DATA_HS_LAN3;
    `endif

// CSI controllers ouptut interface port

localparam   CAM_PIXEL_RX_DATAWIDTH     = 12 /*10*/; //RAW10, RAW12
localparam   CAM_PIXEL_RX_MEM_DATAWIDTH = 12 /*8*/;
localparam   VIDEO_MEM_DATAWIDTH        = 8;

logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [ 5:0]  w_rx_out_dt;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [1:0]   w_rx_out_vc;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [15:0]  w_rx_out_word_count;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [3:0]   w_rx_out_ppc;

logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [NUM_CAM*CAM_PIXEL_RX_MEM_DATAWIDTH-1:0] w_rx_out_data_00;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [NUM_CAM*CAM_PIXEL_RX_MEM_DATAWIDTH-1:0] w_rx_out_data_01;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [NUM_CAM*CAM_PIXEL_RX_MEM_DATAWIDTH-1:0] w_rx_out_data_10;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [NUM_CAM*CAM_PIXEL_RX_MEM_DATAWIDTH-1:0] w_rx_out_data_11;

logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [5:0]   w_axi_addr;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0]         r_axi_addready;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [14:0]  r_axi_rdata;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0]         r_axi_rvalid;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0] [14:0]  csr;
logic [(NO_OF_SUPPORTED_DEV_BY_MIPI-1):0]         irq;

assign o_cam_rstn = 1'b1; /*{4{w_sysclk_arstn}}*/

// ------------------------------------------
//
// MIPI_RX1
//
// ------------------------------------------

//assign check_rx_hs_clk    = mipi_dphy_rx_inst2_WORD_CLKOUT_HS;
assign rx_pclk[1]            = mipi_dphy_rx_inst2_WORD_CLKOUT_HS;
assign RxUlpsClkNot[1]       = mipi_dphy_rx_inst2_RX_ULPS_CLK_NOT;
assign RxUlpsActiveClkNot[1] = mipi_dphy_rx_inst2_RX_ULPS_ACTIVE_CLK_NOT;
assign RxErrEsc[1][0]        = mipi_dphy_rx_inst2_ERR_ESC_LAN0;
assign RxErrEsc[1][1]        = mipi_dphy_rx_inst2_ERR_ESC_LAN1;
assign RxErrControl[1][0]    = mipi_dphy_rx_inst2_ERR_CONTROL_LAN0;
assign RxErrControl[1][1]    = mipi_dphy_rx_inst2_ERR_CONTROL_LAN1;
assign RxErrSotSyncHS[1][0]  = mipi_dphy_rx_inst2_ERR_SOT_SYNC_HS_LAN0;
assign RxErrSotSyncHS[1][1]  = mipi_dphy_rx_inst2_ERR_SOT_SYNC_HS_LAN1;
assign RxUlpsEsc[1][0]       = mipi_dphy_rx_inst2_RX_ULPS_ESC_LAN0;
assign RxUlpsEsc[1][1]       = mipi_dphy_rx_inst2_RX_ULPS_ESC_LAN1;
assign RxClkEsc[1][0]        = mipi_dphy_rx_inst2_ESC_LAN0_CLK;
assign RxClkEsc[1][1]        = mipi_dphy_rx_inst2_ESC_LAN1_CLK;
assign RxUlpsActiveNot[1][0] = mipi_dphy_rx_inst2_RX_ULPS_ACTIVE_NOT_LAN0;
assign RxUlpsActiveNot[1][1] = mipi_dphy_rx_inst2_RX_ULPS_ACTIVE_NOT_LAN1;
assign RxSkewCalHS[1][0]     = mipi_dphy_rx_inst2_RX_SKEW_CAL_HS_LAN0;
assign RxSkewCalHS[1][1]     = mipi_dphy_rx_inst2_RX_SKEW_CAL_HS_LAN1;
assign RxStopState[1][0]     = mipi_dphy_rx_inst2_STOPSTATE_LAN0;
assign RxStopState[1][1]     = mipi_dphy_rx_inst2_STOPSTATE_LAN1;
assign RxValidHS[1][0]       = mipi_dphy_rx_inst2_RX_VALID_HS_LAN0;
assign RxValidHS[1][1]       = mipi_dphy_rx_inst2_RX_VALID_HS_LAN1;
assign RxSyncHS[1][0]        = mipi_dphy_rx_inst2_RX_SYNC_HS_LAN0;
assign RxSyncHS[1][1]        = mipi_dphy_rx_inst2_RX_SYNC_HS_LAN1;
assign RxDataHS[1][0]        = mipi_dphy_rx_inst2_RX_DATA_HS_LAN0;
assign RxDataHS[1][1]        = mipi_dphy_rx_inst2_RX_DATA_HS_LAN1;


`ifdef CSI_RX_4LANES
assign RxErrEsc[1][2]        = mipi_dphy_rx_inst2_ERR_ESC_LAN2;
assign RxErrEsc[1][3]        = mipi_dphy_rx_inst2_ERR_ESC_LAN3;
assign RxErrControl[1][2]    = mipi_dphy_rx_inst2_ERR_CONTROL_LAN2;
assign RxErrControl[1][3]    = mipi_dphy_rx_inst2_ERR_CONTROL_LAN3;
assign RxErrSotSyncHS[1][2]  = mipi_dphy_rx_inst2_ERR_SOT_SYNC_HS_LAN2;
assign RxErrSotSyncHS[1][3]  = mipi_dphy_rx_inst2_ERR_SOT_SYNC_HS_LAN3;
assign RxUlpsEsc[1][2]       = mipi_dphy_rx_inst2_RX_ULPS_ESC_LAN2;
assign RxUlpsEsc[1][3]       = mipi_dphy_rx_inst2_RX_ULPS_ESC_LAN3;
assign RxClkEsc[1][2]        = mipi_dphy_rx_inst2_ESC_LAN2_CLK;
assign RxClkEsc[1][3]        = mipi_dphy_rx_inst2_ESC_LAN3_CLK;
assign RxUlpsActiveNot[1][2] = mipi_dphy_rx_inst2_RX_ULPS_ACTIVE_NOT_LAN2;
assign RxUlpsActiveNot[1][3] = mipi_dphy_rx_inst2_RX_ULPS_ACTIVE_NOT_LAN3;
assign RxSkewCalHS[1][2]     = mipi_dphy_rx_inst2_RX_SKEW_CAL_HS_LAN2;
assign RxSkewCalHS[1][3]     = mipi_dphy_rx_inst2_RX_SKEW_CAL_HS_LAN3;
assign RxStopState[1][2]     = mipi_dphy_rx_inst2_STOPSTATE_LAN2;
assign RxStopState[1][3]     = mipi_dphy_rx_inst2_STOPSTATE_LAN3;
assign RxValidHS[1][2]       = mipi_dphy_rx_inst2_RX_VALID_HS_LAN2;
assign RxValidHS[1][3]       = mipi_dphy_rx_inst2_RX_VALID_HS_LAN3;
assign RxSyncHS[1][2]        = mipi_dphy_rx_inst2_RX_SYNC_HS_LAN2;
assign RxSyncHS[1][3]        = mipi_dphy_rx_inst2_RX_SYNC_HS_LAN3;
assign RxDataHS[1][2]        = mipi_dphy_rx_inst2_RX_DATA_HS_LAN2;
assign RxDataHS[1][3]        = mipi_dphy_rx_inst2_RX_DATA_HS_LAN3;
    `endif


// ------------------------------------------
//
// MIPI_RX2
//
// ------------------------------------------

//assign check_rx_hs_clk    = mipi_dphy_rx_inst3_WORD_CLKOUT_HS;
assign rx_pclk[2]            = mipi_dphy_rx_inst3_WORD_CLKOUT_HS;
assign RxUlpsClkNot[2]       = mipi_dphy_rx_inst3_RX_ULPS_CLK_NOT;
assign RxUlpsActiveClkNot[2] = mipi_dphy_rx_inst3_RX_ULPS_ACTIVE_CLK_NOT;
assign RxErrEsc[2][0]        = mipi_dphy_rx_inst3_ERR_ESC_LAN0;
assign RxErrEsc[2][1]        = mipi_dphy_rx_inst3_ERR_ESC_LAN1;
assign RxErrControl[2][0]    = mipi_dphy_rx_inst3_ERR_CONTROL_LAN0;
assign RxErrControl[2][1]    = mipi_dphy_rx_inst3_ERR_CONTROL_LAN1;
assign RxErrSotSyncHS[2][0]  = mipi_dphy_rx_inst3_ERR_SOT_SYNC_HS_LAN0;
assign RxErrSotSyncHS[2][1]  = mipi_dphy_rx_inst3_ERR_SOT_SYNC_HS_LAN1;
assign RxUlpsEsc[2][0]       = mipi_dphy_rx_inst3_RX_ULPS_ESC_LAN0;
assign RxUlpsEsc[2][1]       = mipi_dphy_rx_inst3_RX_ULPS_ESC_LAN1;
assign RxClkEsc[2][0]        = mipi_dphy_rx_inst3_ESC_LAN0_CLK;
assign RxClkEsc[2][1]        = mipi_dphy_rx_inst3_ESC_LAN1_CLK;
assign RxUlpsActiveNot[2][0] = mipi_dphy_rx_inst3_RX_ULPS_ACTIVE_NOT_LAN0;
assign RxUlpsActiveNot[2][1] = mipi_dphy_rx_inst3_RX_ULPS_ACTIVE_NOT_LAN1;
assign RxSkewCalHS[2][0]     = mipi_dphy_rx_inst3_RX_SKEW_CAL_HS_LAN0;
assign RxSkewCalHS[2][1]     = mipi_dphy_rx_inst3_RX_SKEW_CAL_HS_LAN1;
assign RxStopState[2][0]     = mipi_dphy_rx_inst3_STOPSTATE_LAN0;
assign RxStopState[2][1]     = mipi_dphy_rx_inst3_STOPSTATE_LAN1;
assign RxValidHS[2][0]       = mipi_dphy_rx_inst3_RX_VALID_HS_LAN0;
assign RxValidHS[2][1]       = mipi_dphy_rx_inst3_RX_VALID_HS_LAN1;
assign RxSyncHS[2][0]        = mipi_dphy_rx_inst3_RX_SYNC_HS_LAN0;
assign RxSyncHS[2][1]        = mipi_dphy_rx_inst3_RX_SYNC_HS_LAN1;
assign RxDataHS[2][0]        = mipi_dphy_rx_inst3_RX_DATA_HS_LAN0;
assign RxDataHS[2][1]        = mipi_dphy_rx_inst3_RX_DATA_HS_LAN1;


`ifdef CSI_RX_4LANES
assign RxErrEsc[2][2]        = mipi_dphy_rx_inst3_ERR_ESC_LAN2;
assign RxErrEsc[2][3]        = mipi_dphy_rx_inst3_ERR_ESC_LAN3;
assign RxErrControl[2][2]    = mipi_dphy_rx_inst3_ERR_CONTROL_LAN2;
assign RxErrControl[2][3]    = mipi_dphy_rx_inst3_ERR_CONTROL_LAN3;
assign RxErrSotSyncHS[2][2]  = mipi_dphy_rx_inst3_ERR_SOT_SYNC_HS_LAN2;
assign RxErrSotSyncHS[2][3]  = mipi_dphy_rx_inst3_ERR_SOT_SYNC_HS_LAN3;
assign RxUlpsEsc[2][2]       = mipi_dphy_rx_inst3_RX_ULPS_ESC_LAN2;
assign RxUlpsEsc[2][3]       = mipi_dphy_rx_inst3_RX_ULPS_ESC_LAN3;
assign RxClkEsc[2][2]        = mipi_dphy_rx_inst3_ESC_LAN2_CLK;
assign RxClkEsc[2][3]        = mipi_dphy_rx_inst3_ESC_LAN3_CLK;
assign RxUlpsActiveNot[2][2] = mipi_dphy_rx_inst3_RX_ULPS_ACTIVE_NOT_LAN2;
assign RxUlpsActiveNot[2][3] = mipi_dphy_rx_inst3_RX_ULPS_ACTIVE_NOT_LAN3;
assign RxSkewCalHS[2][2]     = mipi_dphy_rx_inst3_RX_SKEW_CAL_HS_LAN2;
assign RxSkewCalHS[2][3]     = mipi_dphy_rx_inst3_RX_SKEW_CAL_HS_LAN3;
assign RxStopState[2][2]     = mipi_dphy_rx_inst3_STOPSTATE_LAN2;
assign RxStopState[2][3]     = mipi_dphy_rx_inst3_STOPSTATE_LAN3;
assign RxValidHS[2][2]       = mipi_dphy_rx_inst3_RX_VALID_HS_LAN2;
assign RxValidHS[2][3]       = mipi_dphy_rx_inst3_RX_VALID_HS_LAN3;
assign RxSyncHS[2][2]        = mipi_dphy_rx_inst3_RX_SYNC_HS_LAN2;
assign RxSyncHS[2][3]        = mipi_dphy_rx_inst3_RX_SYNC_HS_LAN3;
assign RxDataHS[2][2]        = mipi_dphy_rx_inst3_RX_DATA_HS_LAN2;
assign RxDataHS[2][3]        = mipi_dphy_rx_inst3_RX_DATA_HS_LAN3;
`endif

// ------------------------------------------
//
// MIPI_RX3
//
// -----------------------------------------

//assign check_rx_hs_clk    = mipi_dphy_rx_inst4_WORD_CLKOUT_HS;
assign rx_pclk[3]            = mipi_dphy_rx_inst4_WORD_CLKOUT_HS;
assign RxUlpsClkNot[3]       = mipi_dphy_rx_inst4_RX_ULPS_CLK_NOT;
assign RxUlpsActiveClkNot[3] = mipi_dphy_rx_inst4_RX_ULPS_ACTIVE_CLK_NOT;
assign RxErrEsc[3][0]        = mipi_dphy_rx_inst4_ERR_ESC_LAN0;
assign RxErrEsc[3][1]        = mipi_dphy_rx_inst4_ERR_ESC_LAN1;
assign RxErrControl[3][0]    = mipi_dphy_rx_inst4_ERR_CONTROL_LAN0;
assign RxErrControl[3][1]    = mipi_dphy_rx_inst4_ERR_CONTROL_LAN1;
assign RxErrSotSyncHS[3][0]  = mipi_dphy_rx_inst4_ERR_SOT_SYNC_HS_LAN0;
assign RxErrSotSyncHS[3][1]  = mipi_dphy_rx_inst4_ERR_SOT_SYNC_HS_LAN1;
assign RxUlpsEsc[3][0]       = mipi_dphy_rx_inst4_RX_ULPS_ESC_LAN0;
assign RxUlpsEsc[3][1]       = mipi_dphy_rx_inst4_RX_ULPS_ESC_LAN1;
assign RxClkEsc[3][0]        = mipi_dphy_rx_inst4_ESC_LAN0_CLK;
assign RxClkEsc[3][1]        = mipi_dphy_rx_inst4_ESC_LAN1_CLK;
assign RxUlpsActiveNot[3][0] = mipi_dphy_rx_inst4_RX_ULPS_ACTIVE_NOT_LAN0;
assign RxUlpsActiveNot[3][1] = mipi_dphy_rx_inst4_RX_ULPS_ACTIVE_NOT_LAN1;
assign RxSkewCalHS[3][0]     = mipi_dphy_rx_inst4_RX_SKEW_CAL_HS_LAN0;
assign RxSkewCalHS[3][1]     = mipi_dphy_rx_inst4_RX_SKEW_CAL_HS_LAN1;
assign RxStopState[3][0]     = mipi_dphy_rx_inst4_STOPSTATE_LAN0;
assign RxStopState[3][1]     = mipi_dphy_rx_inst4_STOPSTATE_LAN1;
assign RxValidHS[3][0]       = mipi_dphy_rx_inst4_RX_VALID_HS_LAN0;
assign RxValidHS[3][1]       = mipi_dphy_rx_inst4_RX_VALID_HS_LAN1;
assign RxSyncHS[3][0]        = mipi_dphy_rx_inst4_RX_SYNC_HS_LAN0;
assign RxSyncHS[3][1]        = mipi_dphy_rx_inst4_RX_SYNC_HS_LAN1;
assign RxDataHS[3][0]        = mipi_dphy_rx_inst4_RX_DATA_HS_LAN0;
assign RxDataHS[3][1]        = mipi_dphy_rx_inst4_RX_DATA_HS_LAN1;


`ifdef CSI_RX_4LANES
assign RxErrEsc[3][2]        = mipi_dphy_rx_inst4_ERR_ESC_LAN2;
assign RxErrEsc[3][3]        = mipi_dphy_rx_inst4_ERR_ESC_LAN3;
assign RxErrControl[3][2]    = mipi_dphy_rx_inst4_ERR_CONTROL_LAN2;
assign RxErrControl[3][3]    = mipi_dphy_rx_inst4_ERR_CONTROL_LAN3;
assign RxErrSotSyncHS[3][2]  = mipi_dphy_rx_inst4_ERR_SOT_SYNC_HS_LAN2;
assign RxErrSotSyncHS[3][3]  = mipi_dphy_rx_inst4_ERR_SOT_SYNC_HS_LAN3;
assign RxUlpsEsc[3][2]       = mipi_dphy_rx_inst4_RX_ULPS_ESC_LAN2;
assign RxUlpsEsc[3][3]       = mipi_dphy_rx_inst4_RX_ULPS_ESC_LAN3;
assign RxClkEsc[3][2]        = mipi_dphy_rx_inst4_ESC_LAN2_CLK;
assign RxClkEsc[3][3]        = mipi_dphy_rx_inst4_ESC_LAN3_CLK;
assign RxUlpsActiveNot[3][2] = mipi_dphy_rx_inst4_RX_ULPS_ACTIVE_NOT_LAN2;
assign RxUlpsActiveNot[3][3] = mipi_dphy_rx_inst4_RX_ULPS_ACTIVE_NOT_LAN3;
assign RxSkewCalHS[3][2]     = mipi_dphy_rx_inst4_RX_SKEW_CAL_HS_LAN2;
assign RxSkewCalHS[3][3]     = mipi_dphy_rx_inst4_RX_SKEW_CAL_HS_LAN3;
assign RxStopState[3][2]     = mipi_dphy_rx_inst4_STOPSTATE_LAN2;
assign RxStopState[3][3]     = mipi_dphy_rx_inst4_STOPSTATE_LAN3;
assign RxValidHS[3][2]       = mipi_dphy_rx_inst4_RX_VALID_HS_LAN2;
assign RxValidHS[3][3]       = mipi_dphy_rx_inst4_RX_VALID_HS_LAN3;
assign RxSyncHS[3][2]        = mipi_dphy_rx_inst4_RX_SYNC_HS_LAN2;
assign RxSyncHS[3][3]        = mipi_dphy_rx_inst4_RX_SYNC_HS_LAN3;
assign RxDataHS[3][2]        = mipi_dphy_rx_inst4_RX_DATA_HS_LAN2;
assign RxDataHS[3][3]        = mipi_dphy_rx_inst4_RX_DATA_HS_LAN3;
`endif


// ------------------------------------------
//
// Instantiating the MIPI_RX_CONTROLLERS
//
// ------------------------------------------


generate
  for (mipi_rx = 0; mipi_rx < NO_OF_SUPPORTED_DEV_BY_MIPI; mipi_rx = mipi_rx + 1 )
    begin

csi_rx_controllers
#(
   .NUM_CHANNEL           ( NUM_CAM ),
   .NUM_RX_PER_CHANNEL    ( CSI_RX_NUM_DATA_LANE ),
   .DATAWIDTH_PER_CHANNEL ( CSI_RX_DATA_WIDTH_LANE ),
   .PIXEL_RX_DATAWIDTH    ( CAM_PIXEL_RX_DATAWIDTH ),     // RAW10, RAW12
   .PIXEL_OUT_DATAWIDTH   ( CAM_PIXEL_RX_MEM_DATAWIDTH )  // DATAWIDTH will be store to Memory
)
csi_rx_controllers_inst
(

    .rstn                  ( mipi_cfg_clk_reset_n /*w_sysclk_arstn*/ ),
    .clk                   ( mipi_cfg_clk /*i_pixel_clk*/ ),             // .clk(i_sys_clk_100mhz),   //For Controller Clock 100mhz
    .clk_pixel             ( sys_clk /*hdmi_clk_o i_pixel_clk*/ ),// .clk_pixel(i_pixel_clk),  //pixel clock for 4K@60 min. 220Mhz
     // DPHY interface port

    .clk_byte_HS           ( rx_pclk[mipi_rx]           /*{rx_pclk_3,rx_pclk_2,rx_pclk_1,rx_pclk_0}*/ ),
    .reset_byte_HS_n       ( rx_reset_byte_HS_n[mipi_rx] /*{rx_reset_byte_HS_n_3,rx_reset_byte_HS_n_2,rx_reset_byte_HS_n_1,rx_reset_byte_HS_n_0}*/ ),
    .resetb_rx             ( resetb_rx[mipi_rx]         /*{resetb_rx_3,resetb_rx_2,resetb_rx_1,resetb_rx_0}*/ ),

    .RxDataHS0             ( RxDataHS[mipi_rx][0]  /*{RxDataHS_3[0],RxDataHS_2[0],RxDataHS_1[0],RxDataHS_0[0]*/ ),    //full 16 bit
    .RxDataHS1             ( RxDataHS[mipi_rx][1]  /*{RxDataHS_3[1],RxDataHS_2[1],RxDataHS_1[1],RxDataHS_0[1]*/ ),
    .RxValidHS0            ( RxValidHS[mipi_rx][0] /*{RxValidHS_3[0],RxValidHS_2[0],RxValidHS_1[0],RxValidHS_0[0]*/ ),
    .RxValidHS1            ( RxValidHS[mipi_rx][1] /*{RxValidHS_3[1],RxValidHS_2[1],RxValidHS_1[1],RxValidHS_0[1]*/ ),
    `ifdef CSI_RX_4LANES
    .RxDataHS2             ( RxDataHS[mipi_rx][2]  /*{RxDataHS_3[2],RxDataHS_2[2],RxDataHS_1[2],RxDataHS_0[2]}*/ ),
    .RxDataHS3             ( RxDataHS[mipi_rx][3]  /*{RxDataHS_3[3],RxDataHS_2[3],RxDataHS_1[3],RxDataHS_0[3]}*/ ),
    .RxValidHS2            ( RxValidHS[mipi_rx][2] /*{RxValidHS_3[2],RxValidHS_2[2],RxValidHS_1[2],RxValidHS_0[2]}*/ ),
    .RxValidHS3            ( RxValidHS[mipi_rx][3] /*{RxValidHS_3[3],RxValidHS_2[3],RxValidHS_1[3],RxValidHS_0[3]}*/ ),
    `endif

    .RxSyncHS              ( RxSyncHS[mipi_rx]           /*{RxSyncHS_3 , RxSyncHS_2 , RxSyncHS_1 , RxSyncHS_0 }*/ ),
    .RxUlpsClkNot          ( RxUlpsClkNot[mipi_rx]       /*{RxUlpsClkNot_3 , RxUlpsClkNot_2 , RxUlpsClkNot_1 , RxUlpsClkNot_0 }*/ ),
    .RxUlpsActiveClkNot    ( RxUlpsActiveClkNot[mipi_rx] /*{RxUlpsActiveClkNot_3, RxUlpsActiveClkNot_2, RxUlpsActiveClkNot_1, RxUlpsActiveClkNot_0}*/ ),
    .RxErrEsc              ( RxErrEsc[mipi_rx]           /*{RxErrEsc_3 , RxErrEsc_2 , RxErrEsc_1 , RxErrEsc_0 }*/ ),
    .RxErrControl          ( RxErrControl[mipi_rx]       /*{RxErrControl_3 , RxErrControl_2 , RxErrControl_1 , RxErrControl_0 }*/ ),
    .RxErrSotSyncHS        ( RxErrSotSyncHS[mipi_rx]     /*{RxErrSotSyncHS_3 , RxErrSotSyncHS_2 , RxErrSotSyncHS_1 , RxErrSotSyncHS_0 }*/ ),
    .RxUlpsEsc             ( RxUlpsEsc[mipi_rx]         /*{RxUlpsEsc_3 , RxUlpsEsc_2 , RxUlpsEsc_1 , RxUlpsEsc_0 }*/ ),
    .RxUlpsActiveNot       ( RxUlpsActiveNot[mipi_rx]    /*{RxUlpsActiveNot_3 , RxUlpsActiveNot_2 , RxUlpsActiveNot_1 , RxUlpsActiveNot_0 }*/ ),
    .RxSkewCalHS           ( RxSkewCalHS[mipi_rx]       /*{RxSkewCalHS_3 , RxSkewCalHS_2 , RxSkewCalHS_1 ,  RxSkewCalHS_0 }*/ ),
    .RxStopState           ( RxStopState[mipi_rx]        /*{RxStopState_3 , RxStopState_2 , RxStopState_1 ,  RxStopState_0 }*/ ),

  // CSI controller ouptut interface port

    .rx_out_de             ( w_rx_out_de[mipi_rx] ),
    .rx_out_vs             ( w_rx_out_vs[mipi_rx] ),
    .rx_out_hs             ( w_rx_out_hs[mipi_rx] ),
    .rx_out_dt             ( w_rx_out_dt[mipi_rx] ),
    .rx_out_vc             ( w_rx_out_vc[mipi_rx] ),
    .rx_out_word_count     ( w_rx_out_word_count[mipi_rx] ),
    .rx_out_ppc            ( w_rx_out_ppc[mipi_rx] ),
    .rx_out_data           ( w_rx_out_data[mipi_rx] ),
    .rx_out_data_00        ( w_rx_out_data_00[mipi_rx] ),
    .rx_out_data_01        ( w_rx_out_data_01[mipi_rx] ),
    .rx_out_data_10        ( w_rx_out_data_10[mipi_rx] ),
    .rx_out_data_11        ( w_rx_out_data_11[mipi_rx] ),

  // CSI debug interface

    .w_axi_addr            ( w_axi_addr[mipi_rx] ),
    .r_axi_addready        ( r_axi_addready[mipi_rx] ),
    .r_axi_rdata           ( r_axi_rdata[mipi_rx] ),
    .r_axi_rvalid          ( r_axi_rvalid[mipi_rx] ),
    .csr                   ( csr[mipi_rx] ),
    .irq                   ( irq[mipi_rx] )

);

  end
endgenerate

// --------------------------------------------------
 //
// Active Data module for Sony Sensor data
//
// --------------------------------------------------

`ifdef ACTIVE_DATA_EN

genvar active_data;

generate
  for (active_data = 0; active_data < NO_OF_SUPPORTED_DEV; active_data = active_data + 1 )
    begin
   active_data_mod
   #
   (
     .DATA_WIDTH_I                    ( 8'd64 ),
     .MIPI_DATA_FORMAT_I              ( MIPI_DATA_FORMAT )
   )
   active_data_mod_inst
   (
     .clk_i                            ( sys_clk ),
     .rstn_i                           ( sys_clk_reset_n ),
     .line_valid_i                     ( w_rx_out_hs[active_data] ),
     .frame_valid_i                    ( w_rx_out_vs[active_data] ),
     .data_enable_i                    ( w_rx_out_de[active_data] ),
     .data_i                           ( w_rx_out_data[active_data] ),
     .data_type_i                      ( w_rx_out_dt[active_data] ),
     .image_width_i                    ( dev_reg_info_st_arr[active_data].image_width ),
     .image_height_i                   ( dev_reg_info_st_arr[active_data].image_height ),
     .pixels_per_clock_i               ( w_rx_out_ppc[active_data] ),
     .data_valid_o                     ( rx_sensor_data_valid[active_data] ),
     .frame_valid_o                    ( rx_frame_valid[active_data] ),
     .data_o                           ( rx_sensor_data[active_data] )

   );
    end
endgenerate

`endif


// ------------------------------------------
//
// Configuration of DDR IP
//
// ------------------------------------------

ddr_config_manager
 ddr_config_manager_1
   (
     .clk_i                    ( axi_m_clk ),
     .reset_n_i                ( axi_m_clk_reset_n ),
     .ddr_cfg_done_i           ( ddr_cfg_done_i ),
     .ddr_cfg_done_o           ( ddr_cfg_done ),
     .ddr_cfg_seq_start_o      ( ddr_cfg_seq_start_o ),
     .ddr_cfg_seq_rst_o        ( ddr_cfg_seq_rst_o ),
     .ddr_cfg_seq_sel_o        ( ddr_cfg_seq_sel_o )
    );

//-----------------------------
//     AXI0
//-----------------------------

//Write address optional signals
assign axi_m0_awallstrb_o = 1'b0;
assign axi_m0_awapcmd_o   = 1'b0;
assign axi_m0_awcobuf_o   = 1'b0;
assign axi_m0_awqos_o     = 1'b0;
assign axi_m0_awcache_o   = 4'h0;

//Read address optional signals
assign axi_m0_arqos_o     = 1'b0;
assign axi_m0_arapcmd_o   = 1'b0;


// Active Low AXI Reset
assign axi_m0_arstn_o = axi_m_clk_reset_n;

//-----------------------------
//     AXI1
//-----------------------------

//Write address optional signals
assign axi_m1_awallstrb_o = 1'b0;
assign axi_m1_awapcmd_o   = 1'b0;
assign axi_m1_awcobuf_o   = 1'b0;
assign axi_m1_awqos_o     = 1'b0;
assign axi_m1_awcache_o   = 4'h0;

//Read address optional signals
assign axi_m1_arqos_o     = 1'b0;
assign axi_m1_arapcmd_o   = 1'b0;


// Active Low AXI Reset
assign axi_m1_arstn_o = axi_m_clk_reset_n;


// LED Indication for DDR Configuration
assign led_ddr_o = ddr_cfg_done;

// ------------------------------------------
//
// DDR Frame Buffer Module Instance (AXI0)
//
// ------------------------------------------

generate
  if ( DDR_AXI0 == "TRUE" )
    begin

fbh_wrapper
  #
  (
   .SLFIFO_DEPTH_IN_WORDS_I                      ( SLFIFO_DEPTH_IN_WORDS ),
   .SLFIFO_RD_DATA_WIDTH_IN_BITS_I               ( SLFIFO_RD_DATA_WIDTH_IN_BITS ),
   .SLFIFO_WR_COUNT_DATA_WIDTH_I                 ( SLFIFO_WR_COUNT_DATA_WIDTH ),
   .Y_DATA_FIFO_WR_DATA_WIDTH_I                  ( INTERMEDIATE_FIFO_WR_DATA_WIDTH_IN_BITS ),
   .AXI_M0_WR_DATA_WIDTH_IN_BITS_I               ( AXI_M0_WR_DATA_WIDTH_IN_BITS ),
   .AXI_M0_RD_DATA_WIDTH_IN_BITS_I               ( AXI_M0_RD_DATA_WIDTH_IN_BITS ),
   .FIRST_BUFFER_START_ADDR_I                    ( FIRST_BUFFER_START_ADDR_AXI0 ),
   .BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I        ( BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_AXI0 ),
   .FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I ( FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_AXI0 ),
   .NO_OF_SUPPORTED_DEV_I                        ( NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M ),
   .SEL_DEV_NUM_BITS_I                           ( SEL_DEV_NUM_BITS_BY_EACH_AXI_M ),
   .Y_DATA_FIFO_DEPTH_IN_WORDS_I                 ( Y_DATA_FIFO_DEPTH_IN_WORDS ),
   .MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I   ( MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES )
  )
  ddr_buffer_axi0
    (
     .ddr_wr_xfer_axi_clk_arr_o     ( ddr_wr_xfer_axi_clk_arr[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0]  ),
     .full_frame_wr_completed_arr_o ( full_frame_wr_completed_axi_clk_arr[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .y_data_bufr_full_o            ( y_data_bufr_full [(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .y_data_bufr_empty_o           ( y_data_bufr_empty[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .sel_d_start_stream_axi_clk_o  ( sel_d_start_stream_axi_clk[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .fbh_rd_states_nd_ctrl_o       ( fbh_rd_states_nd_ctrl[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .fbh_rd_dsf_flags_arr_o        ( fbh_rd_dsf_flags_arr[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .fbh_rd_dsf_sel_device_num_o   ( fbh_rd_dsf_sel_device_num[(SEL_DEV_NUM_BITS_BY_EACH_AXI_M-1):0] ),

  // Master Write Address Channel
     .axi_m0_awready_i              ( axi_m0_awready_i ),
     .axi_m0_awaddr_o               ( axi_m0_awaddr_o ),
     .axi_m0_awvalid_o              ( axi_m0_awvalid_o ),
     .axi_m0_awburst_o              ( axi_m0_awburst_o ),
     .axi_m0_awid_o                 ( axi_m0_awid_o ),
     .axi_m0_awlen_o                ( axi_m0_awlen_o ),
     .axi_m0_awlock_o               ( axi_m0_awlock_o ),
     .axi_m0_awsize_o               ( axi_m0_awsize_o ),

  // Master Write Data Channel
     .axi_m0_wready_i               ( axi_m0_wready_i ),
     .axi_m0_wlast_o                ( axi_m0_wlast_o ),
     .axi_m0_wvalid_o               ( axi_m0_wvalid_o ),
     .axi_m0_wdata_o                ( axi_m0_wdata_o ),
     .axi_m0_wstrb_o                ( axi_m0_wstrb_o ),

  // Master Write Response Channel
     .axi_m0_bid_i                  ( axi_m0_bid_i ),
     .axi_m0_bvalid_i               ( axi_m0_bvalid_i ),
     .axi_m0_bready_o               ( axi_m0_bready_o ),

  // Master Read Address Channel
     .axi_m0_arready_i              ( axi_m0_arready_i ),
     .axi_m0_araddr_o               ( axi_m0_araddr_o ),
     .axi_m0_arvalid_o              ( axi_m0_arvalid_o ),
     .axi_m0_arburst_o              ( axi_m0_arburst_o ),
     .axi_m0_arid_o                 ( axi_m0_arid_o ),
     .axi_m0_arlen_o                ( axi_m0_arlen_o ),
     .axi_m0_arlock_o               ( axi_m0_arlock_o ),
     .axi_m0_arsize_o               ( axi_m0_arsize_o ),

  // Master Read Data Channel
     .axi_m0_rid_i                  ( axi_m0_rid_i ),
     .axi_m0_rvalid_i               ( axi_m0_rvalid_i ),
     .axi_m0_rlast_i                ( axi_m0_rlast_i ),
     .axi_m0_rdata_i                ( axi_m0_rdata_i ),
     .axi_m0_rready_o               ( axi_m0_rready_o ),

  // Master Read Response Channel
     .axi_m0_rresp_i                ( axi_m0_rresp_i ),

  // Input clock and reset
     .hdmi_clk                      ( sys_clk ),
     .axi_clk                       ( axi_m_clk ),
     .fxn_gpif_m_clk                ( fxn_gpif_m_clk ),
     .hdmi_clk_reset_n              ( sys_clk_reset_n ),
     .axi_clk_reset_n               ( axi_m_clk_reset_n ),
     .fxn_gpif_m_clk_reset_n        ( fxn_gpif_m_clk_reset_n ),

  // Input data and controls
     .sel_vsync_axi_clk_i           ( sel_vsync_axi_clk[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .sel_vsync_hdmi_i              ( sel_vsync_hdmi_clk[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .sel_vsync_hdmi_pe_pl_i        ( sel_vsync_hdmi_clk_pe_pl[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .sel_vsync_hdmi_ne_pl_i        ( sel_vsync_hdmi_clk_ne_pl[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .sel_hsync_hdmi_i              ( sel_hsync_hdmi_clk[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .sel_vid_data_i                ( sel_intr_fifo_wr_data_hdmi_clk[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),

  // Typedef Structure
     .dev_reg_info_st_arr_axi_clk_i  ( dev_reg_info_st_arr_axi_clk[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .dev_reg_info_st_arr_gpif_clk_i ( dev_reg_info_st_arr[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .dev_reg_info_st_arr_hdmi_clk_i ( dev_reg_info_st_arr_hdmi_clk[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .slfifo_ctrl_req_i              ( slfifo_ctrl_req_st_arr[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .slfifo_data_nd_vld_o           ( slfifo_data_nd_status_st_arr[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .common_reg_info_i              ( common_reg_info ),


     .ddr_wr_xfer_hdmi_clk_arr_i     ( ddr_wr_xfer_hdmi_clk_arr[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .full_frame_wr_completed_hdmi_clk_arr_i  ( full_frame_wr_completed_hdmi_clk_arr[(NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M-1):0] ),
     .ddr_init_done_i               ( ddr_cfg_done )

    );

  end
endgenerate


// ------------------------------------------
//
// DDR Frame Buffer Module Instance (AXI1)
//
// ------------------------------------------

generate
  if ( DDR_AXI1 == "TRUE" )
    begin

fbh_wrapper
  #
  (
   .SLFIFO_DEPTH_IN_WORDS_I                      ( SLFIFO_DEPTH_IN_WORDS ),
   .SLFIFO_RD_DATA_WIDTH_IN_BITS_I               ( SLFIFO_RD_DATA_WIDTH_IN_BITS ),
   .SLFIFO_WR_COUNT_DATA_WIDTH_I                 ( SLFIFO_WR_COUNT_DATA_WIDTH ),
   .Y_DATA_FIFO_WR_DATA_WIDTH_I                  ( INTERMEDIATE_FIFO_WR_DATA_WIDTH_IN_BITS ),
   .AXI_M0_WR_DATA_WIDTH_IN_BITS_I               ( AXI_M0_WR_DATA_WIDTH_IN_BITS ),
   .AXI_M0_RD_DATA_WIDTH_IN_BITS_I               ( AXI_M0_RD_DATA_WIDTH_IN_BITS ),
   .FIRST_BUFFER_START_ADDR_I                    ( FIRST_BUFFER_START_ADDR_AXI1 ),
   .BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I        ( BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_AXI1 ),
   .FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I ( FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_AXI1 ),
   .NO_OF_SUPPORTED_DEV_I                        ( NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M ),
   .SEL_DEV_NUM_BITS_I                           ( SEL_DEV_NUM_BITS_BY_EACH_AXI_M ),
   .Y_DATA_FIFO_DEPTH_IN_WORDS_I                 ( Y_DATA_FIFO_DEPTH_IN_WORDS ),
   .MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I   ( MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES )
  )
  ddr_buffer_axi1
    (
     .ddr_wr_xfer_axi_clk_arr_o     ( ddr_wr_xfer_axi_clk_arr[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .full_frame_wr_completed_arr_o ( full_frame_wr_completed_axi_clk_arr[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .y_data_bufr_full_o            ( y_data_bufr_full[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .y_data_bufr_empty_o           ( y_data_bufr_empty[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .sel_d_start_stream_axi_clk_o  ( sel_d_start_stream_axi_clk[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .fbh_rd_states_nd_ctrl_o       ( fbh_rd_states_nd_ctrl[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .fbh_rd_dsf_flags_arr_o        ( fbh_rd_dsf_flags_arr[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .fbh_rd_dsf_sel_device_num_o   ( fbh_rd_dsf_sel_device_num[(SEL_DEV_NUM_BITS-1):SEL_DEV_NUM_BITS_BY_EACH_AXI_M] ),


  // Master Write Address Channel
     .axi_m0_awready_i              ( axi_m1_awready_i ),
     .axi_m0_awaddr_o               ( axi_m1_awaddr_o ),
     .axi_m0_awvalid_o              ( axi_m1_awvalid_o ),
     .axi_m0_awburst_o              ( axi_m1_awburst_o ),
     .axi_m0_awid_o                 ( axi_m1_awid_o ),
     .axi_m0_awlen_o                ( axi_m1_awlen_o ),
     .axi_m0_awlock_o               ( axi_m1_awlock_o ),
     .axi_m0_awsize_o               ( axi_m1_awsize_o ),

  // Master Write Data Channel
     .axi_m0_wready_i               ( axi_m1_wready_i ),
     .axi_m0_wlast_o                ( axi_m1_wlast_o ),
     .axi_m0_wvalid_o               ( axi_m1_wvalid_o ),
     .axi_m0_wdata_o                ( axi_m1_wdata_o ),
     .axi_m0_wstrb_o                ( axi_m1_wstrb_o ),

  // Master Write Response Channel
     .axi_m0_bid_i                  ( axi_m1_bid_i ),
     .axi_m0_bvalid_i               ( axi_m1_bvalid_i ),
     .axi_m0_bready_o               ( axi_m1_bready_o ),

  // Master Read Address Channel
     .axi_m0_arready_i              ( axi_m1_arready_i ),
     .axi_m0_araddr_o               ( axi_m1_araddr_o ),
     .axi_m0_arvalid_o              ( axi_m1_arvalid_o ),
     .axi_m0_arburst_o              ( axi_m1_arburst_o ),
     .axi_m0_arid_o                 ( axi_m1_arid_o ),
     .axi_m0_arlen_o                ( axi_m1_arlen_o ),
     .axi_m0_arlock_o               ( axi_m1_arlock_o ),
     .axi_m0_arsize_o               ( axi_m1_arsize_o ),

  // Master Read Data Channel
     .axi_m0_rid_i                  ( axi_m1_rid_i ),
     .axi_m0_rvalid_i               ( axi_m1_rvalid_i ),
     .axi_m0_rlast_i                ( axi_m1_rlast_i ),
     .axi_m0_rdata_i                ( axi_m1_rdata_i ),
     .axi_m0_rready_o               ( axi_m1_rready_o ),

  // Master Read Response Channel
     .axi_m0_rresp_i                ( axi_m1_rresp_i ),

  // Input clock and reset
     .hdmi_clk                      ( sys_clk ),
     .axi_clk                       ( axi_m_clk ),
     .fxn_gpif_m_clk                ( fxn_gpif_m_clk ),
     .hdmi_clk_reset_n              ( sys_clk_reset_n ),
     .axi_clk_reset_n               ( axi_m_clk_reset_n ),
     .fxn_gpif_m_clk_reset_n        ( fxn_gpif_m_clk_reset_n ),

  // Input data and controls
     .sel_vsync_axi_clk_i           ( sel_vsync_axi_clk[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .sel_vsync_hdmi_i              ( sel_vsync_hdmi_clk[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .sel_vsync_hdmi_pe_pl_i        ( sel_vsync_hdmi_clk_pe_pl[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .sel_vsync_hdmi_ne_pl_i        ( sel_vsync_hdmi_clk_ne_pl[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .sel_hsync_hdmi_i              ( sel_hsync_hdmi_clk[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .sel_vid_data_i                ( sel_intr_fifo_wr_data_hdmi_clk[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),

  // Typedef Structure
     .dev_reg_info_st_arr_axi_clk_i  ( dev_reg_info_st_arr_axi_clk[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .dev_reg_info_st_arr_gpif_clk_i ( dev_reg_info_st_arr[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .dev_reg_info_st_arr_hdmi_clk_i ( dev_reg_info_st_arr_hdmi_clk[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .slfifo_ctrl_req_i              ( slfifo_ctrl_req_st_arr[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .slfifo_data_nd_vld_o           ( slfifo_data_nd_status_st_arr[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .common_reg_info_i              ( common_reg_info ),

     .ddr_wr_xfer_hdmi_clk_arr_i     ( ddr_wr_xfer_hdmi_clk_arr[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .full_frame_wr_completed_hdmi_clk_arr_i  ( full_frame_wr_completed_hdmi_clk_arr[(NO_OF_SUPPORTED_DEV-1):NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M] ),
     .ddr_init_done_i               ( ddr_cfg_done )

    );

  end
endgenerate


// ------------------------------------------
//
// Onchip Memory as a buffer
//
// ------------------------------------------

genvar on_chip_buf;


// When none of the DDR instance is used as a buffer
generate
  if ( ( DDR_AXI0 == "FALSE" ) && ( DDR_AXI1 == "FALSE" ) )
    begin

      for (on_chip_buf=0; on_chip_buf < NO_OF_SUPPORTED_DEV; on_chip_buf = on_chip_buf + 1 )
        begin

y_data_fifo_rd_wr_gate
  #
  (
   // Parameters
   .Y_DATA_FIFO_WR_DATA_WIDTH_IN_BITS_I         ( INTERMEDIATE_FIFO_WR_DATA_WIDTH_IN_BITS ), // As of now, AXI0 is used
   .Y_DATA_FIFO_RD_DATA_WIDTH_IN_BITS_I         ( AXI_M0_RD_DATA_WIDTH_IN_BITS ),
   .Y_DATA_FIFO_DEPTH_IN_WORDS_I                ( Y_DATA_FIFO_DEPTH_IN_WORDS ),
   .MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I  ( MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES )
  )
  onchip_buffer
    (
     // Outputs
     .slfifo_wr_req_o                    ( slfifo_ctrl_req_st_arr_buf[on_chip_buf].wr_en ),
     .slfifo_wr_data_o                   ( slfifo_ctrl_req_st_arr_buf[on_chip_buf].wr_data ),
     .y_data_bufr_almost_full_o          ( y_data_bufr_almost_full[on_chip_buf] ),
     .y_data_bufr_empty_o                ( y_data_bufr_empty[on_chip_buf] ),
     .y_data_bufr_full_o                 ( y_data_bufr_full[on_chip_buf] ),
     .y_data_bufr_overflow_o             ( /* y_data_bufr_overflow[on_chip_buf] */ ),
//     .full_frame_wr_complete_wo_bufr_o   ( full_frame_wr_complete_wo_bufr_o[on_chip_buf] ),

     // Inputs
     .wr_clk                             ( sys_clk ),
     .wr_reset_n                         ( sys_clk_reset_n ),
     .rd_clk                             ( axi_m_clk /* fxn_gpif_m_clk */),
     .rd_reset_n                         ( axi_m_clk_reset_n /* fxn_gpif_m_clk_reset_n */),
     .sel_d_reset_or_stop_stream_req_i   ( sel_d_reset_or_stop_stream_req[on_chip_buf] /*!sel_d_start_stream_hdmi_clk[on_chip_buf]*/ ),
     .vsync_pe_pl_i                      ( sel_vsync_hdmi_clk_pe_pl[on_chip_buf] ),
     .vsync_axi_clk_i                    ( sel_vsync_axi_clk[on_chip_buf] ),
     .y_fifo_wr_req_i                    ( sel_hsync_hdmi_clk[on_chip_buf] ),
     .y_fifo_wr_data_i                   ( sel_intr_fifo_wr_data_hdmi_clk[on_chip_buf] ),
     .slfifo_almost_full_i               ( slfifo_data_nd_status_st_arr[on_chip_buf].almost_full ),
     .slfifo_full_i                      ( slfifo_data_nd_status_st_arr[on_chip_buf].full ),
     .slfifo_reset_busy_i                ( slfifo_data_nd_status_st_arr[on_chip_buf].reset_busy )
    );

  // Slave FIFO Acive High Reset
  assign slfifo_ext_reset_req = 1'b0;

// ------------------------------------------
//
// Slave FIFO Read Write Access Gate
//
// ------------------------------------------


          slfifo_rd_wr_gate
            #
            (
            // Parameters
            . SLFIFO_WR_DATA_WIDTH_IN_BITS_I             ( AXI_M0_RD_DATA_WIDTH_IN_BITS ), // As of now, AXI0 is used
            . SLFIFO_RD_DATA_WIDTH_IN_BITS_I             ( SLFIFO_RD_DATA_WIDTH_IN_BITS ),
            . SLFIFO_WR_COUNT_DATA_WIDTH_I               ( SLFIFO_WR_COUNT_DATA_WIDTH ),
            . MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I ( MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES ),
            . SLFIFO_DEPTH_IN_WORDS_I                    ( SLFIFO_DEPTH_IN_WORDS )
            )
            slfifo
              (
                // Outputs
                .slfifo_full_o                          ( slfifo_data_nd_status_st_arr[on_chip_buf].full ),
                .slfifo_empty_o                         ( /* slfifo_empty */ ),
                .slfifo_almost_full_o                   ( slfifo_data_nd_status_st_arr[on_chip_buf].almost_full),
                .slfifo_almost_empty_o                  ( slfifo_data_nd_status_st_arr[on_chip_buf].almost_empty ),
                .slfifo_reset_busy_o                    ( slfifo_data_nd_status_st_arr[on_chip_buf].reset_busy ),
                .slfifo_rd_data_valid_o                 ( slfifo_data_nd_status_st_arr[on_chip_buf].rd_data_valid ),
                .slfifo_wr_data_count_o                 ( slfifo_data_nd_status_st_arr[on_chip_buf].wr_data_count ),
                .slfifo_rd_data_count_o                 ( slfifo_data_nd_status_st_arr[on_chip_buf].rd_data_count ),

                // Inputs
                .wr_clk                                 ( axi_m_clk  ),
                .rd_reset_n                             ( fxn_gpif_m_clk_reset_n ),
                .rd_clk                                 ( fxn_gpif_m_clk ),

                .slfifo_reset_req_i                     ( slfifo_ext_reset_req ),
                .slfifo_rd_req_i                        ( slfifo_ctrl_req_st_arr[on_chip_buf].rd_req ),
                .slfifo_rd_data_o                       ( slfifo_data_nd_status_st_arr[on_chip_buf].rd_data ),

                .sel_d_reset_or_stop_stream_req_i       ( sel_d_reset_or_stop_stream_req[on_chip_buf] /*!(dev_reg_info_st_arr[on_chip_buf].start_stream)*/ ),

                .slfifo_wr_req_i                        ( slfifo_ctrl_req_st_arr_buf[on_chip_buf].wr_en ),
                .slfifo_wr_data_i                       ( slfifo_ctrl_req_st_arr_buf[on_chip_buf].wr_data )
               );


            // Soft reset or stop stream request from FW
            always_ff @ ( posedge fxn_gpif_m_clk )
              begin
                if ( ~fxn_gpif_m_clk_reset_n )
                  begin
                    sel_d_reset_or_stop_stream_req[on_chip_buf] <= 1'b0;
                  end
                else
                  begin
                    sel_d_reset_or_stop_stream_req[on_chip_buf] <=   ( ( dev_reg_info_st_arr[on_chip_buf].fw_soft_reset == 1'b1 ) |
                                                                       ( dev_reg_info_st_arr[on_chip_buf].start_stream  == 1'b0 ) );
                  end
              end
  end
  end
endgenerate


// --------------------------------------------------
//
//  Assigning I2C buses for camera as well as FPGA
//
// --------------------------------------------------

genvar i2c_bus,cam_i2c_bus;


generate
  for ( i2c_bus = 0; i2c_bus < NO_OF_FXN_MASTER_I2C; i2c_bus = i2c_bus + 1 )
    begin : FXN_I2C
      assign i2c_bus_in_st_arr[i2c_bus].scl_i = fxn_i2c_scl_i[i2c_bus];
      assign i2c_bus_in_st_arr[i2c_bus].sda_i = fxn_i2c_sda_i[i2c_bus];

      assign fxn_i2c_scl_o[i2c_bus]    = i2c_bus_out_st_arr[i2c_bus].scl_o;
      assign fxn_i2c_scl_en_o[i2c_bus] = i2c_bus_out_st_arr[i2c_bus].scl_en_o;
      assign fxn_i2c_sda_o[i2c_bus]    = i2c_bus_out_st_arr[i2c_bus].sda_o;
      assign fxn_i2c_sda_en_o[i2c_bus] = i2c_bus_out_st_arr[i2c_bus].sda_en_o;
    end
endgenerate

generate
  for ( cam_i2c_bus = 0; cam_i2c_bus < NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C; cam_i2c_bus = cam_i2c_bus + 1 )
    begin : DEV_SUPPORTED_PER_I2C
      assign cam_i2c_bus_in_st_arr[cam_i2c_bus].sda_i = fpga_cam_sda_i[cam_i2c_bus];

      assign fpga_cam_scl_o[cam_i2c_bus]    = cam_i2c_bus_out_st_arr[cam_i2c_bus].scl_o;
      assign fpga_cam_scl_en_o[cam_i2c_bus] = 1'b1; // cam_i2c_bus_out_st_arr[cam_i2c_bus].scl_en_o;
      assign fpga_cam_sda_o[cam_i2c_bus]    = cam_i2c_bus_out_st_arr[cam_i2c_bus].sda_o;
      assign fpga_cam_sda_en_o[cam_i2c_bus] = cam_i2c_bus_out_st_arr[cam_i2c_bus].sda_en_o;
    end
endgenerate

// ------------------------------------------
//
// FX10 GPIF
//
// ------------------------------------------

generate
  if ( GPIF_MASTER_MODE != "LVDS" )
    begin

      // -----------------------
      //
      // FX10 LVCMOS TX Wrapper
      //
      // -----------------------

      fxn_lvcmos_tx_wrapper
        #
        (
        // Parameters
        .GPIF_M_CLK_VALUE_I                              ( GPIF_M_CLK_VALUE ),
        .GPIF_MASTER_MODE_I                              ( GPIF_MASTER_MODE ),
        .LVDS_PHY_TS_TIME_IN_US_I                        ( LVDS_PHY_TS_TIME_IN_US ),
        .TOTAL_DATA_LANES_I                              ( TOTAL_DATA_LANES ),
        .NO_OF_SUPPORTED_DEV_I                           ( NO_OF_SUPPORTED_DEV ),
        .SEL_DEV_NUM_BITS_I                              ( SEL_DEV_NUM_BITS ),
        .NO_OF_FXN_MASTER_I2C_I                          ( NO_OF_FXN_MASTER_I2C),
        .NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I         ( NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C),
        .NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C_I    ( NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C),
        .I2C_SLAVE_ADDR_I                                ( I2C_SLAVE_ADDR ),
        .NO_OF_ADDRESS_BITS_I                            ( NO_OF_ADDRESS_BITS )
        )
        fltw
        (
          // Outputs
          .slf_m_rd_req_n_o                              ( ),
          .slf_m_wr_req_n_o                              ( fxn_gpif_m_wr_req_n ),
          .slf_m_pktend_n_o                              ( fxn_gpif_m_pktend_n ),
          .slf_m_cs_n_o                                  ( fxn_gpif_m_cs_n ),
          .slf_m_epswitch_n_o                            ( fxn_gpif_m_epswitch_n ),
          .slf_m_oe_n_o                                  ( ),
          .slf_m_addr_o                                  ( fxn_gpif_m_addr ),
          .slf_wr_data_pe_o                              ( fxn_gpif_m_wr_data_pe ),
          .slf_wr_data_ne_o                              ( fxn_gpif_m_wr_data_ne ),
          .sel_device_num_o                              ( sel_device_num ),
          .l_zlp_sent_o                                  ( l_zlp_sent ),
          .sel_d_reset_or_stop_stream_req_o              ( sel_reset_or_stop_stream_req ),

          .slfifo_ctrl_req_st_arr_o                      ( slfifo_ctrl_req_st_arr ),
          .sel_d_reg_info_st_o                           ( sel_d_reg_info_st ),
          .dev_reg_info_st_arr_o                         ( dev_reg_info_st_arr[(NO_OF_SUPPORTED_DEV-1):0] ),
          .i2c_bus_out_st_arr_o                          ( i2c_bus_out_st_arr ),
          .cam_i2c_bus_out_st_arr_o                      ( cam_i2c_bus_out_st_arr ),
          .common_reg_info_o                             ( common_reg_info ),

          // Inputs
          .clk                                           ( fxn_gpif_m_clk ),
          .reset_n                                       ( fxn_gpif_m_clk_reset_n ),
          .fxn_buffer_ready_i                            ( fxn_gpif_m_full_flag ),
          .fxn_buffer_partial_i                          ( 1'b1 ),
          .fxn_lvds_rx_link_ready_i                      ( fxn_lvds_rx_link_ready ),
          
          .sw_i                                          ( sw_i ),
          .ddr_ctrl_data_path_idle_i                     ( ddr_ctrl_data_path_idle_gpif_clk ),
          .ddr_ctrl_cmd_queue_almost_full_i              ( ddr_ctrl_cmd_queue_almost_full_gpif_clk ),
          .ddr_ctrl_busy_i                               ( ddr_ctrl_busy_gpif_clk ),
          .ddr_cfg_done_i                                ( ddr_cfg_done_gpif_clk ),

          .mipi_status_reg_i                             ( csr ),
          .vsync_i                                       ( sel_vsync_gpif_clk ),
          .full_frame_wr_completed_i                     ( full_frame_wr_completed_gpif_clk_arr ),
          .full_frame_rd_completed_i                     ( full_frame_rd_completed_gpif_clk_arr ),
          .y_data_bufr_empty_i                           ( y_data_bufr_empty_gpif_clk ),
          .y_data_bufr_full_i                            ( y_data_bufr_full_gpif_clk ),
          .slfifo_data_nd_status_st_arr_i                ( slfifo_data_nd_status_st_arr),
          .i2c_bus_in_st_arr_i                           ( i2c_bus_in_st_arr ),
          .cam_i2c_bus_in_st_arr_i                       ( cam_i2c_bus_in_st_arr )
         );


      // Data Line Assignments

     // For Port 1 Narrow link
  if ( GPIF_LINK_TYPE == "NARROW_PORT_1" )
    begin

      assign fxn_gpif_m_full_flag     = fxn_p1_gpif_m_full_flag_i; // Port 0 FLAGA

      assign fxn_lvds_rx_link_ready   = fxn_lvds_p1_rx_link_ready_i; // Port 0 LINK_RDY

      // LVCMOS Signals
      always_ff @ ( posedge fxn_gpif_m_clk )
        begin
          if ( !fxn_gpif_m_clk_reset_n )
            begin
              fxn_p1_gpif_m_wr_data_pe_o   <= 16'd0;
              fxn_p1_gpif_m_wr_data_ne_o   <= 16'd0;
              fxn_p1_gpif_m_cs_n_o         <= 1'b1;
              fxn_p1_gpif_m_wr_req_n_o     <= 1'b1;
              fxn_p1_gpif_m_oe_n_o         <= 1'b1;
              fxn_p1_gpif_m_pktend_n_o     <= 1'b1;
              fxn_p1_gpif_m_addr_o         <= 2'd0;
              fxn_p1_gpif_m_rd_req_n_o     <= 1'b1;
              fxn_p1_gpif_m_epswitch_n_o   <= 1'b1;
            end
          else
            begin
              if ( LVCMOS_SLFIFO_MODE == "FV_LV" )
                begin
                  fxn_p1_gpif_m_wr_data_pe_o   <= sel_intr_fifo_wr_data_hdmi_clk[0];
                  fxn_p1_gpif_m_wr_data_ne_o   <= sel_intr_fifo_wr_data_hdmi_clk[0];
                  fxn_p1_gpif_m_cs_n_o         <= sel_hsync_hdmi_clk[0];
                  fxn_p1_gpif_m_wr_req_n_o     <= sel_vsync_hdmi_clk[0];
                  fxn_p1_gpif_m_oe_n_o         <= 1'b1;
                  fxn_p1_gpif_m_pktend_n_o     <= fxn_gpif_m_pktend_n;
                  fxn_p1_gpif_m_addr_o         <= fxn_gpif_m_addr;
                  fxn_p1_gpif_m_rd_req_n_o     <= 1'b1;
                  fxn_p1_gpif_m_epswitch_n_o   <= 1'b1;
                end
              else
                begin
                  fxn_p1_gpif_m_wr_data_pe_o   <= fxn_gpif_m_wr_data_pe[15:0];
                  fxn_p1_gpif_m_wr_data_ne_o   <= fxn_gpif_m_wr_data_ne[15:0];
                  fxn_p1_gpif_m_cs_n_o         <= fxn_gpif_m_cs_n;
                  fxn_p1_gpif_m_wr_req_n_o     <= fxn_gpif_m_wr_req_n;
                  fxn_p1_gpif_m_oe_n_o         <= 1'b1;
                  fxn_p1_gpif_m_pktend_n_o     <= fxn_gpif_m_pktend_n;
                  fxn_p1_gpif_m_addr_o         <= fxn_gpif_m_addr;
                  fxn_p1_gpif_m_rd_req_n_o     <= 1'b1;
                  fxn_p1_gpif_m_epswitch_n_o   <= fxn_gpif_m_epswitch_n;
                end
            end
        end
    end

  else if ( GPIF_LINK_TYPE == "NARROW_PORT_0" )
    begin

      assign fxn_gpif_m_full_flag     = fxn_p0_gpif_m_full_flag_i;  // Port 0 FLAGA

      assign fxn_lvds_rx_link_ready   = fxn_lvds_p0_rx_link_ready_i; // Port 0 LINK_RDY

      // LVCMOS Signals
      always_ff @ ( posedge fxn_gpif_m_clk )
        begin
          if ( !fxn_gpif_m_clk_reset_n )
            begin
              fxn_p0_gpif_m_wr_data_pe_o   <= 16'd0;
              fxn_p0_gpif_m_wr_data_ne_o   <= 16'd0;
              fxn_p0_gpif_m_cs_n_o         <= 1'b1;
              fxn_p0_gpif_m_wr_req_n_o     <= 1'b1;
              fxn_p0_gpif_m_oe_n_o         <= 1'b1;
              fxn_p0_gpif_m_pktend_n_o     <= 1'b1;
              fxn_p0_gpif_m_addr_o         <= 2'd0;
              fxn_p0_gpif_m_rd_req_n_o     <= 1'b1;
              fxn_p0_gpif_m_epswitch_n_o   <= 1'b1;
            end
          else
            begin
              if ( LVCMOS_SLFIFO_MODE == "FV_LV" )
                begin
                  fxn_p0_gpif_m_wr_data_pe_o   <= sel_intr_fifo_wr_data_hdmi_clk[0];
                  fxn_p0_gpif_m_wr_data_ne_o   <= sel_intr_fifo_wr_data_hdmi_clk[0];
                  fxn_p0_gpif_m_cs_n_o         <= sel_hsync_hdmi_clk[0];
                  fxn_p0_gpif_m_wr_req_n_o     <= sel_vsync_hdmi_clk[0];
                  fxn_p0_gpif_m_oe_n_o         <= 1'b1;
                  fxn_p0_gpif_m_pktend_n_o     <= fxn_gpif_m_pktend_n;
                  fxn_p0_gpif_m_addr_o         <= fxn_gpif_m_addr;
                  fxn_p0_gpif_m_rd_req_n_o     <= 1'b1;
                  fxn_p0_gpif_m_epswitch_n_o   <= 1'b1;
                end
              else
                begin
                  fxn_p0_gpif_m_wr_data_pe_o   <= fxn_gpif_m_wr_data_pe[15:0];
                  fxn_p0_gpif_m_wr_data_ne_o   <= fxn_gpif_m_wr_data_ne[15:0];
                  fxn_p0_gpif_m_cs_n_o         <= fxn_gpif_m_cs_n;
                  fxn_p0_gpif_m_wr_req_n_o     <= fxn_gpif_m_wr_req_n;
                  fxn_p0_gpif_m_oe_n_o         <= 1'b1;
                  fxn_p0_gpif_m_pktend_n_o     <= fxn_gpif_m_pktend_n;
                  fxn_p0_gpif_m_addr_o         <= fxn_gpif_m_addr;
                  fxn_p0_gpif_m_rd_req_n_o     <= 1'b1;
                  fxn_p0_gpif_m_epswitch_n_o   <= fxn_gpif_m_epswitch_n;
                end
            end
        end
    end

  else if ( GPIF_LINK_TYPE == "WIDE" )
    begin

      assign fxn_gpif_m_full_flag     = fxn_p0_gpif_m_full_flag_i; // Port 0 FLAGA

      assign fxn_lvds_rx_link_ready   = fxn_lvds_p0_rx_link_ready_i; // Port 0 LINK_RDY

      // LVCMOS Signals
      always_ff @ ( posedge fxn_gpif_m_clk )
        begin
          if ( !fxn_gpif_m_clk_reset_n )
            begin
              fxn_p0_gpif_m_wr_data_pe_o   <= 16'd0;
              fxn_p0_gpif_m_wr_data_ne_o   <= 16'd0;
              fxn_p1_gpif_m_wr_data_pe_o   <= 16'd0;
              fxn_p1_gpif_m_wr_data_ne_o   <= 16'd0;
              fxn_p0_gpif_m_cs_n_o         <= 1'b1;
              fxn_p0_gpif_m_wr_req_n_o     <= 1'b1;
              fxn_p0_gpif_m_oe_n_o         <= 1'b1;
              fxn_p0_gpif_m_pktend_n_o     <= 1'b1;
              fxn_p1_gpif_m_addr_o         <= 2'd0;
              fxn_p0_gpif_m_rd_req_n_o     <= 1'b1;
              fxn_p0_gpif_m_epswitch_n_o   <= 1'b1;

            end
          else
            begin
              if ( LVCMOS_SLFIFO_MODE == "FV_LV" )
                begin
                  fxn_p0_gpif_m_wr_data_pe_o   <= sel_intr_fifo_wr_data_hdmi_clk[0];
                  fxn_p0_gpif_m_wr_data_ne_o   <= sel_intr_fifo_wr_data_hdmi_clk[0];
                  fxn_p1_gpif_m_wr_data_pe_o   <= sel_intr_fifo_wr_data_hdmi_clk[0];
                  fxn_p1_gpif_m_wr_data_ne_o   <= sel_intr_fifo_wr_data_hdmi_clk[0];
                  fxn_p0_gpif_m_cs_n_o         <= sel_hsync_hdmi_clk[0];
                  fxn_p0_gpif_m_wr_req_n_o     <= sel_vsync_hdmi_clk[0];
                  fxn_p0_gpif_m_oe_n_o         <= 1'b1;
                  fxn_p0_gpif_m_pktend_n_o     <= fxn_gpif_m_pktend_n;
                  fxn_p1_gpif_m_addr_o         <= fxn_gpif_m_addr;
                  fxn_p0_gpif_m_rd_req_n_o     <= 1'b1;
                  fxn_p0_gpif_m_epswitch_n_o   <= 1'b1;

                end
              else
                begin
                  fxn_p0_gpif_m_wr_data_pe_o   <= fxn_gpif_m_wr_data_pe[15:0];
                  fxn_p0_gpif_m_wr_data_ne_o   <= fxn_gpif_m_wr_data_ne[15:0];
                  fxn_p1_gpif_m_wr_data_pe_o   <= fxn_gpif_m_wr_data_pe[31:16];
                  fxn_p1_gpif_m_wr_data_ne_o   <= fxn_gpif_m_wr_data_ne[31:16];
                  fxn_p0_gpif_m_cs_n_o         <= fxn_gpif_m_cs_n;
                  fxn_p0_gpif_m_wr_req_n_o     <= fxn_gpif_m_wr_req_n;
                  fxn_p0_gpif_m_oe_n_o         <= 1'b1;
                  fxn_p0_gpif_m_pktend_n_o     <= fxn_gpif_m_pktend_n;
                  fxn_p1_gpif_m_addr_o         <= fxn_gpif_m_addr;
                  fxn_p0_gpif_m_rd_req_n_o     <= 1'b1;
                  fxn_p0_gpif_m_epswitch_n_o   <= fxn_gpif_m_epswitch_n;
                end
            end
        end
    end
    end
  else
    begin

      // -----------------------
      //
      // FX10 LVDS TX Wrapper
      //
      // -----------------------

      fxn_lvds_tx_wrapper
        #
        (
         // Parameters
         .ADDR_MANAGED_BY_FPGA_I                        (ADDR_MANAGED_BY_FPGA),
         .GPIF_M_CLK_VALUE_I                            (GPIF_M_CLK_VALUE),
         .GPIF_MASTER_MODE_I                            (GPIF_MASTER_MODE),
         .LVDS_PHY_TS_TIME_IN_US_I                      (LVDS_PHY_TS_TIME_IN_US),
         .LVDS_TX_GEAR_RATIO_I                          (LVDS_TX_GEAR_RATIO),
         .TOTAL_DATA_LANES_I                            (TOTAL_DATA_LANES),
         .ACTIVE_LVDS_DATA_LANE_MASK_MSB_I              (ACTIVE_LVDS_DATA_LANE_MASK_MSB),
         .ACTIVE_LVDS_DATA_LANE_MASK_LSB_I              (ACTIVE_LVDS_DATA_LANE_MASK_LSB),
         .TX_SERIALIZER_LSB_FIRST_I                     (TX_SERIALIZER_LSB_FIRST),
         .SEL_DEV_NUM_BITS_I                            (SEL_DEV_NUM_BITS),
         .NO_OF_SUPPORTED_DEV_I                         (NO_OF_SUPPORTED_DEV),
         .NO_OF_SUPPORTED_DEV_BY_EACH_AXI_I             (NO_OF_SUPPORTED_DEV_BY_EACH_AXI_M),
         .NO_OF_FXN_MASTER_I2C_I                        (NO_OF_FXN_MASTER_I2C),
         .NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I       (NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C),
         .NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C_I  (NO_OF_SUPPORTED_DEV_BY_EACH_FXN_MASTER_I2C),
         .I2C_SLAVE_ADDR_I                              (I2C_SLAVE_ADDR)
         )
        fltw
         (
          // Outputs
          .tx_eop_control_byte_pl_n_o           (tx_eop_control_byte_pl_n), // Active low PKTEND
          .sel_device_num_o                     (sel_device_num),
          .l_zlp_sent_o                         (l_zlp_sent),
          .full_buffer_sent_o                   (full_buffer_sent),
          .wait_for_new_buffer_o                (wait_for_new_buffer),
          .ctrl_byte_o                          (fxn_gpif_m_ctrl_data_p0),
          .wr_data_o                            (fxn_gpif_m_wr_data),
          .slfifo_ctrl_req_st_arr_o             (slfifo_ctrl_req_st_arr),
          .sel_d_reg_info_st_o                  (sel_d_reg_info_st),
          .dev_reg_info_st_arr_o                (dev_reg_info_st_arr[(NO_OF_SUPPORTED_DEV-1):0]),
          .i2c_bus_out_st_arr_o                 (i2c_bus_out_st_arr),
          .cam_i2c_bus_out_st_arr_o             (cam_i2c_bus_out_st_arr),
          .common_reg_info_o                    (common_reg_info),
          .fxn_l3_lp_mode_en_o                  (fxn_l3_lp_mode_en),
          .fxn_gpif_m_wr_data_oe_o              (fxn_gpif_m_wr_data_oe),
          .fxn_gpif_m_ctrl_data_oe_o            (fxn_gpif_m_ctrl_data_oe),
          .fxn_gpif_m_clk_oe_o                  (fxn_gpif_m_clk_oe),
          .fxn_gpif_m_wr_data_rst_n_o           (fxn_gpif_m_wr_data_rst_n),
          .fxn_gpif_m_ctrl_data_rst_n_o         (fxn_gpif_m_ctrl_data_rst_n),
          .fxn_gpif_m_clk_rst_n_o               (fxn_gpif_m_clk_rst_n),

          // Inputs
          .clk                                  (fxn_gpif_m_clk),
          .reset_n                              (fxn_gpif_m_clk_reset_n),
          .fxn_lvds_rx_link_ready_i             (fxn_lvds_rx_link_ready),
          .fxn_buffer_ready_i                   (fxn_gpif_m_full_flag),
          .cam_config_done_i                    (1'b1), // For PTS
          .y_data_bufr_empty_i                  (y_data_bufr_empty_gpif_clk),
          .y_data_bufr_full_i                   (y_data_bufr_full_gpif_clk),
          .mipi_status_reg_i                    (csr),
          .ddr_ctrl_data_path_idle_i            (ddr_ctrl_data_path_idle_gpif_clk),
          .ddr_ctrl_cmd_queue_almost_full_i     (ddr_ctrl_cmd_queue_almost_full_gpif_clk),
          .ddr_ctrl_busy_i                      (ddr_ctrl_busy_gpif_clk),
          .ddr_cfg_done_i                       (ddr_cfg_done_gpif_clk),
          .full_frame_wr_completed_i            (full_frame_wr_completed_gpif_clk_arr),
          .full_frame_rd_completed_i            (full_frame_rd_completed_gpif_clk_arr),
          .vsync_i                              (sel_vsync_gpif_clk),
          .slfifo_data_nd_status_st_arr_i       (slfifo_data_nd_status_st_arr),
          .i2c_bus_in_st_arr_i                  (i2c_bus_in_st_arr),
          .cam_i2c_bus_in_st_arr_i              (cam_i2c_bus_in_st_arr));

      // Data Line Assignments

     // For Port 1 Narrow link
  if ( GPIF_LINK_TYPE == "NARROW_PORT_1" )
    begin
      assign fxn_gpif_m_full_flag      = fxn_p1_gpif_m_full_flag_i; // Port 1 FLAGA

      assign fxn_lvds_rx_link_ready    = fxn_lvds_p1_rx_link_ready_i; // Port 1 LINK_RDY

      // LVDS Signals
      always_ff @ ( posedge fxn_gpif_m_clk )
        begin
          if ( !fxn_gpif_m_clk_reset_n )
            begin
              fxn_gpif_m_wr_data_d8_o         <= 8'd0;
              fxn_gpif_m_wr_data_d9_o         <= 8'd0;
              fxn_gpif_m_wr_data_d10_o        <= 8'd0;
              fxn_gpif_m_wr_data_d11_o        <= 8'd0;
              fxn_gpif_m_wr_data_d12_o        <= 8'd0;
              fxn_gpif_m_wr_data_d13_o        <= 8'd0;
              fxn_gpif_m_wr_data_d14_o        <= 8'd0;
              fxn_gpif_m_wr_data_d15_o        <= 8'd0;
              fxn_gpif_m_ctrl_data_p1_o       <= 8'd0;
              fxn_p1_l3_mode_en_o             <= 1'd0;
              fxn_p1_gpif_m_clk_oe_o          <= 1'd0;
              fxn_p1_gpif_m_ctrl_data_oe_o    <= 1'd0;
              fxn_p1_gpif_m_wr_data_oe_o      <= 8'd0;
              fxn_p1_gpif_m_clk_rst_n_o       <= 1'd1;
              fxn_p1_gpif_m_ctrl_data_rst_n_o <= 1'd1;
              fxn_p1_gpif_m_wr_data_rst_n_o   <= {8{1'b1}};

            end
          else
            begin
              fxn_gpif_m_wr_data_d8_o         <= fxn_gpif_m_wr_data[8];
              fxn_gpif_m_wr_data_d9_o         <= fxn_gpif_m_wr_data[9];
              fxn_gpif_m_wr_data_d10_o        <= fxn_gpif_m_wr_data[10];
              fxn_gpif_m_wr_data_d11_o        <= fxn_gpif_m_wr_data[11];
              fxn_gpif_m_wr_data_d12_o        <= fxn_gpif_m_wr_data[12];
              fxn_gpif_m_wr_data_d13_o        <= fxn_gpif_m_wr_data[13];
              fxn_gpif_m_wr_data_d14_o        <= fxn_gpif_m_wr_data[14];
              fxn_gpif_m_wr_data_d15_o        <= fxn_gpif_m_wr_data[15];
              fxn_gpif_m_ctrl_data_p1_o       <= fxn_gpif_m_ctrl_data_p0;
              fxn_p1_l3_mode_en_o             <= fxn_l3_lp_mode_en;
              fxn_p1_gpif_m_clk_oe_o          <= fxn_gpif_m_clk_oe;
              fxn_p1_gpif_m_ctrl_data_oe_o    <= fxn_gpif_m_ctrl_data_oe;
              fxn_p1_gpif_m_wr_data_oe_o      <= {8{fxn_gpif_m_wr_data_oe}};
              fxn_p1_gpif_m_clk_rst_n_o       <= fxn_gpif_m_clk_rst_n;
              fxn_p1_gpif_m_ctrl_data_rst_n_o <= fxn_gpif_m_ctrl_data_rst_n;
              fxn_p1_gpif_m_wr_data_rst_n_o   <= {8{fxn_gpif_m_wr_data_rst_n}};
            end
        end
    end

  else if ( GPIF_LINK_TYPE == "NARROW_PORT_0" )
    begin

      assign fxn_gpif_m_full_flag     = fxn_p0_gpif_m_full_flag_i; // Port 0 FLAGA

      assign fxn_lvds_rx_link_ready   = fxn_lvds_p0_rx_link_ready_i; // Port 0 LINK_RDY

      // LVDS Signals
      always_ff @ ( posedge fxn_gpif_m_clk )
        begin
          if ( !fxn_gpif_m_clk_reset_n )
            begin
              fxn_gpif_m_wr_data_d0_o         <= 8'd0;
              fxn_gpif_m_wr_data_d1_o         <= 8'd0;
              fxn_gpif_m_wr_data_d2_o         <= 8'd0;
              fxn_gpif_m_wr_data_d3_o         <= 8'd0;
              fxn_gpif_m_wr_data_d4_o         <= 8'd0;
              fxn_gpif_m_wr_data_d5_o         <= 8'd0;
              fxn_gpif_m_wr_data_d6_o         <= 8'd0;
              fxn_gpif_m_wr_data_d7_o         <= 8'd0;
              fxn_gpif_m_ctrl_data_p0_o       <= 8'd0;
              fxn_p0_l3_mode_en_o             <= 1'd0;
              fxn_p0_gpif_m_clk_oe_o          <= 1'd0;
              fxn_p0_gpif_m_ctrl_data_oe_o    <= 1'd0;
              fxn_p0_gpif_m_wr_data_oe_o      <= 8'd0;
              fxn_p0_gpif_m_clk_rst_n_o       <= 1'd1;
              fxn_p0_gpif_m_ctrl_data_rst_n_o <= 1'd1;
              fxn_p0_gpif_m_wr_data_rst_n_o   <= {8{1'b1}};
            end
          else
            begin
              fxn_gpif_m_wr_data_d0_o         <= fxn_gpif_m_wr_data[0];
              fxn_gpif_m_wr_data_d1_o         <= fxn_gpif_m_wr_data[1];
              fxn_gpif_m_wr_data_d2_o         <= fxn_gpif_m_wr_data[2];
              fxn_gpif_m_wr_data_d3_o         <= fxn_gpif_m_wr_data[3];
              fxn_gpif_m_wr_data_d4_o         <= fxn_gpif_m_wr_data[4];
              fxn_gpif_m_wr_data_d5_o         <= fxn_gpif_m_wr_data[5];
              fxn_gpif_m_wr_data_d6_o         <= fxn_gpif_m_wr_data[6];
              fxn_gpif_m_wr_data_d7_o         <= fxn_gpif_m_wr_data[7];
              fxn_gpif_m_ctrl_data_p0_o       <= fxn_gpif_m_ctrl_data_p0;
              fxn_p0_l3_mode_en_o             <= fxn_l3_lp_mode_en;
              fxn_p0_gpif_m_clk_oe_o          <= fxn_gpif_m_clk_oe;
              fxn_p0_gpif_m_ctrl_data_oe_o    <= fxn_gpif_m_ctrl_data_oe;
              fxn_p0_gpif_m_wr_data_oe_o      <= {8{fxn_gpif_m_wr_data_oe}};
              fxn_p0_gpif_m_clk_rst_n_o       <= fxn_gpif_m_clk_rst_n;
              fxn_p0_gpif_m_ctrl_data_rst_n_o <= fxn_gpif_m_ctrl_data_rst_n;
              fxn_p0_gpif_m_wr_data_rst_n_o   <= {8{fxn_gpif_m_wr_data_rst_n}};
            end
        end
    end

  else if ( GPIF_LINK_TYPE == "WIDE" )
    begin

      assign fxn_gpif_m_full_flag     = fxn_p0_gpif_m_full_flag_i; // Port 0 FLAGA

      assign fxn_lvds_rx_link_ready   = fxn_lvds_p0_rx_link_ready_i; // Port 0 LINK_RDY

      // LVDS Signals
      always_ff @ ( posedge fxn_gpif_m_clk )
        begin
          if ( !fxn_gpif_m_clk_reset_n )
            begin
              fxn_gpif_m_wr_data_d0_o         <= 8'd0;
              fxn_gpif_m_wr_data_d1_o         <= 8'd0;
              fxn_gpif_m_wr_data_d2_o         <= 8'd0;
              fxn_gpif_m_wr_data_d3_o         <= 8'd0;
              fxn_gpif_m_wr_data_d4_o         <= 8'd0;
              fxn_gpif_m_wr_data_d5_o         <= 8'd0;
              fxn_gpif_m_wr_data_d6_o         <= 8'd0;
              fxn_gpif_m_wr_data_d7_o         <= 8'd0;
              fxn_gpif_m_wr_data_d8_o         <= 8'd0;
              fxn_gpif_m_wr_data_d9_o         <= 8'd0;
              fxn_gpif_m_wr_data_d10_o        <= 8'd0;
              fxn_gpif_m_wr_data_d11_o        <= 8'd0;
              fxn_gpif_m_wr_data_d12_o        <= 8'd0;
              fxn_gpif_m_wr_data_d13_o        <= 8'd0;
              fxn_gpif_m_wr_data_d14_o        <= 8'd0;
              fxn_gpif_m_wr_data_d15_o        <= 8'd0;
              fxn_gpif_m_ctrl_data_p0_o       <= 8'd0;
              fxn_gpif_m_ctrl_data_p1_o       <= 8'd0;
              fxn_p0_l3_mode_en_o             <= 1'd0;
              fxn_p0_gpif_m_clk_oe_o          <= 1'd0;
              fxn_p0_gpif_m_ctrl_data_oe_o    <= 1'd0;
              fxn_p0_gpif_m_wr_data_oe_o      <= 8'd0;
              fxn_p0_gpif_m_clk_rst_n_o       <= 1'd1;
              fxn_p0_gpif_m_ctrl_data_rst_n_o <= 1'd1;
              fxn_p0_gpif_m_wr_data_rst_n_o   <= {8{1'b1}};
              fxn_p1_l3_mode_en_o             <= 1'd0;
              fxn_p1_gpif_m_clk_oe_o          <= 1'd0;
              fxn_p1_gpif_m_ctrl_data_oe_o    <= 1'd0;
              fxn_p1_gpif_m_wr_data_oe_o      <= 8'd0;
              fxn_p1_gpif_m_clk_rst_n_o       <= 1'd1;
              fxn_p1_gpif_m_ctrl_data_rst_n_o <= 1'd1;
              fxn_p1_gpif_m_wr_data_rst_n_o   <= {8{1'b1}};
            end
          else
            begin

              fxn_gpif_m_wr_data_d0_o         <= fxn_gpif_m_wr_data[0];
              fxn_gpif_m_wr_data_d1_o         <= fxn_gpif_m_wr_data[1];
              fxn_gpif_m_wr_data_d2_o         <= fxn_gpif_m_wr_data[2];
              fxn_gpif_m_wr_data_d3_o         <= fxn_gpif_m_wr_data[3];
              fxn_gpif_m_wr_data_d4_o         <= fxn_gpif_m_wr_data[4];
              fxn_gpif_m_wr_data_d5_o         <= fxn_gpif_m_wr_data[5];
              fxn_gpif_m_wr_data_d6_o         <= fxn_gpif_m_wr_data[6];
              fxn_gpif_m_wr_data_d7_o         <= fxn_gpif_m_wr_data[7];
              fxn_gpif_m_wr_data_d8_o         <= fxn_gpif_m_wr_data[8];
              fxn_gpif_m_wr_data_d9_o         <= fxn_gpif_m_wr_data[9];
              fxn_gpif_m_wr_data_d10_o        <= fxn_gpif_m_wr_data[10];
              fxn_gpif_m_wr_data_d11_o        <= fxn_gpif_m_wr_data[11];
              fxn_gpif_m_wr_data_d12_o        <= fxn_gpif_m_wr_data[12];
              fxn_gpif_m_wr_data_d13_o        <= fxn_gpif_m_wr_data[13];
              fxn_gpif_m_wr_data_d14_o        <= fxn_gpif_m_wr_data[14];
              fxn_gpif_m_wr_data_d15_o        <= fxn_gpif_m_wr_data[15];
              fxn_gpif_m_ctrl_data_p0_o       <= fxn_gpif_m_ctrl_data_p0;
              fxn_gpif_m_ctrl_data_p1_o       <= fxn_gpif_m_ctrl_data_p0;
              fxn_p0_l3_mode_en_o             <= fxn_l3_lp_mode_en;
              fxn_p0_gpif_m_clk_oe_o          <= fxn_gpif_m_clk_oe;
              fxn_p0_gpif_m_ctrl_data_oe_o    <= fxn_gpif_m_ctrl_data_oe;
              fxn_p0_gpif_m_wr_data_oe_o      <= {8{fxn_gpif_m_wr_data_oe}};
              fxn_p0_gpif_m_clk_rst_n_o       <= fxn_gpif_m_clk_rst_n;
              fxn_p0_gpif_m_ctrl_data_rst_n_o <= fxn_gpif_m_ctrl_data_rst_n;
              fxn_p0_gpif_m_wr_data_rst_n_o   <= {8{fxn_gpif_m_wr_data_rst_n}};
              fxn_p1_l3_mode_en_o             <= fxn_l3_lp_mode_en;
              fxn_p1_gpif_m_clk_oe_o          <= fxn_gpif_m_clk_oe;
              fxn_p1_gpif_m_ctrl_data_oe_o    <= fxn_gpif_m_ctrl_data_oe;
              fxn_p1_gpif_m_wr_data_oe_o      <= {8{fxn_gpif_m_wr_data_oe}};
              fxn_p1_gpif_m_clk_rst_n_o       <= fxn_gpif_m_clk_rst_n;
              fxn_p1_gpif_m_ctrl_data_rst_n_o <= fxn_gpif_m_ctrl_data_rst_n;
              fxn_p1_gpif_m_wr_data_rst_n_o   <= {8{fxn_gpif_m_wr_data_rst_n}};
           end
        end
    end

    end
endgenerate

// ------------------------------------------
//
// Slave FIFO Read Write Access Gate
//
// ------------------------------------------



// ------------------------------------------
//
// Synchronizer Module
//
// ------------------------------------------

signal_synchronizer
  #
  (
   // Parameters
   .NO_OF_SUPPORTED_DEV_I      ( NO_OF_SUPPORTED_DEV ),
   .SEL_DEV_NUM_BITS_I         ( SEL_DEV_NUM_BITS )
  )
  sync_manager
    (
     // Outputs in gpif clk domain
      .sel_vsync_gpif_clk_o                            ( sel_vsync_gpif_clk ),
      .y_data_bufr_empty_gpif_clk_o                    ( y_data_bufr_empty_gpif_clk ),
      .y_data_bufr_full_gpif_clk_o                     ( y_data_bufr_full_gpif_clk ),
      .ddr_ctrl_data_path_idle_gpif_clk_o              ( ddr_ctrl_data_path_idle_gpif_clk ),
      .ddr_ctrl_cmd_queue_almost_full_gpif_clk_o       ( ddr_ctrl_cmd_queue_almost_full_gpif_clk ),
      .ddr_ctrl_busy_gpif_clk_o                        ( ddr_ctrl_busy_gpif_clk ),
      .ddr_cfg_done_gpif_clk_o                         ( ddr_cfg_done_gpif_clk ),
      .full_frame_wr_completed_gpif_clk_o              ( full_frame_wr_completed_gpif_clk_arr ),
      .full_frame_rd_completed_gpif_clk_o              ( full_frame_rd_completed_gpif_clk_arr ),

     // Outputs in sys clk domain
      .full_frame_wr_completed_hdmi_clk_o              ( full_frame_wr_completed_hdmi_clk_arr ),
      .ddr_wr_xfer_hdmi_clk_arr_o                      ( ddr_wr_xfer_hdmi_clk_arr ),
      .dev_reg_info_st_arr_hdmi_clk_o                  ( dev_reg_info_st_arr_hdmi_clk ),
      .sel_d_start_stream_hdmi_clk_o                   ( sel_d_start_stream_hdmi_clk ),

     // Outputs in axi clk domain
      .sel_vsync_axi_clk_o                             ( sel_vsync_axi_clk ),
      .l_zlp_sent_axi_clk_o                            ( l_zlp_sent_axi_clk ),
      .fxn_gpif_m_pktend_axi_clk_o                     ( fxn_gpif_m_pktend_axi_clk ),
      .dev_reg_info_st_arr_axi_clk_o                   ( dev_reg_info_st_arr_axi_clk ),

      // Inputs
      .fxn_gpif_m_clk                                  ( fxn_gpif_m_clk ),
      .axi_m_clk                                       ( axi_m_clk ),
      .hdmi_clk                                        ( sys_clk ),
      .fxn_gpif_m_reset_n                              ( fxn_gpif_m_clk_reset_n ),
      .axi_m_reset_n                                   ( axi_m_clk_reset_n ),
      .hdmi_reset_n                                    ( sys_clk_reset_n ),
      .sel_vsync_hdmi_clk_i                            ( sel_vsync_hdmi_clk ),
      .l_zlp_sent_i                                    ( l_zlp_sent ),
      .fxn_gpif_m_pktend_n_i                           ( /*fxn_gpif_m_pktend_n*/ tx_eop_control_byte_pl_n ),
      .y_data_bufr_empty_i                             ( y_data_bufr_empty ),
      .y_data_bufr_full_i                              ( y_data_bufr_full ),
      .ddr_ctrl_data_path_idle_i                       ( ddr_ctrl_data_path_idle_i ),
      .ddr_ctrl_cmd_queue_almost_full_i                ( ddr_ctrl_cmd_queue_almost_full_i ),
      .ddr_ctrl_busy_i                                 ( ddr_ctrl_busy_i ),
      .ddr_cfg_done_i                                  ( ddr_cfg_done ),
      .full_frame_wr_completed_axi_clk_i               ( full_frame_wr_completed_axi_clk_arr ),
      .full_frame_rd_completed_axi_clk_i               ( full_frame_rd_completed_axi_clk_arr ),
      .ddr_wr_xfer_axi_clk_arr_i                       ( ddr_wr_xfer_axi_clk_arr ),
      .dev_reg_info_st_arr_i                           ( dev_reg_info_st_arr ),
      .sel_d_start_stream_axi_clk_i                    ( sel_d_start_stream_axi_clk )
    );

// ------------------------------------------
//
// HDMI Input Processor Module
//
// ------------------------------------------

genvar hdmi_rx_num;

`ifdef HDMI_RX
 generate
  for ( hdmi_rx_num = 0; hdmi_rx_num < NO_OF_SUPPORTED_DEV; hdmi_rx_num = hdmi_rx_num + 1 )
   begin : hdmi_data_gen
hdmi_rx_data_processor
  #
  (
   .HDMI_RX_DATA_WIDTH_I (INTERNAL_TEST_PATTERN_DATA_WIDTH)
  )
  hdmi_src
  (
     .hdmi_hsync_o                  (hdmi_hsync[hdmi_rx_num]),
     .hdmi_vsync_o                  (hdmi_vsync[hdmi_rx_num]),
     .hdmi_data_o                   (hdmi_data[hdmi_rx_num]),
     .hdmi_reset_n_o                (/* hdmi_reset_n_o */),

     .hdmi_clk                      (sys_clk),
     .hdmi_reset_n                  (sys_clk_reset_n),
     .hdmi_clk_lock_i               (sys_clk_lock),
     .dev_reg_info_st_arr_i         (dev_reg_info_st_arr_hdmi_clk[hdmi_rx_num]),
     .hdmi_y0_i                     (hdmi_y0_i),
     .hdmi_y1_i                     (hdmi_y1_i),
     .hdmi_cr0_i                    (hdmi_cr0_i),
     .hdmi_cr1_i                    (hdmi_cr1_i),
     .hdmi_cb0_i                    (hdmi_cb0_i),
     .hdmi_cb1_i                    (hdmi_cb1_i),
     .hdmi_vsync_n_i                (hdmi_vsync_n_i),
     .hdmi_hsync_i                  (hdmi_hsync_i),
     .hdmi_de_i                     (hdmi_de_i)
  );
   end
 endgenerate
`endif

// ------------------------------------------
//
// Clock Mux
//
// ------------------------------------------

// For colour bar, clock source is "mipi_pixel_clk"
// For HDMI, clock source is "hdmi_clk"

generate

  if ( LVCMOS_SLFIFO_MODE == "FV_LV" )
    begin
      clk_mux_2x1
        cm
        (
         .clk_in0_i        ( fxn_gpif_m_clk ),  // MIPI Pixel Clock - Also used by Colorbar Generator
         .reset_in0_n_i    ( fxn_gpif_m_clk_reset_n ),
         .clk_in0_valid_i  ( pll_clk_16m_lock_i ),
         .clk_in1_i        ( hdmi_clk ),        // HDMI Clock
         .reset_in1_n_i    ( hdmi_clk_reset_n ),
         .clk_in1_valid_i  ( 1'b0 /*dev_reg_info_st_arr[0].hdmi_source_connection*/ ),
         .clk_sel_i        ( 1'b0 /*dev_reg_info_st_arr[0].hdmi_source_en*/ ),
         .sel_clk_o        ( sys_clk ),
         .sel_clk_valid_o  ( sys_clk_lock )
        );
    end
  else
    begin
      clk_mux_2x1
        cm
        (
         .clk_in0_i        ( mipi_pixel_clk ),  // MIPI Pixel Clock - Also used by Colorbar Generator
         .reset_in0_n_i    ( mipi_pixel_clk_reset_n ),
         .clk_in0_valid_i  ( pll_clk_16m_lock_i ),
         .clk_in1_i        ( hdmi_clk ),        // HDMI Clock
         .reset_in1_n_i    ( hdmi_clk_reset_n ),
         .clk_in1_valid_i  ( 1'b0 /*dev_reg_info_st_arr[0].hdmi_source_connection*/ ),
         .clk_sel_i        ( 1'b0 /*dev_reg_info_st_arr[0].hdmi_source_en*/ ),
         .sel_clk_o        ( sys_clk ),
         .sel_clk_valid_o  ( sys_clk_lock )
        );
    end
endgenerate


//  assign sys_clk =       ( dev_reg_info_st_arr[0].hdmi_source_en == 1'b1 ) ? hdmi_clk : mipi_pixel_clk ;
//  assign sys_clk_lock =  ( dev_reg_info_st_arr[0].hdmi_source_en == 1'b1 ) ? dev_reg_info_st_arr[0].hdmi_source_connection : pll_clk_16m_lock_i ;

  // assign sys_clk      = hdmi_clk;
  // assign sys_clk_lock = dev_reg_info_st_arr[0].hdmi_source_connection;


// ------------------------------------------
//
// Data Mux
//
// ------------------------------------------

genvar dev_num;

 generate
  for ( dev_num = 0; dev_num < NO_OF_SUPPORTED_DEV; dev_num = dev_num + 1 )
   begin : fifo_data

always_ff @ ( posedge sys_clk )
  begin
    if ( !sys_clk_reset_n )
      begin
        sel_vsync_hdmi_clk[dev_num]             <= '0;
        sel_hsync_hdmi_clk[dev_num]             <= '0;
        sel_intr_fifo_wr_data_hdmi_clk[dev_num] <= '0;
      end
    else if ( dev_reg_info_st_arr_hdmi_clk[dev_num].hdmi_source_en )
     begin
       sel_vsync_hdmi_clk[dev_num]              <= hdmi_vsync[dev_num];
       sel_hsync_hdmi_clk[dev_num]              <= hdmi_hsync[dev_num];
       sel_intr_fifo_wr_data_hdmi_clk[dev_num]  <= hdmi_data[dev_num];
     end
    else if ( dev_reg_info_st_arr_hdmi_clk[dev_num].mipi_source_en )
     begin
       if ( dev_reg_info_st_arr_hdmi_clk[dev_num].mipi_isp_en )
         begin
//           sel_vsync_hdmi_clk[dev_num]              <= isp_fv;
//           sel_hsync_hdmi_clk[dev_num]              <= isp_lv;
//           sel_intr_fifo_wr_data_hdmi_clk[dev_num]  <= isp_data;
         end
       else if ( dev_reg_info_st_arr_hdmi_clk[dev_num].mipi_image_crop_en )
         begin
           sel_vsync_hdmi_clk[dev_num]              <= rx_frame_valid[dev_num];
           sel_hsync_hdmi_clk[dev_num]              <= rx_sensor_data_valid[dev_num];
           sel_intr_fifo_wr_data_hdmi_clk[dev_num]  <= rx_sensor_data[dev_num];
         end
       else
         begin
           sel_vsync_hdmi_clk[dev_num]              <= w_rx_out_vs[dev_num];
           sel_hsync_hdmi_clk[dev_num]              <= ( w_rx_out_hs[dev_num] & w_rx_out_de[dev_num] );
           sel_intr_fifo_wr_data_hdmi_clk[dev_num]  <= w_rx_out_data[dev_num];
         end
     end
    else // check if internal colour bar instance is enabled or not
      begin
        sel_vsync_hdmi_clk[dev_num]             <= internal_tp_fv_hdmi_clk[dev_num];
        sel_hsync_hdmi_clk[dev_num]             <= internal_tp_lv_hdmi_clk[dev_num];
        sel_intr_fifo_wr_data_hdmi_clk[dev_num] <= internal_tp_data_hdmi_clk[dev_num];
      end
  end

// ------------------------------------------
//
// Rising and Falling Edge of VSYNC
//
// ------------------------------------------

always_ff @ ( posedge sys_clk )
  begin
    if ( !sys_clk_reset_n )
      begin
        sel_vsync_hdmi_clk_f1[dev_num]    <= 1'b0;
        sel_vsync_hdmi_clk_f2[dev_num]    <= 1'b0;
        sel_vsync_hdmi_clk_pe_pl[dev_num] <= 1'b0;
        sel_vsync_hdmi_clk_ne_pl[dev_num] <= 1'b0;
      end
    else
      begin
        sel_vsync_hdmi_clk_f1[dev_num]    <= sel_vsync_hdmi_clk[dev_num];
        sel_vsync_hdmi_clk_f2[dev_num]    <= sel_vsync_hdmi_clk_f1[dev_num];
        sel_vsync_hdmi_clk_pe_pl[dev_num] <= (sel_vsync_hdmi_clk_f1[dev_num] & ~sel_vsync_hdmi_clk_f2[dev_num]);
        sel_vsync_hdmi_clk_ne_pl[dev_num] <= (~sel_vsync_hdmi_clk_f1[dev_num] & sel_vsync_hdmi_clk_f2[dev_num]);
      end
  end


  end
endgenerate

endmodule
