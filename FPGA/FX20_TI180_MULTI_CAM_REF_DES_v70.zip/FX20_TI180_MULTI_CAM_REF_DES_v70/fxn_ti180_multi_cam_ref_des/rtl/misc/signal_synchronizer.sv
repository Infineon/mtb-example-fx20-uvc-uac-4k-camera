//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    signal_synchronizer
// Target Devices: All
//
// Description: In this module, the input signals are synchronised with different
//              clock domains.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


`timescale 1ns/100ps

module signal_synchronizer
  #
  (
   // No. of devices/ FIFOs needed
  parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
  parameter SEL_DEV_NUM_BITS_I = 3
  )
 (
  input                              fxn_gpif_m_clk,
  input                              axi_m_clk,
  input                              hdmi_clk,

  input                              fxn_gpif_m_reset_n,
  input                              axi_m_reset_n,
  input                              hdmi_reset_n,

  input  [(NO_OF_SUPPORTED_DEV_I-1):0] sel_vsync_hdmi_clk_i,
  input                              l_zlp_sent_i,
  input                              fxn_gpif_m_pktend_n_i,
  input  [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_empty_i,
  input  [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_full_i,
  input                              ddr_ctrl_data_path_idle_i,
  input                              ddr_ctrl_cmd_queue_almost_full_i,
  input                              ddr_ctrl_busy_i,
  input                              ddr_cfg_done_i,
  input  [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_wr_completed_axi_clk_i,
  input  [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_rd_completed_axi_clk_i,
  input  [(NO_OF_SUPPORTED_DEV_I-1):0] ddr_wr_xfer_axi_clk_arr_i,
  input  dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_i,
  input  [(NO_OF_SUPPORTED_DEV_I-1):0] sel_d_start_stream_axi_clk_i,

  // Outputs in axi clk domain
  output [(NO_OF_SUPPORTED_DEV_I-1):0] sel_vsync_axi_clk_o,
  output                             l_zlp_sent_axi_clk_o,
  output                             fxn_gpif_m_pktend_axi_clk_o,
  output  dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_axi_clk_o,


  // Outputs in sys clk domain
  output [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_wr_completed_hdmi_clk_o,
  output [(NO_OF_SUPPORTED_DEV_I-1):0] ddr_wr_xfer_hdmi_clk_arr_o,
  output  dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_hdmi_clk_o,
  output [(NO_OF_SUPPORTED_DEV_I-1):0] sel_d_start_stream_hdmi_clk_o,


  // Outputs in gpif clk domain
  output [(NO_OF_SUPPORTED_DEV_I-1):0] sel_vsync_gpif_clk_o,
  output [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_empty_gpif_clk_o,
  output [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_full_gpif_clk_o,
  output                             ddr_ctrl_data_path_idle_gpif_clk_o,
  output                             ddr_ctrl_cmd_queue_almost_full_gpif_clk_o,
  output                             ddr_ctrl_busy_gpif_clk_o,
  output                             ddr_cfg_done_gpif_clk_o,
  output [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_wr_completed_gpif_clk_o,
  output [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_rd_completed_gpif_clk_o
 );


// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

 // reg and wires for axi clk domain
logic [(NO_OF_SUPPORTED_DEV_I-1):0] sel_vsync_axi_clk_f1;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] sel_vsync_axi_clk_f2;
logic                             l_zlp_sent_axi_clk_f1;
logic                             l_zlp_sent_axi_clk_f2;
dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_axi_clk_f1;
dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_axi_clk_f2;

 // reg and wires for hdmi clk domain
logic [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_wr_completed_hdmi_clk_f1;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_wr_completed_hdmi_clk_f2;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] ddr_wr_xfer_hdmi_clk_arr_f1;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] ddr_wr_xfer_hdmi_clk_arr_f2;
dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_hdmi_clk_f1;
dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_hdmi_clk_f2;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] sel_d_start_stream_hdmi_clk_f1;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] sel_d_start_stream_hdmi_clk_f2;

 // reg and wires for gpif clk domain
logic [(NO_OF_SUPPORTED_DEV_I-1):0] sel_vsync_gpif_clk_f1;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] sel_vsync_gpif_clk_f2;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_empty_f1;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_empty_f2;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_full_f1;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_full_f2;
logic                             ddr_ctrl_data_path_idle_f1;
logic                             ddr_ctrl_data_path_idle_f2;
logic                             ddr_ctrl_cmd_queue_almost_full_f1;
logic                             ddr_ctrl_cmd_queue_almost_full_f2;
logic                             ddr_ctrl_busy_f1;
logic                             ddr_ctrl_busy_f2;
logic                             ddr_cfg_done_f1;
logic                             ddr_cfg_done_f2;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_wr_completed_f1;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_wr_completed_f2;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_rd_completed_f1;
logic [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_rd_completed_f2;


// ------------------------------------------
//
// 2 FF Synchronizer
//
// ------------------------------------------

// For "axi_m_clk" clock domain
always_ff @ ( posedge axi_m_clk or negedge axi_m_reset_n )
  begin
    if ( ~axi_m_reset_n )
      begin
        sel_vsync_axi_clk_f1            <= 1'b0;
        l_zlp_sent_axi_clk_f1           <= 1'b0;
        dev_reg_info_st_arr_axi_clk_f1  <= '{default:0};
        sel_vsync_axi_clk_f2            <= 1'b0;
        l_zlp_sent_axi_clk_f2           <= 1'b0;
        dev_reg_info_st_arr_axi_clk_f2  <= '{default:0};
      end
    else
      begin
        sel_vsync_axi_clk_f1            <= sel_vsync_hdmi_clk_i;
        l_zlp_sent_axi_clk_f1           <= l_zlp_sent_i;
        dev_reg_info_st_arr_axi_clk_f1  <= dev_reg_info_st_arr_i;
        sel_vsync_axi_clk_f2            <= sel_vsync_axi_clk_f1;
        l_zlp_sent_axi_clk_f2           <= l_zlp_sent_axi_clk_f1;
        dev_reg_info_st_arr_axi_clk_f2  <= dev_reg_info_st_arr_axi_clk_f1;
      end
  end

// Assignments
assign sel_vsync_axi_clk_o            = sel_vsync_axi_clk_f2;
assign l_zlp_sent_axi_clk_o           = l_zlp_sent_axi_clk_f2;
assign dev_reg_info_st_arr_axi_clk_o  = dev_reg_info_st_arr_axi_clk_f2;

// For "hdmi_clk" clock domain
always_ff @ ( posedge hdmi_clk or negedge hdmi_reset_n )
  begin
    if ( ~hdmi_reset_n )
      begin
        full_frame_wr_completed_hdmi_clk_f1    <= 'b0;
        ddr_wr_xfer_hdmi_clk_arr_f1            <= 'b0;
        dev_reg_info_st_arr_hdmi_clk_f1        <= '{default:0};
        sel_d_start_stream_hdmi_clk_f1         <= 'b0;
        full_frame_wr_completed_hdmi_clk_f2    <= 'b0;
        ddr_wr_xfer_hdmi_clk_arr_f2            <= 'b0;
        dev_reg_info_st_arr_hdmi_clk_f2        <= '{default:0};
        sel_d_start_stream_hdmi_clk_f2         <= 'b0;
      end
    else
      begin
        full_frame_wr_completed_hdmi_clk_f1    <= full_frame_wr_completed_axi_clk_i;
        ddr_wr_xfer_hdmi_clk_arr_f1            <= ddr_wr_xfer_axi_clk_arr_i;
        dev_reg_info_st_arr_hdmi_clk_f1        <= dev_reg_info_st_arr_i;
        sel_d_start_stream_hdmi_clk_f1         <= sel_d_start_stream_axi_clk_i;
        full_frame_wr_completed_hdmi_clk_f2    <= full_frame_wr_completed_hdmi_clk_f1;
        ddr_wr_xfer_hdmi_clk_arr_f2            <= ddr_wr_xfer_hdmi_clk_arr_f1;
        dev_reg_info_st_arr_hdmi_clk_f2        <= dev_reg_info_st_arr_hdmi_clk_f1;
        sel_d_start_stream_hdmi_clk_f2         <= sel_d_start_stream_hdmi_clk_f1;
      end
  end

// Assignment
assign full_frame_wr_completed_hdmi_clk_o      = full_frame_wr_completed_hdmi_clk_f2;
assign ddr_wr_xfer_hdmi_clk_arr_o              = ddr_wr_xfer_hdmi_clk_arr_f2;
assign dev_reg_info_st_arr_hdmi_clk_o          = dev_reg_info_st_arr_hdmi_clk_f2;
assign sel_d_start_stream_hdmi_clk_o           = sel_d_start_stream_hdmi_clk_f2;

// In "fxn_gpif_m_clk" clock domain
always_ff @ ( posedge fxn_gpif_m_clk or negedge fxn_gpif_m_reset_n )
  begin
    if ( ~fxn_gpif_m_reset_n )
      begin
        sel_vsync_gpif_clk_f1              <= 'b0;
        sel_vsync_gpif_clk_f2              <= 'b0;
        y_data_bufr_empty_f1               <= 'b0;
        y_data_bufr_empty_f2               <= 'b0;
        y_data_bufr_full_f1                <= 'b0;
        y_data_bufr_full_f2                <= 'b0;
        ddr_ctrl_data_path_idle_f1         <= 'b0;
        ddr_ctrl_data_path_idle_f2         <= 'b0;
        ddr_ctrl_cmd_queue_almost_full_f1  <= 'b0;
        ddr_ctrl_cmd_queue_almost_full_f2  <= 'b0;
        ddr_ctrl_busy_f1                   <= 'b0;
        ddr_ctrl_busy_f2                   <= 'b0;
        ddr_cfg_done_f1                    <= 'b0;
        ddr_cfg_done_f2                    <= 'b0;
        full_frame_wr_completed_f1         <= 'b0;
        full_frame_wr_completed_f2         <= 'b0;
        full_frame_rd_completed_f1         <= 'b0;
        full_frame_rd_completed_f2         <= 'b0;
      end
    else
      begin
        sel_vsync_gpif_clk_f1              <= sel_vsync_hdmi_clk_i;
        sel_vsync_gpif_clk_f2              <= sel_vsync_gpif_clk_f1;
        y_data_bufr_empty_f1               <= y_data_bufr_empty_i;
        y_data_bufr_empty_f2               <= y_data_bufr_empty_f1;
        y_data_bufr_full_f1                <= y_data_bufr_full_i;
        y_data_bufr_full_f2                <= y_data_bufr_full_f1;
        ddr_ctrl_data_path_idle_f1         <= ddr_ctrl_data_path_idle_i;
        ddr_ctrl_data_path_idle_f2         <= ddr_ctrl_data_path_idle_f1;
        ddr_ctrl_cmd_queue_almost_full_f1  <= ddr_ctrl_cmd_queue_almost_full_i;
        ddr_ctrl_cmd_queue_almost_full_f2  <= ddr_ctrl_cmd_queue_almost_full_f1;
        ddr_ctrl_busy_f1                   <= ddr_ctrl_busy_i;
        ddr_ctrl_busy_f2                   <= ddr_ctrl_busy_f1;
        ddr_cfg_done_f1                    <= ddr_cfg_done_i;
        ddr_cfg_done_f2                    <= ddr_cfg_done_f1;
        full_frame_wr_completed_f1         <= full_frame_wr_completed_axi_clk_i;
        full_frame_wr_completed_f2         <= full_frame_wr_completed_f1;
        full_frame_rd_completed_f1         <= full_frame_rd_completed_axi_clk_i;
        full_frame_rd_completed_f2         <= full_frame_rd_completed_f1;
      end
  end

// Assignment
assign sel_vsync_gpif_clk_o                      = sel_vsync_gpif_clk_f2;
assign y_data_bufr_empty_gpif_clk_o              = y_data_bufr_empty_f2;
assign y_data_bufr_full_gpif_clk_o               = y_data_bufr_full_f2;
assign ddr_ctrl_data_path_idle_gpif_clk_o        = ddr_ctrl_data_path_idle_f2;
assign ddr_ctrl_cmd_queue_almost_full_gpif_clk_o = ddr_ctrl_cmd_queue_almost_full_f2;
assign ddr_ctrl_busy_gpif_clk_o                  = ddr_ctrl_busy_f2;
assign ddr_cfg_done_gpif_clk_o                   = ddr_cfg_done_f2;
assign full_frame_wr_completed_gpif_clk_o        = full_frame_wr_completed_f2;
assign full_frame_rd_completed_gpif_clk_o        = full_frame_rd_completed_f2;


// ------------------------------------------
//
// Pulse Synchronizer
//
// ------------------------------------------

// For PKTEND
cdc_pulse_synchronizer
  pktend_ps
   (
    .src_clk_i       ( fxn_gpif_m_clk ),
    .dest_clk_i      ( axi_m_clk ),
    .reset_n         ( fxn_gpif_m_reset_n ),
    .src_data_pl_i   ( ~fxn_gpif_m_pktend_n_i ), // As PKTEND is active low pulse
    .dest_data_pl_o  ( fxn_gpif_m_pktend_axi_clk_o ) // Active High Synchronised Pulse
   );

endmodule