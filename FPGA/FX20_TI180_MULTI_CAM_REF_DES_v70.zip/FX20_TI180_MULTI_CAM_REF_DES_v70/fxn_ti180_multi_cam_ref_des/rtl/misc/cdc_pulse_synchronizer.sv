//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:  FX10/20 Design
// Module Name:  cdc_pulse_synchronizer
// Target Devices: All
//
// Description: This module synchronises the pulse from one clock domain to other.
//
//////////////////////////////////////////////////////////////////////////////////

module cdc_pulse_synchronizer
  (
   input  src_clk_i,      // Source Input Clock
   input  dest_clk_i,     // Destination Input Clock
   input  reset_n,        // Active Low Reset
   input  src_data_pl_i,  // Input Pulse of Source Clock Domain

   output dest_data_pl_o  // Output Pulse of Destination Clock Domain

  );


  // --------------------------------------
  //
  // Local Variable
  //
  // --------------------------------------

  logic in_data;
  logic in_data_f1;
  logic in_data_f2;
  logic in_data_f3;

  // --------------------------------------
  //
  // T Flip Flop
  //
  // --------------------------------------

  always_ff @ ( posedge src_clk_i )
    begin
      if ( ~reset_n )
        begin
          in_data <= 1'b0;
        end
      else if ( src_data_pl_i )
        begin
          in_data <= ~in_data;
        end
    end

  // --------------------------------------
  //
  // 2 Flop Synchronizer
  //
  // --------------------------------------

  always_ff @ ( posedge dest_clk_i )
    begin
      if ( ~reset_n )
        begin
          in_data_f1 <= 1'b0;
          in_data_f2 <= 1'b0;
          in_data_f3 <= 1'b0;
        end
      else
        begin
          in_data_f1 <= in_data;
          in_data_f2 <= in_data_f1;
          in_data_f3 <= in_data_f2;
        end
    end


  // --------------------------------------
  //
  // XOR Gate Output
  //
  // --------------------------------------

  // Synchronized Pulse in Destination Clock Domain

  assign dest_data_pl_o = ( in_data_f2 ^ in_data_f3 );

endmodule