//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:  FX10/20 Design
// Module Name:  reset_synchronizer
// Target Devices: All
//
// Description: This module synchronises the de-assertion of active low reset.
//
//////////////////////////////////////////////////////////////////////////////////

module reset_synchronizer
  (
   input  clk,            // Input Clock
   input  reset_n,        // Active Low Reset

   output sync_reset_n_o  // Output Synchronized Active Low Reset

  );

  // --------------------------------------
  //
  // Local Variable
  //
  // --------------------------------------

  logic in_data;
  logic in_data_f1;
  logic in_data_f2;
  logic in_data_f3;

  // --------------------------------------
  //
  // 2 Flop Synchronizer
  //
  // --------------------------------------

  always_ff @ ( posedge clk or negedge reset_n )
    begin
      if ( ~reset_n )
        begin
          in_data_f1 <= 1'b0;
          in_data_f2 <= 1'b0;
        end
      else
        begin
          in_data_f1 <= 1'b1;
          in_data_f2 <= in_data_f1;
        end
    end


  // --------------------------------------
  //
  // Synchronized Reset
  //
  // --------------------------------------

  assign sync_reset_n_o = in_data_f2;

endmodule