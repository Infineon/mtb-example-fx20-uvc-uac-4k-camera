//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:  FX10/20 Design
// Module Name:  clk_mux_2x1.v
// Target Devices: All
//
// Description: It is the mux module which selects the single clock from mupltiple
//              input clocks based on the select signal.
//
//////////////////////////////////////////////////////////////////////////////////


// Timescale
`timescale 1 ns / 100 ps

module clk_mux_2x1
(
  input  clk_in0_i,        // Input clock 0
  input  reset_in0_n_i,    // Active low reset sychmonised with clock 0 domain
  input  clk_in0_valid_i,  // PLL Lock for clock 0
  input  clk_in1_i,        // Input clock 1
  input  reset_in1_n_i,    // Active low reset sychmonised with clock 1 domain
  input  clk_in1_valid_i,  // PLL Lock for clock 1
  input  clk_sel_i,        // Clock selection signal

  output sel_clk_o,        // Output selected clock
  output sel_clk_valid_o   // Output selected clock lock
);

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

logic clk0_sel_f1;
logic clk0_sel_f2;
logic clk1_sel_f1;
logic clk1_sel_f2;
logic clk0_sel;
logic clk1_sel;
logic sel_clk_0;
logic sel_clk_1;

// ------------------------------------------
//
// Clock 0 Selection
//
// ------------------------------------------

// Clock selection signal is LOW
assign clk0_sel = ( ( clk_sel_i == 1'b0 ) & ( ~clk1_sel_f2 ) );

// Positive Edge Triggered FF
always_ff @ ( posedge clk_in0_i or negedge reset_in0_n_i )
  begin
    if ( ~reset_in0_n_i )
      begin
        clk0_sel_f1 <= 1'b0;
      end
    else
      begin
        clk0_sel_f1 <= clk0_sel;
      end
  end

// Negative Edge Triggered FF
always_ff @ ( negedge clk_in0_i or negedge reset_in0_n_i )
  begin
    if ( ~reset_in0_n_i )
      begin
        clk0_sel_f2 <= 1'b0;
      end
    else
      begin
        clk0_sel_f2 <= clk0_sel_f1;
      end
  end

// Selected clock 0
assign sel_clk_0 = ( clk0_sel_f2 & clk_in0_i );

// ------------------------------------------
//
// Clock 1 Selection
//
// ------------------------------------------

// Clock selection signal is HIGH
assign clk1_sel = ( ( clk_sel_i == 1'b1 ) & ( ~clk0_sel_f2 ) );

// Positive Edge Triggered FF
always_ff @ ( posedge clk_in1_i or negedge reset_in1_n_i )
  begin
    if ( ~reset_in1_n_i )
      begin
        clk1_sel_f1 <= 1'b0;
      end
    else
      begin
        clk1_sel_f1 <= clk1_sel;
      end
  end

// Negative Edge Triggered FF
always_ff @ ( negedge clk_in1_i or negedge reset_in1_n_i )
  begin
    if ( ~reset_in1_n_i )
      begin
        clk1_sel_f2 <= 1'b0;
      end
    else
      begin
        clk1_sel_f2 <= clk1_sel_f1;
      end
  end

// Selected clock 1
assign sel_clk_1 = ( clk1_sel_f2 & clk_in1_i );

// ------------------------------------------
//
// Final Clock Selection
//
// ------------------------------------------

assign sel_clk_o = ( sel_clk_0 | sel_clk_1 );

// ------------------------------------------
//
// Final PLL Lock Selection
//
// ------------------------------------------

// Selected clock valid
assign sel_clk_valid_o = ( clk1_sel_f2 ? clk_in1_valid_i : clk_in0_valid_i );

endmodule