//////////////////////////////////////////////////////////////////////////////////
//(c) 2022-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fbh_rd_wrapper
// Target Devices: Ti180
//
// Description: This module is a wrapper module for Device selection(fbh_rd_dev_sel_fsm.v)
//              and Device Read(fbh_rd_fsm.v) modules.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module fbh_rd_wrapper
 #
 (
  // Slave FIFO Depth
  parameter SLFIFO_DEPTH_IN_WORDS_I     =  512,

  // Slave read data width
  parameter SLFIFO_RD_DATA_WIDTH_IN_BITS_I  = 64,

   // Write count data width
   parameter SLFIFO_WR_COUNT_DATA_WIDTH_I = 16,

  // AXI Master Write Channel Data Width
  parameter AXI_M0_WR_DATA_WIDTH_IN_BITS_I = 512,

  // FIRST_BUFFER_START_ADDR
  parameter FIRST_BUFFER_START_ADDR_I = 32'h0000_0000,

  // BUFFER_START_ADDR_DIFF_FOR_SAME_DEV
  parameter BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I = 32'h03F4_8000,

  // FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV
  parameter FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I = 32'h1000_0000,

  // AXI Master Read Channel Data Width
  parameter AXI_M0_RD_DATA_WIDTH_IN_BITS_I =  256,

  // AXI Master Burst Size
  parameter MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I = 3840,

  // No of fifos/ Devices
  parameter NO_OF_SUPPORTED_DEV_I =  8,

  // No. of bits for device num
  parameter SEL_DEV_NUM_BITS_I =  3

 )
 (
  // clk & Reset
  input                hdmi_clk,
  input                axi_clk,
  input                fxn_gpif_m_clk,

  input                hdmi_clk_reset_n,
  input                axi_clk_reset_n,
  input                fxn_gpif_m_clk_reset_n,

  input                ddr_init_done_i,
  input  [(NO_OF_SUPPORTED_DEV_I-1):0] sel_vsync_axi_clk_i,

 // i2c signals related to device
  // input                cam_app_en,
  // input                hdmi_src_connect_i,
  // input                slfifo_st_vidrst,


 // DDR Write side AXI buffer details
  // input                wr_frame_num,
  // input                wr_frame_buf,

 // Synchronized signals structure
  input                dev_reg_info_st_t     [(NO_OF_SUPPORTED_DEV_I-1):0] device_status_arr_axi_clk_i,
  input                dev_reg_info_st_t     [(NO_OF_SUPPORTED_DEV_I-1):0] device_status_arr_gpif_clk_i,
  output               dev_reg_info_st_t     device_status_gpif_clk_o,
  output               dev_reg_info_st_t     device_status_axi_clk_o,

 // AXI READ related   signals
  input                axi_m0_arready_i,
  input                axi_m0_rvalid_i,
  input                axi_m0_rlast_i,
  input [(AXI_M0_WR_DATA_WIDTH_IN_BITS_I-1):0] axi_m0_rdata_i,

  output logic [32:0]  axi_m0_araddr_o,
  output logic         axi_m0_arvalid_o,
  output logic [ 1:0]  axi_m0_arburst_o,
  output       [ 5:0]  axi_m0_arid_o,
  output logic [ 7:0]  axi_m0_arlen_o,
  output               axi_m0_arlock_o,
  output logic [ 2:0]  axi_m0_arsize_o,
  output               axi_m0_rready_o,

  input  fbh_wr_addr_nd_ctrl_st_t     [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_wr_addr_nd_ctrl_i,     // Common signals between write and read FBH modules
  output fbh_rd_states_nd_ctrl_st_t   [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_rd_states_nd_ctrl_o,   // Common signals between FBH modules
  output fbh_rd_dsf_flags_st_t        [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_rd_dsf_flags_arr_o,    // Common signals between FBH modules
  input  common_reg_info_st_t                                        common_reg_info_i,


// slfifo Buffer status
 input                 slfifo_ctrl_req_st_t       [NO_OF_SUPPORTED_DEV_I-1:0] slfifo_ctrl_req_i,
 output                slfifo_data_nd_status_st_t [NO_OF_SUPPORTED_DEV_I-1:0] slfifo_data_nd_status_o,

 // input                 slfifo_reset_busy_i,
 // input  [9:0]         slfifo_wr_data_count_i,

 output logic  [(SEL_DEV_NUM_BITS_I-1):0]  fbh_rd_dsf_sel_device_num_o

);

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

// logic  [(SEL_DEV_NUM_BITS_I-1):0]  fbh_rd_dsf_sel_device_num;
 logic           update_dev_num;
 logic [(NO_OF_SUPPORTED_DEV_I-1):0]  sel_d_reset_or_stop_stream_req_axi_clk;
// logic [31:0]    sel_d_frame_size_in_bytes;
 logic [(NO_OF_SUPPORTED_DEV_I-1):0] [31:0]    frame_size_in_bytes;
slfifo_ctrl_req_st_t         [(NO_OF_SUPPORTED_DEV_I-1):0] slfifo_wr_ctrl_req;


// ------------------------------------------
//
// Read Device Selection FSM
//
// ------------------------------------------

 fbh_rd_dev_sel_fsm
  #
  (
   .SLFIFO_DEPTH_IN_WORDS_I (SLFIFO_DEPTH_IN_WORDS_I),
   .NO_OF_SUPPORTED_DEV_I   (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I      (SEL_DEV_NUM_BITS_I)

  )
  fbhrddsf
  (

    .sel_d_reset_or_stop_stream_req_axi_clk_o (sel_d_reset_or_stop_stream_req_axi_clk),
    .frame_size_in_bytes_o                    (frame_size_in_bytes),
    .fbh_rd_dsf_sel_device_num_o              (fbh_rd_dsf_sel_device_num_o),
    .fbh_rd_dsf_flags_arr_o                   (fbh_rd_dsf_flags_arr_o),
    .device_status_gpif_clk_o                 (device_status_gpif_clk_o),
    .device_status_axi_clk_o                  (device_status_axi_clk_o),
    .clk                                      (axi_clk),              // axi_clk
    .reset_n                                  (axi_clk_reset_n),
    .ddr_init_done_i                          (ddr_init_done_i),     // DDR Calibration Done
    .update_dev_num_i                         (update_dev_num),      // From fbh_rd_fsm
    .sel_vsync_axi_clk_i                      (sel_vsync_axi_clk_i),
    .fbh_wr_addr_nd_ctrl_i                    (fbh_wr_addr_nd_ctrl_i),
    .fbh_rd_states_nd_ctrl_i                  (fbh_rd_states_nd_ctrl_o),
    .slfifo_status_i                          (slfifo_data_nd_status_o),
    .common_reg_info_i                        (common_reg_info_i),
    .device_status_arr_gpif_clk_i             (device_status_arr_gpif_clk_i),
    .device_status_arr_axi_clk_i              (device_status_arr_axi_clk_i)

  );

// ------------------------------------------
//
// Read DDR FSM
//
// ------------------------------------------

  fbh_rd_fsm
  #
  (
   .SLFIFO_DEPTH_IN_WORDS_I                      (SLFIFO_DEPTH_IN_WORDS_I),
   .AXI_M0_WR_DATA_WIDTH_IN_BITS_I               (AXI_M0_WR_DATA_WIDTH_IN_BITS_I),
   .FIRST_BUFFER_START_ADDR_I                    (FIRST_BUFFER_START_ADDR_I),
   .BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I        (BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I),
   .FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I (FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I),
   .AXI_M0_RD_DATA_WIDTH_IN_BITS_I               (AXI_M0_RD_DATA_WIDTH_IN_BITS_I),
   .MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I   (MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I),
   .NO_OF_SUPPORTED_DEV_I                        ( NO_OF_SUPPORTED_DEV_I ),
   .SEL_DEV_NUM_BITS_I                           ( SEL_DEV_NUM_BITS_I )

  )

  fbhrdfsm
  (

   .update_dev_num_o         (update_dev_num),
   .fbh_rd_states_nd_ctrl_o  (fbh_rd_states_nd_ctrl_o),
   .slfifo_wr_ctrl_req_o     (slfifo_wr_ctrl_req),


   .clk                      (axi_clk),
   .reset_n                  (axi_clk_reset_n),
//   .reset_n_hdmi             (reset_n_hdmi),     // Optional
   .fbh_rd_fsm_sel_device_num_i  (fbh_rd_dsf_sel_device_num_o),   // Active Device Number
   .ddr_init_done_i          (ddr_init_done_i),
   .sel_d_reset_or_stop_stream_req_axi_clk_i (sel_d_reset_or_stop_stream_req_axi_clk),
   .frame_size_in_bytes_i    (frame_size_in_bytes),


   .axi_m0_arready_i         (axi_m0_arready_i), // AXI Read inputs
   .axi_m0_rvalid_i          (axi_m0_rvalid_i),
   .axi_m0_rlast_i           (axi_m0_rlast_i),
   .axi_m0_rdata_i           (axi_m0_rdata_i),

   .axi_m0_araddr_o          (axi_m0_araddr_o),   // AXI Read Outputs
   .axi_m0_arvalid_o         (axi_m0_arvalid_o),
   .axi_m0_arburst_o         (axi_m0_arburst_o),
   .axi_m0_arid_o            (axi_m0_arid_o),
   .axi_m0_arlen_o           (axi_m0_arlen_o),
   .axi_m0_arlock_o          (axi_m0_arlock_o),
   .axi_m0_arsize_o          (axi_m0_arsize_o),
   .axi_m0_rready_o          (axi_m0_rready_o),
   .fbh_rd_dsf_flags_arr_i   (fbh_rd_dsf_flags_arr_o),
   .fbh_wr_addr_nd_ctrl_i    (fbh_wr_addr_nd_ctrl_i),
   .common_reg_info_i        (common_reg_info_i),
   .device_status_arr_axi_clk_i  (device_status_arr_axi_clk_i),
   .slfifo_status_i          (slfifo_data_nd_status_o)
  );


// ------------------------------------------
//
// Slave FIFO Read Write Access Gate
//
// ------------------------------------------

genvar i;

 generate
  for (i = 0; i < NO_OF_SUPPORTED_DEV_I; i= i+1)
   begin : slfifo_data

slfifo_rd_wr_gate
  #
  (
  // Parameters
  . SLFIFO_WR_DATA_WIDTH_IN_BITS_I            ( AXI_M0_RD_DATA_WIDTH_IN_BITS_I ), // As of now, AXI0 is used
  . SLFIFO_RD_DATA_WIDTH_IN_BITS_I            ( SLFIFO_RD_DATA_WIDTH_IN_BITS_I ),
  . SLFIFO_WR_COUNT_DATA_WIDTH_I              ( SLFIFO_WR_COUNT_DATA_WIDTH_I ),
  .MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I ( MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I ),
  . SLFIFO_DEPTH_IN_WORDS_I                   ( SLFIFO_DEPTH_IN_WORDS_I )
  )
  slfifo
    (
      // Outputs
      .slfifo_full_o                          ( slfifo_data_nd_status_o[i].full ),
      .slfifo_empty_o                         ( /* slfifo_empty */ ),
      .slfifo_almost_full_o                   ( slfifo_data_nd_status_o[i].almost_full),
      .slfifo_almost_empty_o                  ( slfifo_data_nd_status_o[i].almost_empty ),
      .slfifo_reset_busy_o                    ( slfifo_data_nd_status_o[i].reset_busy ),
      .slfifo_rd_data_valid_o                 ( slfifo_data_nd_status_o[i].rd_data_valid ),
      .slfifo_wr_data_count_o                 ( slfifo_data_nd_status_o[i].wr_data_count ),
      .slfifo_rd_data_count_o                 ( slfifo_data_nd_status_o[i].rd_data_count ),

      // Inputs
      .wr_clk                                 ( axi_clk  ),
      .rd_reset_n                             ( fxn_gpif_m_clk_reset_n ),
      .rd_clk                                 ( fxn_gpif_m_clk ),

      .slfifo_reset_req_i                     ( 1'b0 /*slfifo_ctrl_req_i[i].reset_req*/ ),/////////////////////
      .slfifo_rd_req_i                        ( slfifo_ctrl_req_i[i].rd_req ),
      .slfifo_rd_data_o                       ( slfifo_data_nd_status_o[i].rd_data ),

      .sel_d_reset_or_stop_stream_req_i       ( sel_d_reset_or_stop_stream_req_axi_clk[i] /*!fbh_rd_sel_d_start_stream[i]*/ ),

      .slfifo_wr_req_i                        ( slfifo_wr_ctrl_req[i].wr_en ),
      .slfifo_wr_data_i                       ( slfifo_wr_ctrl_req[i].wr_data )
     );

  end
endgenerate


endmodule