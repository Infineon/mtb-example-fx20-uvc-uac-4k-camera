//////////////////////////////////////////////////////////////////////////////////
//(c) 2022-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fbh_rd_fsm
// Target Devices: Ti180
//
// Description: This module is responsible for reading data from DDR4 for particular device number
//


// Include the package file
`include "package/user_define_pkg.sv"


module fbh_rd_fsm
 #
 (
  // Slave FIFO Depth
  parameter SLFIFO_DEPTH_IN_WORDS_I     = 512,

  // AXI Master Write Channel Data Width
  parameter AXI_M0_WR_DATA_WIDTH_IN_BITS_I = 512,

  // FIRST_BUFFER_START_ADDR
  parameter FIRST_BUFFER_START_ADDR_I = 32'h0000_0000,

  // BUFFER_START_ADDR_DIFF_FOR_SAME_DEV
  parameter BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I = 32'h03F4_8000,

  // FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV
  parameter FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I = 32'h1000_0000,

  // AXI Master Read Channel Data Width
  parameter AXI_M0_RD_DATA_WIDTH_IN_BITS_I = 256,

  // AXI Master Burst Size
  parameter MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I = 3840,

   // No. of devices/ FIFOs needed
  parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
  parameter SEL_DEV_NUM_BITS_I  = 3
 )
(

  // Dev Selection FSM
  output logic                  update_dev_num_o,
  output fbh_rd_states_nd_ctrl_st_t   [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_rd_states_nd_ctrl_o,    // Common signals between FBH modules
  output slfifo_ctrl_req_st_t         [(NO_OF_SUPPORTED_DEV_I-1):0]  slfifo_wr_ctrl_req_o,       // Slfifo control requests

 // clk & Reset
  input                         clk,
  input                         reset_n,
//  input                         reset_n_hdmi,

 // Active device Number information
  input        [(SEL_DEV_NUM_BITS_I-1):0]  fbh_rd_fsm_sel_device_num_i,     // From fbh_rd_dev_sel_fsm
  input                         ddr_init_done_i,
  input [(NO_OF_SUPPORTED_DEV_I-1):0]  sel_d_reset_or_stop_stream_req_axi_clk_i,
//  input [31:0]                  sel_d_frame_size_in_bytes_i,
  input [(NO_OF_SUPPORTED_DEV_I-1):0] [31:0] frame_size_in_bytes_i,

 // AXI READ related signals
  input                         axi_m0_arready_i,
  input                         axi_m0_rvalid_i,
  input                         axi_m0_rlast_i,
  input [(AXI_M0_WR_DATA_WIDTH_IN_BITS_I-1):0]  axi_m0_rdata_i,

  output logic [32:0]           axi_m0_araddr_o,
  output logic                  axi_m0_arvalid_o,
  output logic [ 1:0]           axi_m0_arburst_o,
  output       [ 5:0]           axi_m0_arid_o,
  output logic [ 7:0]           axi_m0_arlen_o,
  output                        axi_m0_arlock_o,
  output logic [ 2:0]           axi_m0_arsize_o,
  output                        axi_m0_rready_o,

  input  dev_reg_info_st_t          [(NO_OF_SUPPORTED_DEV_I-1):0]  device_status_arr_axi_clk_i,
  input  common_reg_info_st_t    common_reg_info_i,

  input  fbh_rd_dsf_flags_st_t        [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_rd_dsf_flags_arr_i,   // Common signals between FBH modules
  input  fbh_wr_addr_nd_ctrl_st_t     [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_wr_addr_nd_ctrl_i,    // Common signals between write and read FBH modules
  input  slfifo_data_nd_status_st_t   [(NO_OF_SUPPORTED_DEV_I-1):0]  slfifo_status_i           // Slfifo  status signals

);

// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // No of read states
  localparam NO_OF_RD_FSM_STATES = 4'd8;

  logic [(NO_OF_SUPPORTED_DEV_I-1):0]        sel_buf_rd_flag;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0]        sel_rd_frame_buf_for_addr;

  // FSM States
  enum logic [(NO_OF_RD_FSM_STATES-1):0] {
    RD_IDLE                                = 8'h1,
    RD_ADDR                                = 8'h2,
    RD_DATA                                = 8'h4,
    WR_SLFIFO_DATA                         = 8'h8,
    UPDATE_DEV_NUM                         = 8'h10,
    RD_DDR_INIT                            = 8'h20
  } ddr_rd_fsm_cs, ddr_rd_fsm_ns;

// ------------------------------------------
//
// Local Variables
//
// -----------------------------------------

  logic         axi_m0_arvalid;
  logic         update_dev_num_pl;

// -------------------------------------
//
// DDR Read FSM
//
// -------------------------------------

  // Current State
  always_ff @ ( posedge clk )
    begin
      if ( !reset_n || !ddr_init_done_i )
        begin
          ddr_rd_fsm_cs <= RD_DDR_INIT;
        end
    else if ( sel_d_reset_or_stop_stream_req_axi_clk_i[fbh_rd_fsm_sel_device_num_i] )
      begin
         ddr_rd_fsm_cs <= RD_IDLE;
      end
      else
        begin
          ddr_rd_fsm_cs <= ddr_rd_fsm_ns;
        end
    end


  // Next State
  always_comb
    begin
      ddr_rd_fsm_ns <= RD_DDR_INIT;
      unique case ( ddr_rd_fsm_cs )

      // Wait until DDR is initialised.
        RD_DDR_INIT :
          begin
            if ( ddr_init_done_i )
              begin
                ddr_rd_fsm_ns <= RD_IDLE;
              end
            else
              begin
                ddr_rd_fsm_ns <= RD_DDR_INIT;
              end
          end

      // Wait until start_serving_device_pl is communicated by rd_dev_sel_fsm
        RD_IDLE :
          begin
            if ( fbh_rd_dsf_flags_arr_i[fbh_rd_fsm_sel_device_num_i].start_serving_device_pl  )
              begin
                 ddr_rd_fsm_ns <= RD_ADDR;
              end
            else
              begin
                 ddr_rd_fsm_ns <= RD_IDLE;
              end
          end

      // Wait for read address ready
        RD_ADDR :
          begin
            if ( axi_m0_arready_i == 1'b1 )
              begin
                ddr_rd_fsm_ns <= RD_DATA;
              end
            else
              begin
                ddr_rd_fsm_ns <= RD_ADDR;
              end
          end

      // Start reading the data
        RD_DATA :
          begin
            if ( fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_burst_complete )
              begin
                ddr_rd_fsm_ns <= WR_SLFIFO_DATA;
              end
            else
              begin
                ddr_rd_fsm_ns <= RD_DATA;
              end
          end

      // Writing to slfifo   ( redundant state will remove later )
        WR_SLFIFO_DATA :
          begin
            ddr_rd_fsm_ns <= UPDATE_DEV_NUM;
          end

      // Updating the device number
        UPDATE_DEV_NUM :
          begin
            ddr_rd_fsm_ns <= RD_IDLE;
          end

      endcase
    end

    // Next State signals.
  always_comb
    begin

      axi_m0_arvalid    <= 1'b0;
      update_dev_num_pl <= 1'b0;

      unique case ( ddr_rd_fsm_cs )

      // Wait until DDR is initialised.
        RD_DDR_INIT :
          begin

          end

      // Wait until start_serving_device_pl is communicated by rd_dev_sel_fsm
        RD_IDLE :
          begin

          end

      // Wait for read address ready and generate read address valid
        RD_ADDR :
          begin
            axi_m0_arvalid  <= 1'b1;
          end

      // Start reading the data
        RD_DATA :
          begin

          end

      // Writing to slfifo   ( redundant state will remove later )
        WR_SLFIFO_DATA :
          begin

          end

      // Updating the device number
         UPDATE_DEV_NUM  :
          begin
            update_dev_num_pl  <= 1'b1;
          end


      endcase
    end

   // M0 Address read id
  assign axi_m0_arid_o = 8'd0;

   // M0 Read Burst Size
  assign axi_m0_arsize_o = AXI_M0_ARSIZE;

  // M0 Read Burst Length
  assign axi_m0_arlen_o  = AXI_M0_ARLEN;

  // M0 Read Burst Type
  assign axi_m0_arburst_o = AXI_M0_ARBURST;

  // M0 Read Lock
  assign axi_m0_arlock_o = 1'd0;

  // M0 Read ready
  assign axi_m0_rready_o = 1'b1;

// ------------------------------------------
//
//  Registering the outputs
//
// ------------------------------------------

  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin

          axi_m0_arvalid_o        <= 1'b0;
          axi_m0_araddr_o         <= 33'b0;
          update_dev_num_o        <= 1'b0;
          sel_rd_frame_buf_for_addr <= '0;        // 1FF delay for sel_rd_frame_buf, used for updating read address
        end
      else
        begin
          axi_m0_arvalid_o        <= axi_m0_arvalid;
          axi_m0_araddr_o         <= fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_addr;
          update_dev_num_o        <= update_dev_num_pl;
          sel_rd_frame_buf_for_addr[fbh_rd_fsm_sel_device_num_i] <= fbh_rd_dsf_flags_arr_i[fbh_rd_fsm_sel_device_num_i].sel_rd_frame_buf;

        end
    end



// Read Address generation
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_addr <= 32'h0000_0000;
        end
      else if ( sel_d_reset_or_stop_stream_req_axi_clk_i[fbh_rd_fsm_sel_device_num_i] )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_addr <= 32'h0000_0000;
        end
      else if ( sel_rd_frame_buf_for_addr[fbh_rd_fsm_sel_device_num_i] )  // 1FF delay for sel_rd_frame_buf, used for updating read address
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_addr <= ( ( FIRST_BUFFER_START_ADDR_I + FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I*fbh_rd_fsm_sel_device_num_i ) +
                                                                                    ( BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I*(fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].rd_frame_buf ) ) );
        end
      else if ( fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_complete )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_addr <= fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_addr + AXI_M0_RD_ADDR_INCR_FACTOR;
        end
    end


// sel_rd_buf_flag used for indicating first time sel_rd_frame_buf for every device
// Used for initialization rd_frame_buf as wr_frame_buf
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          sel_buf_rd_flag[fbh_rd_fsm_sel_device_num_i] <= '0;
        end
      else if ( sel_d_reset_or_stop_stream_req_axi_clk_i[fbh_rd_fsm_sel_device_num_i] )
        begin
          sel_buf_rd_flag[fbh_rd_fsm_sel_device_num_i] <= '0;
        end
      else if ( fbh_rd_dsf_flags_arr_i[fbh_rd_fsm_sel_device_num_i].sel_rd_frame_buf )
        begin
          sel_buf_rd_flag[fbh_rd_fsm_sel_device_num_i] <= 1'b1;
        end
    end

  // Read Frame Buffer
  always @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].rd_frame_buf <= 'h0;
        end
      else if ( sel_d_reset_or_stop_stream_req_axi_clk_i[fbh_rd_fsm_sel_device_num_i] )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].rd_frame_buf <= 'h0;
        end
      else if ( ( fbh_rd_dsf_flags_arr_i[fbh_rd_fsm_sel_device_num_i].sel_rd_frame_buf ) &
                ( sel_buf_rd_flag[fbh_rd_fsm_sel_device_num_i] == 1'b0 ) )                  // Used for initialization rd_frame_buf as wr_frame_buf
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].rd_frame_buf <= ( ( fbh_wr_addr_nd_ctrl_i[fbh_rd_fsm_sel_device_num_i].wr_frame_buf ) % NO_OF_DDR_BUFFERS ) ;
        end
      else if ( fbh_rd_dsf_flags_arr_i[fbh_rd_fsm_sel_device_num_i].sel_rd_frame_buf )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].rd_frame_buf <= ( ( fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].rd_frame_buf + 1'b1 ) % NO_OF_DDR_BUFFERS ) ;
        end
    end

  // DDR Memory Read Complete
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_complete <= 1'b0;
        end
      else
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_complete <= ( ( axi_m0_rvalid_i ) & ( axi_m0_rready_o ) );
        end
    end

  // All read transactions are completed.
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_burst_complete <= 1'b0;
        end
      else
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_burst_complete <= ( ( axi_m0_rvalid_i ) & ( axi_m0_rready_o ) & ( axi_m0_rlast_i ) );
        end
    end

  // DDR Memory Read Enable
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_en <= 1'b0;
        end
      else if ( sel_d_reset_or_stop_stream_req_axi_clk_i[fbh_rd_fsm_sel_device_num_i] )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_en <= 1'b0;
        end
      else if ( fbh_rd_dsf_flags_arr_i[fbh_rd_fsm_sel_device_num_i].bufr_already_selected /*ddr_rd_start*/ == 1'b1 )
        begin
          if ( fbh_wr_addr_nd_ctrl_i[fbh_rd_fsm_sel_device_num_i].wr_frame_buf == fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].rd_frame_buf )   // If write frame buffer and read frame buffer are same then
            begin                                                                                                                                       // in case of RGB444 make ddr_mem_rd_en zero to maintain gap of 1 buffer otherwise maintain gap of 1 burst.
              if ( ( ( device_status_arr_axi_clk_i[fbh_rd_fsm_sel_device_num_i].hdmi_mode_rgb == 1'b0 ) & common_reg_info_i.uvc_stream_mode_en ) |
                 ( common_reg_info_i.uvc_stream_mode_en == 1'b0 ) )
            begin
              fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_en <= ( ( ( fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_addr + DDR_BUFR_RD_CONSTANT ) <= fbh_wr_addr_nd_ctrl_i[fbh_rd_fsm_sel_device_num_i].ddr_mem_y_data_bufr_wr_addr ) & ( fbh_wr_addr_nd_ctrl_i[fbh_rd_fsm_sel_device_num_i].ddr_mem_y_data_bufr_wr_addr >= DDR_BUFR_RD_CONSTANT ) );
            end
          else
            begin
                  fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_en <= 1'b0;
                end
            end
          else
            begin
              fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_en <= 1'b1;
            end
        end
      else
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].ddr_mem_rd_en <= 1'b0;
        end
    end

  // Counting read words from DDR
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].no_of_ddr_rd_words <= 32'b0;
        end
      else if (
                ( fbh_rd_dsf_flags_arr_i[fbh_rd_fsm_sel_device_num_i].sel_rd_frame_buf ) |
                ( sel_d_reset_or_stop_stream_req_axi_clk_i[fbh_rd_fsm_sel_device_num_i] )
              )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].no_of_ddr_rd_words <= 32'b0;
        end
      else if ( slfifo_wr_ctrl_req_o[fbh_rd_fsm_sel_device_num_i].wr_en )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].no_of_ddr_rd_words <= fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].no_of_ddr_rd_words + INCR_DDR_RD_COUNT;
        end
    end

  // Full frame is read.
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].full_frame_rd_completed_o <= 1'b1;
        end
      else if ( (sel_d_reset_or_stop_stream_req_axi_clk_i[fbh_rd_fsm_sel_device_num_i]) |
                ( fbh_rd_dsf_flags_arr_i[fbh_rd_fsm_sel_device_num_i].sel_rd_frame_buf )
              )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].full_frame_rd_completed_o <= 1'b0;
        end
      else if ( ( fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].no_of_ddr_rd_words == ( frame_size_in_bytes_i[fbh_rd_fsm_sel_device_num_i] - ( 2 ** AXI_M0_ARSIZE ) ) ) &
                ( slfifo_wr_ctrl_req_o[fbh_rd_fsm_sel_device_num_i].wr_en )
              )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].full_frame_rd_completed_o <= 1'b1;
        end
    end

  // Full Burst is read.
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].full_burst_rd_completed_o <= 1'b0;
        end
      else if ( (sel_d_reset_or_stop_stream_req_axi_clk_i[fbh_rd_fsm_sel_device_num_i]) |
                ( fbh_rd_dsf_flags_arr_i[fbh_rd_fsm_sel_device_num_i].sel_rd_frame_buf )
              )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].full_burst_rd_completed_o <= 1'b0;
        end
      else if ( ( fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].no_of_ddr_rd_words == ( AXI_M0_XFER_LEN_IN_BYTES - ( 2 ** AXI_M0_ARSIZE ) ) ) &
                ( slfifo_wr_ctrl_req_o[fbh_rd_fsm_sel_device_num_i].wr_en )
              )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].full_burst_rd_completed_o <= 1'b1;
        end
    end



 // Slave FIFO Write Request
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          slfifo_wr_ctrl_req_o[fbh_rd_fsm_sel_device_num_i].wr_en <= 1'b0;
        end
      else
        begin
          slfifo_wr_ctrl_req_o[fbh_rd_fsm_sel_device_num_i].wr_en <= ( ( axi_m0_rvalid_i ) & ( axi_m0_rready_o ) );
        end
    end

  // Which word of read data to be stored? LSW or MSW?
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].save_rdata_msw <= 1'b0;
        end
      else if ( ( axi_m0_rvalid_i ) & ( axi_m0_rready_o ) )
        begin
          fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].save_rdata_msw <= ~( fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].save_rdata_msw );
        end
    end


  // Slave FIFO Write Data
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          slfifo_wr_ctrl_req_o[fbh_rd_fsm_sel_device_num_i].wr_data <= 256'd0;
        end
      else if ( fbh_rd_states_nd_ctrl_o[fbh_rd_fsm_sel_device_num_i].save_rdata_msw )
        begin
          slfifo_wr_ctrl_req_o[fbh_rd_fsm_sel_device_num_i].wr_data <= axi_m0_rdata_i[511:256];
        end
      else
        begin
          slfifo_wr_ctrl_req_o[fbh_rd_fsm_sel_device_num_i].wr_data <= axi_m0_rdata_i[255:0];
        end
    end


endmodule