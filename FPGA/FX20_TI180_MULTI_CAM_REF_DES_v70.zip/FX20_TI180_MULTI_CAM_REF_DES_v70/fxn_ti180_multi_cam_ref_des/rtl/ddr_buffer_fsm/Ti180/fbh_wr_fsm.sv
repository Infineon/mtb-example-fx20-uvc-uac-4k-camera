//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
//This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:      FX10/20 Design
// Module Name:      fbh_wr_fsm
// Target Devices:   Ti180
//
// Description: This module is responsible for writing image/frame
//              data into/from DDR4 memory. In DDR4, there are couple of buffers
//              which act as a ping pong and each of it can store a full 4K frame.
//              Efinix Ti180 has Hard DDR4 Controller IP which supports AXI4
//              interface. Hence, in this module, AXI4 Master has been implemented
//              to access AXI slave of Hard IP.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


`define COUNTER_DEBUG

// Timescale
`timescale 1 ns / 100 ps

module fbh_wr_fsm
 #
 (
  // HDMI/Test Pattern Data Width
  parameter Y_DATA_FIFO_WR_DATA_WIDTH_I = 64,

  // AXI Master Write Channel Data Width
  parameter AXI_M0_WR_DATA_WIDTH_IN_BITS_I = 512,

  // AXI Master Read Channel Data Width
  parameter AXI_M0_RD_DATA_WIDTH_IN_BITS_I = 256,

  // FIRST_BUFFER_START_ADDR
  parameter FIRST_BUFFER_START_ADDR_I = 32'h0000_0000,

  // BUFFER_START_ADDR_DIFF_FOR_SAME_DEV
  parameter BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I = 32'h03F4_8000,

  // FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV
  parameter FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I = 32'h1000_0000,

  // Counter datawidth
  parameter COUNTER_DATAWIDTH_I = 32,

   // No. of devices/ FIFOs needed
  parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
  parameter SEL_DEV_NUM_BITS_I  = 3,

  // Y Data FIFO Depth
  parameter Y_DATA_FIFO_DEPTH_IN_WORDS_I = 8192,

  // AXI Master Burst Size
  parameter MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I = 3840

 )
 (
  // Output Device Specific
  output logic                                                   y_data_bufr_almost_empty_o,
  output logic                                                   y_data_bufr_rst_busy_o,
  output logic                                                   ddr_mem_wr_burst_complete_o,
  output logic                                                   ddr_mem_wr_burst_resp_complete_o,
  output logic                                                   full_frame_wr_completed_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                     bufr_already_selected_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                     first_bufr_selected_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                     full_frame_wr_completed_arr_o,
  output  fbh_wr_addr_nd_ctrl_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] fbh_wr_addr_nd_ctrl_o,
  output logic                                                   update_wr_dev_num_o,


  // Debug purpose
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                     y_data_bufr_full_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                     y_data_bufr_empty_o,

  // Master Write Address Channel
  input                                                        axi_m0_awready_i,
  output logic [32:0]                                          axi_m0_awaddr_o,
  output logic                                                 axi_m0_awvalid_o,
  output logic [ 1:0]                                          axi_m0_awburst_o,
  output       [ 5:0]                                          axi_m0_awid_o,
  output logic [ 7:0]                                          axi_m0_awlen_o,
  output                                                       axi_m0_awlock_o,
  output logic [ 2:0]                                          axi_m0_awsize_o,

  // Master Write Data Channel
  input                                                        axi_m0_wready_i,
  output logic                                                 axi_m0_wlast_o,
  output logic                                                 axi_m0_wvalid_o,
  output logic [(AXI_M0_WR_DATA_WIDTH_IN_BITS_I-1):0]          axi_m0_wdata_o,
  output       [((AXI_M0_WR_DATA_WIDTH_IN_BITS_I/8)-1):0]      axi_m0_wstrb_o,

  // Master Write Response Channel
  input        [ 5:0]                                          axi_m0_bid_i,
  input                                                        axi_m0_bvalid_i,
  output logic                                                 axi_m0_bready_o,

  // Input clock and reset
  input                                                        hdmi_clk,
  input                                                        axi_clk,
  input                                                        hdmi_clk_reset_n,
  input                                                        axi_clk_reset_n,

  // Input data and controls
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]                       sel_vsync_axi_clk_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]                       sel_vsync_hdmi_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]                       sel_vsync_hdmi_pe_pl_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]                       sel_vsync_hdmi_ne_pl_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]                       sel_hsync_hdmi_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0] [(Y_DATA_FIFO_WR_DATA_WIDTH_I-1):0] sel_vid_data_i,
  input dev_reg_info_st_t           [(NO_OF_SUPPORTED_DEV_I-1):0]        dev_reg_info_st_arr_axi_clk_i,
  input dev_reg_info_st_t           [(NO_OF_SUPPORTED_DEV_I-1):0]        dev_reg_info_st_arr_gpif_clk_i,
  input dev_reg_info_st_t           [(NO_OF_SUPPORTED_DEV_I-1):0]        dev_reg_info_st_arr_hdmi_clk_i,
  input fbh_rd_states_nd_ctrl_st_t  [(NO_OF_SUPPORTED_DEV_I-1):0]        fbh_rd_states_nd_ctrl_i,
  input fbh_rd_dsf_flags_st_t       [(NO_OF_SUPPORTED_DEV_I-1):0]        fbh_rd_dsf_flags_arr_i,
  input common_reg_info_st_t        common_reg_info_i,



  input      [(NO_OF_SUPPORTED_DEV_I-1):0]                       ddr_wr_xfer_axi_clk_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]                       ddr_wr_xfer_hdmi_clk_arr_i,

  // Device based signals
  input      [(NO_OF_SUPPORTED_DEV_I-1):0] [31:0]              frame_size_info_i,
  input                                                        yuv_420_en_axi_clk_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]                     sel_d_reset_or_hdmi_src_connect_axi_clk_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]                     full_frame_wr_completed_hdmi_clk_arr_i,
  input      [(SEL_DEV_NUM_BITS_I-1):0]                        fbh_wr_fsm_sel_device_num_i,            // Communicated by fbh_wr_dev_sel_fsm
  input                                                        fbh_wr_fsm_start_serving_device_pl_i,
  input                                                        sel_next_bufr_i,
  input                                                        first_sel_next_bufr_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0] [31:0]              wr_starting_address_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0] [15:0]              no_of_bytes_in_single_line_i,

  // DDR init related signals
  input                                                        ddr_init_done_i

 );


// ------------------------------------------
//
// Local   Parameters
//
// ------------------------------------------

  // Number of bytes in a single transfer
  // AXI supports up to 4K byte. Hence, it is 3840.
  // For 4K, it is half line. For 1080p, it's full line.
  localparam AXI_M0_XFER_LEN_IN_BYTES = MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I;

  // Y data FIFO WRITE data width in byte
  localparam Y_DATA_FIFO_WR_DATA_WIDTH_IN_BYTES = ( Y_DATA_FIFO_WR_DATA_WIDTH_I / 8 );

  // Y data FIFO read data width in bits
  localparam Y_DATA_FIFO_RD_DATA_WIDTH  = AXI_M0_WR_DATA_WIDTH_IN_BITS_I;

  // AXI Master 0 write data width in bytes
  localparam AXI_M0_WR_DATA_WIDTH_IN_BYTES  = ( AXI_M0_WR_DATA_WIDTH_IN_BITS_I / 8 );

  // Total write burst length
  localparam AXI_M0_WR_BURST_LEN = ( AXI_M0_XFER_LEN_IN_BYTES / AXI_M0_WR_DATA_WIDTH_IN_BYTES );

  // DDR AXI M0 Increment Factor in bytes
  localparam AXI_M0_WR_ADDR_INCR_FACTOR = ( AXI_M0_WR_BURST_LEN * AXI_M0_WR_DATA_WIDTH_IN_BYTES );

  // DDR AXI Parameters
  // ASIZE for Write Side 512 bits = 64 bytes
  localparam [2:0] AXI_M0_AWSIZE  = 3'd6;

  // Write and Read Burst Size
  localparam [7:0] AXI_M0_AWLEN   = (AXI_M0_WR_BURST_LEN - 1);

  // Burst type = Incremental
  localparam [1:0] AXI_M0_AWBURST = 2'd1;

  // Counter Increment Factor
  localparam [7:0] INCR_Y_DATA_FIFO_WR_COUNT = ( Y_DATA_FIFO_WR_DATA_WIDTH_I / 8 );
  localparam [7:0] INCR_Y_DATA_FIFO_RD_COUNT = ( Y_DATA_FIFO_RD_DATA_WIDTH / 8 );
  localparam [7:0] INCR_DDR_WR_COUNT         = ( AXI_M0_WR_DATA_WIDTH_IN_BITS_I / 8 );

  localparam RD_DATA_WORDS_DATAWIDTH  = 4'd8;


  // No of write States
  localparam NO_OF_WR_FSM_STATES = 5'd8;

  // Write FSM states
  enum logic [(NO_OF_WR_FSM_STATES-1):0] {
    IDLE                                = 8'h1,
    RD_Y_DATA_BUFR                      = 8'h2,
    WR_Y_ADDR                           = 8'h4,
    WR_Y_DATA                           = 8'h8,
    POST_WR_Y_DATA                      = 8'h10,
    UPDATE_WR_DEV_NUM                   = 8'h20,
    DDR_INIT                            = 8'h40
  } ddr_wr_fsm_cs, ddr_wr_fsm_ns;


// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              vsync_axi_clk_pe_pl;

  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              y_data_bufr_wr_en;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              y_data_bufr_reset;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              y_data_bufr_rd_req;
//  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              y_data_bufr_full;
//  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              y_data_bufr_empty;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              y_data_bufr_almost_empty;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              y_data_bufr_rst_busy;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              y_data_bufr_rd_valid;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              y_data_bufr_overflow;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              y_data_bufr_underflow;
  logic  [ 7:0]                                     y_data_bufr_wr_count;
  logic                                             rd_data_words_count_en;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              rd_data_words_count_en_arr;

  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              sel_next_bufr_arr;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              sel_next_bufr_arr_f1;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              sel_next_bufr_flag_arr;
  logic                                             axi_m_busy;
  logic                                             axi_wr_m_busy;
  logic                                             rd_y_data_bufr;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              rd_y_data_bufr_arr;
  logic                                             sel_y_data_bufr_wr_addr;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              sel_y_data_bufr_wr_addr_arr;
//  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              full_frame_wr_completed_arr_o;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              full_frame_wr_completion_reset;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              full_burst_wr_completed;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              full_burst_wr_completed_pl;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              first_sel_next_bufr_arr;
//  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              ddr_wr_xfer_axi_clk_arr_o;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              yuv_420_en_axi_clk_arr;

  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              first_bufr_selected_f1;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              first_bufr_selected_f2;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              first_bufr_selected_pe_pl;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]              first_bufr_selected_ne_pl;
  logic                                             update_wr_dev_num_pl;

  logic                                             axi_m0_awvalid;
  logic                                             axi_m0_wvalid;
  logic                                             axi_m0_wlast;
  logic                                             axi_m0_bready;


  logic  [(NO_OF_SUPPORTED_DEV_I -1):0] [31:0]                               vsync_axi_clk_sr;
  logic  [(NO_OF_SUPPORTED_DEV_I -1):0] [(Y_DATA_FIFO_WR_DATA_WIDTH_I-1):0]  y_data_bufr_wr_data;
  logic  [(NO_OF_SUPPORTED_DEV_I -1):0] [15:0]                               y_data_bufr_wr_datacount;
  logic  [(NO_OF_SUPPORTED_DEV_I -1):0] [(COUNTER_DATAWIDTH_I-1):0]          no_of_wr_words_in_y_data_bufr;
  logic  [(NO_OF_SUPPORTED_DEV_I -1):0] [(Y_DATA_FIFO_RD_DATA_WIDTH-1):0]    y_data_bufr_rd_data;
  logic  [(NO_OF_SUPPORTED_DEV_I -1):0] [15:0]                               y_data_bufr_rd_datacount;
  logic  [(NO_OF_SUPPORTED_DEV_I -1):0] [(COUNTER_DATAWIDTH_I-1):0]          no_of_rd_bytes_from_y_data_bufr;
  logic  [(NO_OF_SUPPORTED_DEV_I -1):0] [(RD_DATA_WORDS_DATAWIDTH-1):0]      no_of_y_data_bufr_rd_data_words;
  logic  [(NO_OF_SUPPORTED_DEV_I -1):0] [(COUNTER_DATAWIDTH_I-1):0]          no_of_ddr_wr_words;
  logic  [(NO_OF_SUPPORTED_DEV_I -1):0] [31:0]                               ddr_mem_y_data_bufr_wr_addr;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0]  [15:0] mem_wr_counter;



// ----------------------------------------------------
//
// Intermediate Y FIFO and other signals for DDR write
// Generated based on no. of devices
//
// ---------------------------------------------------

 genvar i;

 generate
  for (i = 0; i < NO_OF_SUPPORTED_DEV_I; i= i+1)
   begin : gen_fifos

   // Choosing Write FIFO datawidth and counters datawidth based on no. of devices

        localparam START_FIFO_WR_DATAWIDTH     = Y_DATA_FIFO_WR_DATA_WIDTH_I * i;
        localparam END_FIFO_WR_DATAWIDTH       = Y_DATA_FIFO_WR_DATA_WIDTH_I * (i+1) -1;

        localparam START_FIFO_COUNTER_DATAWIDTH = COUNTER_DATAWIDTH_I * i;
        localparam END_FIFO_COUNTER_DATAWIDTH   = COUNTER_DATAWIDTH_I * (i+1) -1;


// Generating YFIFO based on no. of devices

y_data_fifo
 #
 (
  // Parameters
  .WR_DATA_WIDTH_IN_BITS_I                     ( Y_DATA_FIFO_WR_DATA_WIDTH_I ),
  .RD_DATA_WIDTH_IN_BITS_I                     ( AXI_M0_WR_DATA_WIDTH_IN_BITS_I ),
  .FIFO_DEPTH_IN_WORDS_I                       ( Y_DATA_FIFO_DEPTH_IN_WORDS_I ),
  .MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I  ( AXI_M0_XFER_LEN_IN_BYTES )
 )
  y_data_bufr
      (
        .almost_full_o ( ),
        .full_o         ( y_data_bufr_full_o[i] ),
        .overflow_o     ( y_data_bufr_overflow[i] ),
        .wr_ack_o       ( ),
        .empty_o        ( y_data_bufr_empty_o[i] ),
        .almost_empty_o ( ),
        .prog_empty_o   ( y_data_bufr_almost_empty[i] ),
        .underflow_o    ( y_data_bufr_underflow[i] ),
        .rd_valid_o     ( y_data_bufr_rd_valid[i] ),
        .rdata          ( y_data_bufr_rd_data[i] ),
        .wr_clk_i       ( hdmi_clk ),
        .rd_clk_i       ( axi_clk ),
        .wr_en_i        ( y_data_bufr_wr_en[i] ),
        .rd_en_i        ( y_data_bufr_rd_req[i] ),
        .wdata          ( y_data_bufr_wr_data[i] ),
        .wr_datacount_o ( y_data_bufr_wr_datacount[i] ),
        .rd_datacount_o ( y_data_bufr_rd_datacount[i] ),
        .a_rst_i        ( y_data_bufr_reset[i] ),
        .rst_busy       ( y_data_bufr_rst_busy[i] )
       );


// -------------------------------------
//
// FIFO Write Enable and Write Data logic
//
// -------------------------------------

  // Write Enable
  always_ff @( posedge hdmi_clk )
    begin
      if ( ~hdmi_clk_reset_n )
        begin
          y_data_bufr_wr_en[i] <= 1'b0;
        end
      else
        begin
          y_data_bufr_wr_en[i] <= sel_hsync_hdmi_i[i];
        end
    end


  // Write Data
  always_ff @( posedge hdmi_clk )
    begin
      if ( ~hdmi_clk_reset_n )
        begin
          y_data_bufr_wr_data[i] <= 'h0;
        end
      else
        begin
          y_data_bufr_wr_data[i]  <= sel_vid_data_i[i];
        end
    end

// -------------------------------------
//
// FIFO Reset logic
//
// -------------------------------------

 // FIFO Reset
  always_ff @( posedge hdmi_clk )
    begin
      if ( ~hdmi_clk_reset_n )
        begin
          y_data_bufr_reset[i] <= 1'b1;
        end
      else
        begin
          // y_data_bufr_reset[i] <= ( full_frame_wr_completed_hdmi_clk_arr_i[i] | !hdmi_src_connect_hdmi_clk_i[i] | sel_next_bufr[i]  );
           y_data_bufr_reset[i] <= ( ( full_frame_wr_completed_hdmi_clk_arr_i[i] /*full_frame_wr_completion_reset[i]*/ ) |
                                     ( ddr_wr_xfer_hdmi_clk_arr_i[i] == 1'b0 )  |
                                     ( first_bufr_selected_pe_pl[i] ) |
                                     ( dev_reg_info_st_arr_hdmi_clk_i[i].hdmi_source_connection == 1'b0 )
                                    );
        end
    end
  
 
// Full frame reset generation based on vsync    
   always_ff @( posedge hdmi_clk )
     begin
       if ( ~hdmi_clk_reset_n )
         begin
           full_frame_wr_completion_reset[i] <= 'h0;
         end
      else if  ( sel_vsync_hdmi_i[i] == 0 )
         begin
          full_frame_wr_completion_reset[i] <= full_frame_wr_completed_hdmi_clk_arr_i[i];
         end
     end
     


// -----------------------------------------------
//
// Rising and Falling Edge of first sel next bufr
//
// -----------------------------------------------

always_ff @ ( posedge axi_clk )
  begin
    if ( !axi_clk_reset_n )
      begin
        first_bufr_selected_f1[i]    <= 1'b0;
        first_bufr_selected_f2[i]    <= 1'b0;
        first_bufr_selected_pe_pl[i] <= 1'b0;
        first_bufr_selected_ne_pl[i] <= 1'b0;
      end
    else
      begin
        first_bufr_selected_f1[i]    <= first_bufr_selected_o[i];
        first_bufr_selected_f2[i]    <= first_bufr_selected_f1[i];
        first_bufr_selected_pe_pl[i] <= (first_bufr_selected_f1[i] & ~first_bufr_selected_f2[i]);
        first_bufr_selected_ne_pl[i] <= (~first_bufr_selected_f1[i] & first_bufr_selected_f2[i]);
      end
  end


// --------------------------------------
//
// Debug Counter
//
// --------------------------------------


`ifdef COUNTER_DEBUG

// Write word counter for yfifo
   always_ff @( posedge hdmi_clk )
     begin
       if ( ~hdmi_clk_reset_n )
         begin
           no_of_wr_words_in_y_data_bufr[i] <= 'h0;
         end
     else if ( ( sel_vsync_hdmi_i[i] == 1'b0 ) & ( y_data_bufr_wr_en[i] == 1'b0 ) )
       begin
         no_of_wr_words_in_y_data_bufr[i] <= 32'd0;
       end
       else if ( y_data_bufr_wr_en[i] )
         begin
           no_of_wr_words_in_y_data_bufr[i] <= no_of_wr_words_in_y_data_bufr[i] + INCR_Y_DATA_FIFO_WR_COUNT;
         end
     end


// Read word counter for yfifo
   always_ff @( posedge axi_clk )
     begin
       if ( ~axi_clk_reset_n )
         begin
           no_of_rd_bytes_from_y_data_bufr[i] <= 'h0;
         end
     else if ( sel_next_bufr_arr[i] )
       begin
         no_of_rd_bytes_from_y_data_bufr[i] <= 32'd0;
       end
     else if ( y_data_bufr_rd_req[i] )
       begin
         no_of_rd_bytes_from_y_data_bufr[i] <= no_of_rd_bytes_from_y_data_bufr[i] + INCR_Y_DATA_FIFO_RD_COUNT;
       end
     end

`endif

// Counter for read data words from FIFO
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          no_of_y_data_bufr_rd_data_words[i] <= 8'd0;
        end
      else if ( ( no_of_y_data_bufr_rd_data_words[i] == AXI_M0_AWLEN ) & ( axi_m0_wready_i ) )
        begin
          no_of_y_data_bufr_rd_data_words[i] <= 8'd0;
        end
      else if ( ( rd_y_data_bufr_arr[i] ) |
                ( ( rd_data_words_count_en_arr[i] ) & ( axi_m0_wready_i ) & ( no_of_y_data_bufr_rd_data_words[i] > 1'b0 ) )
              )
        begin
          no_of_y_data_bufr_rd_data_words[i] <= no_of_y_data_bufr_rd_data_words[i] + 1'b1;
        end
    end

// Y FIFO read request
  assign y_data_bufr_rd_req[i] = ( ( rd_y_data_bufr_arr[i] ) | ( rd_data_words_count_en_arr[i] & axi_m0_wready_i & ( no_of_y_data_bufr_rd_data_words[i] > 1'b0 ) ) );


// --------------------------------------
//
// Switching logic to select
// between Write frame buffer and
// Read frame buffer
//
// --------------------------------------

  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf <= 'h0;
        end
      else if ( ( ddr_wr_xfer_axi_clk_i[i] == 1'b0 ) |
                ( sel_d_reset_or_hdmi_src_connect_axi_clk_i[i] == 1'b1 )
              )
        begin
          fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf <= 'h0;
        end
      else if ( sel_next_bufr_arr[i] & ( sel_next_bufr_flag_arr[i] == 1'b0 ) )
        begin
          fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf <= fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf;
        end
      else if ( sel_next_bufr_arr[i] )
        begin
          if ( fbh_rd_dsf_flags_arr_i[i].bufr_already_selected/*ddr_rd_start*/ & ( ( ( fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf + 1'b1 ) % NO_OF_DDR_BUFFERS ) == fbh_rd_states_nd_ctrl_i[i].rd_frame_buf ) )      // If both wr frame buf and read frame buf are same then skip that buffer and write to next available buffer.
            begin
              case (fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf)
                NO_OF_DDR_BUFFERS: fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf <= 'h0;
                    default: fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf <= ( ( fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf ) % NO_OF_DDR_BUFFERS ) ;
              endcase
            end
          else
            begin
              case (fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf)
                NO_OF_DDR_BUFFERS: fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf <= 'h0;
                    default: fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf <= ( ( fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf + 1'b1 ) % NO_OF_DDR_BUFFERS );
              endcase
            end
        end
    end

// --------------------------------------
//
// Counter to count number of
// write frames
//
// --------------------------------------

// 1 FFs delay for sel_next_bufr_arr
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          sel_next_bufr_arr_f1[i] <=  1'b0;
        end
      else
        begin
          sel_next_bufr_arr_f1[i] <= sel_next_bufr_arr[i];
        end
    end

// sel_next_bufr_flag_arr used for indicating first time sel_next_bufr_arr for every device
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          sel_next_bufr_flag_arr[i] <= '0;
        end
      else if ( ( ddr_wr_xfer_axi_clk_i[i] == 1'b0 ) |
                ( sel_d_reset_or_hdmi_src_connect_axi_clk_i[i] == 1'b1 )
              )
        begin
          sel_next_bufr_flag_arr[i] <= '0;
        end
      else if ( sel_next_bufr_arr[i] )
        begin
          sel_next_bufr_flag_arr[i] <= 1'b1;
        end
    end

/*
// Full frame completed logic
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          full_frame_wr_completed_arr_o[i] <= 2'b0;
        end
      else if ( yuv_420_en_axi_clk_arr[i] )
        begin
          full_frame_wr_completed_arr_o[i] <= ( no_of_ddr_wr_words[i] == frame_size_info_i[i] ) ;
        end
      else
        begin
//          full_frame_wr_completed_arr_o[i] <= ( ( ( no_of_ddr_wr_words[i] == frame_size_info_i[i] ) ) & ( y_data_bufr_empty_o[i] ) );
          full_frame_wr_completed_arr_o[i] <=  ( no_of_ddr_wr_words[i] == frame_size_info_i[i] ) ;
        end
    end
*/


// Write Address generation logic

/*
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          ddr_mem_y_data_bufr_wr_addr[i] <= 32'd0;
        end
      else if ( ( ddr_wr_xfer_axi_clk_i[i] == 1'b0 ) |
                ( sel_d_reset_or_hdmi_src_connect_axi_clk_i[i] == 1'b1 )
              )
        begin
          ddr_mem_y_data_bufr_wr_addr[i] <= 32'd0;
        end
      else if ( sel_next_bufr_arr_f1[i] )
        begin
          ddr_mem_y_data_bufr_wr_addr[i] <= ( ( FIRST_BUFFER_START_ADDR_I + FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I*i ) +
                                              ( BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I*(fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf ) ) );
        end
      else if ( ddr_mem_wr_burst_complete_o & ( fbh_wr_fsm_sel_device_num_i == i ) )
        begin
          ddr_mem_y_data_bufr_wr_addr[i] <= ddr_mem_y_data_bufr_wr_addr[i] + AXI_M0_WR_ADDR_INCR_FACTOR;
        end
      else if ( full_frame_wr_completed_arr_o[i] & ( fbh_wr_fsm_sel_device_num_i == i ) )
        begin
          ddr_mem_y_data_bufr_wr_addr[i] <=  32'h3FFF_FFFF;
        end
    end
*/


  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          ddr_mem_y_data_bufr_wr_addr[i] <= 32'd0;
        end
      else if ( ( ddr_wr_xfer_axi_clk_i[i] == 1'b0 ) |
                ( sel_d_reset_or_hdmi_src_connect_axi_clk_i[i] == 1'b1 )
              )
        begin
          ddr_mem_y_data_bufr_wr_addr[i] <= 32'd0;
        end
      else if ( sel_next_bufr_arr_f1[i] )
        begin
          if ( ( ( dev_reg_info_st_arr_axi_clk_i[i].hdmi_mode_rgb == 1'b0 ) & common_reg_info_i.uvc_stream_mode_en ) |
                 ( common_reg_info_i.uvc_stream_mode_en == 1'b0 ) )
            begin
          ddr_mem_y_data_bufr_wr_addr[i] <= ( ( FIRST_BUFFER_START_ADDR_I + FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I*i ) +
                                              ( BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I*(fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf ) ) );
        end
         else
            begin
          ddr_mem_y_data_bufr_wr_addr[i] <= ( ( wr_starting_address_i[i] + FIRST_BUFFER_START_ADDR_I + FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I*i ) +
                                              ( BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I*(fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf ) ) );
           end
       end

      else if ( ( mem_wr_counter[i] >= ( no_of_bytes_in_single_line_i[i] ) ) &
              ( ( dev_reg_info_st_arr_axi_clk_i[i].hdmi_mode_rgb & common_reg_info_i.uvc_stream_mode_en ) ) &
                ( fbh_wr_fsm_sel_device_num_i == i ) )
        begin
          ddr_mem_y_data_bufr_wr_addr[i] <= ddr_mem_y_data_bufr_wr_addr[i] - ( 2*no_of_bytes_in_single_line_i[i] );
        end

      else if ( ddr_mem_wr_burst_complete_o & ( fbh_wr_fsm_sel_device_num_i == i ) )
        begin
          ddr_mem_y_data_bufr_wr_addr[i] <= ddr_mem_y_data_bufr_wr_addr[i] + AXI_M0_WR_ADDR_INCR_FACTOR;
        end
      else if ( full_frame_wr_completed_arr_o[i] & ( fbh_wr_fsm_sel_device_num_i == i ) )
        begin
          ddr_mem_y_data_bufr_wr_addr[i] <=  32'h3FFF_FFFF;
        end
    end

// For changing write address
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          mem_wr_counter[i] <= '0;
        end
      else if ( ( ( ddr_wr_xfer_axi_clk_i[i] == 1'b0 ) |
                ( sel_d_reset_or_hdmi_src_connect_axi_clk_i[i] == 1'b1 ) |
                ( mem_wr_counter[i] >= ( no_of_bytes_in_single_line_i[i] ) ) ) &
                ( fbh_wr_fsm_sel_device_num_i == i )
              )
        begin
          mem_wr_counter[i] <= '0;
        end
      else if ( ddr_mem_wr_burst_complete_o & ( fbh_wr_fsm_sel_device_num_i == i ) )
        begin
          mem_wr_counter[i] <= mem_wr_counter[i] + AXI_M0_WR_ADDR_INCR_FACTOR;
        end
    end

//  Logic for AXI write address to communicate with read based on no. of devices
//  Act same as awaddr
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          fbh_wr_addr_nd_ctrl_o[i].ddr_mem_y_data_bufr_wr_addr  <= 32'b0;
        end
      else if ( ( ddr_wr_xfer_axi_clk_i[i] == 1'b0 ) |
                ( sel_d_reset_or_hdmi_src_connect_axi_clk_i[i] == 1'b1 )
              )
        begin
          fbh_wr_addr_nd_ctrl_o[i].ddr_mem_y_data_bufr_wr_addr <= 32'd0;
        end
      else if ( sel_next_bufr_arr_f1[i] )
        begin
          if ( ( ( dev_reg_info_st_arr_axi_clk_i[i].hdmi_mode_rgb == 1'b0 ) & common_reg_info_i.uvc_stream_mode_en ) |
                 ( common_reg_info_i.uvc_stream_mode_en == 1'b0 ) )
            begin
              fbh_wr_addr_nd_ctrl_o[i].ddr_mem_y_data_bufr_wr_addr <= ( ( FIRST_BUFFER_START_ADDR_I + FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I*i ) +
                                              ( BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I*(fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf ) ) );
           end
         else
            begin
             fbh_wr_addr_nd_ctrl_o[i].ddr_mem_y_data_bufr_wr_addr <= ( ( wr_starting_address_i[i] + FIRST_BUFFER_START_ADDR_I + FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I*i ) +
                                              ( BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I*(fbh_wr_addr_nd_ctrl_o[i].wr_frame_buf ) ) );
           end
       end
      else if ( sel_y_data_bufr_wr_addr_arr[i] & ( fbh_wr_fsm_sel_device_num_i == i ) )
        begin
          fbh_wr_addr_nd_ctrl_o[i].ddr_mem_y_data_bufr_wr_addr  <= ddr_mem_y_data_bufr_wr_addr[i];
        end
      else if ( full_frame_wr_completed_arr_o[i] & ( fbh_wr_fsm_sel_device_num_i == i ) )
        begin
          fbh_wr_addr_nd_ctrl_o[i].ddr_mem_y_data_bufr_wr_addr  <= 32'h3FFF_FFFF;
        end
    end

// DDR Write word counter
   always_ff @( posedge axi_clk )
     begin
       if ( ~axi_clk_reset_n )
         begin
           no_of_ddr_wr_words[i] <= 32'd0;
         end
//     else if ( sel_next_bufr_arr[i] )
     else if ( ( full_frame_wr_completed_arr_o[i] & ddr_mem_wr_burst_resp_complete_o /*full_frame_wr_completion_reset[i] == 1'b1*/ ) |
               ( ddr_wr_xfer_axi_clk_i[i] == 1'b0 ) |
               ( sel_d_reset_or_hdmi_src_connect_axi_clk_i[i] == 1'b1 ) )
       begin
         no_of_ddr_wr_words[i] <= 32'd0;
       end
     else if ( axi_m0_wvalid_o & axi_m0_wready_i & ( fbh_wr_fsm_sel_device_num_i == i ) )
       begin
         no_of_ddr_wr_words[i] <= no_of_ddr_wr_words[i] + INCR_DDR_WR_COUNT;
       end
     end


 end
endgenerate




// -------------------------------------
//
// DDR Write FSM
//
// -------------------------------------


  // Current State
  always_ff @ ( posedge axi_clk )
    begin
      if ( !axi_clk_reset_n || !ddr_init_done_i )
        begin
          ddr_wr_fsm_cs <= DDR_INIT;
        end
      else if ( ( ddr_wr_xfer_axi_clk_i[fbh_wr_fsm_sel_device_num_i] == 1'b0 ) |
                ( sel_d_reset_or_hdmi_src_connect_axi_clk_i[fbh_wr_fsm_sel_device_num_i] == 1'b1 )
              )
        begin
          ddr_wr_fsm_cs <= IDLE;
        end
     else
        begin
          ddr_wr_fsm_cs <= ddr_wr_fsm_ns;
        end
    end

  // Next State
  always_comb
    begin
      ddr_wr_fsm_ns <= DDR_INIT;
      unique case ( ddr_wr_fsm_cs )

        // Wait until DDR is initialized
        DDR_INIT :
          begin
            if ( ddr_init_done_i )
              begin
                ddr_wr_fsm_ns <= IDLE;
              end
            else
              begin
                ddr_wr_fsm_ns <= DDR_INIT;
              end
          end

        // Wait until start_serving_device_pl sent by wr_dev_sel_fsm
        IDLE :
          begin
            if ( fbh_wr_fsm_start_serving_device_pl_i )  // Informed from fbh_wr_dev_sel_fsm
              begin
                ddr_wr_fsm_ns <= RD_Y_DATA_BUFR;
              end
            else
              begin
                ddr_wr_fsm_ns <= IDLE;
              end
          end

        // Read first word from Y data FIFO
        RD_Y_DATA_BUFR :
          begin
            ddr_wr_fsm_ns <= WR_Y_ADDR;
          end

        // Generate address valid pulse
        WR_Y_ADDR :
          begin
            ddr_wr_fsm_ns <= WR_Y_DATA;
          end

        // Write data into DDR until burst is complete
        WR_Y_DATA :
          begin
            if ( axi_m0_wlast_o & axi_m0_wready_i )
              begin
                ddr_wr_fsm_ns <= POST_WR_Y_DATA;
              end
            else
              begin
                ddr_wr_fsm_ns <= WR_Y_DATA;
              end
          end

        // Wait for response from DDR
        POST_WR_Y_DATA :
          begin
            if ( axi_m0_bvalid_i & axi_m0_bready_o )
              begin
                ddr_wr_fsm_ns <= UPDATE_WR_DEV_NUM;
              end
            else
              begin
                ddr_wr_fsm_ns <= POST_WR_Y_DATA;
              end
          end

        // Update write device number
        UPDATE_WR_DEV_NUM :
          begin
            ddr_wr_fsm_ns <= IDLE;
          end

      endcase
    end


  // Next State Signals
  always_comb
    begin

      rd_y_data_bufr           <= 1'b0;
      axi_m0_awvalid           <= 1'b0;
      axi_m0_wvalid            <= 1'b0;
      axi_m0_wlast             <= 1'b0;
      axi_m0_bready            <= 1'b0;
      sel_y_data_bufr_wr_addr  <= 1'b0;
      axi_m_busy               <= 1'b0;
      rd_data_words_count_en   <= 1'b0;
      update_wr_dev_num_pl     <= 1'b0;

      unique case ( ddr_wr_fsm_cs )

        // Address is calculated outside of this block.
        // Hence, in every state, its value should be preserved.
        IDLE :
          begin

          end

        // Read first word from Y data FIFO
        RD_Y_DATA_BUFR :
          begin
            rd_y_data_bufr  <= 1'b1;
            axi_m_busy      <= 1'b1;
          end

        // Generate address valid pulse
        WR_Y_ADDR :
          begin
            axi_m_busy              <= 1'b1;
            sel_y_data_bufr_wr_addr <= 1'b1;
          end

        // Write data into DDR until burst is complete
        WR_Y_DATA :
          begin
            axi_m_busy              <= 1'b1;
            axi_m0_awvalid          <= 1'b1;
            rd_data_words_count_en  <= 1'b1;
            sel_y_data_bufr_wr_addr <= 1'b1;

            // Check if it is the last burst or not.
            if ( ( ( y_data_bufr_wr_count  == ( AXI_M0_AWLEN - 1'b1 ) ) &
                   ( axi_m0_wready_i )
                 ) |
                 ( ( AXI_M0_AWLEN    == 1'b0 ) &  // When ALEN = 0, WLAST and WVALID must be
                   ( ( axi_m0_wlast_o & axi_m0_wready_i ) == 1'b0 )
                 )
               )
              begin
                axi_m0_wlast  <= 1'b1;
                axi_m0_wvalid <= 1'b1;
              end
            else if ( ( y_data_bufr_wr_count == AXI_M0_AWLEN ) )
              begin
                if ( axi_m0_wready_i == 1'b1 )
                  begin
                    axi_m0_wlast  <= 1'b0;
                    axi_m0_wvalid <= 1'b0;
                  end
                else
                  begin
                    axi_m0_wlast  <= 1'b1;
                    axi_m0_wvalid <= 1'b1;
                  end
              end
            else
              begin
                axi_m0_wlast  <= 1'b0;
                axi_m0_wvalid <= 1'b1;
              end

          end

        // Wait for response from DDR
        POST_WR_Y_DATA :
          begin
            axi_m_busy    <= 1'b1;

            if ( axi_m0_bvalid_i & axi_m0_bready_o )
              begin
                axi_m0_bready <= 1'b0;
              end
            else
              begin
                axi_m0_bready <= 1'b1;
              end
          end

        // Update write device number
        UPDATE_WR_DEV_NUM :
          begin
            update_wr_dev_num_pl <= 1'b1;
          end

      endcase
    end


// ------------------------------------------
//
// Registered Outputs
//
// ------------------------------------------

  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          axi_m0_wvalid_o            <= 1'b0;
          axi_m0_wlast_o             <= 1'b0;
          axi_m0_bready_o            <= 1'b0;
          axi_wr_m_busy              <= 1'b0;
          update_wr_dev_num_o        <= 1'b0;
        end
      else
        begin
          axi_m0_wvalid_o          <= axi_m0_wvalid;
          axi_m0_wlast_o           <= axi_m0_wlast;
          axi_m0_bready_o          <= axi_m0_bready;
          axi_wr_m_busy            <= axi_m_busy;
          update_wr_dev_num_o      <= update_wr_dev_num_pl;
        end
    end

// -------------------------------------
//
// Misc Logic related to Write FSM
//
// -------------------------------------

  // M0 AWID
  assign axi_m0_awid_o = 8'd0;

  // M0 Write Strobe
  assign axi_m0_wstrb_o = 64'hFFFF_FFFF_FFFF_FFFF;

  // M0 Write Burst Size
  assign axi_m0_awsize_o = AXI_M0_AWSIZE;

  // M0 Write Burst Length
  assign axi_m0_awlen_o  = AXI_M0_AWLEN;

  // M0 Write Burst Type
  assign axi_m0_awburst_o = AXI_M0_AWBURST;

  // M0 Write Lock
  assign axi_m0_awlock_o = 1'd0;


  // Write Y data Count
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          y_data_bufr_wr_count <= 8'd0;
        end
      else if ( axi_m0_wvalid_o == 1'b0 )
        begin
          y_data_bufr_wr_count <= 8'd0;
        end
      else if ( axi_m0_wready_i == 1'b1 )
        begin
          y_data_bufr_wr_count <= y_data_bufr_wr_count + 1'b1;
        end
    end


  // Address valid generation for AXI
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          axi_m0_awvalid_o <= 1'b0;
        end
      else if ( axi_m0_awready_i )
        begin
          axi_m0_awvalid_o <= 1'b0;
        end
      else if ( ( axi_m0_awvalid ) & ( y_data_bufr_wr_count == 8'd0 ) )
        begin
          axi_m0_awvalid_o <= 1'b1;
        end
    end

//  Logic for AXI write address
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          axi_m0_awaddr_o  <= 33'b0;
        end
      else if ( ( ddr_wr_xfer_axi_clk_i[fbh_wr_fsm_sel_device_num_i] == 1'b0 ) |
                ( sel_d_reset_or_hdmi_src_connect_axi_clk_i[fbh_wr_fsm_sel_device_num_i] == 1'b1 )
              )
        begin
          axi_m0_awaddr_o  <= 33'b0;
        end
      else if ( sel_y_data_bufr_wr_addr_arr[fbh_wr_fsm_sel_device_num_i] )
        begin
          axi_m0_awaddr_o  <= ddr_mem_y_data_bufr_wr_addr[fbh_wr_fsm_sel_device_num_i];
        end
      else if ( full_frame_wr_completed_arr_o[fbh_wr_fsm_sel_device_num_i] )
        begin
          axi_m0_awaddr_o  <= 32'h3FFF_FFFF;
        end
    end


//  Response is sent by DDR after writing one burst
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          ddr_mem_wr_burst_resp_complete_o  <= 1'b0;
        end
      else
        begin
          ddr_mem_wr_burst_resp_complete_o  <= ( (axi_m0_bvalid_i) & (axi_m0_bready_o) );
        end
    end

//  One burst of data is written into DDR
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          ddr_mem_wr_burst_complete_o  <= 1'b0;
        end
      else
        begin
          ddr_mem_wr_burst_complete_o  <= ( (axi_m0_wvalid_o) & (axi_m0_wready_i) & axi_m0_wlast_o );
        end
    end

//  assign ddr_mem_wr_burst_resp_complete_o = ( (axi_m0_bvalid_i) & (axi_m0_bready_o) );
//  assign ddr_mem_wr_burst_complete_o      = ( (axi_m0_wvalid_o) & (axi_m0_wready_i) & axi_m0_wlast_o );

//  Assigning read data of yfifo to axi write data
  assign axi_m0_wdata_o = y_data_bufr_rd_data[fbh_wr_fsm_sel_device_num_i];


// Generating buffer already selected signal based on device
// Take care of full_frame_wr_completed_o
// Used by fbh_wr_dev_sel_fsm
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          bufr_already_selected_o[fbh_wr_fsm_sel_device_num_i]  <= 1'b0;
        end
      else if ( full_frame_wr_completed_arr_o[fbh_wr_fsm_sel_device_num_i] |
              ( ddr_wr_xfer_axi_clk_i[fbh_wr_fsm_sel_device_num_i] == 1'b0 ) |
              ( sel_d_reset_or_hdmi_src_connect_axi_clk_i[fbh_wr_fsm_sel_device_num_i] == 1'b1 ) )
        begin
          bufr_already_selected_o[fbh_wr_fsm_sel_device_num_i]  <= 1'b0;
        end
      else if ( sel_next_bufr_arr[fbh_wr_fsm_sel_device_num_i] )
        begin
          bufr_already_selected_o[fbh_wr_fsm_sel_device_num_i]  <= 1'b1;
        end
    end

  // Generating first sel next buffer signal based on device
  // Used by fbh_wr_dev_sel_fsm
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          first_bufr_selected_o[fbh_wr_fsm_sel_device_num_i]  <= 1'b0;
        end
      else if ( ( ddr_wr_xfer_axi_clk_i[fbh_wr_fsm_sel_device_num_i] == 1'b0 ) |
                ( sel_d_reset_or_hdmi_src_connect_axi_clk_i[fbh_wr_fsm_sel_device_num_i] == 1'b1 ) )
        begin
          first_bufr_selected_o[fbh_wr_fsm_sel_device_num_i]  <= 1'b0;
        end
      else if ( first_sel_next_bufr_arr[fbh_wr_fsm_sel_device_num_i] )
        begin
          first_bufr_selected_o[fbh_wr_fsm_sel_device_num_i]  <= 1'b1;
        end
    end


// Full frame completed logic
  always_ff @ ( posedge axi_clk )
    begin
      if ( ~axi_clk_reset_n )
        begin
          full_frame_wr_completed_arr_o[fbh_wr_fsm_sel_device_num_i] <= 2'b0;
        end
      else if ( yuv_420_en_axi_clk_arr[fbh_wr_fsm_sel_device_num_i] )
        begin
          full_frame_wr_completed_arr_o[fbh_wr_fsm_sel_device_num_i] <= ( no_of_ddr_wr_words[fbh_wr_fsm_sel_device_num_i] == frame_size_info_i[fbh_wr_fsm_sel_device_num_i] ) ;
        end
      else
        begin
//          full_frame_wr_completed_arr_o[i] <= ( ( ( no_of_ddr_wr_words[i] == frame_size_info_i ) ) & ( y_data_bufr_empty_o[i] ) );
          full_frame_wr_completed_arr_o[fbh_wr_fsm_sel_device_num_i] <=  ( no_of_ddr_wr_words[fbh_wr_fsm_sel_device_num_i] == frame_size_info_i[fbh_wr_fsm_sel_device_num_i] );
        end
    end


// ------------------------------------------
//
// Registered Outputs based on device number
//
// ------------------------------------------

always_ff @ ( posedge axi_clk )
  begin
    if ( !axi_clk_reset_n )
      begin
        rd_y_data_bufr_arr                 <= 8'b0;
        rd_data_words_count_en_arr         <= 8'b0;
        sel_y_data_bufr_wr_addr_arr        <= 8'b0;
        sel_next_bufr_arr                  <= 8'b0;
        first_sel_next_bufr_arr            <= 8'b0;
        yuv_420_en_axi_clk_arr             <= 8'b0;
        y_data_bufr_almost_empty_o         <= 8'b0;
        y_data_bufr_rst_busy_o             <= 8'b0;
        full_frame_wr_completed_o          <= 8'b0;
      end
    else
      begin
              rd_y_data_bufr_arr                 [fbh_wr_fsm_sel_device_num_i]  <= rd_y_data_bufr;
              rd_data_words_count_en_arr         [fbh_wr_fsm_sel_device_num_i]  <= rd_data_words_count_en;
              sel_y_data_bufr_wr_addr_arr        [fbh_wr_fsm_sel_device_num_i]  <= sel_y_data_bufr_wr_addr;
              sel_next_bufr_arr                  [fbh_wr_fsm_sel_device_num_i]  <= sel_next_bufr_i;
              first_sel_next_bufr_arr            [fbh_wr_fsm_sel_device_num_i]  <= first_sel_next_bufr_i;
              yuv_420_en_axi_clk_arr             [fbh_wr_fsm_sel_device_num_i]  <= yuv_420_en_axi_clk_i;
              y_data_bufr_almost_empty_o                                        <= y_data_bufr_almost_empty       [fbh_wr_fsm_sel_device_num_i];
              y_data_bufr_rst_busy_o                                            <= y_data_bufr_rst_busy           [fbh_wr_fsm_sel_device_num_i];
              full_frame_wr_completed_o                                         <= full_frame_wr_completed_arr_o  [fbh_wr_fsm_sel_device_num_i];
      end
  end


endmodule
