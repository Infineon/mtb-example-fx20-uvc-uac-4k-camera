//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:     FX10/20 Design
// Module Name:     fbh_wr_dev_sel_fsm
// Target Devices:  Ti180
//
// Description: This module is responsible for selecting device number for writing
//              data into/from DDR4 memory for that particular device. In DDR4, there are couple of buffers
//              which act as a ping pong and each of it can store a full 4K frame.
//              Efinix Ti180 has Hard DDR4 Controller IP which supports AXI4
//              interface. Hence, in this module, AXI4 Master has been implemented
//              to access AXI slave of Hard IP.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


// Timescale
`timescale 1 ns / 100 ps

module fbh_wr_dev_sel_fsm
 #
 (
   // No. of devices/ FIFOs needed
  parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
  parameter SEL_DEV_NUM_BITS_I  = 3

 )
 (
  // Output
  output logic                                  fbh_wr_dsf_start_serving_device_pl_o,
  output logic [(SEL_DEV_NUM_BITS_I-1):0]         fbh_wr_dsf_sel_device_num_o,
  output logic                                  fbh_wr_dsf_sel_next_bufr_pl_o,
  output logic                                  fbh_wr_dsf_first_bufr_selected_pl_o,
  output dev_reg_info_st_t                      fbh_wr_sel_d_reg_info_st_axi_clk_o,
  output dev_reg_info_st_t                      fbh_wr_sel_d_reg_info_st_gpif_clk_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]      ddr_wr_xfer_axi_clk_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]      sel_d_start_stream_axi_clk_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]    sel_d_reset_or_hdmi_src_connect_axi_clk_o,
  output                                        yuv_420_en_axi_clk_o,
//  output logic [(NO_OF_SUPPORTED_DEV_I-1):0] [31:0] sel_d_frame_size_in_bytes_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0] [31:0] frame_size_in_bytes_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0] [31:0] wr_starting_address_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0] [15:0] no_of_bytes_in_single_line_o,


  // Input
  input                                       clk,
  input                                       reset_n,
  input                                       y_data_bufr_almost_empty_i,
  input                                       y_data_bufr_rst_busy_i,
  input  [(NO_OF_SUPPORTED_DEV_I-1):0]                  sel_vsync_axi_clk_i,
  input  [(NO_OF_SUPPORTED_DEV_I-1):0]                  y_data_bufr_empty_i,
  input dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_axi_clk_i,
  input dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_gpif_clk_i,
  input common_reg_info_st_t                            common_reg_info_i,

  input  [(NO_OF_SUPPORTED_DEV_I-1):0]                  fbh_wr_dsf_first_bufr_selected_i,
  input  [(NO_OF_SUPPORTED_DEV_I-1):0]                  fbh_wr_dsf_bufr_already_selected_i,
  input                                       full_frame_wr_completed_i,
  input                                       ddr_mem_wr_burst_complete_i,
  input                                       ddr_mem_wr_burst_resp_complete_i,
  input                                       update_wr_dev_num_i,
  input                                       ddr_init_done_i
 );


// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // Device switching delay clocks

  localparam NO_OF_DEVICE_SWITCH_DELAY_CLOCKS = 3'd5;

  // No of States
  localparam NO_OF_FSM_STATES = 4'd15;

  // FSM States
  enum logic [(NO_OF_FSM_STATES-1):0] {
    IDLE                                = 15'h1,
    SEL_NEXT_BUFR                       = 15'h2,
    CHECK_BUFR_ALREADY_SELECTED_OR_NOT  = 15'h4,
    IS_SEL_DEV_ACTIVE                   = 15'h8,
    SERVE_SEL_DEV                       = 15'h10,
    WAIT_SEL_DEV_SERVED                 = 15'h20,
    INCR_DEV_NUMBER                     = 15'h40,
    WAIT_INCR_DEV_NUMBER                = 15'h80,
    FIRST_SEL_NEXT_BUFR                 = 15'h100
  } fbh_wr_dsf_dev_s_cs, fbh_wr_dsf_dev_s_ns;

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  // FSM Signals
  logic                           fbh_wr_dsf_start_serving_device_pl;
  logic                           fbh_wr_dsf_incr_dev_num_pl;
  logic                           fbh_wr_dsf_first_bufr_selected_pl;
  logic                           fbh_wr_dsf_sel_next_bufr_pl;
  logic  [2:0]                    device_sw_count;
  logic                           incr_device_sw_count_pl;
  logic  [(SEL_DEV_NUM_BITS_I-1):0] fbh_wr_dsf_sel_int_device_num;
//  logic  [31:0]                   sel_d_frame_size_in_pixels;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0] [31:0] frame_size_in_pixels;

  logic [(NO_OF_SUPPORTED_DEV_I-1):0] [31:0] wr_starting_address_init;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0] [15:0] no_of_pixels_in_single_line;

// ------------------------------------------
//
// FSM
//
// ------------------------------------------

// Current State
always_ff @ ( posedge clk )
  begin
    if ( !reset_n || !ddr_init_done_i  )
      begin
        fbh_wr_dsf_dev_s_cs <= IDLE;
      end

      // Based on ddr_wr_xfer of selected device increment device number.
    else if ( ( ddr_wr_xfer_axi_clk_o[fbh_wr_dsf_sel_device_num_o] == 1'b0 ) |
              ( sel_d_reset_or_hdmi_src_connect_axi_clk_o[fbh_wr_dsf_sel_device_num_o] == 1'b1 ) )  // To handle sudden start_stop condition on actual device
      begin
        fbh_wr_dsf_dev_s_cs <= INCR_DEV_NUMBER;
      end
    else
      begin
        fbh_wr_dsf_dev_s_cs <= fbh_wr_dsf_dev_s_ns;
      end
  end


// Next State
always_comb
  begin
    fbh_wr_dsf_dev_s_ns <= IDLE;
    unique case ( fbh_wr_dsf_dev_s_cs )

      // Move to FIRST_SEL_NEXT_BUFR state based on ddr_wr_xfer of selected device
      IDLE :
        begin
          if ( ( ddr_wr_xfer_axi_clk_o[fbh_wr_dsf_sel_device_num_o] == 1'b1 ) &
               ( sel_d_reset_or_hdmi_src_connect_axi_clk_o[fbh_wr_dsf_sel_device_num_o] == 1'b0 )
             )
            begin
              fbh_wr_dsf_dev_s_ns <= FIRST_SEL_NEXT_BUFR;
            end
          else
            begin
              fbh_wr_dsf_dev_s_ns <= INCR_DEV_NUMBER;
            end
        end

      // Move to SEL_NEXT_BUFR
      // Until first_sel_bufr is high for particular device
      // No need to go to IDLE state for checking ddr_wr_xfer condition
      FIRST_SEL_NEXT_BUFR :
        begin
          fbh_wr_dsf_dev_s_ns <= SEL_NEXT_BUFR;           // IS_SEL_DEV_ACTIVE
        end

      // Move to WAIT_INCR_DEV_NUMBER so that required variables will get updated
      SEL_NEXT_BUFR :
        begin
          fbh_wr_dsf_dev_s_ns <= WAIT_INCR_DEV_NUMBER;    // IS_SEL_DEV_ACTIVE
        end

      // Check if Buffer is already selected for particular device or not
      // Also take care of full frame write completed signal
      CHECK_BUFR_ALREADY_SELECTED_OR_NOT :
        begin
          if ( ( ddr_wr_xfer_axi_clk_o[fbh_wr_dsf_sel_int_device_num] == 1'b1 ) &
               ( sel_d_reset_or_hdmi_src_connect_axi_clk_o[fbh_wr_dsf_sel_int_device_num] == 1'b0 )
             )
            begin
              if ( fbh_wr_dsf_first_bufr_selected_i[fbh_wr_dsf_sel_device_num_o] )
                begin
                   if ( fbh_wr_dsf_bufr_already_selected_i[fbh_wr_dsf_sel_device_num_o] )
                     begin
                       fbh_wr_dsf_dev_s_ns <= IS_SEL_DEV_ACTIVE;
                     end
                   else
                     begin
                      fbh_wr_dsf_dev_s_ns <= SEL_NEXT_BUFR; //INCR_DEV_NUMBER;
                     end
                end
              else
                begin
                  fbh_wr_dsf_dev_s_ns <= IDLE;
                end
            end
          else
            begin
              fbh_wr_dsf_dev_s_ns <= INCR_DEV_NUMBER;
            end
        end

      // Is selected device has data worth one burst?
      IS_SEL_DEV_ACTIVE :
        begin
          if ( ( y_data_bufr_almost_empty_i == 1'b0 ) & ( y_data_bufr_rst_busy_i == 1'b0 )
             )
            begin
              fbh_wr_dsf_dev_s_ns <= SERVE_SEL_DEV;
            end
          else
            begin
              fbh_wr_dsf_dev_s_ns <= INCR_DEV_NUMBER;
            end
        end

      // Device has data. Let's serve it.
      SERVE_SEL_DEV :
        begin
          fbh_wr_dsf_dev_s_ns <= WAIT_SEL_DEV_SERVED;
        end

      // Wait until device is served based on burst by burst
      WAIT_SEL_DEV_SERVED :
        begin
          if ( update_wr_dev_num_i )
            begin
              fbh_wr_dsf_dev_s_ns <= INCR_DEV_NUMBER;
            end
          else
            begin
              fbh_wr_dsf_dev_s_ns <= WAIT_SEL_DEV_SERVED;
            end
        end

      // Incrementing device number
      INCR_DEV_NUMBER :
        begin
          fbh_wr_dsf_dev_s_ns <= WAIT_INCR_DEV_NUMBER;
        end

      // Waiting for the variables to get updated
      WAIT_INCR_DEV_NUMBER :
        begin
          if ( device_sw_count == NO_OF_DEVICE_SWITCH_DELAY_CLOCKS )
            begin
              fbh_wr_dsf_dev_s_ns <= CHECK_BUFR_ALREADY_SELECTED_OR_NOT;
            end
          else
            begin
              fbh_wr_dsf_dev_s_ns <= WAIT_INCR_DEV_NUMBER;
            end
        end
    endcase
  end


// Next State: Signals
always_comb
  begin

    fbh_wr_dsf_start_serving_device_pl           <= 1'b0;
    fbh_wr_dsf_incr_dev_num_pl                   <= 1'b0;
    fbh_wr_dsf_first_bufr_selected_pl            <= 1'b0;
    fbh_wr_dsf_sel_next_bufr_pl                  <= 1'b0;
    incr_device_sw_count_pl                      <= 1'b0;

    unique case ( fbh_wr_dsf_dev_s_cs )

      // Move to FIRST_SEL_NEXT_BUFR state based on ddr_wr_xfer of selected device
      IDLE :
        begin

        end

      // Move to SEL_NEXT_BUFR
      // Until first_sel_bufr is high for particular device
      // No need to go to IDLE state for checking ddr_wr_xfer condition
      FIRST_SEL_NEXT_BUFR :
        begin
          fbh_wr_dsf_first_bufr_selected_pl <= 1'b1;
        end

      // Move to WAIT_INCR_DEV_NUMBER so that required variables will get updated
      SEL_NEXT_BUFR :
        begin
          fbh_wr_dsf_sel_next_bufr_pl <= 1'b1;
        end

      // Check if Buffer is already selected for particular device or not
      // Also take care of full frame write completed signal
      CHECK_BUFR_ALREADY_SELECTED_OR_NOT :
        begin

        end

      // Is selected device has data?
      IS_SEL_DEV_ACTIVE :
        begin

        end

      // Device has data. Let's serve it.
      SERVE_SEL_DEV :
        begin
          fbh_wr_dsf_start_serving_device_pl <= 1'b1;
        end

      // Wait until device is served.
      WAIT_SEL_DEV_SERVED :
        begin

        end

      // Incrementing device number
      INCR_DEV_NUMBER :
        begin
          fbh_wr_dsf_incr_dev_num_pl <= 1'b1;
        end

      // Waiting for the variables to get updated
      WAIT_INCR_DEV_NUMBER :
        begin
          incr_device_sw_count_pl <= 1'b1;
        end

    endcase
  end


// ------------------------------------------
//
// Registered Outputs
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        fbh_wr_dsf_start_serving_device_pl_o    <= 1'b0;
        fbh_wr_dsf_first_bufr_selected_pl_o     <= 1'b0;
        fbh_wr_dsf_sel_next_bufr_pl_o           <= 1'b0;
      end
    else
      begin
        fbh_wr_dsf_start_serving_device_pl_o    <= fbh_wr_dsf_start_serving_device_pl;
        fbh_wr_dsf_first_bufr_selected_pl_o     <= fbh_wr_dsf_first_bufr_selected_pl;
        fbh_wr_dsf_sel_next_bufr_pl_o           <= fbh_wr_dsf_sel_next_bufr_pl;
      end
  end


// ------------------------------------------
//
// Selected Device
//
// ------------------------------------------


// Internal Device Number
// It is used by FSM to check whether device is active or not.
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        fbh_wr_dsf_sel_int_device_num <= 3'd0;
      end
    else if ( fbh_wr_dsf_incr_dev_num_pl )
      begin
        if ( fbh_wr_dsf_sel_int_device_num == ( NO_OF_SUPPORTED_DEV_I - 1'b1 ) )
          begin
            fbh_wr_dsf_sel_int_device_num <= '0;
          end
        else
          begin
            fbh_wr_dsf_sel_int_device_num <= fbh_wr_dsf_sel_int_device_num + 1'b1;
          end
      end
  end

// Actual Device Number
// It is used by FBH Module based on sel_start_stream
generate
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fbh_wr_dsf_sel_device_num_o <= '0;
      end
    else if ( fbh_wr_dsf_incr_dev_num_pl )
      begin
        if ( fbh_wr_dsf_sel_int_device_num == ( NO_OF_SUPPORTED_DEV_I - 1'b1 ) )
          begin
            if ( ( ddr_wr_xfer_axi_clk_o[0] == 1'b1 ) &
                 ( sel_d_reset_or_hdmi_src_connect_axi_clk_o[0] == 1'b0 )
               )
              begin
                fbh_wr_dsf_sel_device_num_o <= '0;
              end
          end
        else if ( ( ddr_wr_xfer_axi_clk_o[fbh_wr_dsf_sel_int_device_num + 1] == 1'b1 ) &
                  ( sel_d_reset_or_hdmi_src_connect_axi_clk_o[fbh_wr_dsf_sel_int_device_num + 1] == 1'b0 )
                )
          begin
            fbh_wr_dsf_sel_device_num_o <= fbh_wr_dsf_sel_int_device_num + 1'b1;
          end
      end
  end
endgenerate


// ----------------------------------------------
//
// Updating Structures based on selected device
//
// ----------------------------------------------

// Structure Updation in axi domain
// It is used by modules to retrive infromation regarding variables based on device number.
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        fbh_wr_sel_d_reg_info_st_axi_clk_o <= '{default:0};
      end
    else
      begin
        fbh_wr_sel_d_reg_info_st_axi_clk_o <= dev_reg_info_st_arr_axi_clk_i[fbh_wr_dsf_sel_device_num_o];
      end
  end

// Structure Updation in gpif domain
// It is used by modules to retrive infromation regarding variables based on device number.
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        fbh_wr_sel_d_reg_info_st_gpif_clk_o <= '{default:0};
      end
    else
      begin
        fbh_wr_sel_d_reg_info_st_gpif_clk_o <= dev_reg_info_st_arr_gpif_clk_i[fbh_wr_dsf_sel_device_num_o];
      end
  end

// Not used anywhere right now

assign yuv_420_en_axi_clk_o = fbh_wr_sel_d_reg_info_st_axi_clk_o.yuv422_420_conversion_mode_en;


// Assertion as well as de-assertion is delayed until
// VSYNC is LOW and Y data is empty.
// It is used by DDR Write FSM. So, when resolution or
// FPS is changed inbetween, it should not affect the write process.

 genvar i;

 generate
  for (i = 0; i < NO_OF_SUPPORTED_DEV_I; i= i+1)
   begin : start_ddr_wr_xfer

    always_ff @ (posedge clk)
      begin
        if ( ~reset_n )
          begin
            ddr_wr_xfer_axi_clk_o[i] <= 1'd0;
          end
         else if ( ( dev_reg_info_st_arr_axi_clk_i[i].start_stream == 1'b0 ) & ( update_wr_dev_num_i == 1'b1 ) )
            begin
             ddr_wr_xfer_axi_clk_o[i] <= 1'd0;
            end
        else if ( ( sel_vsync_axi_clk_i[i] == 1'b0 ) & ( y_data_bufr_empty_i[i] ) )
          begin
            ddr_wr_xfer_axi_clk_o[i] <= dev_reg_info_st_arr_axi_clk_i[i].start_stream;
          end
      end

// Assertion is delayed until VSYNC is LOW.
// De-assertion will be immediate. It is used by DDR Read FSM and other modules.
    always_ff @ (posedge clk)
      begin
        if ( ~reset_n )
          begin
            sel_d_start_stream_axi_clk_o[i] <= 1'd0;
          end
        else if ( dev_reg_info_st_arr_axi_clk_i[i].start_stream == 1'b0 )
          begin
            sel_d_start_stream_axi_clk_o[i] <= 1'b0;
          end
        else if (sel_vsync_axi_clk_i[i] == 1'b0 )
          begin
            sel_d_start_stream_axi_clk_o[i] <= 1'b1;
          end
      end


// Soft reset from FW or
// HDMI Source is not connected
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_d_reset_or_hdmi_src_connect_axi_clk_o[i] <= 1'b0;
      end
    else
      begin
        sel_d_reset_or_hdmi_src_connect_axi_clk_o[i] <= ( ( dev_reg_info_st_arr_axi_clk_i[i].fw_soft_reset == 1'b1 ) |
                                                         /*( sel_d_start_stream_axi_clk_o[i]  == 1'b0 ) |*/     // Already taken care by ddr_wr_xfer
                                                         ( dev_reg_info_st_arr_axi_clk_i[i].hdmi_source_connection == 1'b0 )
                                                        );
      end
   end

// Write address Initilization from last line
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        wr_starting_address_init[i] <= 32'h0;
      end
    else
      begin
        wr_starting_address_init[i] <= ( ( dev_reg_info_st_arr_gpif_clk_i[i].image_height - 1'h1 ) *
                                         dev_reg_info_st_arr_gpif_clk_i[i].image_width );
      end
  end

// No_of_pixels in one line
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        no_of_pixels_in_single_line[i] <= 16'd0;
      end
    else
      begin
        no_of_pixels_in_single_line[i] <= dev_reg_info_st_arr_gpif_clk_i[i].image_width;
      end
  end

// Write address starting address
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        wr_starting_address_o[i] <= 32'h0000_0000;
        no_of_bytes_in_single_line_o[i] <= 16'h0;
      end
    else if ( ( ( dev_reg_info_st_arr_axi_clk_i[i].hdmi_mode_rgb == 1'b0 ) & common_reg_info_i.uvc_stream_mode_en ) |
              ( common_reg_info_i.uvc_stream_mode_en == 1'b0 ) )
      begin
        wr_starting_address_o[i] <= 32'h0000_0000;
        no_of_bytes_in_single_line_o[i] <= 16'h0;
      end
    else
      begin
        case ( dev_reg_info_st_arr_gpif_clk_i[i].image_pixel_width )

          8'd8    : begin
                      wr_starting_address_o[i] <=   ( wr_starting_address_init[i] );
                      no_of_bytes_in_single_line_o[i] <= dev_reg_info_st_arr_gpif_clk_i[i].image_width;
                    end
          8'd12,
          8'd16   : begin
                      wr_starting_address_o[i] <=   wr_starting_address_init[i] << 1'b1;
                      no_of_bytes_in_single_line_o[i] <= dev_reg_info_st_arr_gpif_clk_i[i].image_width << 1'b1;
                    end
          8'd24,
          8'd32   : begin
                      wr_starting_address_o[i] <= ( wr_starting_address_init[i] << 2'd2);
                      no_of_bytes_in_single_line_o[i] <= dev_reg_info_st_arr_gpif_clk_i[i].image_width << 2'd2;
                    end
          default : begin
                      wr_starting_address_o[i] <=   wr_starting_address_init[i] << 1'b1;
                      no_of_bytes_in_single_line_o[i] <= dev_reg_info_st_arr_gpif_clk_i[i].image_width << 1'b1;
                    end


        endcase
      end
  end

// ------------------------------------------
//
// Frame Size In Bytes
//
// ------------------------------------------

//
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        frame_size_in_pixels[i] <= 32'h0;
      end
    else
      begin
        frame_size_in_pixels[i] <= ( ( dev_reg_info_st_arr_gpif_clk_i[i].image_height ) *
                                       dev_reg_info_st_arr_gpif_clk_i[i].image_width );
      end
  end

// Image Size in bytes
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        frame_size_in_bytes_o[i] <= 32'h0;
      end
    else
      begin
        case (dev_reg_info_st_arr_gpif_clk_i[i].image_pixel_width)

          8'd8    : frame_size_in_bytes_o[i] <=   frame_size_in_pixels[i];

          8'd12,
          8'd16   : frame_size_in_bytes_o[i] <=   frame_size_in_pixels[i] << 1'b1;

          8'd24,
          8'd32   : frame_size_in_bytes_o[i] <= (frame_size_in_pixels[i] << 2'd2);
          default : frame_size_in_bytes_o[i] <=   frame_size_in_pixels[i] << 1'b1;

        endcase
      end
  end

   end
 endgenerate


// ------------------------------------------
//
// Frame Size In Bytes
//
// ------------------------------------------

/*
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_d_frame_size_in_pixels <= 8'd0;
      end
    else
      begin
        sel_d_frame_size_in_pixels <= ( fbh_wr_sel_d_reg_info_st_gpif_clk_o.image_height *
                                        fbh_wr_sel_d_reg_info_st_gpif_clk_o.image_width
                                       );
      end
  end

// Image Size in bytes
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_d_frame_size_in_bytes_o <= 32'd0;
      end
    else
      begin
        case (fbh_wr_sel_d_reg_info_st_gpif_clk_o.image_pixel_width)

          8'd8    : sel_d_frame_size_in_bytes_o <=   sel_d_frame_size_in_pixels;

          8'd12,
          8'd16   : sel_d_frame_size_in_bytes_o <=   sel_d_frame_size_in_pixels << 1'b1;

          8'd24,
          8'd32   : sel_d_frame_size_in_bytes_o <= (sel_d_frame_size_in_pixels << 2'd2);
          default : sel_d_frame_size_in_bytes_o <=   sel_d_frame_size_in_pixels << 1'b1;

        endcase
      end
  end

*/

// ----------------------------------------------
//
// Switching device requires a 2 or 3 clock cycles to update
// variables.
//
// ----------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        device_sw_count <= 3'd0;
      end
    else if ( incr_device_sw_count_pl == 1'b0 )
      begin
        device_sw_count <= 3'd0;
      end
    else if ( device_sw_count == NO_OF_DEVICE_SWITCH_DELAY_CLOCKS )
      begin
        device_sw_count <= device_sw_count;
      end
    else
      begin
        device_sw_count <= device_sw_count + 1'b1;
      end
  end


endmodule
