//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2026, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fbh_wr_wrapper
// Target Devices: Ti180
//
// Description: This is a wrapper which includes following modules,
//
//                 1. FBH Device Selection FSM
//                 2. FBH Write FSM
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


// Timescale
`timescale 1ns/100ps

module fbh_wr_wrapper
  #
  (

  // HDMI/Test Pattern Data Width
  parameter Y_DATA_FIFO_WR_DATA_WIDTH_I = 9'd64,

  // AXI Master Write Channel Data Width
  parameter AXI_M0_WR_DATA_WIDTH_IN_BITS_I = 11'd512,

  // AXI Master Read Channel Data Width
  parameter AXI_M0_RD_DATA_WIDTH_IN_BITS_I = 11'd256,

  // FIRST_BUFFER_START_ADDR
  parameter FIRST_BUFFER_START_ADDR_I = 32'h0000_0000,

  // BUFFER_START_ADDR_DIFF_FOR_SAME_DEV
  parameter BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I = 32'h03F4_8000,

  // FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV
  parameter FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I = 32'h1000_0000,

  // Counter datawidth
  parameter COUNTER_DATAWIDTH_I = 6'd32,

  // No of fifos
  parameter NO_OF_SUPPORTED_DEV_I = 8,

  // No. of bits for device num
  parameter SEL_DEV_NUM_BITS_I  = 3,

  // Y Data FIFO Depth
  parameter Y_DATA_FIFO_DEPTH_IN_WORDS_I = 8192,

  // AXI Master Burst Size
  parameter MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I = 3840

  )
 (

  // Outputs
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                     ddr_wr_xfer_axi_clk_arr_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                     full_frame_wr_completed_arr_o,
  output       [(NO_OF_SUPPORTED_DEV_I-1):0]                     y_data_bufr_full_o,
  output       [(NO_OF_SUPPORTED_DEV_I-1):0]                     y_data_bufr_empty_o,
  output  fbh_wr_addr_nd_ctrl_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] fbh_wr_addr_nd_ctrl_o,
  output logic  [(NO_OF_SUPPORTED_DEV_I-1):0]                    sel_d_start_stream_axi_clk_o,

  // Master Write Address Channel
  input                                                        axi_m0_awready_i,
  output logic [32:0]                                          axi_m0_awaddr_o,
  output logic                                                 axi_m0_awvalid_o,
  output logic [ 1:0]                                          axi_m0_awburst_o,
  output       [ 5:0]                                          axi_m0_awid_o,
  output logic [ 7:0]                                          axi_m0_awlen_o,
  output                                                       axi_m0_awlock_o,
  output logic [ 2:0]                                          axi_m0_awsize_o,

  // Master Write Data Channel
  input                                                        axi_m0_wready_i,
  output logic                                                 axi_m0_wlast_o,
  output logic                                                 axi_m0_wvalid_o,
  output logic [(AXI_M0_WR_DATA_WIDTH_IN_BITS_I-1):0]          axi_m0_wdata_o,
  output       [((AXI_M0_WR_DATA_WIDTH_IN_BITS_I/8)-1):0]      axi_m0_wstrb_o,

  // Master Write Response Channel
  input        [ 5:0]                                          axi_m0_bid_i,
  input                                                        axi_m0_bvalid_i,
  output logic                                                 axi_m0_bready_o,

  // Input clock and reset
  input                                                         hdmi_clk,
  input                                                         axi_clk,
  input                                                         hdmi_clk_reset_n,
  input                                                         axi_clk_reset_n,

  // Input data and controls
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          sel_vsync_axi_clk_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          sel_vsync_hdmi_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          sel_vsync_hdmi_pe_pl_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          sel_vsync_hdmi_ne_pl_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          sel_hsync_hdmi_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0] [(Y_DATA_FIFO_WR_DATA_WIDTH_I-1):0] sel_vid_data_i,
  input dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0]           dev_reg_info_st_arr_axi_clk_i,    // Device specific registers in axi clk domain
  input dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0]           dev_reg_info_st_arr_gpif_clk_i,   // Device specific registers in gpif clk domain
  input dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0]        dev_reg_info_st_arr_hdmi_clk_i,   // Device specific registers in hdmi clk domain

  input fbh_rd_states_nd_ctrl_st_t  [(NO_OF_SUPPORTED_DEV_I-1):0] fbh_rd_states_nd_ctrl_i,
  input fbh_rd_dsf_flags_st_t       [(NO_OF_SUPPORTED_DEV_I-1):0] fbh_rd_dsf_flags_arr_i,
  input common_reg_info_st_t                                      common_reg_info_i,


  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          ddr_wr_xfer_hdmi_clk_arr_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          full_frame_wr_completed_hdmi_clk_arr_i,

  // DDR init related signals
  input                                                         ddr_init_done_i
 );

// ------------------------------------------
//
// Local Parameter
//
// ------------------------------------------


// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic        fbh_wr_dsf_start_serving_device_pl;
  logic        fbh_wr_dsf_sel_next_bufr_pl;
  logic        fbh_wr_dsf_first_sel_next_bufr_pl;
  logic        ddr_mem_wr_burst_complete;
  logic        ddr_mem_wr_burst_resp_complete;
//  logic        ddr_wr_xfer_axi_clk;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0] sel_d_reset_or_hdmi_src_connect_axi_clk;
  logic        yuv_420_en_axi_clk;
//  logic [31:0] sel_d_frame_size_in_bytes;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0] [31:0] frame_size_in_bytes;

  logic        y_data_bufr_almost_empty;
  logic        y_data_bufr_rst_busy;
  logic        vsync_sclk_pe_pl;
  logic        full_burst_wr_completed;
  logic        full_frame_wr_completed;
  logic        update_wr_dev_num;

  logic [(NO_OF_SUPPORTED_DEV_I-1):0]  y_data_bufr_empty;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0]  bufr_already_selected;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0]  first_bufr_selected;
  logic [(SEL_DEV_NUM_BITS_I-1):0]     fbh_wr_dsf_sel_device_num;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0] [31:0] wr_starting_address;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0] [15:0] no_of_bytes_in_single_line;

  dev_reg_info_st_t              fbh_wr_sel_d_reg_info_st_axi_clk;   // Device specific registers in axi clk domain
  dev_reg_info_st_t              fbh_wr_sel_d_reg_info_st_gpif_clk;  // Device specific registers in gpif clk domain

// ------------------------------------------
//
// Device Selection FSM for Write FBH
//
// ------------------------------------------

fbh_wr_dev_sel_fsm
  #
  (
   // Parameters
   .NO_OF_SUPPORTED_DEV_I                  (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I                     (SEL_DEV_NUM_BITS_I)
    )
  fbhwrdsf
   (
    // Outputs
    .fbh_wr_dsf_start_serving_device_pl_o        (fbh_wr_dsf_start_serving_device_pl),
    .fbh_wr_dsf_sel_device_num_o                 (fbh_wr_dsf_sel_device_num),
    .fbh_wr_dsf_sel_next_bufr_pl_o               (fbh_wr_dsf_sel_next_bufr_pl),
    .fbh_wr_dsf_first_bufr_selected_pl_o         (fbh_wr_dsf_first_sel_next_bufr_pl),
    .fbh_wr_sel_d_reg_info_st_axi_clk_o          (fbh_wr_sel_d_reg_info_st_axi_clk),
    .fbh_wr_sel_d_reg_info_st_gpif_clk_o         (fbh_wr_sel_d_reg_info_st_gpif_clk),
    .ddr_wr_xfer_axi_clk_o                       (ddr_wr_xfer_axi_clk_arr_o),
    .sel_d_start_stream_axi_clk_o                (sel_d_start_stream_axi_clk_o),
    .sel_d_reset_or_hdmi_src_connect_axi_clk_o   (sel_d_reset_or_hdmi_src_connect_axi_clk),
    .yuv_420_en_axi_clk_o                        (yuv_420_en_axi_clk),
    .frame_size_in_bytes_o                       (frame_size_in_bytes),
    .wr_starting_address_o                       (wr_starting_address),
    .no_of_bytes_in_single_line_o                (no_of_bytes_in_single_line),

    // Inputs
    .clk                                         (axi_clk),
    .reset_n                                     (axi_clk_reset_n),
    .y_data_bufr_almost_empty_i                  (y_data_bufr_almost_empty),
    .y_data_bufr_rst_busy_i                      (y_data_bufr_rst_busy),
    .sel_vsync_axi_clk_i                         (sel_vsync_axi_clk_i),
    .y_data_bufr_empty_i                         (y_data_bufr_empty_o),
    .common_reg_info_i                           (common_reg_info_i),
    .dev_reg_info_st_arr_axi_clk_i               (dev_reg_info_st_arr_axi_clk_i),
    .dev_reg_info_st_arr_gpif_clk_i              (dev_reg_info_st_arr_gpif_clk_i),
    .fbh_wr_dsf_first_bufr_selected_i            (first_bufr_selected),
    .fbh_wr_dsf_bufr_already_selected_i          (bufr_already_selected),
    .full_frame_wr_completed_i                   (full_frame_wr_completed),
    .update_wr_dev_num_i                         (update_wr_dev_num),
    .ddr_mem_wr_burst_complete_i                 (ddr_mem_wr_burst_complete),
    .ddr_mem_wr_burst_resp_complete_i            (ddr_mem_wr_burst_resp_complete),
    .ddr_init_done_i                             (ddr_init_done_i)

    );


// ------------------------------------------
//
// Write FBH
//
// ------------------------------------------


fbh_wr_fsm
  #
  (
   // Parameters
   .Y_DATA_FIFO_WR_DATA_WIDTH_I                  (Y_DATA_FIFO_WR_DATA_WIDTH_I),
   .AXI_M0_WR_DATA_WIDTH_IN_BITS_I               (AXI_M0_WR_DATA_WIDTH_IN_BITS_I),
   .AXI_M0_RD_DATA_WIDTH_IN_BITS_I               (AXI_M0_RD_DATA_WIDTH_IN_BITS_I),
   .FIRST_BUFFER_START_ADDR_I                    (FIRST_BUFFER_START_ADDR_I),
   .BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I        (BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I),
   .FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I (FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I),
   .COUNTER_DATAWIDTH_I                          (COUNTER_DATAWIDTH_I),
   .NO_OF_SUPPORTED_DEV_I                        (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I                           (SEL_DEV_NUM_BITS_I),
   .Y_DATA_FIFO_DEPTH_IN_WORDS_I                 (Y_DATA_FIFO_DEPTH_IN_WORDS_I),
   .MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I   (MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I)
    )
  fbhwrfsm
   (
    // Outputs
    .y_data_bufr_almost_empty_o                (y_data_bufr_almost_empty),
    .y_data_bufr_rst_busy_o                    (y_data_bufr_rst_busy),
    .ddr_mem_wr_burst_complete_o               (ddr_mem_wr_burst_complete),
    .ddr_mem_wr_burst_resp_complete_o          (ddr_mem_wr_burst_resp_complete),
    .full_frame_wr_completed_o                 (full_frame_wr_completed),
    .bufr_already_selected_o                   (bufr_already_selected),
    .first_bufr_selected_o                     (first_bufr_selected),
    .full_frame_wr_completed_arr_o             (full_frame_wr_completed_arr_o),
    .fbh_wr_addr_nd_ctrl_o                     (fbh_wr_addr_nd_ctrl_o),
   	.update_wr_dev_num_o                       (update_wr_dev_num),

    .y_data_bufr_full_o                        (y_data_bufr_full_o),
    .y_data_bufr_empty_o                       (y_data_bufr_empty_o),

    // Master Write Address Channel
    .axi_m0_awready_i                          (axi_m0_awready_i),
    .axi_m0_awaddr_o                           (axi_m0_awaddr_o),
    .axi_m0_awvalid_o                          (axi_m0_awvalid_o),
    .axi_m0_awburst_o                          (axi_m0_awburst_o),
    .axi_m0_awid_o                             (axi_m0_awid_o),
    .axi_m0_awlen_o                            (axi_m0_awlen_o),
    .axi_m0_awlock_o                           (axi_m0_awlock_o),
    .axi_m0_awsize_o                           (axi_m0_awsize_o),

    // Master Write Data Channel
    .axi_m0_wready_i                           (axi_m0_wready_i),
    .axi_m0_wlast_o                            (axi_m0_wlast_o),
    .axi_m0_wvalid_o                           (axi_m0_wvalid_o),
    .axi_m0_wdata_o                            (axi_m0_wdata_o),
    .axi_m0_wstrb_o                            (axi_m0_wstrb_o),

    // Master Write Response Channel
    .axi_m0_bid_i                             (axi_m0_bid_i),
    .axi_m0_bvalid_i                          (axi_m0_bvalid_i),
    .axi_m0_bready_o                          (axi_m0_bready_o),

    // Inputs
    .hdmi_clk                                 (hdmi_clk),
    .axi_clk                                  (axi_clk),
    .hdmi_clk_reset_n                         (hdmi_clk_reset_n),
    .axi_clk_reset_n                          (axi_clk_reset_n),
    .sel_vsync_axi_clk_i                      (sel_vsync_axi_clk_i),
    .sel_vsync_hdmi_i                         (sel_vsync_hdmi_i),
    .sel_vsync_hdmi_pe_pl_i                   (sel_vsync_hdmi_pe_pl_i),
    .sel_vsync_hdmi_ne_pl_i                   (sel_vsync_hdmi_ne_pl_i),
   	.sel_hsync_hdmi_i                         (sel_hsync_hdmi_i),
    .sel_vid_data_i                           (sel_vid_data_i),

    .ddr_wr_xfer_axi_clk_i                    (ddr_wr_xfer_axi_clk_arr_o),
    .ddr_wr_xfer_hdmi_clk_arr_i               (ddr_wr_xfer_hdmi_clk_arr_i),
    .frame_size_info_i                        (frame_size_in_bytes),
    .yuv_420_en_axi_clk_i                     (yuv_420_en_axi_clk),
    .sel_d_reset_or_hdmi_src_connect_axi_clk_i (sel_d_reset_or_hdmi_src_connect_axi_clk),
    .full_frame_wr_completed_hdmi_clk_arr_i   (full_frame_wr_completed_hdmi_clk_arr_i),
    .dev_reg_info_st_arr_axi_clk_i            (dev_reg_info_st_arr_axi_clk_i),
    .dev_reg_info_st_arr_gpif_clk_i           (dev_reg_info_st_arr_gpif_clk_i),
    .dev_reg_info_st_arr_hdmi_clk_i           (dev_reg_info_st_arr_hdmi_clk_i),
    .fbh_rd_states_nd_ctrl_i                  (fbh_rd_states_nd_ctrl_i),
    .fbh_rd_dsf_flags_arr_i                   (fbh_rd_dsf_flags_arr_i),
    .common_reg_info_i                        (common_reg_info_i),
    .wr_starting_address_i                    (wr_starting_address),
    .no_of_bytes_in_single_line_i             (no_of_bytes_in_single_line),
    .fbh_wr_fsm_sel_device_num_i              (fbh_wr_dsf_sel_device_num),
    .fbh_wr_fsm_start_serving_device_pl_i     (fbh_wr_dsf_start_serving_device_pl),
    .sel_next_bufr_i                          (fbh_wr_dsf_sel_next_bufr_pl),
    .first_sel_next_bufr_i                    (fbh_wr_dsf_first_sel_next_bufr_pl),
    .ddr_init_done_i                          (ddr_init_done_i)

    );


endmodule


