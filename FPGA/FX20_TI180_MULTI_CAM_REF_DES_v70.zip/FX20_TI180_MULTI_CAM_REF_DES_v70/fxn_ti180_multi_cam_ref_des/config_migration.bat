:: Copy the file contents
@echo off
CLS
echo File content copy script

echo ****************************************WARNING*********************************************
echo        [1;5;33m Make sure EFINITY project is closed while running this script[0m
echo ********************************************************************************************
echo.

setlocal

:: Set Source Files
SET SOURCE1_DVK_LVDS=design_files\LVDS\fxn_ti180_dvk_multi_cam_ref_des.peri.xml
SET SOURCE1_DVK_LVCMOS_SDR=design_files\LVCMOS\SDR\fxn_ti180_dvk_multi_cam_ref_des.peri.xml
SET SOURCE1_DVK_LVCMOS_DDR=design_files\LVCMOS\DDR\fxn_ti180_dvk_multi_cam_ref_des.peri.xml

SET SOURCE1_SDK_LVDS=design_files\LVDS\fxn_ti180_sdk_multi_cam_ref_des.peri.xml
SET SOURCE1_SDK_LVCMOS_SDR=design_files\LVCMOS\SDR\fxn_ti180_sdk_multi_cam_ref_des.peri.xml
SET SOURCE1_SDK_LVCMOS_DDR=design_files\LVCMOS\DDR\fxn_ti180_sdk_multi_cam_ref_des.peri.xml

SET DESTINATION1=fxn_ti180_multi_cam_ref_des.peri.xml

SET SOURCE2_DVK=design_files\fxn_ti180_dvk_multi_cam_ref_des.xml
SET SOURCE2_SDK=design_files\fxn_ti180_sdk_multi_cam_ref_des.xml
SET DESTINATION2=fxn_ti180_multi_cam_ref_des.xml

SET SOURCE3_DVK_LVDS=design_files\LVDS\fxn_ti180_dvk_multi_cam_ref_des.sdc
SET SOURCE3_DVK_LVCMOS_SDR=design_files\LVCMOS\SDR\fxn_ti180_dvk_multi_cam_ref_des.sdc
SET SOURCE3_DVK_LVCMOS_DDR=design_files\LVCMOS\DDR\fxn_ti180_dvk_multi_cam_ref_des.sdc

SET SOURCE3_SDK_LVDS=design_files\LVDS\fxn_ti180_sdk_multi_cam_ref_des.sdc
SET SOURCE3_SDK_LVCMOS_SDR=design_files\LVCMOS\SDR\fxn_ti180_sdk_multi_cam_ref_des.sdc
SET SOURCE3_SDK_LVCMOS_DDR=design_files\LVCMOS\DDR\fxn_ti180_sdk_multi_cam_ref_des.sdc

SET DESTINATION3=sdc\fxn_ti180_multi_cam_ref_des.sdc

echo Select SDK or DVK
echo DVK - Project Configuration for FX20/10/5 DVK and FPGA Ti180J484 DVK
echo SDK - Project Configuration for 4 MIPI solution demo kit
echo

:MENU

SET /P CHOICE="Enter SDK or DVK:" (SDK/DVK)
echo Selected : "%CHOICE%"
SET /P INTERFACE="Enter LVCMOS or LVDS:" (LVCMOS/LVDS)
echo Choose Interface : "%INTERFACE%"

IF /I "%INTERFACE%"=="LVCMOS" (
SET /P INTERFACE_MODE="Enter SDR or DDR:" (SDR/DDR)
echo Selected Mode : "%INTERFACE_MODE%"
)
echo *****************************************
echo STEP 0: SELECTING SOURCE
echo *****************************************

IF /I "%CHOICE%"=="DVK" IF /I "%INTERFACE%"=="LVDS" GOTO DVK_LVDS
IF /I "%CHOICE%"=="DVK" IF /I "%INTERFACE%"=="LVCMOS" GOTO DVK_LVCMOS
IF /I "%CHOICE%"=="SDK" IF /I "%INTERFACE%"=="LVDS" GOTO SDK_LVDS
IF /I "%CHOICE%"=="SDK" IF /I "%INTERFACE%"=="LVCMOS" GOTO SDK_LVCMOS

:DVK_LVDS
    SET SOURCE1="%SOURCE1_DVK_LVDS%"
    SET SOURCE2="%SOURCE2_DVK%"
    SET SOURCE3="%SOURCE3_DVK_LVDS%"
    GOTO NEXT_STEP

:DVK_LVCMOS
    IF /I "%INTERFACE_MODE%"=="SDR" GOTO DVK_LVCMOS_SDR   
    IF /I "%INTERFACE_MODE%"=="DDR" GOTO DVK_LVCMOS_DDR

:DVK_LVCMOS_SDR
    SET SOURCE1="%SOURCE1_DVK_LVCMOS_SDR%"
    SET SOURCE2="%SOURCE2_DVK%"
    SET SOURCE3="%SOURCE3_DVK_LVCMOS_SDR%"
    GOTO NEXT_STEP

:DVK_LVCMOS_DDR
    SET SOURCE1="%SOURCE1_DVK_LVCMOS_DDR%"
    SET SOURCE2="%SOURCE2_DVK%"
    SET SOURCE3="%SOURCE3_DVK_LVCMOS_DDR%"
    GOTO NEXT_STEP

:SDK_LVDS
    SET SOURCE1="%SOURCE1_SDK_LVDS%"
    SET SOURCE2="%SOURCE2_SDK%"
    SET SOURCE3="%SOURCE3_SDK_LVDS%"
    GOTO NEXT_STEP

:SDK_LVCMOS      
    IF /I "%INTERFACE_MODE%"=="SDR" GOTO SDK_LVCMOS_SDR   
    IF /I "%INTERFACE_MODE%"=="DDR" GOTO SDK_LVCMOS_DDR

:SDK_LVCMOS_SDR
    SET SOURCE1="%SOURCE1_SDK_LVCMOS_SDR%"
    SET SOURCE2="%SOURCE2_SDK%"
    SET SOURCE3="%SOURCE3_SDK_LVCMOS_SDR%"
    GOTO NEXT_STEP
 
:SDK_LVCMOS_DDR
    SET SOURCE1="%SOURCE1_SDK_LVCMOS_DDR%"
    SET SOURCE2="%SOURCE2_SDK%"
    SET SOURCE3="%SOURCE3_SDK_LVCMOS_DDR%"
    GOTO NEXT_STEP

echo Error: Invalid Choice. Please run again
GOTO END

:NEXT_STEP

echo *****************************************
echo STEP 1: COPYING CONTENTS
echo *****************************************
  copy "%SOURCE1%" "%DESTINATION1%" >nul
  IF %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to Copy peri.xml file
    PAUSE
    EXIT /B 1
)
  copy "%SOURCE2%" "%DESTINATION2%" >nul
    IF %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to Copy .xml file
    PAUSE
    EXIT /B 1
)
  copy "%SOURCE3%" "%DESTINATION3%" >nul

IF %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to Copy .sdc file contents.
    PAUSE
    EXIT /B 1
)
      echo Success: File contents copied successfully.
      GOTO END

:END
echo Exiting...
PAUSE
EXIT /B 0

