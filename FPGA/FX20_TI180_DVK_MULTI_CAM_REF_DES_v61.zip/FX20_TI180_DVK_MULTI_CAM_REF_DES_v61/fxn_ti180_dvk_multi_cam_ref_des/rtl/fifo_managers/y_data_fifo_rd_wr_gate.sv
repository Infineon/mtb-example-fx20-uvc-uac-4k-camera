//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:  FX10/20 Design
// Module Name:  y_data_fifo_rd_wr_gate
// Target Devices: Ti180
//
// Description: This module acts as a gate of the Y data FIFO, which is the onchip
//              memory for input data. When DDR buffer is not used, this onchip
//              FIFO is used as a storage.
//
//////////////////////////////////////////////////////////////////////////////////

// Timescale
`timescale 1 ns / 100 ps

module y_data_fifo_rd_wr_gate
 #
 (
  // HDMI/Test Pattern Data Width
  parameter Y_DATA_FIFO_WR_DATA_WIDTH_IN_BITS_I = 64,

  // FIFO read data width. Same as Slave FIFO write data width
  parameter Y_DATA_FIFO_RD_DATA_WIDTH_IN_BITS_I = 256,

  // Y Data FIFO Depth
  parameter Y_DATA_FIFO_DEPTH_IN_WORDS_I = 8192,

  // AXI Master Burst Size
  parameter MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I = 3840
 )
 (
  // Input clock and reset
  input              wr_clk,
  input              wr_reset_n,
  input              rd_clk,
  input              rd_reset_n,

  input              sel_d_reset_or_stop_stream_req_i,
  input              vsync_pe_pl_i,
  input              vsync_axi_clk_i,
  input              y_fifo_wr_req_i,
  input      [ ( Y_DATA_FIFO_WR_DATA_WIDTH_IN_BITS_I-1 ):0] y_fifo_wr_data_i,

  // Slave fifo Related signals
  input              slfifo_almost_full_i,
  input              slfifo_reset_busy_i,
  input              slfifo_full_i,

  output             y_data_bufr_empty_o,
  output             y_data_bufr_full_o,
  output             y_data_bufr_overflow_o,
  output             y_data_bufr_almost_full_o,
  output logic       slfifo_wr_req_o,
  output logic [(Y_DATA_FIFO_RD_DATA_WIDTH_IN_BITS_I-1):0] slfifo_wr_data_o

  // output             full_frame_wr_complete_wo_bufr_o
 );


// -------------------------------------
//
// Local Variables
//
// -------------------------------------

  logic  y_fifo_reset_req;
  logic  y_fifo_reset_busy;

  logic  y_fifo_rd_req;
  logic  y_fifo_rd_data_valid;
  logic  [(Y_DATA_FIFO_RD_DATA_WIDTH_IN_BITS_I-1):0] y_fifo_rd_data;

// -------------------------------------
//
// Y data FIFO
//
// -------------------------------------

y_data_fifo
 #
 (
  // Parameters
  .WR_DATA_WIDTH_IN_BITS_I ( Y_DATA_FIFO_WR_DATA_WIDTH_IN_BITS_I ),
  .RD_DATA_WIDTH_IN_BITS_I ( Y_DATA_FIFO_RD_DATA_WIDTH_IN_BITS_I ),
  .FIFO_DEPTH_IN_WORDS_I   ( Y_DATA_FIFO_DEPTH_IN_WORDS_I )
 )
  onchip_y_fifo
  (
   .almost_full_o  (  ),
   .prog_full_o    ( y_data_bufr_almost_full_o ),
   .full_o         ( y_data_bufr_full_o ),
   .overflow_o     ( y_data_bufr_overflow_o ),
   .wr_ack_o       (  ),
   .empty_o        ( y_data_bufr_empty_o ),
   .almost_empty_o (  ),
   .prog_empty_o   (  ),
   .underflow_o    (  ),
   .rd_valid_o     ( y_fifo_rd_data_valid ),
   .rdata          ( y_fifo_rd_data ),
   .wr_clk_i       ( wr_clk ),
   .rd_clk_i       ( rd_clk ),
   .wr_en_i        ( y_fifo_wr_req_i /* & !y_data_bufr_almost_full_o */ ), // As almost full is used to pause FV LV Generator
   .rd_en_i        ( y_fifo_rd_req ),
   .wdata          ( y_fifo_wr_data_i ),
   .wr_datacount_o (  ),
   .rd_datacount_o (  ),
   .a_rst_i        ( y_fifo_reset_req ),
   .rst_busy       ( y_fifo_reset_busy )
  );


// -------------------------------------
//
// Y Data Buffer Reset
//
// -------------------------------------

always_ff @ ( posedge wr_clk  )
  begin
    if ( ~wr_reset_n )
      begin
        y_fifo_reset_req <= 1'b1;
      end
    else
      begin
        y_fifo_reset_req <= (
                              ( ( vsync_pe_pl_i == 1'b1 ) & ( y_data_bufr_empty_o == 1'b1 ) ) |
                              ( sel_d_reset_or_stop_stream_req_i == 1'b1 )
                            );
      end
  end


// -------------------------------------
//
// Y Data FIFO Read Logic
//
// -------------------------------------

// Read Request
assign y_fifo_rd_req = ( ( y_data_bufr_empty_o == 1'b0 )  &
                         ( slfifo_almost_full_i == 1'b0 ) &
                         /* ( slfifo_full_i == 1'b0 )        & */
                         ( slfifo_reset_busy_i == 1'b0 )  /* &
                         ( y_fifo_reset_busy == 1'b0 ) */
                       );

// -------------------------------------
//
// Slave FIFO Write Logic
//
// -------------------------------------

// Write Request
always_ff @ ( posedge rd_clk or negedge rd_reset_n )
  begin
    if ( ~rd_reset_n )
      begin
        slfifo_wr_req_o <= 1'b0;
      end
    else
      begin
        slfifo_wr_req_o <= y_fifo_rd_data_valid;
      end
  end

// Read Data
always_ff @ ( posedge rd_clk or negedge rd_reset_n )
  begin
    if ( ~rd_reset_n )
      begin
        slfifo_wr_data_o <= 128'h0;
      end
    else
      begin
        slfifo_wr_data_o <= y_fifo_rd_data;
      end
  end


// -------------------------------------
//
// Debug
//
// -------------------------------------

reg [31:0] y_fifo_wr_count;
reg [31:0] y_fifo_rd_count;
reg        vsync_axi_clk_f1;
reg        vsync_axi_clk_pe_pl;

// assign full_frame_wr_complete_wo_bufr_o = (y_fifo_wr_count == 32'hFD_2000);

always_ff @ ( posedge wr_clk  )
  begin
    if ( ~wr_reset_n )
      begin
        y_fifo_wr_count <= 32'd0;
      end
    else if ( vsync_pe_pl_i | sel_d_reset_or_stop_stream_req_i )
      begin
        y_fifo_wr_count <= 32'd0;
      end
    else if ( y_fifo_wr_req_i )
      begin
        y_fifo_wr_count <= y_fifo_wr_count + (Y_DATA_FIFO_WR_DATA_WIDTH_IN_BITS_I/8);
      end
  end

always_ff @ ( posedge rd_clk or negedge rd_reset_n )
  begin
    if ( ~rd_reset_n )
      begin
        y_fifo_rd_count <= 32'd0;
      end
    else if ( vsync_axi_clk_pe_pl | sel_d_reset_or_stop_stream_req_i )
      begin
        y_fifo_rd_count <= 32'd0;
      end
    else if ( y_fifo_rd_req )
      begin
        y_fifo_rd_count <= y_fifo_rd_count + (Y_DATA_FIFO_RD_DATA_WIDTH_IN_BITS_I/8);
      end
  end

always_ff @ ( posedge rd_clk or negedge rd_reset_n )
  begin
    if ( ~rd_reset_n )
      begin
        vsync_axi_clk_f1    <= 1'd0;
        vsync_axi_clk_pe_pl <= 1'd0;
      end
    else
      begin
        vsync_axi_clk_f1    <= vsync_axi_clk_i;
        vsync_axi_clk_pe_pl <= (vsync_axi_clk_i & !vsync_axi_clk_f1);
      end
  end

endmodule