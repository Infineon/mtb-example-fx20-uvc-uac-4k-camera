//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    ddr_config_manager
// Target Devices: Ti180
//
// Description: This module provide information regarding configuration
//              of DDR memory is done or not.
//
//////////////////////////////////////////////////////////////////////////////////

// Timescale
`timescale 1 ns / 100 ps

module ddr_config_manager
(
  input            clk_i,                            // AXI user clock
  input            reset_n_i,                        // Main user Async active low reset
  input            ddr_cfg_done_i,

  output  logic    ddr_cfg_done_o,                   // ddr_config_status.
  output  logic    ddr_cfg_seq_start_o,
  output  logic    ddr_cfg_seq_rst_o,
  output  logic    ddr_cfg_seq_sel_o

);


  // FSM States
  enum logic [2:0] {
    IDLE              = 3'h1,
    CFG_START         = 3'h2,
    CFG_DONE          = 3'h4
  } cfg_cs, cfg_ns;

// -------------------------------------
//
//  Local Variables
//
// -------------------------------------

logic       ddr_cfg_done;
logic       ddr_cfg_seq_start;
logic       ddr_cfg_seq_rst;
logic       ddr_cfg_seq_sel;
logic       cfg_valid_count;
logic [7:0] cfg_count;

// -------------------------------------
//
//  DDR4 config State machine
//
// -------------------------------------

  // Current State

always_ff @(posedge clk_i)
 begin
  if(~reset_n_i)
   begin
    cfg_cs <= IDLE;
   end
  else
   begin
    cfg_cs <= cfg_ns;
   end
 end

// Next State

always_comb
 begin
   cfg_ns <= IDLE;
  unique case(cfg_cs)
   IDLE:
    begin
     if(cfg_count == 8'hff)
      cfg_ns <= CFG_START;
     else
      cfg_ns <= IDLE;
    end
   CFG_START:
    begin
     if(ddr_cfg_done_i)   // Configuration Done signal from DDR
      cfg_ns <= CFG_DONE;
     else
      cfg_ns <= CFG_START;
     end
   CFG_DONE:
    cfg_ns <= CFG_DONE;
  endcase
 end

// Next state signals

always_comb
 begin
  cfg_valid_count   <= 1'b0;
  ddr_cfg_seq_start <= 1'b0;
  ddr_cfg_done      <= 1'b0;
  ddr_cfg_seq_rst   <= 1'b0;
  ddr_cfg_seq_sel   <= 1'b0;                 //Always zero

   unique case(cfg_cs)
    IDLE:
     begin
      cfg_valid_count   <= 1'b1;
      ddr_cfg_seq_rst   <= 1'b1;
     end
    CFG_START:
     begin
      ddr_cfg_seq_start <= 1'b1;
     end
    CFG_DONE:
     begin
      ddr_cfg_seq_start <= 1'b1;
      ddr_cfg_done      <= 1'b1;
     end
   endcase
 end

// Counter used

always_ff @(posedge clk_i)
 begin
  if(~reset_n_i)
   begin
    cfg_count <= 8'h0;
   end
  else if(cfg_valid_count)
   begin
    cfg_count <= cfg_count + 8'h1;
   end
  else
   cfg_count <= 8'h0;
 end


always_ff @(posedge clk_i)
 begin
  if(~reset_n_i)
   begin
    ddr_cfg_seq_start_o <= 1'b0;
    ddr_cfg_done_o      <= 1'b0;
    ddr_cfg_seq_rst_o   <= 1'b0;
    ddr_cfg_seq_sel_o   <= 1'b0;
   end
  else
   begin
    ddr_cfg_seq_start_o <= ddr_cfg_seq_start;
    ddr_cfg_done_o      <= ddr_cfg_done;
    ddr_cfg_seq_rst_o   <= ddr_cfg_seq_rst;
    ddr_cfg_seq_sel_o   <= ddr_cfg_seq_sel;
   end
 end

endmodule


//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2019 Efinix Inc. All rights reserved.
//
// This   document  contains  proprietary information  which   is
// protected by  copyright. All rights  are reserved.  This notice
// refers to original work by Efinix, Inc. which may be derivitive
// of other work distributed under license of the authors.  In the
// case of derivative work, nothing in this notice overrides the
// original author's license agreement.  Where applicable, the
// original license agreement is included in it's original
// unmodified form immediately below this header.
//
// WARRANTY DISCLAIMER.
//     THE  DESIGN, CODE, OR INFORMATION ARE PROVIDED “AS IS” AND
//     EFINIX MAKES NO WARRANTIES, EXPRESS OR IMPLIED WITH
//     RESPECT THERETO, AND EXPRESSLY DISCLAIMS ANY IMPLIED WARRANTIES,
//     INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
//     MERCHANTABILITY, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR
//     PURPOSE.  SOME STATES DO NOT ALLOW EXCLUSIONS OF AN IMPLIED
//     WARRANTY, SO THIS DISCLAIMER MAY NOT APPLY TO LICENSEE.
//
// LIMITATION OF LIABILITY.
//     NOTWITHSTANDING ANYTHING TO THE CONTRARY, EXCEPT FOR BODILY
//     INJURY, EFINIX SHALL NOT BE LIABLE WITH RESPECT TO ANY SUBJECT
//     MATTER OF THIS AGREEMENT UNDER TORT, CONTRACT, STRICT LIABILITY
//     OR ANY OTHER LEGAL OR EQUITABLE THEORY (I) FOR ANY INDIRECT,
//     SPECIAL, INCIDENTAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES OF ANY
//     CHARACTER INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF
//     GOODWILL, DATA OR PROFIT, WORK STOPPAGE, OR COMPUTER FAILURE OR
//     MALFUNCTION, OR IN ANY EVENT (II) FOR ANY AMOUNT IN EXCESS, IN
//     THE AGGREGATE, OF THE FEE PAID BY LICENSEE TO EFINIX HEREUNDER
//     (OR, IF THE FEE HAS BEEN WAIVED, $100), EVEN IF EFINIX SHALL HAVE
//     BEEN INFORMED OF THE POSSIBILITY OF SUCH DAMAGES.  SOME STATES DO
//     NOT ALLOW THE EXCLUSION OR LIMITATION OF INCIDENTAL OR
//     CONSEQUENTIAL DAMAGES, SO THIS LIMITATION AND EXCLUSION MAY NOT
//     APPLY TO LICENSEE.
//
/////////////////////////////////////////////////////////////////////////////