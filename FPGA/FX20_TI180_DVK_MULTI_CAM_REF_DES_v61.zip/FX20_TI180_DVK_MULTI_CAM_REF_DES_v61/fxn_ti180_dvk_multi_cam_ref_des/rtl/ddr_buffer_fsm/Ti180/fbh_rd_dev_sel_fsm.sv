//////////////////////////////////////////////////////////////////////////////////
//(c) 2022-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:  FX10/20 Design
// Module Name:  fbh_rd_dev_sel_fsm
// Target Devices: Ti180
//
// Description: This module is responsible for selecting device number for reading
//              data into/from DDR4 memory for that particular device.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module fbh_rd_dev_sel_fsm
  #
  (

  // Slave FIFO Depth
  parameter SLFIFO_DEPTH_IN_WORDS_I = 512,

   // No. of devices/ FIFOs needed
  parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
  parameter SEL_DEV_NUM_BITS_I  = 3

  )
 (

  // Outputs
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]  sel_d_reset_or_stop_stream_req_axi_clk_o,
  output logic [31:0]              sel_d_frame_size_in_bytes_o,
  output logic [(SEL_DEV_NUM_BITS_I-1):0]  fbh_rd_dsf_sel_device_num_o,
  output fbh_rd_dsf_flags_st_t      [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_rd_dsf_flags_arr_o,


  output                           dev_reg_info_st_t device_status_gpif_clk_o, // Device Specific Register Information in gpif clk domain
  output                           dev_reg_info_st_t device_status_axi_clk_o,  // Device Specific Register Information in axi clk domain

  // Input
  input                              clk,
  input                              reset_n,
  input                              ddr_init_done_i,   // From ddr config manager
  input                              update_dev_num_i,  // From rd_fsm
  input  [(NO_OF_SUPPORTED_DEV_I-1):0] sel_vsync_axi_clk_i,

  input  fbh_wr_addr_nd_ctrl_st_t   [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_wr_addr_nd_ctrl_i,   // Common signals between write and read FBH modules
  input  fbh_rd_states_nd_ctrl_st_t [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_rd_states_nd_ctrl_i, // Common signals between read FBH modules
  input  common_reg_info_st_t                                      common_reg_info_i,
  input  slfifo_data_nd_status_st_t [(NO_OF_SUPPORTED_DEV_I-1):0]  slfifo_status_i,         // Slfifo  status signals
  input  dev_reg_info_st_t          [(NO_OF_SUPPORTED_DEV_I-1):0]  device_status_arr_gpif_clk_i,
  input  dev_reg_info_st_t          [(NO_OF_SUPPORTED_DEV_I-1):0]  device_status_arr_axi_clk_i


 );


// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // Device switching delay clocks

  localparam NO_OF_DEVICE_SWITCH_DELAY_CLOCKS = 3'd5;

  // No of States
  localparam NO_OF_FSM_STATES = 4'd10;

  // FSM States
  enum logic [(NO_OF_FSM_STATES-1):0] {
    IDLE                                = 10'h1,
    IS_DEVICE_AVAILABLE_TO_RD           = 10'h2,
    SEL_RD_BUFR                         = 10'h4,
    CHECK_RD_BUFR_SELECTED_OR_NOT       = 10'h8,
    CHECK_SLFIFO_FULL                   = 10'h10,
    SERVE_SEL_DEV                       = 10'h20,
    WAIT_SEL_DEV_SERVED                 = 10'h40,
    INCR_DEV_NUMBER                     = 10'h80,
    WAIT_INCR_DEV_NUMBER                = 10'h100,
    DDR_RD_START                        = 10'h200
  } fbh_rd_dsf_dev_s_cs, fbh_rd_dsf_dev_s_ns;

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  // FSM Signals
  logic                           fbh_rd_dsf_incr_dev_num_pl;
  logic  [2:0]                    device_sw_count;
  logic                           incr_device_sw_count_pl;
  logic                           sel_d_start_stream_axi_clk_o;
  logic [31:0]                    sel_d_frame_size_in_pixels;
  logic [(SEL_DEV_NUM_BITS_I-1):0]  fbh_rd_dsf_sel_int_device_num;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0]  sel_rd_frame_buf_f1;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0]  sel_rd_frame_buf_f2;

// ------------------------------------------
//
// FSM
//
// ------------------------------------------


// Current State
always_ff @ ( posedge clk )
  begin
    if ( !reset_n || !ddr_init_done_i )
      begin
        fbh_rd_dsf_dev_s_cs <= IDLE;
      end
    else if ( sel_d_reset_or_stop_stream_req_axi_clk_o[fbh_rd_dsf_sel_device_num_o] )   // To handle sudden start_stop condition on actual device
      begin
        fbh_rd_dsf_dev_s_cs <= INCR_DEV_NUMBER;
      end
    else
      begin
        fbh_rd_dsf_dev_s_cs <= fbh_rd_dsf_dev_s_ns;
      end
  end


// Next State
always_comb
  begin
    fbh_rd_dsf_dev_s_ns <= IDLE;
    unique case ( fbh_rd_dsf_dev_s_cs )

      // Wait until DDR is initialised.
      IDLE :
        begin
          if ( ddr_init_done_i )
            begin
              fbh_rd_dsf_dev_s_ns <= IS_DEVICE_AVAILABLE_TO_RD;
            end
          else
            begin
              fbh_rd_dsf_dev_s_ns <= IDLE;
            end
        end

      // Confirm read frame number is not equal to write frame number .
      IS_DEVICE_AVAILABLE_TO_RD :
        begin
           if ( sel_d_reset_or_stop_stream_req_axi_clk_o[fbh_rd_dsf_sel_device_num_o] == 1'b0 )
            begin
              fbh_rd_dsf_dev_s_ns <= SEL_RD_BUFR;
            end
          else
            begin
              fbh_rd_dsf_dev_s_ns <= INCR_DEV_NUMBER;
            end
        end

      // Select read buffer
      SEL_RD_BUFR :
        begin
           fbh_rd_dsf_dev_s_ns <= WAIT_INCR_DEV_NUMBER;
        end

      // Check if read Buffer is already selected for particular device or not
      CHECK_RD_BUFR_SELECTED_OR_NOT :
        begin
          if ( sel_d_reset_or_stop_stream_req_axi_clk_o[fbh_rd_dsf_sel_int_device_num] == 1'b0 )
            begin
              if ( fbh_rd_dsf_flags_arr_o[fbh_rd_dsf_sel_device_num_o].bufr_already_selected )
                begin
                  fbh_rd_dsf_dev_s_ns <= DDR_RD_START;
                end
              else
                begin
                  fbh_rd_dsf_dev_s_ns <= IDLE;
                end
            end
          else
            begin
              fbh_rd_dsf_dev_s_ns <= INCR_DEV_NUMBER;
            end
        end

      DDR_RD_START :
        begin
          fbh_rd_dsf_dev_s_ns <= CHECK_SLFIFO_FULL;
        end

      // Check if SlaveFIFO is Full or available to Read.
      CHECK_SLFIFO_FULL :
          begin
            if ( ( slfifo_status_i[fbh_rd_dsf_sel_device_num_o].full == 1'b0 ) &
                 ( fbh_rd_states_nd_ctrl_i[fbh_rd_dsf_sel_device_num_o].ddr_mem_rd_en ) &
                 ( slfifo_status_i[fbh_rd_dsf_sel_device_num_o].reset_busy == 1'b0 ) &
                 ( ( SLFIFO_DEPTH_IN_WORDS_I - (slfifo_status_i[fbh_rd_dsf_sel_device_num_o].wr_data_count) ) > AXI_M0_ARLEN )
               ) // If same buffer is read, make sure that
              begin
                fbh_rd_dsf_dev_s_ns <= SERVE_SEL_DEV;
              end
            else
              begin
                fbh_rd_dsf_dev_s_ns <= INCR_DEV_NUMBER;
              end
          end

      // Instruct the Read FSM to start reading data.
      SERVE_SEL_DEV :
       begin
         fbh_rd_dsf_dev_s_ns <= WAIT_SEL_DEV_SERVED;
       end

      // Wait until current device is served
      WAIT_SEL_DEV_SERVED :
       begin
        if ( update_dev_num_i )
         begin
          fbh_rd_dsf_dev_s_ns <= INCR_DEV_NUMBER;
         end
        else
         begin
          fbh_rd_dsf_dev_s_ns <= WAIT_SEL_DEV_SERVED;
         end
       end

      // Move to next device
      INCR_DEV_NUMBER :
       begin
         fbh_rd_dsf_dev_s_ns <= WAIT_INCR_DEV_NUMBER;
       end

      // Device switching delay clocks
      WAIT_INCR_DEV_NUMBER :
       begin
         if ( device_sw_count == NO_OF_DEVICE_SWITCH_DELAY_CLOCKS )
           begin
             fbh_rd_dsf_dev_s_ns <= CHECK_RD_BUFR_SELECTED_OR_NOT;
           end
         else
           begin
             fbh_rd_dsf_dev_s_ns <= WAIT_INCR_DEV_NUMBER;
           end
       end

    endcase
  end


// Next State: Signals
always_comb
  begin

    fbh_rd_dsf_flags_arr_o[fbh_rd_dsf_sel_device_num_o].sel_rd_frame_buf        <= 1'b0;
    fbh_rd_dsf_flags_arr_o[fbh_rd_dsf_sel_device_num_o].start_serving_device_pl <= 1'b0;
    fbh_rd_dsf_incr_dev_num_pl          <= 1'b0;
    incr_device_sw_count_pl             <= 1'b0;

    unique case ( fbh_rd_dsf_dev_s_cs )

      // Wait until DDR is initialised.
      IDLE :
        begin

        end

      // Confirm read frame number is not equal to write frame number .
      IS_DEVICE_AVAILABLE_TO_RD :
        begin

        end

      // Select read buffer
      SEL_RD_BUFR :
        begin
           fbh_rd_dsf_flags_arr_o[fbh_rd_dsf_sel_device_num_o].sel_rd_frame_buf <= 1'b1;
        end

      // Check if read Buffer is already selected for particular device or not
      CHECK_RD_BUFR_SELECTED_OR_NOT :
        begin

        end

      DDR_RD_START :
        begin

        end

      // Check if SlaveFIFO is Full or available to Read.
      CHECK_SLFIFO_FULL :
        begin

        end

      // Device has data. Let's serve it.
      SERVE_SEL_DEV :
        begin
          fbh_rd_dsf_flags_arr_o[fbh_rd_dsf_sel_device_num_o].start_serving_device_pl <= 1'b1;
        end

      // Wait until device is served.
      WAIT_SEL_DEV_SERVED :
        begin

        end

      // Move to next device
      INCR_DEV_NUMBER :
        begin
          fbh_rd_dsf_incr_dev_num_pl <= 1'b1;
        end

  // Device switching delay clocks
      WAIT_INCR_DEV_NUMBER :
        begin
          incr_device_sw_count_pl <= 1'b1;
        end

    endcase
  end


// ------------------------------------------
//
//  Registering the outputs
//
// ------------------------------------------

  // 2 FFs delay for generating read bufr already selected signal
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          sel_rd_frame_buf_f1[fbh_rd_dsf_sel_device_num_o]  <= 1'b0;
          sel_rd_frame_buf_f2[fbh_rd_dsf_sel_device_num_o]  <= 1'b0;
        end
      else
        begin
          sel_rd_frame_buf_f1[fbh_rd_dsf_sel_device_num_o]  <= fbh_rd_dsf_flags_arr_o[fbh_rd_dsf_sel_device_num_o].sel_rd_frame_buf;
          sel_rd_frame_buf_f2[fbh_rd_dsf_sel_device_num_o]  <= sel_rd_frame_buf_f1[fbh_rd_dsf_sel_device_num_o];
        end
    end


// ------------------------------------------
//
// Selected Device
//
// ------------------------------------------


// Internal Device Number
// It is used by FSM to check whether device is active or not.
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        fbh_rd_dsf_sel_int_device_num <= 3'd0;
      end
    else if ( fbh_rd_dsf_incr_dev_num_pl )
      begin
        if ( fbh_rd_dsf_sel_int_device_num == ( NO_OF_SUPPORTED_DEV_I - 1'b1 ) )
          begin
            fbh_rd_dsf_sel_int_device_num <= '0;
          end
        else
          begin
            fbh_rd_dsf_sel_int_device_num <= fbh_rd_dsf_sel_int_device_num + 1'b1;
          end
      end
  end

// Actual Device Number
// It is used by FBH Module based on sel_start_stream
generate
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fbh_rd_dsf_sel_device_num_o <= '0;
      end
    else if ( fbh_rd_dsf_incr_dev_num_pl )
      begin
        if ( fbh_rd_dsf_sel_int_device_num == ( NO_OF_SUPPORTED_DEV_I - 1'b1 ) )
          begin
            if ( sel_d_reset_or_stop_stream_req_axi_clk_o[0] == 1'b0 )
              begin
                fbh_rd_dsf_sel_device_num_o <= '0;
              end
          end
        else if ( sel_d_reset_or_stop_stream_req_axi_clk_o[fbh_rd_dsf_sel_int_device_num + 1] == 1'b0 )
          begin
            fbh_rd_dsf_sel_device_num_o <= fbh_rd_dsf_sel_int_device_num + 1'b1;
          end
      end
  end
endgenerate

// ----------------------------------------------
//
// Switching device requires a 2 or 3 clock cycles to update
// variables.
//
// ----------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        device_sw_count <= 3'd0;
      end
    else if ( incr_device_sw_count_pl == 1'b0 )
      begin
        device_sw_count <= 3'd0;
      end
    else if ( device_sw_count == NO_OF_DEVICE_SWITCH_DELAY_CLOCKS )
      begin
        device_sw_count <= device_sw_count;
      end
    else
      begin
        device_sw_count <= device_sw_count + 1'b1;
      end
  end



// ----------------------------------------------
//
// Updating Structures based on selected device
//
// ----------------------------------------------

// Structure Updation
// It is used by modules to retrive infromation logic regarding variables based on device number.
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        device_status_axi_clk_o <= '{default:0};
      end
    else
      begin
        device_status_axi_clk_o <= device_status_arr_axi_clk_i[fbh_rd_dsf_sel_device_num_o];
      end
  end

// ----------------------------------------------
//
// Updating Structures based on selected device
//
// ----------------------------------------------

// Structure Updation
// It is used by modules to retrive infromation logic regarding variables based on device number.
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        device_status_gpif_clk_o <= '{default:0};
      end
    else
      begin
        device_status_gpif_clk_o <= device_status_arr_gpif_clk_i[fbh_rd_dsf_sel_device_num_o];
      end
  end


// Assertion is delayed until VSYNC is LOW.
// De-assertion will be immediate. It is used by .
// always_ff @ (posedge clk)
//   begin
//     if ( ~reset_n )
//       begin
//         sel_d_start_stream_axi_clk_o <= 1'd0;
//      end
//     else if ( device_status_arr_axi_clk_i[fbh_rd_dsf_sel_device_num_o].start_stream == 1'b0 )
//       begin
//         sel_d_start_stream_axi_clk_o <= 1'b0;
//       end
//     else if (sel_vsync_axi_clk_i[fbh_rd_dsf_sel_device_num_o] == 1'b0 )
//       begin
//         sel_d_start_stream_axi_clk_o <= 1'b1;
//       end
//   end





// ------------------------------------------
//
// Stream Start/Stop and FW Soft Reset
//
// ------------------------------------------

/*
// Soft reset or stop stream request from FW or
// HDMI Source is not connected
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_d_reset_or_stop_stream_req_axi_clk_o <= 1'b0;
      end
    else
      begin
        sel_d_reset_or_stop_stream_req_axi_clk_o <= ( ( device_status_axi_clk_o.fw_soft_reset == 1'b1 ) |
                                                      ( device_status_axi_clk_o.start_stream  == 1'b0 ) |
                                                      ( device_status_axi_clk_o.hdmi_source_connection == 1'b0 )
                                                     );
      end
  end
*/
 genvar i;

 generate
  for (i = 0; i < NO_OF_SUPPORTED_DEV_I; i= i+1)
   begin : stop_stream_req

// Soft reset or stop stream request from FW or
// HDMI Source is not connected
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_d_reset_or_stop_stream_req_axi_clk_o[i] <= 1'b0;
      end
    else
      begin
        sel_d_reset_or_stop_stream_req_axi_clk_o[i] <= ( ( device_status_arr_axi_clk_i[i].fw_soft_reset == 1'b1 ) |
                                                         ( device_status_arr_axi_clk_i[i].start_stream  == 1'b0 ) |
                                                         ( device_status_arr_axi_clk_i[i].hdmi_source_connection == 1'b0 )
                                                        );
      end
  end


  // Generating buffer already selected signal based on selected device
  // Also takes care of Full frame sent
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          fbh_rd_dsf_flags_arr_o[i].bufr_already_selected  <= 1'b0;
        end
      else if ( ( fbh_rd_states_nd_ctrl_i[i].full_frame_rd_completed_o ) |
              ( sel_d_reset_or_stop_stream_req_axi_clk_o[i] ) )
        begin
          fbh_rd_dsf_flags_arr_o[i].bufr_already_selected  <= 1'b0;
        end
      else if ( sel_rd_frame_buf_f2[i] )
        begin
          fbh_rd_dsf_flags_arr_o[i].bufr_already_selected  <= 1'b1;
        end
    end

   end
 endgenerate


// ------------------------------------------
//
// Frame Size In Bytes
//
// ------------------------------------------

//
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_d_frame_size_in_pixels <= 8'd0;
      end
    else
      begin
        sel_d_frame_size_in_pixels <= ( device_status_gpif_clk_o.image_height *
                                        device_status_gpif_clk_o.image_width
                                       );
      end
  end

// Image Size in bytes
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_d_frame_size_in_bytes_o <= 32'd0;
      end
    else
      begin
        case (device_status_gpif_clk_o.image_pixel_width)

          8'd8    : sel_d_frame_size_in_bytes_o <=   sel_d_frame_size_in_pixels;

          8'd12,
          8'd16   : sel_d_frame_size_in_bytes_o <=   sel_d_frame_size_in_pixels << 1'b1;

          8'd24,
          8'd32   : sel_d_frame_size_in_bytes_o <= (sel_d_frame_size_in_pixels << 2'd2);
          default : sel_d_frame_size_in_bytes_o <=   sel_d_frame_size_in_pixels << 1'b1;

        endcase
      end
  end



endmodule
