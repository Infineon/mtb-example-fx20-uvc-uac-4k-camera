//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fbh_wrapper
// Target Devices: Ti180
//
// Description: This is a wrapper for frame buffer handler which includes following modules,
//
//                 1. FBH write wrapper
//                 2. FBH read  wrapper
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


// Timescale
`timescale 1ns/100ps

module fbh_wrapper
  #
  (
  // Slave FIFO Depth
  parameter SLFIFO_DEPTH_IN_WORDS_I     = 512,

  // Slave read data width
  parameter SLFIFO_RD_DATA_WIDTH_IN_BITS_I = 64,

   // Write count data width
   parameter SLFIFO_WR_COUNT_DATA_WIDTH_I = 16,

  // HDMI/Test Pattern Data Width
  parameter Y_DATA_FIFO_WR_DATA_WIDTH_I = 64,

  // AXI Master Write Channel Data Width
  parameter AXI_M0_WR_DATA_WIDTH_IN_BITS_I = 512,

  // AXI Master Read Channel Data Width
  parameter AXI_M0_RD_DATA_WIDTH_IN_BITS_I = 256,

  // FIRST_BUFFER_START_ADDR
  parameter FIRST_BUFFER_START_ADDR_I = 32'h0000_0000,

  // BUFFER_START_ADDR_DIFF_FOR_SAME_DEV
  parameter BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I = 32'h03F4_8000,

  // FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV
  parameter FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I = 32'h1000_0000,

  // No of fifos
  parameter NO_OF_SUPPORTED_DEV_I = 8,

  // No. of bits for device num
  parameter SEL_DEV_NUM_BITS_I  = 3,

  // Y Data FIFO Depth
  parameter Y_DATA_FIFO_DEPTH_IN_WORDS_I = 8192,

  // AXI Master Burst Size
  parameter MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I = 3840

  )
 (

  // Outputs
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                      ddr_wr_xfer_axi_clk_arr_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                      full_frame_wr_completed_arr_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                      y_data_bufr_full_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                      y_data_bufr_empty_o,
  output logic                                                    update_dev_num_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0]                      sel_d_start_stream_axi_clk_o,

  output fbh_rd_states_nd_ctrl_st_t   [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_rd_states_nd_ctrl_o,
  output fbh_rd_dsf_flags_st_t        [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_rd_dsf_flags_arr_o,

 output logic  [(SEL_DEV_NUM_BITS_I-1):0]                       fbh_rd_dsf_sel_device_num_o,

  // Master Write Address Channel
  input                                                         axi_m0_awready_i,
  output logic [32:0]                                           axi_m0_awaddr_o,
  output logic                                                  axi_m0_awvalid_o,
  output logic [ 1:0]                                           axi_m0_awburst_o,
  output       [ 5:0]                                           axi_m0_awid_o,
  output logic [ 7:0]                                           axi_m0_awlen_o,
  output                                                        axi_m0_awlock_o,
  output logic [ 2:0]                                           axi_m0_awsize_o,

  // Master Write Data Channel
  input                                                         axi_m0_wready_i,
  output logic                                                  axi_m0_wlast_o,
  output logic                                                  axi_m0_wvalid_o,
  output logic [(AXI_M0_WR_DATA_WIDTH_IN_BITS_I-1):0]           axi_m0_wdata_o,
  output       [((AXI_M0_WR_DATA_WIDTH_IN_BITS_I/8)-1):0]       axi_m0_wstrb_o,

  // Master Write Response Channel
  input        [ 5:0]                                           axi_m0_bid_i,
  input                                                         axi_m0_bvalid_i,
  output logic                                                  axi_m0_bready_o,

  // Master Read Address Channel
  input                                                         axi_m0_arready_i,
  output logic   [32:0]                                         axi_m0_araddr_o,
  output logic                                                  axi_m0_arvalid_o,
  output logic   [ 1:0]                                         axi_m0_arburst_o,
  output         [ 5:0]                                         axi_m0_arid_o,
  output logic   [ 7:0]                                         axi_m0_arlen_o,
  output                                                        axi_m0_arlock_o,
  output logic   [ 2:0]                                         axi_m0_arsize_o,

  // Master Read Data Channel
  input      [ 5:0]                                             axi_m0_rid_i,
  input                                                         axi_m0_rvalid_i,
  input                                                         axi_m0_rlast_i,
  input      [(AXI_M0_WR_DATA_WIDTH_IN_BITS_I-1):0]             axi_m0_rdata_i, // As data bus is of 512 bits
  output logic                                                  axi_m0_rready_o,

  // Master Read Response Channel
  input      [ 1:0]                                             axi_m0_rresp_i,

  // Input clock and reset
  input                                                         hdmi_clk,
  input                                                         axi_clk,
  input                                                         fxn_gpif_m_clk,
  input                                                         hdmi_clk_reset_n,
  input                                                         axi_clk_reset_n,
  input                                                         fxn_gpif_m_clk_reset_n,

  // Input data and controls
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          sel_vsync_axi_clk_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          sel_vsync_hdmi_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          sel_vsync_hdmi_pe_pl_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          sel_vsync_hdmi_ne_pl_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          sel_hsync_hdmi_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0] [(Y_DATA_FIFO_WR_DATA_WIDTH_I-1):0] sel_vid_data_i,
  input dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0]           dev_reg_info_st_arr_axi_clk_i,
  input dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0]           dev_reg_info_st_arr_gpif_clk_i,
  input dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0]         dev_reg_info_st_arr_hdmi_clk_i,
  input common_reg_info_st_t                                    common_reg_info_i,


  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          ddr_wr_xfer_hdmi_clk_arr_i,
  input    [(NO_OF_SUPPORTED_DEV_I-1):0]                          full_frame_wr_completed_hdmi_clk_arr_i,

  // slfifo Buffer status
  input  slfifo_ctrl_req_st_t       [NO_OF_SUPPORTED_DEV_I-1:0]    slfifo_ctrl_req_i,
  output slfifo_data_nd_status_st_t [NO_OF_SUPPORTED_DEV_I-1:0]    slfifo_data_nd_vld_o,

  // DDR init related signals
  input                                                         ddr_init_done_i
 );

// ------------------------------------------
//
// Local Parameter
//
// ------------------------------------------

// Used for counters
localparam COUNTER_DATAWIDTH = 32;

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

fbh_wr_addr_nd_ctrl_st_t     [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_wr_addr_nd_ctrl;
// fbh_rd_states_nd_ctrl_st_t   [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_rd_states_nd_ctrl;
// fbh_rd_dsf_flags_st_t        [(NO_OF_SUPPORTED_DEV_I-1):0]  fbh_rd_dsf_flags_arr;

// ------------------------------------------
//
// Write FBH Wrapper
//
// ------------------------------------------

fbh_wr_wrapper
  #
  (
   // Parameters
   .Y_DATA_FIFO_WR_DATA_WIDTH_I                  (Y_DATA_FIFO_WR_DATA_WIDTH_I),
   .AXI_M0_WR_DATA_WIDTH_IN_BITS_I               (AXI_M0_WR_DATA_WIDTH_IN_BITS_I),
   .AXI_M0_RD_DATA_WIDTH_IN_BITS_I               (AXI_M0_RD_DATA_WIDTH_IN_BITS_I),
   .FIRST_BUFFER_START_ADDR_I                    (FIRST_BUFFER_START_ADDR_I),
   .BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I        (BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I),
   .FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I (FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I),
   .COUNTER_DATAWIDTH_I                          (COUNTER_DATAWIDTH),
   .NO_OF_SUPPORTED_DEV_I                        (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I                           (SEL_DEV_NUM_BITS_I),
   .Y_DATA_FIFO_DEPTH_IN_WORDS_I                 (Y_DATA_FIFO_DEPTH_IN_WORDS_I),
   .MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I   (MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I)
    )
  fbhwrwrap
   (
    // Outputs
    .ddr_wr_xfer_axi_clk_arr_o                 (ddr_wr_xfer_axi_clk_arr_o),
    .full_frame_wr_completed_arr_o             (full_frame_wr_completed_arr_o),
    .y_data_bufr_full_o                        (y_data_bufr_full_o),
    .y_data_bufr_empty_o                       (y_data_bufr_empty_o),
    .fbh_wr_addr_nd_ctrl_o                     (fbh_wr_addr_nd_ctrl),
    .sel_d_start_stream_axi_clk_o              (sel_d_start_stream_axi_clk_o),

    // Master Write Address Channel
    .axi_m0_awready_i                          (axi_m0_awready_i),
    .axi_m0_awaddr_o                           (axi_m0_awaddr_o),
    .axi_m0_awvalid_o                          (axi_m0_awvalid_o),
    .axi_m0_awburst_o                          (axi_m0_awburst_o),
    .axi_m0_awid_o                             (axi_m0_awid_o),
    .axi_m0_awlen_o                            (axi_m0_awlen_o),
    .axi_m0_awlock_o                           (axi_m0_awlock_o),
    .axi_m0_awsize_o                           (axi_m0_awsize_o),

    // Master Write Data Channel
    .axi_m0_wready_i                           (axi_m0_wready_i),
    .axi_m0_wlast_o                            (axi_m0_wlast_o),
    .axi_m0_wvalid_o                           (axi_m0_wvalid_o),
    .axi_m0_wdata_o                            (axi_m0_wdata_o),
    .axi_m0_wstrb_o                            (axi_m0_wstrb_o),

    // Master Write Response Channel
    .axi_m0_bid_i                             (axi_m0_bid_i),
    .axi_m0_bvalid_i                          (axi_m0_bvalid_i),
    .axi_m0_bready_o                          (axi_m0_bready_o),

    // Inputs
    .hdmi_clk                                 (hdmi_clk),
    .axi_clk                                  (axi_clk),
    .hdmi_clk_reset_n                         (hdmi_clk_reset_n),
    .axi_clk_reset_n                          (axi_clk_reset_n),
    .sel_vsync_axi_clk_i                      (sel_vsync_axi_clk_i),
    .sel_vsync_hdmi_i                         (sel_vsync_hdmi_i),
    .sel_vsync_hdmi_pe_pl_i                   (sel_vsync_hdmi_pe_pl_i),
    .sel_vsync_hdmi_ne_pl_i                   (sel_vsync_hdmi_ne_pl_i),
    .sel_hsync_hdmi_i                         (sel_hsync_hdmi_i),
    .sel_vid_data_i                           (sel_vid_data_i),
    .dev_reg_info_st_arr_axi_clk_i            (dev_reg_info_st_arr_axi_clk_i),
    .dev_reg_info_st_arr_gpif_clk_i           (dev_reg_info_st_arr_gpif_clk_i),
    .dev_reg_info_st_arr_hdmi_clk_i           (dev_reg_info_st_arr_hdmi_clk_i),
    .fbh_rd_states_nd_ctrl_i                  (fbh_rd_states_nd_ctrl_o),
    .fbh_rd_dsf_flags_arr_i                   (fbh_rd_dsf_flags_arr_o),
    .common_reg_info_i                        (common_reg_info_i),
    .ddr_wr_xfer_hdmi_clk_arr_i               (ddr_wr_xfer_hdmi_clk_arr_i),
    .full_frame_wr_completed_hdmi_clk_arr_i   (full_frame_wr_completed_hdmi_clk_arr_i),
    .ddr_init_done_i                          (ddr_init_done_i)

    );


// ------------------------------------------
//
// Read FBH Wrapper
//
// ------------------------------------------

fbh_rd_wrapper
  #
  (
   // Parameters
   .SLFIFO_DEPTH_IN_WORDS_I                      (SLFIFO_DEPTH_IN_WORDS_I),
   .SLFIFO_RD_DATA_WIDTH_IN_BITS_I               (SLFIFO_RD_DATA_WIDTH_IN_BITS_I),
   .SLFIFO_WR_COUNT_DATA_WIDTH_I                 (SLFIFO_WR_COUNT_DATA_WIDTH_I),
   .AXI_M0_WR_DATA_WIDTH_IN_BITS_I               (AXI_M0_WR_DATA_WIDTH_IN_BITS_I),
   .FIRST_BUFFER_START_ADDR_I                    (FIRST_BUFFER_START_ADDR_I),
   .BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I        (BUFFER_START_ADDR_DIFF_FOR_SAME_DEV_I),
   .FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I (FIRST_BUFFER_START_ADDR_DIFF_FOR_OTHER_DEV_I),
   .AXI_M0_RD_DATA_WIDTH_IN_BITS_I               (AXI_M0_RD_DATA_WIDTH_IN_BITS_I),
   .MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I   (MAX_AXI_SINGLE_TRANSACTION_SIZE_IN_BYTES_I),
   .NO_OF_SUPPORTED_DEV_I                        (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I                           (SEL_DEV_NUM_BITS_I)
   )
 fbhrdwrap
   (
    .hdmi_clk                                 (hdmi_clk),
    .hdmi_clk_reset_n                         (hdmi_clk_reset_n),
    .axi_clk                                  (axi_clk),
    .axi_clk_reset_n                          (axi_clk_reset_n),
    .fxn_gpif_m_clk                           (fxn_gpif_m_clk),
    .fxn_gpif_m_clk_reset_n                   (fxn_gpif_m_clk_reset_n),

    .ddr_init_done_i                          (ddr_init_done_i),
    .sel_vsync_axi_clk_i                      (sel_vsync_axi_clk_i),

    .device_status_arr_axi_clk_i              (dev_reg_info_st_arr_axi_clk_i),
    .device_status_arr_gpif_clk_i             (dev_reg_info_st_arr_gpif_clk_i),

    .axi_m0_arready_i                         (axi_m0_arready_i),
    .axi_m0_rvalid_i                          (axi_m0_rvalid_i),
    .axi_m0_rlast_i                           (axi_m0_rlast_i),
    .axi_m0_rdata_i                           (axi_m0_rdata_i),
    .axi_m0_araddr_o                          (axi_m0_araddr_o),
    .axi_m0_arvalid_o                         (axi_m0_arvalid_o),
    .axi_m0_arburst_o                         (axi_m0_arburst_o),
    .axi_m0_arid_o                            (axi_m0_arid_o),
    .axi_m0_arlen_o                           (axi_m0_arlen_o),
    .axi_m0_arlock_o                          (axi_m0_arlock_o),
    .axi_m0_arsize_o                          (axi_m0_arsize_o),
    .axi_m0_rready_o                          (axi_m0_rready_o),

    .fbh_wr_addr_nd_ctrl_i                    (fbh_wr_addr_nd_ctrl),
    .fbh_rd_states_nd_ctrl_o                  (fbh_rd_states_nd_ctrl_o),
    .fbh_rd_dsf_flags_arr_o                   (fbh_rd_dsf_flags_arr_o),
    .device_status_gpif_clk_o                 (),
    .device_status_axi_clk_o                  (),
    .slfifo_ctrl_req_i                        (slfifo_ctrl_req_i),
    .slfifo_data_nd_status_o                  (slfifo_data_nd_vld_o),
    .common_reg_info_i                        (common_reg_info_i),
    .fbh_rd_dsf_sel_device_num_o              (fbh_rd_dsf_sel_device_num_o)


    );


endmodule


