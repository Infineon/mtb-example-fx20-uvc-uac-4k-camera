//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    sdr_ddr_manager
// Target Devices: T120/Ti180
//
// Description: This module acts as a master of LVCMOS slave FIFO interface of
//              FX10/20.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


`timescale 1ns/100ps

module sdr_ddr_manager
  #
  (
   // Slave FIFO Data Width in Bits
   parameter DATA_WIDTH_IN_BITS_I      = 32,

   // GPIF Master Mode: LVDS or LVCMOS
   parameter GPIF_MASTER_MODE_I = "LVCMOS_DDR",

   // Number of address bits
   parameter NO_OF_ADDRESS_BITS_I = 2,

   // Slave FIFO Data Width in Bits
   localparam DATA_WIDTH_ON_EACH_EDGE = ( DATA_WIDTH_IN_BITS_I/2 )
  )
 (
  input              clk,
  input              reset_n,

  // Outputs
  output logic         slf_m_wr_req_n_o,
  output logic         slf_m_pktend_n_o,
  output logic         slf_m_cs_n_o,

  output logic [(NO_OF_ADDRESS_BITS_I-1):0] slf_m_addr_o,
  output logic [(DATA_WIDTH_IN_BITS_I-1):0] slf_wr_data_pe_o,
  output logic [(DATA_WIDTH_IN_BITS_I-1):0] slf_wr_data_ne_o,

  // Inputs
  input              slf_m_wr_req_n_i,
  input              slf_m_pktend_n_i,
  input              slf_m_cs_n_i,
  input              pnl_slf_data_valid_i,

  input      [(NO_OF_ADDRESS_BITS_I-1):0] slf_m_addr_i,
  input      [(DATA_WIDTH_IN_BITS_I-1):0] slf_wr_data_i,
  input      [(DATA_WIDTH_IN_BITS_I-1):0] pnl_slf_wr_data_i
 );

// ---------------------------------------------------
//
// Write Request, Packet End, Chip Select & Address
//
// ---------------------------------------------------

  always_ff @ ( posedge clk )
    begin
      if ( !reset_n )
        begin
          slf_m_wr_req_n_o <= 1'h1;
          slf_m_pktend_n_o <= 1'h1;
          slf_m_cs_n_o     <= 1'h1;
          slf_m_addr_o     <= 2'h0;
        end
      else
        begin
          slf_m_wr_req_n_o <= slf_m_wr_req_n_i;
          slf_m_pktend_n_o <= slf_m_pktend_n_i;
          slf_m_cs_n_o     <= slf_m_cs_n_i;
          slf_m_addr_o     <= slf_m_addr_i;
        end
    end

// ------------------------------------------
//
// DDR or SDR?
//
// ------------------------------------------

generate
  if ( GPIF_MASTER_MODE_I == "LVCMOS_DDR" )
    begin : LVCMOS_DDR_BLOCK

      // Write Data
      always_ff @ ( posedge clk )
        begin
          if ( !reset_n )
            begin
              slf_wr_data_pe_o <= 32'h0;
              slf_wr_data_ne_o <= 32'h0;
            end
          else if ( pnl_slf_data_valid_i )
            begin
              slf_wr_data_pe_o <= pnl_slf_wr_data_i[(DATA_WIDTH_ON_EACH_EDGE-1):0];
              slf_wr_data_ne_o <= pnl_slf_wr_data_i[(DATA_WIDTH_IN_BITS_I-1):DATA_WIDTH_ON_EACH_EDGE];
            end
          else
            begin
              slf_wr_data_pe_o <= slf_wr_data_i[(DATA_WIDTH_ON_EACH_EDGE-1):0];
              slf_wr_data_ne_o <= slf_wr_data_i[(DATA_WIDTH_IN_BITS_I-1):DATA_WIDTH_ON_EACH_EDGE];
            end
        end
    end
  else
    begin : LVCMOS_SDR_BLOCK
      always_ff @ ( posedge clk )
        begin
          if ( !reset_n )
            begin
              slf_wr_data_pe_o <= 32'h0;
              slf_wr_data_ne_o <= 32'h0;
            end
          else
            begin
              slf_wr_data_pe_o <= slf_wr_data_i[(DATA_WIDTH_IN_BITS_I-1):0];
              slf_wr_data_ne_o <= 32'h0;
            end
        end
    end
endgenerate














endmodule