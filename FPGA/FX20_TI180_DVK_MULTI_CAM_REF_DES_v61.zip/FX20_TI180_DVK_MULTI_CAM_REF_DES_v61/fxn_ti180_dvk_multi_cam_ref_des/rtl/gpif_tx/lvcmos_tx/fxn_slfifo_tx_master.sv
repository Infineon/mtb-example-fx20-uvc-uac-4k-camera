//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fxn_slfifo_tx_master
// Target Devices: All
//
// Description: This module acts as a master of LVCMOS slave FIFO interface of
//              FX10/20.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


`timescale 1ns/100ps

module fxn_slfifo_tx_master
  #
  (
   // Slave FIFO Data Width in Bits
   parameter DATA_WIDTH_IN_BITS_I      = 32,

   // No. of devices/ FIFOs needed
   parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
   parameter SEL_DEV_NUM_BITS_I = 3,

   // GPIF Master Mode: LVDS or LVCMOS
   parameter GPIF_MASTER_MODE_I = "LVCMOS_DDR",

   // Number of address bits
   parameter NO_OF_ADDRESS_BITS_I = 2
  )
 (
  input                clk,
  input                reset_n,

  // Outputs
  output logic         slfifo_rd_req_o,
  output logic         slf_m_wr_req_n_o,
  output logic         slf_m_pktend_n_o,
  output               slf_m_cs_n_o,
  output logic         change_thread_addr_pl_o,
  output logic         l_zlp_sent_o,
  output logic         slfifo_reset_req_o,
  output logic         frame_data_sent_pl_o,
  output logic [(NO_OF_ADDRESS_BITS_I-1):0] slf_m_addr_o,
  output logic [(DATA_WIDTH_IN_BITS_I-1):0] slf_wr_data_o,
  output logic         data_pkt_sent_pl_o,

  // Inputs
  input                start_serving_device_pl_i,
  input                slf_m_par_flag_i,
  input                slf_m_full_flag_i,
  input                slfifo_rd_data_valid_i,
  input                slfifo_almost_empty_i,
  input        [(DATA_WIDTH_IN_BITS_I-1):0] slfifo_rd_data_i,

  // Registers
  input                sel_reset_or_stop_stream_req_i,
  input        [31:0]  frame_size_info_i,

  input                u3v_stream_en_i,
  input        [63:0]  u3v_chunk_data_out_i,
  input                u3v_chunk_data_out_vld_i,
  input                u3v_chunk_data_end_i,
  output logic         u3v_chunk_start,
  input     [(SEL_DEV_NUM_BITS_I-1):0]  sel_device_num_i,

  input common_reg_info_st_t common_reg_info_i,    // Common Register Information
  input dev_reg_info_st_t    sel_d_reg_info_st_i   // Device Specific Register Information


 );

// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // No of States
  localparam NO_OF_FSM_STATES     = 8'd22;
  localparam NO_OF_SUB_FSM_STATES = 8'd11;

  // Number of bytes in a transfer
  localparam NO_OF_BYTES_PER_XFER = DATA_WIDTH_IN_BITS_I / 8;

  // Adress to FLAGA assertion delay
  // Why 10 clocks?
  // After sending thread and socket address from
  // this FSM, it may take 3
  // clocks to update FLAGA status. For safer side,
  // here, it is taken 10.
  localparam ADDR_TO_FLAGA_DELAY_CLK = 50;

  // UVC Header Information
  localparam UVC_LENGTH                 = 8'h20;
  localparam UVC_BIT_FIELD              = 8'h8C;
  localparam NO_OF_UVC_HEADER_BYTES     = 8'd32;
  localparam UVC_HEADER_BYTES_MAX_COUNT = ( ( NO_OF_UVC_HEADER_BYTES - 1'b1 ) / NO_OF_BYTES_PER_XFER );
  localparam UVC_HEADER_BYTES_MAX_COUNT_DATA_WIDTH_IN_BITS = $clog2(UVC_HEADER_BYTES_MAX_COUNT);


  // U3V Header Information
  // Leader Length
  localparam LEADER_SIZE_IN_BYTES_LSB = 8'd56;
  localparam LEADER_SIZE_IN_BYTES_MSB = 8'd0;

  localparam TRAILER_SIZE_IN_BYTES_LSB = 8'd40;
  localparam TRAILER_SIZE_IN_BYTES_MSB = 8'd0;

  // No of clock cycles needed for full leader
  localparam U3V_LEADER_BYTES_MAX_COUNT = ( ( LEADER_SIZE_IN_BYTES_LSB - 1'b1 ) / NO_OF_BYTES_PER_XFER );
  localparam U3V_LEADER_BYTES_MAX_COUNT_DATA_WIDTH_IN_BITS = $clog2(U3V_LEADER_BYTES_MAX_COUNT);

  // No of clock cycles needed for full trailer
  localparam U3V_TRAILER_BYTES_MAX_COUNT = ( ( TRAILER_SIZE_IN_BYTES_LSB - 1'b1 ) / NO_OF_BYTES_PER_XFER );
  localparam U3V_TRAILER_BYTES_MAX_COUNT_DATA_WIDTH_IN_BITS = $clog2(U3V_TRAILER_BYTES_MAX_COUNT);

  // Magic Key
  localparam LEADER_MAGIC_KEY  = 32'h4C563355;
  localparam TRAILER_MAGIC_KEY = 32'h54563355;

  // Payload Type
  localparam PAYLOAD_TYPE_IMAGE = 16'h0001;

  // Reserved Byte
  localparam RESERVED_BYTE = 8'd0;

  // Pixel Format With LSByte First
  localparam IMAGE_FORMAT = 32'h02100032;

  // FSM States
  enum logic [(NO_OF_FSM_STATES-1):0] {
    IDLE                                 = 22'h1,
    WAIT_BOTH_FLAGS_ASSERTED             = 22'h2,
    IS_UVC_OR_U3V                        = 22'h4,
    IS_UVC_HEADER_REQUIRED               = 22'h8,
    TX_U3V_LEADER                        = 22'h10,
    START_TX_UVC_HEADER                  = 22'h20,
    WAIT_UNTIL_LEADER_SENT               = 22'h40,
    START_TX_DATA                        = 22'h80,
    WAIT_DATA_SENT                       = 22'h100,
    WAIT_FULL_FLAG_DEASSERTED            = 22'h200,
    IS_NEW_ADDR_REQUIRED                 = 22'h400,
    INCR_THREAD_ADDR                     = 22'h800,
    WAIT_UNTIL_FLAGS_ASSERTED            = 22'h1000,
    TX_PARTIAL_PKT                       = 22'h2000,
    WAIT_UNTIL_PKTEND_SENT               = 22'h4000,
    IS_U3V_TRAILER_REQUIRED              = 22'h8000,
    TX_U3V_TRAILER                       = 22'h10000,
    WAIT_UNTIL_TRAILER_SENT              = 22'h20000,
    INFORM_FULL_FRAME_SENT               = 22'h40000,
    CHECK_U3V_CHUNK_DATA_EN              = 22'h80000,
    WAIT_CHUNK_DATA_SENT                 = 22'h100000,
	INFORM_FULL_BUFR_SENT                = 22'h200000
  } slf_cs, slf_ns;

  // Sub FSM States
  enum logic [(NO_OF_SUB_FSM_STATES-1):0] {
    PKTEND_IDLE                                 = 11'h1,
    IS_U3V_LEADER_DATA_REQUIRED                 = 11'h2,
    TX_LEADER_DATA                              = 11'h4,
    IS_U3V_TRAILER_DATA_REQUIRED                = 11'h8,
    TX_TRAILER_DATA                             = 11'h10,
    TX_PKTEND                                   = 11'h20,
    WAIT_UNTIL_FULL_FLAG_DEASSERTED             = 11'h40,
    IS_NEW_ADDR_NEEDED                          = 11'h80,
    CHANGE_THREAD_ADDR                          = 11'h100,
    WAIT_UNTIL_FULL_FLAG_ASSERTED               = 11'h200,
    INFORM_PKTEND_SENT                          = 11'h400
  } zlp_cs, zlp_ns;


// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic                           fifo_rd_req;
  logic                           tx_pktend_completed_pl;
  logic                           tx_partial_pkt_pl;
  logic                           tx_pktend_pl;
  logic                           incr_flaga_sample_count;
  logic                           change_thread_addr_pl;
  logic                           incr_thread_addr_pl;
  logic                           inform_frame_sent_pl;
  logic                           inform_data_pkt_sent_pl;
  logic                           slfifo_reset_req;
  logic  [15:0]                   sel_buffer_size_info;
  logic  [ 7:0]                   flaga_sample_count;
  logic  [15:0]                   data_byte_counter;
  logic  [(NO_OF_SUPPORTED_DEV_I-1):0][31:0] no_of_frame_bytes_yet_to_be_sent;
  logic  [31:0]                   no_of_frame_bytes_sent_to_fx10;
  logic  [63:0]                   u3v_block_id;
  logic  [(UVC_HEADER_BYTES_MAX_COUNT_DATA_WIDTH_IN_BITS-1):0] uvc_header_cnt;
  logic  [(U3V_LEADER_BYTES_MAX_COUNT_DATA_WIDTH_IN_BITS-1):0] u3v_leader_data_cnt;
  logic  [(U3V_TRAILER_BYTES_MAX_COUNT_DATA_WIDTH_IN_BITS-1):0] u3v_trailer_data_cnt;
  logic                           tx_u3v_leader_pl;
  logic                           tx_u3v_trailer_pl;
  logic                           uvc_header_data_valid;
  logic                           u3v_leader_data_valid;
  logic                           u3v_trailer_data_valid;
  logic                           partial_buf_info;
  logic                           uvc_frame_idx;
  logic                           slf_u3v_header_data_valid;
  logic [(DATA_WIDTH_IN_BITS_I-1):0] slf_u3v_header_data;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0] uvc_frame_header_sent;

// ------------------------------------------
//
// Buffer Size Info
//
// ------------------------------------------

// If UVC header data is sent by FPGA, that value must be
// deducted from the size received from FX10.
// In case of U3V, header data length does not affect the
// buffer size.
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        sel_buffer_size_info  <= 16'b0;
      end
    else if ( ( common_reg_info_i.uvc_stream_mode_en == 1'b1 ) &
              ( common_reg_info_i.tx_header_info_as_payload == 1'b1 ) &
              ( uvc_frame_header_sent[sel_device_num_i] == 1'b0 )
            )
      begin
        sel_buffer_size_info <= ( sel_d_reg_info_st_i.buffer_size_info - NO_OF_UVC_HEADER_BYTES );
      end
    else
      begin
        sel_buffer_size_info <= sel_d_reg_info_st_i.buffer_size_info;
      end
  end

// ------------------------------------------
//
// Main Data FSM
//
// ------------------------------------------

// Current State
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        slf_cs <= IDLE;
      end
    else if ( sel_reset_or_stop_stream_req_i )
      begin
        slf_cs <= IDLE /* INFORM_FULL_FRAME_SENT */;
      end
    else
      begin
        slf_cs <= slf_ns;
      end
  end

// Next State
always_comb
  begin
    slf_ns <= IDLE;
    unique case ( slf_cs )

      // Wait until ready and partial flags are HIGH.
      IDLE :
        begin
          if ( start_serving_device_pl_i )
            begin
              slf_ns <= WAIT_BOTH_FLAGS_ASSERTED;
            end
          else
            begin
              slf_ns <= IDLE;
            end
        end

      // Wait until ready and partial flags are HIGH after
      // thread switching delay.
      WAIT_BOTH_FLAGS_ASSERTED :
        begin
          if ( ( slf_m_full_flag_i ) &
               ( slf_m_par_flag_i  ) &
               ( flaga_sample_count == ADDR_TO_FLAGA_DELAY_CLK )
             )
            begin
              slf_ns <= IS_UVC_OR_U3V;
            end
          else
            begin
              slf_ns <= WAIT_BOTH_FLAGS_ASSERTED;
            end
        end

      // Is it UVC or U3V mode?
      IS_UVC_OR_U3V :
        begin
          if ( common_reg_info_i.uvc_stream_mode_en == 1'b1 )  // UVC Mode
            begin
              slf_ns <= IS_UVC_HEADER_REQUIRED;
            end
          else if(u3v_stream_en_i)
            begin
              slf_ns <= TX_U3V_LEADER;
            end
          else
            begin
              slf_ns <= IS_UVC_OR_U3V;
            end
        end

   //   // Is Header required?
   //   IS_U3V_LEADER_DATA_REQUIRED :
   //     begin
   //       if ( common_reg_info_i.tx_header_info_as_payload ) // U3V header is enable or not
   //         begin
   //           slf_ns <= TX_LEADER_DATA;
   //         end
   //       else
   //         begin
   //           slf_ns <= TX_U3V_LEADER;
   //         end
   //     end
   //
   //   // Transmit Leader Data
   //   TX_LEADER_DATA :
   //     begin
   //       if ( u3v_leader_data_cnt == U3V_LEADER_BYTES_MAX_COUNT )
   //         begin
   //            slf_ns <= TX_U3V_LEADER;
   //          end
   //       else
   //         begin
   //           slf_ns <= TX_LEADER_DATA;
   //         end
   //     end

      // Transmit Leader
      TX_U3V_LEADER :
        begin
          slf_ns <= WAIT_UNTIL_LEADER_SENT;
        end

      // Wait until ZLP is sent
      WAIT_UNTIL_LEADER_SENT :
        begin
          if ( tx_pktend_completed_pl == 1'b1 )
            begin
              slf_ns <= START_TX_DATA;
            end
          else
            begin
              slf_ns <= WAIT_UNTIL_LEADER_SENT;
            end
        end

      // Is UVC header required?
      IS_UVC_HEADER_REQUIRED :
        begin
          if ( ( common_reg_info_i.tx_header_info_as_payload == 1'b1 ) &
               ( uvc_frame_header_sent[sel_device_num_i] == 1'b0 ) )
            begin
              slf_ns <= START_TX_UVC_HEADER;
            end
          else
            begin
              slf_ns <= START_TX_DATA;
            end
        end

      //  Transmit Header
      START_TX_UVC_HEADER :
        begin
          if ( ( uvc_header_cnt == UVC_HEADER_BYTES_MAX_COUNT ) /* & ( uvc_header_data_valid ) */ )
            begin
              slf_ns <= START_TX_DATA;
            end
          else
            begin
              slf_ns <= START_TX_UVC_HEADER;
            end
        end

      // Start sending data
      START_TX_DATA :
        begin
          if ( slfifo_almost_empty_i == 1'b0 )
            begin
              slf_ns <= WAIT_DATA_SENT;
            end
          else
            begin
              slf_ns <= START_TX_DATA;
            end
        end

      // Wait until data bytes are sent.
      WAIT_DATA_SENT :
        begin
          if ( ( no_of_frame_bytes_yet_to_be_sent[sel_device_num_i] <= NO_OF_BYTES_PER_XFER ) & ( fifo_rd_req ) )
            begin
              if ((common_reg_info_i.uvc_stream_mode_en==1'b0)  && ( u3v_chunk_data_end_i==1'b0 )) // Check if Chunk Data Enabled
                begin
                  slf_ns <= CHECK_U3V_CHUNK_DATA_EN;
                end
              else
                begin
                  slf_ns <= TX_PARTIAL_PKT;
                end
            end
          else if ( ( data_byte_counter  >= (sel_buffer_size_info - NO_OF_BYTES_PER_XFER) ) & ( fifo_rd_req ) )
            begin
              slf_ns <= WAIT_FULL_FLAG_DEASSERTED;
            end
          else
            begin
              slf_ns <= WAIT_DATA_SENT;
            end
        end

      // Wait until Full flag is de-asserted
      WAIT_FULL_FLAG_DEASSERTED :
        begin
          if ( slf_m_full_flag_i == 1'b0 )
            begin
              slf_ns <= IS_NEW_ADDR_REQUIRED;
            end
          else
            begin
              slf_ns <= WAIT_FULL_FLAG_DEASSERTED;
            end
        end

      // Does EP support multiple threads?
      IS_NEW_ADDR_REQUIRED :
        begin
          if ( sel_d_reg_info_st_i.active_thread == 2'd2 ) // Multiple threads for an EP
            begin
              slf_ns <= INCR_THREAD_ADDR;
            end
          else
            begin
           `ifdef DEVICE_SEL_BASED_ON_FRAME
              slf_ns <= WAIT_UNTIL_FLAGS_ASSERTED;    // WAIT_BOTH_FLAGS_ASSERTED
	       `else
              slf_ns <= INFORM_FULL_BUFR_SENT;
          `endif
            end
        end

      // Inform that full buffer is sent
      INFORM_FULL_BUFR_SENT :
        begin
          slf_ns <= IDLE;
        end

      // Change to next thread and wait for flags to be asserted
      INCR_THREAD_ADDR :
        begin
       `ifdef DEVICE_SEL_BASED_ON_FRAME
          slf_ns <= WAIT_UNTIL_FLAGS_ASSERTED;    // WAIT_BOTH_FLAGS_ASSERTED
	      `else
          slf_ns <= INFORM_FULL_BUFR_SENT;
       `endif
        end

      // Are full & partial flag asserted again?
      WAIT_UNTIL_FLAGS_ASSERTED :
        begin
          if ( slf_m_full_flag_i & slf_m_par_flag_i )
            begin
              slf_ns <= IS_UVC_HEADER_REQUIRED;
            end
          else
            begin
              slf_ns <= WAIT_UNTIL_FLAGS_ASSERTED;
            end
        end

      // Check if U3V feature Chunk Data is Enabled
      CHECK_U3V_CHUNK_DATA_EN:
       begin
        if(u3v_chunk_data_end_i==1'b0)
         begin
           slf_ns <= WAIT_CHUNK_DATA_SENT;
         end
        else
         begin
           slf_ns <= TX_PARTIAL_PKT;
         end
       end
      // Send Chunk Data
       WAIT_CHUNK_DATA_SENT:
        begin
        if(u3v_chunk_data_end_i== 1'b1)
        begin
            slf_ns <= TX_PARTIAL_PKT;
        end
       else
         begin
           slf_ns <= WAIT_CHUNK_DATA_SENT;
         end
        end

      // Transmit PKTEND
      TX_PARTIAL_PKT :
        begin
          slf_ns <= WAIT_UNTIL_PKTEND_SENT;
        end

      // Wait until ZLP is sent
      WAIT_UNTIL_PKTEND_SENT :
        begin
          if ( tx_pktend_completed_pl == 1'b1 )
            begin
              slf_ns <= IS_U3V_TRAILER_REQUIRED;
            end
          else
            begin
              slf_ns <= WAIT_UNTIL_PKTEND_SENT;
            end
        end

      // Is U3V Trailer required?
      IS_U3V_TRAILER_REQUIRED :
        begin
          if ( common_reg_info_i.uvc_stream_mode_en == 1'b1 ) // UVC Mode
            begin
              slf_ns <= INFORM_FULL_FRAME_SENT;
            end
          else
            begin
              slf_ns <= TX_U3V_TRAILER;
            end
        end

      // Transmit U3V Trailer
      TX_U3V_TRAILER :
        begin
          slf_ns <= WAIT_UNTIL_TRAILER_SENT;
        end

      // Wait until ZLP is sent
      WAIT_UNTIL_TRAILER_SENT :
        begin
          if ( tx_pktend_completed_pl == 1'b1 )
            begin
              slf_ns <= INFORM_FULL_FRAME_SENT;
            end
          else
            begin
              slf_ns <= WAIT_UNTIL_TRAILER_SENT;
            end
        end

      // Inform that full frame is sent
      INFORM_FULL_FRAME_SENT :
        begin
          slf_ns <= IDLE;
        end

    endcase
  end


// Next State Signals
always_comb
  begin

    tx_partial_pkt_pl       <= 1'b0;
    fifo_rd_req             <= 1'b0;
    change_thread_addr_pl   <= 1'b0;
    inform_frame_sent_pl    <= 1'b0;
    slfifo_reset_req        <= 1'b0;
    u3v_chunk_start         <= 1'b0;
    incr_flaga_sample_count <= 1'b0;
    tx_u3v_leader_pl        <= 1'b0;
    tx_u3v_trailer_pl       <= 1'b0;
    uvc_header_data_valid   <= 1'b0;
    inform_data_pkt_sent_pl <= 1'b0;

    unique case ( slf_cs )

      // Wait until ready and partial flags are HIGH.
      IDLE :
        begin

        end

      // Wait until ready and partial flags are HIGH.
      WAIT_BOTH_FLAGS_ASSERTED :
        begin
          incr_flaga_sample_count <= 1'b1;
        end

      // Is ZLP required?
      IS_UVC_OR_U3V :
        begin

        end

      // Transmit Leader ZLP
      TX_U3V_LEADER :
        begin
          tx_u3v_leader_pl <= 1'b1;
        end

      // Wait until ZLP is sent
      WAIT_UNTIL_LEADER_SENT :
        begin

        end

      //  Is Header required?
      IS_UVC_HEADER_REQUIRED :
        begin

        end

      //  Transmit Header
      START_TX_UVC_HEADER :
        begin
          uvc_header_data_valid <= 1'b1;
        end

      // Start sending data
      START_TX_DATA :
        begin

        end

      // Wait until data bytes are sent.
      WAIT_DATA_SENT :
        begin
          fifo_rd_req <= ~slfifo_almost_empty_i;
        end

      // Wait until Full flag is de-asserted
      WAIT_FULL_FLAG_DEASSERTED :
        begin

        end

      // Does EP support multiple threads?
      IS_NEW_ADDR_REQUIRED :
        begin

        end

      // Change to next thread and wait for flags to be asserted
      INCR_THREAD_ADDR :
        begin
          change_thread_addr_pl <= 1'b1;
        end

      // Inform that full buffer is sent
      INFORM_FULL_BUFR_SENT :
        begin
          inform_data_pkt_sent_pl <= 1'b1;
        end

      // Are full & partial flag asserted again?
      WAIT_UNTIL_FLAGS_ASSERTED :
        begin

        end

     // Chunk Data States
     CHECK_U3V_CHUNK_DATA_EN :
       begin
         u3v_chunk_start <= 1'b1;
       end

     WAIT_CHUNK_DATA_SENT :
       begin
         u3v_chunk_start <= 1'b1; // 1'b0
       end

      // Transmit PKTEND
      TX_PARTIAL_PKT :
        begin
          tx_partial_pkt_pl <= 1'b1;
        end

      // Wait until ZLP is sent
      WAIT_UNTIL_PKTEND_SENT :
        begin
          slfifo_reset_req <= 1'b1;
        end

      // Is ZLP required?
      IS_U3V_TRAILER_REQUIRED :
        begin

        end

      // Transmit Trailer ZLP
      TX_U3V_TRAILER :
        begin
          tx_u3v_trailer_pl <= 1'b1;
        end

      // Wait until ZLP is sent
      WAIT_UNTIL_TRAILER_SENT :
        begin

        end

      // Inform that full frame is sent
      INFORM_FULL_FRAME_SENT :
        begin
          inform_frame_sent_pl <= 1'b1;
        end

    endcase
  end


// ------------------------------------------
//
// Register Outputs
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        frame_data_sent_pl_o    <= 1'b0;
        change_thread_addr_pl_o <= 1'b0;
        slfifo_rd_req_o         <= 1'b0;
        slfifo_reset_req_o      <= 1'b0;
        data_pkt_sent_pl_o      <= 1'b0;
      end
    else
      begin
        frame_data_sent_pl_o    <= inform_frame_sent_pl;
        change_thread_addr_pl_o <= ( change_thread_addr_pl | incr_thread_addr_pl );
        slfifo_rd_req_o         <= fifo_rd_req;
        slfifo_reset_req_o      <= slfifo_reset_req;
        data_pkt_sent_pl_o      <= inform_data_pkt_sent_pl;
      end
  end


// ------------------------------------------
//
// PKTEND FSM
//
// ------------------------------------------

// This FSM manages to transmit partial packet,
// leader or trailer data including ZLP.

// Current State
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        zlp_cs <= PKTEND_IDLE;
      end
    else if ( sel_reset_or_stop_stream_req_i )
      begin
        zlp_cs <= PKTEND_IDLE;
      end
    else
      begin
        zlp_cs <= zlp_ns;
      end
  end

// Next State
always_comb
  begin
    zlp_ns <= PKTEND_IDLE;
    unique case ( zlp_cs )

      // Wait until "tx_partial_pkt_pl" or
      // "tx_u3v_leader_pl" or
      // "tx_u3v_trailer_pl" is asserted
      PKTEND_IDLE :
        begin
          if ( tx_partial_pkt_pl == 1'b1 )
            begin
              zlp_ns <= TX_PKTEND;
            end
          else if ( tx_u3v_leader_pl == 1'b1 )
            begin
              zlp_ns <= IS_U3V_LEADER_DATA_REQUIRED;
            end
          else if ( tx_u3v_trailer_pl == 1'b1 )
            begin
              zlp_ns <= IS_U3V_TRAILER_DATA_REQUIRED;
            end
          else
            begin
              zlp_ns <= PKTEND_IDLE;
            end
        end

      // Is Header required?
      IS_U3V_LEADER_DATA_REQUIRED :
        begin
          if ( ( common_reg_info_i.tx_header_info_as_payload == 1'b1 ) & ( common_reg_info_i.uvc_stream_mode_en == 1'b0 ) ) // U3V header is required
            begin
              zlp_ns <= TX_LEADER_DATA;
            end
          else
            begin
              zlp_ns <= TX_PKTEND;
            end
        end

      // Transmit Leader Data
      TX_LEADER_DATA :
        begin
          if ( u3v_leader_data_cnt == U3V_LEADER_BYTES_MAX_COUNT )
            begin
              zlp_ns <= TX_PKTEND;
            end
          else
            begin
              zlp_ns <= TX_LEADER_DATA;
            end
        end

      // Trailer data or ZLP?
      IS_U3V_TRAILER_DATA_REQUIRED :
        begin
          if ( ( common_reg_info_i.tx_header_info_as_payload == 1'b1 ) & ( common_reg_info_i.uvc_stream_mode_en == 1'b0 ) ) // U3V header is required
            begin
              zlp_ns <= TX_TRAILER_DATA;
            end
          else
            begin
              zlp_ns <= TX_PKTEND;
            end
        end

      // Transmit Trailer Data
      TX_TRAILER_DATA :
        begin
          if ( u3v_trailer_data_cnt == U3V_TRAILER_BYTES_MAX_COUNT )
            begin
              zlp_ns <= TX_PKTEND;
            end
          else
            begin
              zlp_ns <= TX_TRAILER_DATA;
            end
        end

      // Transmit PKTEND
      TX_PKTEND :
        begin
          zlp_ns <= WAIT_UNTIL_FULL_FLAG_DEASSERTED;
        end

      // Wait until full flag is de-asserted
      WAIT_UNTIL_FULL_FLAG_DEASSERTED :
        begin
          if ( slf_m_full_flag_i == 1'b0 )

            begin
              zlp_ns <= IS_NEW_ADDR_NEEDED;
            end
          else
            begin
              zlp_ns <= WAIT_UNTIL_FULL_FLAG_DEASSERTED;
            end
        end

      // Does EP support multiple threads?
      IS_NEW_ADDR_NEEDED :
        begin
          if ( sel_d_reg_info_st_i.active_thread == 2'd2 ) // Multiple threads for an EP
            begin
              zlp_ns <= CHANGE_THREAD_ADDR;
            end
          else
            begin
              zlp_ns <= WAIT_UNTIL_FULL_FLAG_ASSERTED;
            end
        end

      // Change to next thread and wait for flags to be asserted
      CHANGE_THREAD_ADDR :
        begin
          zlp_ns <= WAIT_UNTIL_FULL_FLAG_ASSERTED;
        end

      // Are full & partial flag asserted again?
      WAIT_UNTIL_FULL_FLAG_ASSERTED :
        begin
          if ( slf_m_full_flag_i == 1'b1 )
            begin
              zlp_ns <= INFORM_PKTEND_SENT;
            end
          else
            begin
              zlp_ns <= WAIT_UNTIL_FULL_FLAG_ASSERTED;
            end
        end

      // Inform that ZLP is sent
      INFORM_PKTEND_SENT :
        begin
          zlp_ns <= PKTEND_IDLE;
        end

    endcase
  end



// Next State Signals
always_comb
  begin

    tx_pktend_pl           <= 1'b0;
    incr_thread_addr_pl    <= 1'b0;
    // tx_pktend_completed_pl <= 1'b0;
    u3v_leader_data_valid  <= 1'b0;
    u3v_trailer_data_valid <= 1'b0;

    unique case ( zlp_cs )

      // Wait until "tx_partial_pkt_pl" is asserted
      PKTEND_IDLE :
        begin

        end

      // Is Header required?
      IS_U3V_LEADER_DATA_REQUIRED :
        begin

        end

      // Transmit Leader Data
      TX_LEADER_DATA :
        begin
          u3v_leader_data_valid <= 1'b1;
        end

      // Trailer data or ZLP?
      IS_U3V_TRAILER_DATA_REQUIRED :
        begin

        end

      // Transmit Trailer Data
      TX_TRAILER_DATA :
        begin
          u3v_trailer_data_valid <= 1'b1;
        end


      // Transmit ZLP
      TX_PKTEND :
        begin
          tx_pktend_pl <= 1'b1;
        end

      // Wait until full flag is de-asserted
      WAIT_UNTIL_FULL_FLAG_DEASSERTED :
        begin

        end

      // Does EP support multiple threads?
      IS_NEW_ADDR_REQUIRED :
        begin

        end

      // Change to next thread and wait for flags to be asserted
      CHANGE_THREAD_ADDR :
        begin
          incr_thread_addr_pl <= 1'b1;
        end

      // Are full & partial flag asserted again?
      WAIT_UNTIL_FULL_FLAG_ASSERTED :
        begin

        end

      // Inform that PKTEND is sent
      INFORM_PKTEND_SENT :
        begin
          // tx_pktend_completed_pl <= 1'b1;
        end

    endcase
  end


// ------------------------------------------
//
// PKTEND is asserted
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        tx_pktend_completed_pl <= 1'd0;
      end
    else
         begin
        tx_pktend_completed_pl <= ( zlp_cs == INFORM_PKTEND_SENT );
         end
  end

// ------------------------------------------
//
// Data Counter
//
// ------------------------------------------

// Read data counter
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        data_byte_counter <= 16'd0;
      end
    else if ( ( ( data_byte_counter == (sel_buffer_size_info - NO_OF_BYTES_PER_XFER) ) &
                ( fifo_rd_req ) ) |
                ( start_serving_device_pl_i )
                // ( frame_data_sent_pl_o ) |
                // ( sel_reset_or_stop_stream_req_i )
            )
      begin
        data_byte_counter <= 16'd0;
      end
    else if ( fifo_rd_req )
      begin
        if ( no_of_frame_bytes_yet_to_be_sent[sel_device_num_i] < NO_OF_BYTES_PER_XFER )
          begin
            data_byte_counter <= data_byte_counter + no_of_frame_bytes_yet_to_be_sent[sel_device_num_i];
          end
        else
          begin
            data_byte_counter <= data_byte_counter + NO_OF_BYTES_PER_XFER;
          end
      end
  end


// Frame data counter
// It is initialized with frame size and will be decremented by data lane value.
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        no_of_frame_bytes_yet_to_be_sent <= {NO_OF_SUPPORTED_DEV_I{frame_size_info_i}};
      end
    else if ( frame_data_sent_pl_o | sel_reset_or_stop_stream_req_i )
    // else if ( start_serving_device_pl_i )
      begin
        no_of_frame_bytes_yet_to_be_sent[sel_device_num_i] <= frame_size_info_i;
      end
    else if ( fifo_rd_req )
      begin
        if ( no_of_frame_bytes_yet_to_be_sent[sel_device_num_i] >= NO_OF_BYTES_PER_XFER )
          begin
            no_of_frame_bytes_yet_to_be_sent[sel_device_num_i] <= no_of_frame_bytes_yet_to_be_sent[sel_device_num_i] - NO_OF_BYTES_PER_XFER;
          end
        else
          begin
            no_of_frame_bytes_yet_to_be_sent[sel_device_num_i] <= 32'd0;
          end
      end
  end


// Frame data counter
// It is incremented with the no. of bytes sent to fx10
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        no_of_frame_bytes_sent_to_fx10 <= 32'd0;
      end
    else if ( ( !slf_m_pktend_n_o ) | ( sel_reset_or_stop_stream_req_i ) )
         begin
        no_of_frame_bytes_sent_to_fx10 <= 32'd0;
         end
    else if ( !slf_m_wr_req_n_o )
      begin
        no_of_frame_bytes_sent_to_fx10 <= no_of_frame_bytes_sent_to_fx10 + NO_OF_BYTES_PER_XFER ;
      end
  end


// ------------------------------------------
//
// FX10 UVC header Count
//
// ------------------------------------------

// UVC Header Count
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        uvc_header_cnt <= 3'd0;
      end
    else if ( uvc_header_data_valid )
      begin
        if ( uvc_header_cnt == UVC_HEADER_BYTES_MAX_COUNT )
          begin
            uvc_header_cnt <= 3'd0;
          end
        else
          begin
            uvc_header_cnt <= uvc_header_cnt + 3'd1;
          end
      end
  end

// ------------------------------------------
//
// Is UVC frame header sent?
//
// ------------------------------------------

// Logic to find out whether UVC frame header is sent or not.
// To get the maximum throughput in UVC, header must be sent during
// the first buffer of the frame only with the last packet bit
// (LAST_PKT_INDICATOR_BIT) as HIGH. Hence, for even frames,
// it's 0x8E and for odd, it's 0x8F.
 always_ff @ ( posedge clk )
   begin
     if ( ~reset_n )
       begin
         uvc_frame_header_sent <= {NO_OF_SUPPORTED_DEV_I{1'b0}};
       end
     else if ( ( frame_data_sent_pl_o == 1'b1 ) | ( sel_reset_or_stop_stream_req_i == 1'b1 ) )
       begin
         uvc_frame_header_sent[sel_device_num_i] <= 1'b0;
       end
     else if ( ( data_byte_counter == (sel_buffer_size_info - NO_OF_BYTES_PER_XFER) ) & ( fifo_rd_req ) )
       begin
         uvc_frame_header_sent[sel_device_num_i] <= 1'b1;
       end
   end

// ------------------------------------------
//
// Partial buffer informtion for UVC header
//
// ------------------------------------------

// Partial Buffer Info: It is not required as
// UVC header will be added only once in a frame.
// Hence, "partial_buf_info" bit is always HIGH.

assign partial_buf_info = 1'b1;
/*
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        partial_buf_info <= 1'b0;
      end
    else if ( no_of_frame_bytes_yet_to_be_sent[sel_device_num_i] <= NO_OF_BYTES_PER_XFER )
      begin
        partial_buf_info <= 1'b0;
      end
    else if ( ( ( no_of_frame_bytes_yet_to_be_sent[sel_device_num_i] + data_byte_counter ) < ( sel_buffer_size_info ) ) )
      begin
        partial_buf_info <= 1'b1;
      end
  end
*/

// ------------------------------------------
//
//  UVC frame Index for UVC header
//
// ------------------------------------------

// UVC Frame Index
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        uvc_frame_idx <= 1'b0;
      end
    else if ( !slf_m_pktend_n_o )
      begin
        uvc_frame_idx <= !uvc_frame_idx;
      end
    else
      begin
        uvc_frame_idx <= uvc_frame_idx;
      end
  end


// ------------------------------------------
//
// FX10 Write Request and Data
//
// ------------------------------------------

// SLWR
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        slf_m_wr_req_n_o <= 1'b1;
      end
    else if ( sel_reset_or_stop_stream_req_i )
      begin
        slf_m_wr_req_n_o <= 1'b1;
      end
    else
      begin
        slf_m_wr_req_n_o <= ( (!slfifo_rd_data_valid_i) & (!slf_u3v_header_data_valid) & (!uvc_header_data_valid) & (!u3v_chunk_data_out_vld_i)) ;
      end
  end

// Write Data
generate
  if ( GPIF_MASTER_MODE_I == "LVCMOS_DDR" )
    begin : LVCMOS_DDR_BLOCK
       always_ff @ ( posedge clk )
         begin
           if ( !reset_n )
             begin
               slf_wr_data_o <= '0;
             end
           else if (u3v_chunk_data_out_vld_i) // If valid chunk data is available
              begin
               slf_wr_data_o <= u3v_chunk_data_out_i;
              end

           else
             begin
               case ( { uvc_header_data_valid, slf_u3v_header_data_valid } )

                 2'b10 :
                   begin
                     if ( uvc_header_cnt == 3'd0 )
                       begin
                         slf_wr_data_o <= (DATA_WIDTH_IN_BITS_I)'( { 48'h0, UVC_BIT_FIELD[7:2], partial_buf_info, uvc_frame_idx, UVC_LENGTH[7:0] } );
                       end
                     else
                       begin
                         slf_wr_data_o <= '0;
                       end
                   end

                 2'b01 :
                   begin
                     slf_wr_data_o <= slf_u3v_header_data;
                   end

                 default :
                   begin
                     slf_wr_data_o <= slfifo_rd_data_i;
                   end

               endcase
             end
         end
    end

  else
    begin : LVCMOS_SDR_BLOCK
      // Data
      always_ff @ ( posedge clk )
        begin
          if ( !reset_n )
            begin
              slf_wr_data_o <= 64'h0;
            end
           else if (u3v_chunk_data_out_vld_i) // If valid chunk data is available
              begin
               slf_wr_data_o <= u3v_chunk_data_out_i;
              end
          else if ( ( uvc_header_cnt == 3'd0 ) & uvc_header_data_valid )
            begin
              slf_wr_data_o <= { 16'h0, UVC_BIT_FIELD[7:2], partial_buf_info, uvc_frame_idx, UVC_LENGTH[7:0] };
            end
          else if ( uvc_header_data_valid  )
             begin
               slf_wr_data_o <= 32'd0;
             end
          else
            begin
             slf_wr_data_o <= slfifo_rd_data_i;
            end
        end
    end
endgenerate


// ------------------------------------------
//
// FX10 Partial Packet
//
// ------------------------------------------

// PKTEND
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        slf_m_pktend_n_o <= 1'b1;
      end
    else
      begin
        slf_m_pktend_n_o <= !tx_pktend_pl;
      end
  end


// ------------------------------------------
//
// FX10 Thread Address
//
// ------------------------------------------

// Always asserted chip select
assign slf_m_cs_n_o = 1'b0;


// Thread address
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        slf_m_addr_o <= 2'd0;
      end
    else
      begin
        slf_m_addr_o <= sel_d_reg_info_st_i.thread_addr;
      end
  end


// ------------------------------------------
//
// Is Leader ZLP sent?
//
// ------------------------------------------

// Logic to find out whether Leader is sent or not.
// Once leader is sent, FSM will start reading data from DDR.
// When trailer is sent or cam_app_en is low, this signal will be 0.

  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          l_zlp_sent_o <= 1'b0;
        end
      else if ( common_reg_info_i.uvc_stream_mode_en )
        begin
          l_zlp_sent_o <= 1'b1;
        end
      else if ( ( ( !slf_m_pktend_n_o ) & ( !slf_m_wr_req_n_o ) ) |
                ( sel_reset_or_stop_stream_req_i )
              )
        begin
          l_zlp_sent_o <= 1'b0;
        end
      else if ( ( slf_cs == WAIT_UNTIL_LEADER_SENT ) & ( tx_pktend_completed_pl == 1'b1 ) )
        begin
          l_zlp_sent_o <= 1'b1;
        end
    end

// ----------------------------------------------
//
// Wait before sampling FLAGA
//
// ----------------------------------------------

// FX10 requires a 3 or 4 clock cycles to assert FLAGA
// in response to thread address.

// Here, when "start_serving_device_pl_i" is HIGH, next
// clock, new address is available on address bus.
// Hence, in "WAIT_BOTH_FLAGS_ASSERTED" state, FSM waits
// for 4 or 5 clock cycles to make sure that flag status
// are correctly sampled.
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        flaga_sample_count <= 8'd0;
      end
    else if ( incr_flaga_sample_count == 1'b0 )
      begin
        flaga_sample_count <= 8'd0;
      end
    else
      begin
        flaga_sample_count <= flaga_sample_count + 1'b1;
      end
  end

// ------------------------------------------
//
// U3V Header
//
// ------------------------------------------

// U3V Leader Count
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        u3v_leader_data_cnt <= 3'd0;
      end
    else if ( u3v_leader_data_valid )
      begin
        if ( u3v_leader_data_cnt == U3V_LEADER_BYTES_MAX_COUNT )
          begin
            u3v_leader_data_cnt <= 3'd0;
          end
        else
          begin
            u3v_leader_data_cnt <= u3v_leader_data_cnt + 3'd1;
          end
      end
  end

// U3V Trailer Count
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        u3v_trailer_data_cnt <= 3'd0;
      end
    else if ( u3v_trailer_data_valid )
      begin
        if ( u3v_trailer_data_cnt == U3V_TRAILER_BYTES_MAX_COUNT )
          begin
            u3v_trailer_data_cnt <= 3'd0;
          end
        else
          begin
            u3v_trailer_data_cnt <= u3v_trailer_data_cnt + 3'd1;
          end
      end
  end

// U3V Block ID
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        u3v_block_id <= 64'd0;
      end
    else if ( sel_reset_or_stop_stream_req_i )
      begin
        u3v_block_id <= 64'd0;
      end
    else if ( frame_data_sent_pl_o )
      begin
        u3v_block_id <= u3v_block_id + 1'b1;
      end
  end

// U3V Header Data Valid
always_ff @ ( posedge clk  )
  begin
    if ( !reset_n )
      begin
        slf_u3v_header_data_valid <= 1'd0;
      end
    else
      begin
        slf_u3v_header_data_valid <= ( u3v_leader_data_valid | u3v_trailer_data_valid );
      end
  end

// Leader/Trailer Data
// In LVCMOS DDR mode, LSBits are sent on rising edge of a clock and
// MSBits are on falling edge.
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        slf_u3v_header_data <= 64'h0;
      end
    else
      begin
        case ( { u3v_leader_data_valid, u3v_trailer_data_valid } )

          2'b10 :
            begin
              case ( u3v_leader_data_cnt )

                3'd0 : slf_u3v_header_data <= { LEADER_SIZE_IN_BYTES_MSB, LEADER_SIZE_IN_BYTES_LSB, {2{RESERVED_BYTE}}, LEADER_MAGIC_KEY };
                3'd1 : slf_u3v_header_data <= u3v_block_id;
                3'd2 : slf_u3v_header_data <= { {4{RESERVED_BYTE}}, PAYLOAD_TYPE_IMAGE, {2{RESERVED_BYTE}} };
                3'd3 : slf_u3v_header_data <= { IMAGE_FORMAT, {4{RESERVED_BYTE}}};
                3'd4 : slf_u3v_header_data <= { {2{RESERVED_BYTE}}, sel_d_reg_info_st_i.image_height, {2{RESERVED_BYTE}}, sel_d_reg_info_st_i.image_width};
                3'd5 : slf_u3v_header_data <= { 8{RESERVED_BYTE} };
                3'd6 : slf_u3v_header_data <= { 8{RESERVED_BYTE} };

                // 3'd0 : slf_u3v_header_data <= { LEADER_MAGIC_KEY, LEADER_SIZE_IN_BYTES_MSB, LEADER_SIZE_IN_BYTES_LSB, {2{RESERVED_BYTE}} };
                // 3'd1 : slf_u3v_header_data <= { u3v_block_id[31:0], u3v_block_id[63:32]};
                // 3'd2 : slf_u3v_header_data <= { PAYLOAD_TYPE_IMAGE, {2{RESERVED_BYTE}}, {4{RESERVED_BYTE}} };
                // 3'd3 : slf_u3v_header_data <= { {4{RESERVED_BYTE}}, IMAGE_FORMAT };
                // 3'd4 : slf_u3v_header_data <= { {2{RESERVED_BYTE}}, sel_image_width_info_i, {2{RESERVED_BYTE}}, sel_image_height_info_i };
                // 3'd5 : slf_u3v_header_data <= { 8{RESERVED_BYTE} };
                // 3'd6 : slf_u3v_header_data <= { 8{RESERVED_BYTE} };

              endcase
            end

          2'b01 :
            begin
              case ( u3v_trailer_data_cnt )

                3'd0 : slf_u3v_header_data <= { TRAILER_SIZE_IN_BYTES_MSB, TRAILER_SIZE_IN_BYTES_LSB, {2{RESERVED_BYTE}}, TRAILER_MAGIC_KEY };
                3'd1 : slf_u3v_header_data <= u3v_block_id;
                3'd2 : slf_u3v_header_data <= { frame_size_info_i, {4{RESERVED_BYTE}} };
                3'd3 : slf_u3v_header_data <= { {2{RESERVED_BYTE}}, sel_d_reg_info_st_i.image_height, {4{RESERVED_BYTE}} };
                3'd4 : slf_u3v_header_data <= {8{RESERVED_BYTE}};

                // 3'd0 : slf_u3v_header_data <= { TRAILER_MAGIC_KEY, TRAILER_SIZE_IN_BYTES_MSB, TRAILER_SIZE_IN_BYTES_LSB, {2{RESERVED_BYTE}} };
                // 3'd1 : slf_u3v_header_data <= { u3v_block_id[31:0], u3v_block_id[63:32]};
                // 3'd2 : slf_u3v_header_data <= { {4{RESERVED_BYTE}}, frame_size_info_i };
                // 3'd3 : slf_u3v_header_data <= { {6{RESERVED_BYTE}}, sel_image_height_info_i };
                // 3'd4 : slf_u3v_header_data <= {8{RESERVED_BYTE}};

              endcase
            end

          default :
            begin
              slf_u3v_header_data <= slf_u3v_header_data;
            end

        endcase
      end
  end


endmodule