//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    init_thread_seq_fsm
// Target Devices: All
//
// Description: This module transmits the initialization sequence to FXn. It
//              includes thread and socket address initialization, clearing
//              payload counter and event counters if they are enabled. At the
//              end, it transmits frame header size if it needs to be sent by
//              FPGA.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module init_thread_seq_fsm
  #
  (
   // Address to be managed by FPGA or not
   parameter ADDR_MANAGED_BY_FPGA_I = "TRUE"
  )
 (
  input               clk,
  input               reset_n,

  // Outputs
  output logic        init_thread_seq_completed_pl_o,
  output logic [ 7:0] its_data_byte_o,
  output logic        its_data_byte_valid_o,
  output logic [ 7:0] its_ctrl_byte_o,
  output logic        its_ctrl_byte_valid_o,

  // Inputs
  input               tx_thread_init_seq_pl_i,
  input               fxn_buffer_ready_i,     // Buffer Ready from FXn
  input               sel_d_reset_or_stop_stream_req_i,

  // Registers
  input dev_reg_info_st_t       sel_d_reg_info_st_i,
  input common_reg_info_st_t    common_reg_info_i
 );


// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // Total flags per thread
  localparam NO_OF_FLAGS_FOR_EACH_THREAD = 3'd4;

  // Set Thread Address
  localparam [3:0] THREAD_ADDR_CONTROL_BYTE = 4'b0001;

  // Set Socket Address
  localparam [2:0] SOCKET_ADDR_CONTROL_BYTE = 3'b001;

  // Clear Payload Counter
  localparam [6:0] CLR_PLC_CONTROL_BYTE = 6'b101_010;

  // Clear Event Counters
  localparam [4:0] CLR_EC_CONTROL_BYTE = 5'b011_01;

  // Metadata 0 Lower Word
  localparam [4:0] FRAME_HEADER_LW_CONTROL_BYTE = 5'b010_01;

  // Set any flag of a particular thread
  localparam [3:0] SET_FLAG_CONTROL_BYTE = 4'b1000;

  // Clear any flag of a particular thread
  localparam [3:0] CLEAR_FLAG_CONTROL_BYTE = 4'b1001;

  // Parity bit initial value
  localparam [0:0] PARITY_BIT = 1'b0;

  // LSbit of Control Byte
  localparam [0:0] CONTROL_BYTE_LS_BIT = 1'b1;

  // IDLE Control Byte
  localparam [7:0] IDLE_CONTROL_BYTE = 8'd1;

  // Adress to FLAGA assertion delay
  // Why 10 clocks?
  // After sending thread and socket address from
  // this FSM, it takes around 4 clocks to be on
  // control lane. And after that it may take 3
  // clocks to update FLAGA status. For safer side,
  // here, it is taken 10.
  localparam ADDR_TO_FLAGA_DELAY_CLK = 50;

  // No of States
  localparam NO_OF_FSM_STATES = 8'd16;

  enum logic [(NO_OF_FSM_STATES-1):0] {
    IDLE                                = 16'h1,
    SET_THREAD_ADDR                     = 16'h2,
    SET_SOCKET_ADDR                     = 16'h4,
    WAIT_READY_FLAG_ASSERTED            = 16'h8,
    IS_PAYLOAD_COUNTER_ENABLED          = 16'h10,
    INIT_PAYLOAD_COUNTER                = 16'h20,
    IS_EVENT_COUNTER_ENABLED            = 16'h40,
    INIT_EVENT_COUNTER                  = 16'h80,
    INIT_EVENT_COUNTER_1                = 16'h100,
    IS_FRAME_HEADER_ENABLED             = 16'h200,
    TX_FRAME_HEADER_LEN_INFO            = 16'h400,
    WAIT_BUFFER_AVAILABLE               = 16'h800,
    IS_FLAG_ENABLED                     = 16'h1000,
    SET_FIRST_FRAME_FLAG                = 16'h2000,
    CLR_FIRST_FRAME_FLAG                = 16'h4000,
    INFORM_THREAD_INIT_SEQ_COMPLETED    = 16'h8000
  } init_ts_cs, init_ts_ns;


// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic  [ 7:0] frame_header_length;
  logic  [ 3:0] bit_counter;
  logic  [ 7:0] flaga_sample_count;


  logic         tx_thead_addr_pl;
  logic         tx_socket_addr_pl;
  logic         clr_payload_counter_pl;
  logic         clr_event_counter_pl;
  logic         clr_event_counter_1_pl;
  logic         tx_frame_header_len_info_pl;
  logic         init_thread_seq_completed_pl;
  logic         clr_first_frame_flag_pl;
  logic         tx_first_frame_flag_pl;
  logic         incr_flaga_sample_count;

// ------------------------------------------
//
// FSM
//
// ------------------------------------------

// Current State
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        init_ts_cs <= IDLE;
      end
    else if ( sel_d_reset_or_stop_stream_req_i )
      begin
        init_ts_cs <= IDLE;
      end
    else
      begin
        init_ts_cs <= init_ts_ns;
      end
  end

// Next State
always_comb
  begin
    init_ts_ns <= IDLE;
    unique case ( init_ts_cs )

      // Frame manager informs to start initialization.
      // If address management needs to be done by FPGA,
      // next state is SET_THREAD_ADDR.
      IDLE :
        begin
          if ( tx_thread_init_seq_pl_i == 1'b1 )
            begin
              if ( ADDR_MANAGED_BY_FPGA_I == "TRUE" )
                begin
                  init_ts_ns <= SET_THREAD_ADDR;
                end
              else
                begin
                  init_ts_ns <= INIT_PAYLOAD_COUNTER;
                end
            end
          else
            begin
              init_ts_ns <= IDLE;
            end
        end

      // Initialize thread address
      SET_THREAD_ADDR :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          init_ts_ns <= SET_SOCKET_ADDR;
        end
          else
            begin
              init_ts_ns <= SET_THREAD_ADDR;
            end
        end

      // Initialize socket address
      // No need to wait until READY flag is de-asserted
      // as FW is intializing GPIF SM that's why READY flag is toggling
      SET_SOCKET_ADDR :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
              init_ts_ns <= WAIT_READY_FLAG_ASSERTED;
            end
          else
            begin
              init_ts_ns <= SET_SOCKET_ADDR;
            end
        end

      // Wait for sampling for 50 clock cycles
      // to update FLAGA status
      WAIT_READY_FLAG_ASSERTED :
        begin
          if ( flaga_sample_count == ADDR_TO_FLAGA_DELAY_CLK )
            begin
              if ( fxn_buffer_ready_i )
                begin
                  init_ts_ns <= IS_PAYLOAD_COUNTER_ENABLED;
                end
              else
                begin
                  init_ts_ns <= WAIT_READY_FLAG_ASSERTED;
                end
            end
          else
            begin
              init_ts_ns <= WAIT_READY_FLAG_ASSERTED;
            end
          end

      // Is payload counter enabled?
      IS_PAYLOAD_COUNTER_ENABLED :
        begin
          if ( sel_d_reg_info_st_i.c_n_crc_info[2] == 1'b1 )
            begin
              init_ts_ns <= INIT_PAYLOAD_COUNTER;
            end
          else
            begin
              init_ts_ns <= IS_EVENT_COUNTER_ENABLED;
            end
        end

      // Clear payload counter
      INIT_PAYLOAD_COUNTER :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          init_ts_ns <= IS_EVENT_COUNTER_ENABLED;
        end
          else
            begin
              init_ts_ns <= INIT_PAYLOAD_COUNTER;
            end
        end

      // Is event counter enabled?
      IS_EVENT_COUNTER_ENABLED :
        begin
          if ( sel_d_reg_info_st_i.c_n_crc_info != 2'd0 )
            begin
              init_ts_ns <= INIT_EVENT_COUNTER;
            end
          else
            begin
              init_ts_ns <= IS_FRAME_HEADER_ENABLED;
            end
        end

      // Clear event counter 0
      INIT_EVENT_COUNTER :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
              init_ts_ns <= INIT_EVENT_COUNTER_1;
            end
          else
            begin
              init_ts_ns <= INIT_EVENT_COUNTER;
            end
        end

      // Clear event counter 1
      INIT_EVENT_COUNTER_1 :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
              init_ts_ns <= IS_FRAME_HEADER_ENABLED;
            end
          else
            begin
              init_ts_ns <= INIT_EVENT_COUNTER_1;
            end
        end

      // Shall FPGA send frame header? Yes, in UVC mode only.
      IS_FRAME_HEADER_ENABLED :
        begin
          if ( ( common_reg_info_i.tx_header_info_as_metadata == 1'b1 ) &
               ( common_reg_info_i.uvc_stream_mode_en == 1'b1 )
             )
            begin
              init_ts_ns <= TX_FRAME_HEADER_LEN_INFO;
            end
          else
            begin
              init_ts_ns <= WAIT_BUFFER_AVAILABLE;
            end
        end

      // Send frame header length word
      TX_FRAME_HEADER_LEN_INFO :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          init_ts_ns <= WAIT_BUFFER_AVAILABLE;
        end
          else
            begin
              init_ts_ns <= TX_FRAME_HEADER_LEN_INFO;
            end
        end

      // Wait until READY signal is HIGH.
      WAIT_BUFFER_AVAILABLE :
        begin
          if ( fxn_buffer_ready_i )
            begin
              init_ts_ns <= IS_FLAG_ENABLED;
            end
          else
            begin
              init_ts_ns <= WAIT_BUFFER_AVAILABLE;
            end
        end

      // Check whether 3rd flag (first frame flag) is enabled or not
      IS_FLAG_ENABLED :
        begin
          if ( sel_d_reg_info_st_i.flag_info[3] == 1'b1 )
            begin
              init_ts_ns <= SET_FIRST_FRAME_FLAG;
            end
          else
            begin
              init_ts_ns <= INFORM_THREAD_INIT_SEQ_COMPLETED;
            end
        end

      // Inform FX10 that first frame will be transmitted soon
      SET_FIRST_FRAME_FLAG :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          init_ts_ns <= CLR_FIRST_FRAME_FLAG;
        end
          else
            begin
              init_ts_ns <= SET_FIRST_FRAME_FLAG;
            end
        end

      // Clear the same flag
      CLR_FIRST_FRAME_FLAG :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          init_ts_ns <= INFORM_THREAD_INIT_SEQ_COMPLETED;
        end
          else
            begin
              init_ts_ns <= CLR_FIRST_FRAME_FLAG;
            end
        end

      // Initialization is completed
      INFORM_THREAD_INIT_SEQ_COMPLETED :
        begin
          init_ts_ns <= IDLE;
        end

    endcase
  end

// Next State Signals
always_comb
  begin

    tx_thead_addr_pl             <= 1'b0;
    tx_socket_addr_pl            <= 1'b0;
    clr_payload_counter_pl       <= 1'b0;
    clr_event_counter_pl         <= 1'b0;
    tx_frame_header_len_info_pl  <= 1'b0;
    init_thread_seq_completed_pl <= 1'b0;
    tx_first_frame_flag_pl       <= 1'b0;
    clr_first_frame_flag_pl      <= 1'b0;
    clr_event_counter_1_pl       <= 1'b0;
    incr_flaga_sample_count      <= 1'b0;

    unique case ( init_ts_cs )

      // Frame manager informs to start initialization.
      // If address management needs to be done by FPGA,
      // next state is SET_THREAD_ADDR.
      IDLE :
        begin

        end

      // Initialize thread address
      SET_THREAD_ADDR :
        begin
          tx_thead_addr_pl <= (bit_counter == 1'b0);
        end

      // Initialize socket address
      SET_SOCKET_ADDR :
        begin
          tx_socket_addr_pl <= (bit_counter == 1'b0);
        end

      // Wait for sampling for 50 clock cycles
      // to update FLAGA status
      WAIT_READY_FLAG_ASSERTED :
        begin
          incr_flaga_sample_count    <= 1'b1;
        end

      // Is payload counter enabled?
      IS_PAYLOAD_COUNTER_ENABLED :
        begin

        end

      // Clear payload counter
      INIT_PAYLOAD_COUNTER :
        begin
          clr_payload_counter_pl <= (bit_counter == 1'b0);
        end

      // Is event counter enabled?
      IS_EVENT_COUNTER_ENABLED :
        begin

        end

      // Clear event counter
      INIT_EVENT_COUNTER :
        begin
          clr_event_counter_pl <= (bit_counter == 1'b0);
        end

      // Wait until initialization completes
      INIT_EVENT_COUNTER_1 :
        begin
          clr_event_counter_1_pl <= (bit_counter == 1'b0);
        end

      // Shall FPGA send frame header?
      IS_FRAME_HEADER_ENABLED :
        begin

        end

      // Send frame header length word
      TX_FRAME_HEADER_LEN_INFO :
        begin
          tx_frame_header_len_info_pl <= (bit_counter == 1'b0);
        end

      // Wait until READY signal is HIGH.
      WAIT_BUFFER_AVAILABLE :
        begin

        end

      // Check whether flags are enabled or not
      IS_FLAG_ENABLED :
        begin

        end

      // Inform FX10 that first frame will be transmitted soon
      SET_FIRST_FRAME_FLAG :
        begin
          tx_first_frame_flag_pl <= (bit_counter == 1'b0);
        end

      // Clear the same flag
      CLR_FIRST_FRAME_FLAG :
        begin
          clr_first_frame_flag_pl <= (bit_counter == 1'b0);
        end

      // Initialization is completed
      INFORM_THREAD_INIT_SEQ_COMPLETED :
        begin
          init_thread_seq_completed_pl <= 1'b1;
        end

    endcase
  end


// ------------------------------------------
//
// Register Outputs
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        init_thread_seq_completed_pl_o <= 1'b0;
        // clr_event_counters_pl_f1       <= 1'b0;
      end
    else
      begin
        init_thread_seq_completed_pl_o <= init_thread_seq_completed_pl;
        // clr_event_counters_pl_f1       <= clr_event_counter_pl;
      end
  end


// ---------------------------------------------------
//
// Frame Header Size
//
// ---------------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        frame_header_length <= 8'd0;
      end
    else if ( sel_d_reg_info_st_i.c_n_crc_info == 2'd0 ) // Event Counters are disabled
      begin
        frame_header_length <= UVC_HEADER_LENGTH_IN_BYTES;
      end
    else
      begin
        frame_header_length <= UVC_HEADER_LEN_WITH_EVENT_COUNTERS;
      end
  end


// ------------------------------------------
//
// Control Byte and Valid Signal
//
// ------------------------------------------

// Control Byte
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        its_ctrl_byte_o <= 8'd0;
      end
    else
      begin
        case ( 1'b1 ) // Parallel case. All conditions are mutually exclusive.

          tx_thead_addr_pl                    : its_ctrl_byte_o <= { PARITY_BIT, THREAD_ADDR_CONTROL_BYTE, sel_d_reg_info_st_i.thread_1_info, CONTROL_BYTE_LS_BIT };

          tx_socket_addr_pl                   : its_ctrl_byte_o <= { PARITY_BIT, SOCKET_ADDR_CONTROL_BYTE, sel_d_reg_info_st_i.thread_1_socket_info, CONTROL_BYTE_LS_BIT };

          clr_payload_counter_pl              : its_ctrl_byte_o <= { PARITY_BIT, CLR_PLC_CONTROL_BYTE, CONTROL_BYTE_LS_BIT };

          clr_event_counter_pl &
          sel_d_reg_info_st_i.c_n_crc_info[0] : its_ctrl_byte_o <= { PARITY_BIT, CLR_EC_CONTROL_BYTE, 1'b0, CONTROL_BYTE_LS_BIT }; // EVC[0]

          clr_event_counter_1_pl &
          sel_d_reg_info_st_i.c_n_crc_info[1] : its_ctrl_byte_o <= { PARITY_BIT, CLR_EC_CONTROL_BYTE, 1'b1, CONTROL_BYTE_LS_BIT }; // EVC[1]

          tx_frame_header_len_info_pl         : its_ctrl_byte_o <= { PARITY_BIT, FRAME_HEADER_LW_CONTROL_BYTE, 1'b0, CONTROL_BYTE_LS_BIT }; // always_ff use SVARWL[0]

          tx_first_frame_flag_pl              : its_ctrl_byte_o <= { PARITY_BIT, SET_FLAG_CONTROL_BYTE, 2'd3, CONTROL_BYTE_LS_BIT };

          clr_first_frame_flag_pl             : its_ctrl_byte_o <= { PARITY_BIT, CLEAR_FLAG_CONTROL_BYTE, 2'd3, CONTROL_BYTE_LS_BIT };

          default                             : its_ctrl_byte_o <= IDLE_CONTROL_BYTE;

        endcase
      end
  end

// Control Byte Valid
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        its_ctrl_byte_valid_o <= 1'b0;
      end
    else
      begin
        its_ctrl_byte_valid_o <= (
                                  tx_thead_addr_pl       |
                                  tx_socket_addr_pl      |
                                  clr_payload_counter_pl |
                                  clr_event_counter_pl & sel_d_reg_info_st_i.c_n_crc_info[0] |
                                  clr_event_counter_1_pl & sel_d_reg_info_st_i.c_n_crc_info[1] |
                                  tx_frame_header_len_info_pl |
                                  tx_first_frame_flag_pl |
                                  clr_first_frame_flag_pl
                                 );
      end
  end

// ------------------------------------------
//
// Data Byte and Valid Signal
//
// ------------------------------------------

// Data Byte
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        its_data_byte_o <= 8'd0;
      end
    else if ( tx_frame_header_len_info_pl )
      begin
        its_data_byte_o <= frame_header_length;
      end
  end

// Data Byte Valid
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        its_data_byte_valid_o <= 1'b0;
      end
    else
      begin
        its_data_byte_valid_o <= tx_frame_header_len_info_pl;
      end
  end

// Bit Counter
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        bit_counter <= 3'd0;
      end
    else if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
      begin
        bit_counter <= 3'd0;
      end
    else if ( tx_thead_addr_pl            |
              tx_socket_addr_pl           |
              clr_payload_counter_pl      |
              clr_event_counter_pl        |
              clr_event_counter_1_pl      |
              tx_frame_header_len_info_pl |
              tx_first_frame_flag_pl      |
              clr_first_frame_flag_pl     |
              ( bit_counter != 1'b0 )
            )
      begin
        bit_counter <= bit_counter + 1'b1;
      end
  end


// ----------------------------------------------
//
// Wait before sampling FLAGA
//
// ----------------------------------------------

// FLAGA may take 3 or 4 clocks to get updated
// once new address is available. Here, after
// 10 clock cycles, FLAGA will be sampled.
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        flaga_sample_count <= 8'd0;
      end
    else if ( incr_flaga_sample_count == 1'b0 )
      begin
        flaga_sample_count <= 8'd0;
      end
    else if ( flaga_sample_count == ADDR_TO_FLAGA_DELAY_CLK )
      begin
        flaga_sample_count <= flaga_sample_count;
      end
    else
      begin
        flaga_sample_count <= flaga_sample_count + 1'b1;
      end
  end

endmodule