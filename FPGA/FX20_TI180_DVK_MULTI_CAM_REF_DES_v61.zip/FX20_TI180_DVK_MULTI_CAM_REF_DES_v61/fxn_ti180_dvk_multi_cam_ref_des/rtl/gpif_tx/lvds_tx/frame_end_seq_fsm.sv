//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    frame_end_seq_fsm
// Target Devices: All
//
// Description: This module transmits the frame header information.
//
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module frame_end_seq_fsm
 (
  input               clk,
  input               reset_n,

  // Outputs
  output logic        frame_end_seq_sent_pl_o,
  output logic [ 7:0] fe_ctrl_byte_o,
  output logic        fe_ctrl_byte_valid_o,

  // Inputs
  input               sel_d_reset_or_stop_stream_req_i,
  input               tx_frame_end_seq_pl_i,

  input dev_reg_info_st_t sel_d_reg_info_st_i

 );

// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // Clear any flag of a particular thread
  localparam [3:0] CLEAR_FLAG_CONTROL_BYTE = 4'b1001;

  // Update Event Counter
  localparam [4:0] UPDATE_EC_CONTROL_BYTE = 5'b01100;

  // Total flags per thread
  localparam       NO_OF_FLAGS_FOR_EACH_THREAD = 3'd4;

  // Total EC per thread
  localparam       NO_OF_EC_FOR_EACH_THREAD = 2'd2;

  // LSbit of Control Byte
  localparam [0:0] CONTROL_BYTE_LS_BIT = 1'b1;

  // IDLE Control Byte
  localparam [7:0] IDLE_CONTROL_BYTE = 8'd1;

  // No of States
  localparam       NO_OF_FSM_STATES = 6;

  // Parity Bit: Will be added by "data_n_control_byte_manager"
  localparam [0:0] PARITY_BIT = 1'd0;

  // FSM States
  enum logic [(NO_OF_FSM_STATES-1):0] {
    IDLE                         = 6'h1,
    IS_FLAG_ENABLED              = 6'h2,
    TX_CLR_FLAG_CTRL_BYTE        = 6'h4,
    IS_EVENT_COUNTER_ENABLED     = 6'h8,
    TX_UPDATE_EV_COUNT_CTRL_BYTE = 6'h10,
    INFORM_FRAME_END_SEQ_SENT    = 6'h20
  } fe_cs, fe_ns;

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic  clr_frame_valid_flag_pl;
  logic  update_ec_pl;
  logic  frame_end_seq_sent_pl;
  logic [3:0] bit_counter;

// ------------------------------------------
//
// FSM
//
// ------------------------------------------

// Current State
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fe_cs <= IDLE;
      end
    else if ( sel_d_reset_or_stop_stream_req_i )
      begin
        fe_cs <= IDLE;
      end
    else
      begin
        fe_cs <= fe_ns;
      end
  end

// Next State
always_comb
  begin
    fe_ns <= IDLE;
    unique case ( fe_cs )

      // Wait until Frame Manager informs to
      // transmit Frame End Sequence.
      IDLE :
        begin
          if ( tx_frame_end_seq_pl_i == 1'b1 )
            begin
              fe_ns <= IS_FLAG_ENABLED;
            end
          else
            begin
              fe_ns <= IDLE;
            end
        end

      // Check whether first flag (frame valid) is enabled or not
      IS_FLAG_ENABLED :
        begin
          if ( sel_d_reg_info_st_i.flag_info[0] == 1'b1 )
            begin
              fe_ns <= TX_CLR_FLAG_CTRL_BYTE;
            end
          else
            begin
              fe_ns <= IS_EVENT_COUNTER_ENABLED;
            end
        end

      // Clear "Frame Valid" Flag
      TX_CLR_FLAG_CTRL_BYTE :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          fe_ns <= IS_EVENT_COUNTER_ENABLED;
        end
          else
            begin
              fe_ns <= TX_CLR_FLAG_CTRL_BYTE;
            end
        end

      // Is event counter enabled?
      IS_EVENT_COUNTER_ENABLED :
        begin
          if ( sel_d_reg_info_st_i.c_n_crc_info[0] == 1'b1 )
            begin
              fe_ns <= TX_UPDATE_EV_COUNT_CTRL_BYTE;
            end
          else
            begin
              fe_ns <= INFORM_FRAME_END_SEQ_SENT;
            end
        end

      // Send update event count control byte
      TX_UPDATE_EV_COUNT_CTRL_BYTE :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          fe_ns <= INFORM_FRAME_END_SEQ_SENT;
        end
          else
            begin
              fe_ns <= TX_UPDATE_EV_COUNT_CTRL_BYTE;
            end
        end

      // Frame end sequence is sent
      INFORM_FRAME_END_SEQ_SENT :
        begin
          fe_ns <= IDLE;
        end

    endcase
  end


// Next State Signals
always_comb
  begin

    clr_frame_valid_flag_pl <= 1'b0;
    update_ec_pl            <= 1'b0;
    frame_end_seq_sent_pl   <= 1'b0;

    unique case ( fe_cs )

      // Wait until Frame Manager informs to
      // transmit Frame End Sequence.
      IDLE :
        begin

        end

      // Check whether first flag (frame valid) is enabled or not
      IS_FLAG_ENABLED :
        begin

        end

      // Clear "Frame Valid" Flag
      TX_CLR_FLAG_CTRL_BYTE :
        begin
          clr_frame_valid_flag_pl <= ( bit_counter == 1'b0 );
        end

      // Is event counter enabled?
      IS_EVENT_COUNTER_ENABLED :
        begin

        end

      // Send update event count control byte
      TX_UPDATE_EV_COUNT_CTRL_BYTE :
        begin
          update_ec_pl <= ( bit_counter == 1'b0 );
        end

      // Frame end sequence is sent
      INFORM_FRAME_END_SEQ_SENT :
        begin
          frame_end_seq_sent_pl <= 1'b1;
        end

    endcase
  end

// ------------------------------------------
//
// Register Outputs
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        frame_end_seq_sent_pl_o <= 1'b0;
      end
    else
      begin
        frame_end_seq_sent_pl_o <= frame_end_seq_sent_pl;
      end
  end


// ------------------------------------------
//
// Control Byte and Valid Signal
//
// ------------------------------------------

// Control Byte
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fe_ctrl_byte_o <= 8'd0;
      end
    else
      begin
        case ( 1'b1 ) // Parallel case. All conditions are mutually exclusive.

          clr_frame_valid_flag_pl : fe_ctrl_byte_o <= { PARITY_BIT, CLEAR_FLAG_CONTROL_BYTE, 2'b0, CONTROL_BYTE_LS_BIT };

          update_ec_pl            : fe_ctrl_byte_o <= { PARITY_BIT, UPDATE_EC_CONTROL_BYTE, 1'b0, CONTROL_BYTE_LS_BIT };

          default                 : fe_ctrl_byte_o <= IDLE_CONTROL_BYTE;

        endcase
      end
  end

// Control Byte Valid
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fe_ctrl_byte_valid_o <= 1'b0;
      end
    else
      begin
        fe_ctrl_byte_valid_o <= (
                                 clr_frame_valid_flag_pl |
                                 update_ec_pl
                                );
      end
  end

// Bit Counter
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        bit_counter <= 3'd0;
      end
    else if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
      begin
        bit_counter <= 3'd0;
      end
    else if ( ( clr_frame_valid_flag_pl | update_ec_pl ) |
              ( bit_counter != 1'b0 )
            )
      begin
        bit_counter <= bit_counter + 1'b1;
      end
  end

endmodule
