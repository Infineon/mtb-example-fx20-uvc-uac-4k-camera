//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    data_n_ctrl_byte_generator
// Target Devices: All
//
// Description: This module generates the data and control bytes for FX10. It
//              includes the parity generator as well.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module data_n_ctrl_byte_generator
  #
  (
   // Gear Ratio for LVDS
   parameter LVDS_TX_GEAR_RATIO_I = 4'd8,

   // LVDS Data Lanes
   parameter TOTAL_LVDS_DATA_LANES_I = 16,

   // Active LVDS Data Lane Mask MSBit
   parameter ACTIVE_LVDS_DATA_LANE_MASK_MSB_I = 15,

   // Active LVDS Data Lane Mask LSBit
   parameter ACTIVE_LVDS_DATA_LANE_MASK_LSB_I = 0,

   // FPGA Serializer needs LSBit first and FX10 needs MSBit first
   parameter TX_SERIALIZER_LSB_FIRST_I = 1
  )
 (
  input               clk,
  input               reset_n,

  // Outputs
  output logic [(LVDS_TX_GEAR_RATIO_I-1):0] ctrl_byte_o,
  output logic [15:0][(LVDS_TX_GEAR_RATIO_I-1):0] wr_data_o,


  // Inputs
  // Control Bytes
  input        [ 7:0] fe_ctrl_byte_i,
  input        [ 7:0] dp_ctrl_byte_i,
  input        [ 7:0] pnl_ctrl_byte_i,
  input        [ 7:0] fh_ctrl_byte_i,
  input        [ 7:0] its_ctrl_byte_i,
  input        [ 7:0] fm_ctrl_byte_i,

  // Data Bytes
  input        [ 7:0] dp_data_byte_i,
  input        [ 7:0] its_data_byte_i,
  input        [ 7:0] pnl_data_byte_i,

  // Valid Signals
  input               fe_ctrl_byte_valid_i,
  input               dp_ctrl_byte_valid_i,
  input               pnl_ctrl_byte_valid_i,
  input               fh_ctrl_byte_valid_i,
  input               its_ctrl_byte_valid_i,
  input               its_data_byte_valid_i,
  input               pnl_data_byte_valid_i,
  input               dp_data_byte_valid_i,
  input               slfifo_rd_data_valid_i,
  input               uvc_header_data_valid_i,
  input               u3v_header_data_valid_i,
  input               fm_ctrl_byte_valid_i,

  input       [(TOTAL_LVDS_DATA_LANES_I * 8)-1:0] slfifo_rd_data_i,
  input       [(TOTAL_LVDS_DATA_LANES_I * 8)-1:0] uvc_frame_header_data_i,
  input       [(TOTAL_LVDS_DATA_LANES_I * 8)-1:0] u3v_frame_header_data_i

 );

// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // IDLE Control Byte
  localparam [ 7:0] IDLE_CONTROL_BYTE = 8'd1;

  // Reference count for reading Control and Data FIFO
  localparam BIT_COUNTER_REF_COUNT_FOR_CTRL_N_DATA_FIFO_RD = ( ( NO_OF_CLK_REQ_FOR_BYTE < 3 ) ? ( NO_OF_CLK_REQ_FOR_BYTE - 1 ) : ( NO_OF_CLK_REQ_FOR_BYTE - 3 ) );

// ------------------------------------------
//
// Local Variable
//
// ------------------------------------------

  logic [ACTIVE_LVDS_DATA_LANE_MASK_MSB_I:ACTIVE_LVDS_DATA_LANE_MASK_LSB_I][7:0] data_fifo_wr_data;
  logic [ACTIVE_LVDS_DATA_LANE_MASK_MSB_I:ACTIVE_LVDS_DATA_LANE_MASK_LSB_I][7:0] data_fifo_rd_data;
  logic [ACTIVE_LVDS_DATA_LANE_MASK_MSB_I:ACTIVE_LVDS_DATA_LANE_MASK_LSB_I][7:0] wr_data;

  logic       data_fifo_wr_req;
  logic       ctrl_fifo_empty;
  logic       ctrl_fifo_rd_valid;
  logic       ctrl_fifo_wr_req;
  logic       ctrl_fifo_rd_req;
  logic       ctrl_fifo_reset_busy;
  logic [7:0] ctrl_byte;
  logic [7:0] ctrl_fifo_wr_data;
  logic [7:0] ctrl_fifo_rd_data;
  logic [2:0] bit_counter;

  genvar data_lane;

// ------------------------------------------
//
// Control FIFO
//
// ------------------------------------------

data_n_ctrl_fifo
 #
 (
  // Parameters
   .DATA_WIDTH_IN_BITS_I  ( 8  /* CTRL_BYTE_FIFO_DATA_WIDTH_IN_BITS_I */ ),
   .FIFO_DEPTH_IN_WORDS_I ( 64 /* CTRL_BYTE_FIFO_DEPTH_IN_WORDS_I */ )
 )
  control_byte_fifo
    (
     .almost_full_o      (  ),
     .prog_full_o        (  ),
     .full_o             (  ),
     .wr_ack_o           (  ),
     .empty_o            ( ctrl_fifo_empty ),
     .almost_empty_o     (  ),
     .rd_valid_o         ( ctrl_fifo_rd_valid ),
     .clk_i              ( clk ),
     .wr_en_i            ( ctrl_fifo_wr_req ),
     .rd_en_i            ( ctrl_fifo_rd_req ),
     .wdata              ( ctrl_fifo_wr_data ),
     .rst_busy           ( ctrl_fifo_reset_busy ),
     .rdata              ( ctrl_fifo_rd_data ),
     .a_rst_i            ( !reset_n ),
     .datacount_o        (  ),
     .underflow_o        (  ),
     .overflow_o         (  )
    );

// ------------------------------------------
//
// Control FIFO Write Logic
//
// ------------------------------------------

// FIFO to store control byte.
// This is required when more than a clock cycle is needed to
// transmit control byte. During trasmitting control byte,
// if new byte is received, it will be managed by this FIFO.


// MS bit of control byte is an odd parity.
// Here, bit wise XOR operator is used to generate odd parity.
// Inverted bit is the odd parity.
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        ctrl_fifo_wr_data <= IDLE_CONTROL_BYTE;
      end
    else
      begin
        case ( 1'b1 )

          fe_ctrl_byte_valid_i  : ctrl_fifo_wr_data <= { ~(^fe_ctrl_byte_i[6:0]),  fe_ctrl_byte_i[6:0]  };
          dp_ctrl_byte_valid_i  : ctrl_fifo_wr_data <= { ~(^dp_ctrl_byte_i[6:0]),  dp_ctrl_byte_i[6:0]  };
          pnl_ctrl_byte_valid_i : ctrl_fifo_wr_data <= { pnl_ctrl_byte_i[7:0] }; // No need to calculate parity in phy and link training
          fh_ctrl_byte_valid_i  : ctrl_fifo_wr_data <= { ~(^fh_ctrl_byte_i[6:0]),  fh_ctrl_byte_i[6:0]  };
          its_ctrl_byte_valid_i : ctrl_fifo_wr_data <= { ~(^its_ctrl_byte_i[6:0]), its_ctrl_byte_i[6:0] };
          fm_ctrl_byte_valid_i  : ctrl_fifo_wr_data <= { ~(^fm_ctrl_byte_i[6:0]), fm_ctrl_byte_i[6:0] };

          default               : ctrl_fifo_wr_data <= IDLE_CONTROL_BYTE;

        endcase
      end
  end

// Write Request of "Control FIFO"
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        ctrl_fifo_wr_req <= 1'b0;
      end
    else
      begin
        ctrl_fifo_wr_req <= ( fe_ctrl_byte_valid_i  |
                              dp_ctrl_byte_valid_i  |
                              pnl_ctrl_byte_valid_i |
                              fh_ctrl_byte_valid_i  |
                              its_ctrl_byte_valid_i |
                              fm_ctrl_byte_valid_i
                            );
      end
  end

//

  logic [31:0] ctrl_byte_wr_count, ctrl_byte_rd_count, act_ctrl_byte_wr_count;

  always_ff @ ( posedge clk )
    begin
      if ( !reset_n )
        begin
          ctrl_byte_wr_count <= '0;
        end
      else if ( ctrl_fifo_wr_req )
        begin
          if ( ctrl_fifo_wr_data == 8'hEF )
            begin
              ctrl_byte_wr_count <= '0;
            end
          else if ( ctrl_fifo_wr_data == 8'h80 )
            begin
              ctrl_byte_wr_count <= ctrl_byte_wr_count + 1'b1;
            end
        end
    end

  always_ff @ ( posedge clk )
    begin
      if ( !reset_n )
        begin
          act_ctrl_byte_wr_count <= '0;
        end
      else if ( ( ctrl_byte_o == 4'h7 ) & ( bit_counter == 1'b0 ) )
        begin
          act_ctrl_byte_wr_count <= '0;
        end
      else if ( ( ctrl_byte_o == 0 ) & ( bit_counter == 1'b1 ) )
        begin
          act_ctrl_byte_wr_count <= act_ctrl_byte_wr_count + 1'b1;
        end
    end

  always_ff @ ( posedge clk )
    begin
      if ( !reset_n )
        begin
          ctrl_byte_rd_count <= '0;
        end
      else if ( ctrl_fifo_rd_valid )
        begin
          if ( ctrl_fifo_rd_data == 8'hEF )
            begin
              ctrl_byte_rd_count <= '0;
            end
          else if ( ctrl_fifo_rd_data == 8'h80 )
            begin
              ctrl_byte_rd_count <= ctrl_byte_rd_count + 1'b1;
            end
      end
  end



// ------------------------------------------
//
// Control FIFO Read Logic
//
// ------------------------------------------

  // Read Request of "Control FIFO"
  assign ctrl_fifo_rd_req = ( ( ctrl_fifo_empty == 1'b0 ) &
                              ( bit_counter == BIT_COUNTER_REF_COUNT_FOR_CTRL_N_DATA_FIFO_RD ) /* &
                              ( ctrl_fifo_reset_busy == 1'b0 ) */
                            );

  // Control Byte
  always_ff @ ( posedge clk )
    begin
      if ( !reset_n )
        begin
          ctrl_byte <= IDLE_CONTROL_BYTE;
        end
      else if ( ctrl_fifo_rd_valid == 1'b1 )
        begin
          ctrl_byte <= ctrl_fifo_rd_data;
        end
      else if ( /* ( ctrl_fifo_empty == 1'b1 ) & */
                ( ( ( bit_counter == 1'b0 ) & ( LVDS_TX_GEAR_RATIO_I == 8 ) ) | ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 2 ) ) )
              )
        begin
          ctrl_byte <= IDLE_CONTROL_BYTE;
        end
    end

// ------------------------------------------
//
// Data FIFO
//
// ------------------------------------------

// Data FIFO
data_n_ctrl_fifo
 #
 (
  // Parameters
   .DATA_WIDTH_IN_BITS_I  ( TOTAL_LVDS_DATA_LANES_I * 8 ),
   .FIFO_DEPTH_IN_WORDS_I ( 64 /* CTRL_BYTE_FIFO_DEPTH_IN_WORDS_I */ )
 )
  data_fifo
    (
     .almost_full_o      (  ),
     .prog_full_o        (  ),
     .full_o             (  ),
     .wr_ack_o           (  ),
     .empty_o            (  ),
     .almost_empty_o     (  ),
     .rd_valid_o         (  ),
     .clk_i              ( clk ),
     .wr_en_i            ( data_fifo_wr_req ),
     .rd_en_i            ( ctrl_fifo_rd_req ),
     .wdata              ( data_fifo_wr_data ),
     .rst_busy           (  ),
     .rdata              ( data_fifo_rd_data ),
     .a_rst_i            ( !reset_n ),
     .datacount_o        (  ),
     .underflow_o        (  ),
     .overflow_o         (  )
    );

// ------------------------------------------
//
// Data FIFO Write Logic
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        data_fifo_wr_req <= 1'b0;
      end
    else
      begin
        data_fifo_wr_req <= ( pnl_data_byte_valid_i   |
                                       dp_data_byte_valid_i    |
                                       its_data_byte_valid_i   |
                                       slfifo_rd_data_valid_i  |
                                       uvc_header_data_valid_i |
                                       u3v_header_data_valid_i |
                                       fe_ctrl_byte_valid_i    |
                              dp_ctrl_byte_valid_i    |
                              pnl_ctrl_byte_valid_i   |
                                       fh_ctrl_byte_valid_i    |
                                       its_ctrl_byte_valid_i   |
                              fm_ctrl_byte_valid_i
                            );
      end
  end

// Write Request of "Data FIFO"
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        data_fifo_wr_data <= {TOTAL_LVDS_DATA_LANES_I{IDLE_CONTROL_BYTE}};
      end
    else
      begin

        case ( 1'b1 )

          pnl_data_byte_valid_i   : data_fifo_wr_data <= {TOTAL_LVDS_DATA_LANES_I{pnl_data_byte_i}}; // During PHY training, this will take care of data.
          dp_data_byte_valid_i    : data_fifo_wr_data <= {TOTAL_LVDS_DATA_LANES_I{dp_data_byte_i}};
          its_data_byte_valid_i   : data_fifo_wr_data <= {TOTAL_LVDS_DATA_LANES_I{its_data_byte_i}};
          slfifo_rd_data_valid_i  : data_fifo_wr_data <= slfifo_rd_data_i;
          uvc_header_data_valid_i : data_fifo_wr_data <= uvc_frame_header_data_i;
          u3v_header_data_valid_i : data_fifo_wr_data <= u3v_frame_header_data_i;

          default                 : data_fifo_wr_data <= {TOTAL_LVDS_DATA_LANES_I{IDLE_CONTROL_BYTE}};

        endcase

      end
  end

// ------------------------------------------
//
// Data FIFO Read Logic
//
// ------------------------------------------

  // Write Data
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
          wr_data <= {TOTAL_LVDS_DATA_LANES_I{IDLE_CONTROL_BYTE}};
      end
      else if ( ctrl_fifo_rd_valid == 1'b1 )
      begin
          wr_data <= data_fifo_rd_data;
      end
      else if ( /* ( ctrl_fifo_empty == 1'b1 ) & */
                ( ( ( bit_counter == 1'b0 ) & ( LVDS_TX_GEAR_RATIO_I == 8 ) ) | ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 2 ) ) )
              )
      begin
          wr_data <= {TOTAL_LVDS_DATA_LANES_I{IDLE_CONTROL_BYTE}};
      end
  end

//  always_comb
//    begin
//      if ( !reset_n )
//        begin
//          ctrl_byte <= IDLE_CONTROL_BYTE;
//          wr_data   <= {TOTAL_LVDS_DATA_LANES_I{IDLE_CONTROL_BYTE}};
//        end
//      else if ( ( ctrl_fifo_rd_valid == 1'b0 ) &
//                ( ctrl_fifo_empty == 1'b1 ) &
//                ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
//              )
//        begin
//          ctrl_byte <= IDLE_CONTROL_BYTE;
//          wr_data   <= {TOTAL_LVDS_DATA_LANES_I{IDLE_CONTROL_BYTE}};
//        end
//      else
//        begin
//          ctrl_byte <= ctrl_fifo_rd_data;
//          wr_data   <= data_fifo_rd_data;
//        end
//    end


// ------------------------------------------
//
// Misc. Logic
//
// ------------------------------------------

// Bit Counter
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        bit_counter <= 3'd0;
      end
    else if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
      begin
        bit_counter <= 3'd0;
      end
    else
      begin
        bit_counter <= bit_counter + 1'b1;
      end
  end


// ------------------------------------------
//
// Data and Control Byte
//
// ------------------------------------------


// MSB to LSB Conversion
// Some FPGA LVDS TX HIP transmits LSBit first and some MSBit first.
// FX10/20 requires the MSBit first.

// For 8:1 gear ratio
generate
  if ( LVDS_TX_GEAR_RATIO_I == 8 )
    begin : GR_8

      // Data
      for ( data_lane = ACTIVE_LVDS_DATA_LANE_MASK_LSB_I; data_lane <= ACTIVE_LVDS_DATA_LANE_MASK_MSB_I; data_lane++ )
        begin
          always_ff @ ( posedge clk )
            begin
              if ( !reset_n )
                begin
                  wr_data_o[data_lane] <= IDLE_CONTROL_BYTE;
                end
              else if ( TX_SERIALIZER_LSB_FIRST_I == 1'b0 )
                begin
                  wr_data_o[data_lane] <= wr_data[data_lane];
                end
              else
                begin
                  wr_data_o[data_lane] <= {wr_data[data_lane][0], wr_data[data_lane][1], wr_data[data_lane][2], wr_data[data_lane][3],
                                           wr_data[data_lane][4], wr_data[data_lane][5], wr_data[data_lane][6], wr_data[data_lane][7]};
                end
            end
        end

      // Control Byte
      always_ff @ ( posedge clk )
        begin
          if ( !reset_n )
            begin
              ctrl_byte_o <= IDLE_CONTROL_BYTE;
            end
          else if ( TX_SERIALIZER_LSB_FIRST_I == 1'b0 )
            begin
              ctrl_byte_o <= ctrl_byte;
            end
          else
            begin
              ctrl_byte_o <= {ctrl_byte[0], ctrl_byte[1], ctrl_byte[2], ctrl_byte[3],
                              ctrl_byte[4], ctrl_byte[5], ctrl_byte[6], ctrl_byte[7]};
            end
        end
    end
endgenerate


// For 4:1 gear ratio
generate
  if ( LVDS_TX_GEAR_RATIO_I == 4 )
    begin : GR_4

      for ( data_lane = ACTIVE_LVDS_DATA_LANE_MASK_LSB_I; data_lane <= ACTIVE_LVDS_DATA_LANE_MASK_MSB_I; data_lane++ )
        begin
          always_ff @ ( posedge clk )
            begin
              if ( !reset_n )
                begin
                  wr_data_o[data_lane] <= '0;
                end
              else if ( TX_SERIALIZER_LSB_FIRST_I == 1'b0 )
                begin
                  unique case ( bit_counter )
                      3'd1: wr_data_o[data_lane] <= wr_data[data_lane][7:4];

                      3'd0: wr_data_o[data_lane] <= wr_data[data_lane][3:0];
                  endcase
                end
              else
                begin
                  unique case ( bit_counter )
                      3'd1: wr_data_o[data_lane] <= {wr_data[data_lane][4], wr_data[data_lane][5], wr_data[data_lane][6], wr_data[data_lane][7]};

                      3'd0: wr_data_o[data_lane] <= {wr_data[data_lane][0], wr_data[data_lane][1], wr_data[data_lane][2], wr_data[data_lane][3]};
                  endcase
                end
            end
        end

      // Control Byte
      always_ff @ ( posedge clk )
        begin
          if ( !reset_n )
            begin
              ctrl_byte_o <= 4'(IDLE_CONTROL_BYTE);
            end
          else if ( TX_SERIALIZER_LSB_FIRST_I == 1'b0 )
            begin
              unique case ( bit_counter )
                  3'd1: ctrl_byte_o <= ctrl_byte[7:4];

                  3'd0: ctrl_byte_o <= ctrl_byte[3:0];
              endcase
            end
          else
            begin
              unique case ( bit_counter )
                  3'd1: ctrl_byte_o <= {ctrl_byte[4], ctrl_byte[5], ctrl_byte[6], ctrl_byte[7]};

                  3'd0: ctrl_byte_o <= {ctrl_byte[0], ctrl_byte[1], ctrl_byte[2], ctrl_byte[3]};
              endcase
            end
        end
    end
endgenerate


// For 2:1 gear ratio
generate
  if ( LVDS_TX_GEAR_RATIO_I == 2 )
    begin : GR_2

      for ( data_lane = ACTIVE_LVDS_DATA_LANE_MASK_LSB_I; data_lane <= ACTIVE_LVDS_DATA_LANE_MASK_MSB_I; data_lane++ )
        begin
          always_ff @ ( posedge clk )
            begin
              if ( !reset_n )
                begin
                  wr_data_o[data_lane] <= '0;
                end
              else if ( TX_SERIALIZER_LSB_FIRST_I == 1'b0 )
                begin
                  unique case ( bit_counter )
                      3'd3: wr_data_o[data_lane] <= wr_data[data_lane][7:6];

                      3'd0: wr_data_o[data_lane] <= wr_data[data_lane][5:4];

                      3'd1: wr_data_o[data_lane] <= wr_data[data_lane][3:2];

                      3'd2: wr_data_o[data_lane] <= wr_data[data_lane][1:0];
                  endcase
                end
              else
                begin
                  unique case ( bit_counter )
                      3'd3: wr_data_o[data_lane] <= {wr_data[data_lane][6], wr_data[data_lane][7]};

                      3'd0: wr_data_o[data_lane] <= {wr_data[data_lane][4], wr_data[data_lane][5]};

                      3'd1: wr_data_o[data_lane] <= {wr_data[data_lane][2], wr_data[data_lane][3]};

                      3'd2: wr_data_o[data_lane] <= {wr_data[data_lane][0], wr_data[data_lane][1]};
                  endcase
                end
            end
        end

      // Control Byte
      always_ff @ ( posedge clk )
        begin
          if ( !reset_n )
            begin
              ctrl_byte_o <= 2'(IDLE_CONTROL_BYTE);
            end
          else if ( TX_SERIALIZER_LSB_FIRST_I == 1'b0 )
            begin
              unique case ( bit_counter )
                  3'd3: ctrl_byte_o <= ctrl_byte[7:6];

                  3'd0: ctrl_byte_o <= ctrl_byte[5:4];

                  3'd1: ctrl_byte_o <= ctrl_byte[3:2];

                  3'd2: ctrl_byte_o <= ctrl_byte[1:0];
              endcase
            end
          else
            begin
              unique case ( bit_counter )
                  3'd3: ctrl_byte_o <= {ctrl_byte[6], ctrl_byte[7]};

                  3'd0: ctrl_byte_o <= {ctrl_byte[4], ctrl_byte[5]};

                  3'd1: ctrl_byte_o <= {ctrl_byte[2], ctrl_byte[3]};

                  3'd2: ctrl_byte_o <= {ctrl_byte[0], ctrl_byte[1]};
              endcase
            end
        end
    end
endgenerate


// For 1:1 gear ratio
generate
  if ( LVDS_TX_GEAR_RATIO_I == 1 )
    begin : GR_1

      for ( data_lane = ACTIVE_LVDS_DATA_LANE_MASK_LSB_I; data_lane <= ACTIVE_LVDS_DATA_LANE_MASK_MSB_I; data_lane++ )
        begin
          always_ff @ ( posedge clk )
            begin
              if ( !reset_n )
                begin
                  wr_data_o[data_lane] <= '0;
                end
              else
                begin
                  wr_data_o[data_lane] <= wr_data[data_lane][3'd7 - bit_counter];
                end
            end
        end

      // Control Byte
      always_ff @ ( posedge clk )
        begin
          if ( !reset_n )
            begin
              ctrl_byte_o <= 1'(IDLE_CONTROL_BYTE);
            end
          else
            begin
              ctrl_byte_o <= ctrl_byte[3'd7 - bit_counter];
            end
        end

    end
endgenerate


endmodule
