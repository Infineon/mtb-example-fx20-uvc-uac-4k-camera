//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fxn_lvds_tx_top
// Target Devices: All
//
// Description: This is lvds top module which includes following modules,
//
//                 1. Device Selection FSM
//                 2. Frame Manager FSM
//                 3. LVDS PHY and Link Training FSM
//                 4. Initial thread sequence FSM
//                 5. Frame Header Information FSM
//                 6. Data Packet Manager FSM
//                 7. Frame End Sequence FSM
//                 8. Data and Control Byte Generator
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module fxn_lvds_tx_top
  #
  (
   // Address to be managed by FPGA or not
   parameter ADDR_MANAGED_BY_FPGA_I = "TRUE",

   // Clock Value
   parameter GPIF_M_CLK_VALUE_I = 75_000_000,

   // GPIF Master Mode: LVDS or LVCMOS
   parameter GPIF_MASTER_MODE_I = "LVDS",

   // LVDS PHY Training Interval in micro seconds
   parameter LVDS_PHY_TS_TIME_IN_US_I = 50,

   // Gear Ratio for LVDS
   parameter LVDS_TX_GEAR_RATIO_I = 4'd8,

   // LVDS Data Lanes
   parameter TOTAL_DATA_LANES_I = 16,

   // Active LVDS Data Lane Mask MSBit
   parameter ACTIVE_LVDS_DATA_LANE_MASK_MSB_I = 15,

   // Active LVDS Data Lane Mask LSBit
   parameter ACTIVE_LVDS_DATA_LANE_MASK_LSB_I = 0,

   // FPGA Serializer needs LSBit first and FX10 needs MSBit first
   parameter TX_SERIALIZER_LSB_FIRST_I = 1,

   // No. of devices/ FIFOs needed
   parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
   parameter SEL_DEV_NUM_BITS_I = 3
  )
 (
  input              clk,
  input              reset_n,

  // Outputs
  output             change_thread_addr_pl_o,
  output             tx_eop_control_byte_pl_n_o,
//  output             slfifo_rd_req_o,
//  output             slfifo_reset_req_o,
  output     [(SEL_DEV_NUM_BITS_I-1):0]  sel_device_num_o,
  output             sel_d_reset_or_stop_stream_req_o,
  output     [(LVDS_TX_GEAR_RATIO_I-1):0] ctrl_byte_o,
  output     [15:0][(LVDS_TX_GEAR_RATIO_I-1):0]  wr_data_o,
  output             l_zlp_sent_o,
  output             full_buffer_sent_o,
  output             wait_for_new_buffer_o,

  // Inputs
  input              fxn_lvds_rx_link_ready_i,
  input              enter_l1_mode_i,
  input              enter_l2_mode_i,
  input              exit_l1_mode_i,
  input              exit_l2_mode_i,
  input              fxn_buffer_ready_i,
  input              cam_config_done_i,
  input              new_thread_addr_available_pl_i,
  input  [(NO_OF_SUPPORTED_DEV_I-1):0]   vsync_i,
//  input              slfifo_almost_empty_i,
//  input              slfifo_rd_data_valid_i,

//  input      [(TOTAL_DATA_LANES_I*LVDS_TX_GEAR_RATIO_I)-1:0] slfifo_rd_data_i,

  input  common_reg_info_st_t    common_reg_info_i,
  input  dev_reg_info_st_t          [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_i,
  input  slfifo_data_nd_status_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] slfifo_data_nd_status_st_arr_i,
  output slfifo_ctrl_req_st_t       [(NO_OF_SUPPORTED_DEV_I-1):0] slfifo_ctrl_req_st_arr_o,
  output dev_reg_info_st_t       sel_d_reg_info_st_o
 );

// ------------------------------------------
//
// Local Parameter
//
// ------------------------------------------

  // IDLE Interval in micro seconds after training completes
  localparam IDLE_TIME_AFTER_TRAINING_IN_US = 3;

  // No of Link Training Count
  localparam LINK_TRAINING_COUNT = 1;

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic        lvds_phy_n_link_training_done_pl;
  logic        full_frame_sent_pl;
  logic        start_lvds_phy_n_link_training_pl;
  logic        start_serving_device_pl;
  logic        tx_thread_init_seq_pl;
  logic        init_thread_seq_completed_pl;
  logic        tx_frame_header_info_pl;
  logic        tx_data_pkt_pl;
  logic        tx_frame_end_seq_pl;
  logic        frame_header_info_sent_pl;
  logic        frame_data_sent_pl;
  logic        frame_end_seq_sent_pl;
  logic        uvc_header_data_valid;
  logic        u3v_header_data_valid;

  logic [(TOTAL_DATA_LANES_I * 8)-1:0] uvc_frame_header_data;
  logic [(TOTAL_DATA_LANES_I * 8)-1:0] u3v_frame_header_data;
  logic [ 7:0] fe_ctrl_byte;
  logic [ 7:0] dp_ctrl_byte;
  logic [ 7:0] pnl_ctrl_byte;
  logic [ 7:0] fh_ctrl_byte;
  logic [ 7:0] dp_data_byte;
  logic [ 7:0] its_data_byte;
  logic [ 7:0] its_ctrl_byte;
  logic [ 7:0] pnl_data_byte;
  logic [ 7:0] fm_ctrl_byte;
  logic        fh_ctrl_byte_valid;
  logic        dp_ctrl_byte_valid;
  logic        fe_ctrl_byte_valid;
  logic        pnl_ctrl_byte_valid;
  logic        its_ctrl_byte_valid;
  logic        its_data_byte_valid;
  logic        dp_data_byte_valid;
  logic        pnl_data_byte_valid;
  logic        fm_ctrl_byte_valid;
  // logic        lvds_phy_training_ongoing;
  logic        all_devices_served_pl;
  logic        data_packet_sent_pl;
  logic        data_pkt_sent_pl;
//  logic        sel_d_reset_or_stop_stream_req;
  logic [31:0] sel_d_frame_size_in_bytes;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0][31:0] no_of_frame_bytes_yet_to_be_sent;

// ------------------------------------------
//
// Device Selection FSM
//
// ------------------------------------------

dev_selection_fsm
  #
  (
   // Parameters
   .GPIF_MASTER_MODE_I                    (GPIF_MASTER_MODE_I),
   .TOTAL_DATA_LANES_I                    (TOTAL_DATA_LANES_I),
   .NO_OF_SUPPORTED_DEV_I                 (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I                    (SEL_DEV_NUM_BITS_I))
  lvds_tx_dsf
   (
    // Outputs
    .all_devices_served_pl_o              (all_devices_served_pl),
    .start_lvds_phy_n_link_training_pl_o  (start_lvds_phy_n_link_training_pl),
    .start_serving_device_pl_o            (start_serving_device_pl),
    .sel_device_num_o                     (sel_device_num_o[(SEL_DEV_NUM_BITS_I-1):0]),
    .enter_l1_lp_mode_o                   (),  // Not supported
    .enter_l2_lp_mode_o                   (),  // Not supported
    .exit_l1_lp_mode_o                    (),  // Not supported
    .exit_l2_lp_mode_o                    (),  // Not supported
    .sel_d_reset_or_stop_stream_req_o     (sel_d_reset_or_stop_stream_req_o),
    .sel_d_frame_size_in_bytes_o          (sel_d_frame_size_in_bytes),
    .sel_d_reg_info_st_o                  (sel_d_reg_info_st_o),

    // Inputs
    .clk                                  (clk),
    .reset_n                              (reset_n),
    .fxn_lvds_rx_link_ready_i             (fxn_lvds_rx_link_ready_i),
    .fxn_buffer_ready_i                   (fxn_buffer_ready_i),
    .lvds_phy_n_link_training_done_pl_i   (lvds_phy_n_link_training_done_pl),
    .enter_l1_mode_i                      (enter_l1_mode_i),
    .enter_l2_mode_i                      (enter_l2_mode_i),
    .exit_l1_mode_i                       (exit_l1_mode_i),
    .exit_l2_mode_i                       (exit_l2_mode_i),
    .full_frame_sent_pl_i                 (full_frame_sent_pl),
    .data_pkt_sent_pl_i                   (data_pkt_sent_pl),
    .slfifo_data_nd_status_st_arr_i       (slfifo_data_nd_status_st_arr_i),
    .common_reg_info_i                    (common_reg_info_i),
    .dev_reg_info_st_arr_i                (dev_reg_info_st_arr_i[(NO_OF_SUPPORTED_DEV_I-1):0]));


// ------------------------------------------
//
// Frame Manager FSM
//
// ------------------------------------------

frame_manager_fsm
  #
  (
   // Parameters
   .ADDR_MANAGED_BY_FPGA_I               (ADDR_MANAGED_BY_FPGA_I),
   .NO_OF_SUPPORTED_DEV_I                (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I                   (SEL_DEV_NUM_BITS_I)
   )
  fmf
   (
    // Outputs
    .tx_thread_init_seq_pl_o              (tx_thread_init_seq_pl),
    .tx_frame_header_info_pl_o            (tx_frame_header_info_pl),
    .tx_data_pkt_pl_o                     (tx_data_pkt_pl),
    .tx_frame_end_seq_pl_o                (tx_frame_end_seq_pl),
    .full_frame_sent_pl_o                 (full_frame_sent_pl),
    .data_pkt_sent_pl_o                   (data_pkt_sent_pl),
    .slfifo_reset_req_o                   (/* slfifo_reset_req_o */),
    .fm_ctrl_byte_o                       (fm_ctrl_byte),
    .fm_ctrl_byte_valid_o                 (fm_ctrl_byte_valid),
    // Inputs
    .clk                                  (clk),
    .reset_n                              (reset_n),
    .fxn_buffer_ready_i                   (fxn_buffer_ready_i),
    .slfifo_almost_empty_i                (slfifo_data_nd_status_st_arr_i[sel_device_num_o].almost_empty),
    .sel_d_reset_or_stop_stream_req_i     (sel_d_reset_or_stop_stream_req_o),
    .sel_d_frame_size_in_bytes_i          (sel_d_frame_size_in_bytes),
    .init_thread_seq_completed_pl_i       (init_thread_seq_completed_pl),
    .sel_device_num_i                     (sel_device_num_o[(SEL_DEV_NUM_BITS_I-1):0]),
    .start_serving_device_pl_i            (start_serving_device_pl),
    .frame_header_info_sent_pl_i          (frame_header_info_sent_pl),
    .frame_data_sent_pl_i                 (frame_data_sent_pl),
    .data_packet_sent_pl_i                (data_packet_sent_pl),
    .no_of_frame_bytes_yet_to_be_sent_i   (no_of_frame_bytes_yet_to_be_sent),
    .frame_end_seq_sent_pl_i              (frame_end_seq_sent_pl),
    .common_reg_info_i                    (common_reg_info_i),
    .sel_d_reg_info_st_i                  (sel_d_reg_info_st_o));


// ------------------------------------------
//
// PHY and Link Training
//
// ------------------------------------------

lvds_phy_n_link_training_fsm
  #
  (
   // Parameters
   .GPIF_M_CLK_VALUE_I                  (GPIF_M_CLK_VALUE_I),
   .ADDR_MANAGED_BY_FPGA_I              (ADDR_MANAGED_BY_FPGA_I),
   .GPIF_MASTER_MODE_I                  (GPIF_MASTER_MODE_I),
   .LVDS_PHY_TS_TIME_IN_US_I            (LVDS_PHY_TS_TIME_IN_US_I),
   .LINK_TRAINING_COUNT_I               (LINK_TRAINING_COUNT),
   .IDLE_TIME_AFTER_TRAINING_IN_US_I    (IDLE_TIME_AFTER_TRAINING_IN_US),
   .DATA_WIDTH_IN_BITS_I                (32))
  lvds_tx_lpnltf
   (
    // Outputs
    .pnl_slf_wr_data_o                   (),
    .pnl_slf_data_valid_o                (),
    .pnl_ctrl_byte_o                     (pnl_ctrl_byte[7:0]),
    .pnl_data_byte_o                     (pnl_data_byte[7:0]),
    .pnl_ctrl_byte_valid_o               (pnl_ctrl_byte_valid),
    .pnl_data_byte_valid_o               (pnl_data_byte_valid),
    .lvds_phy_n_link_training_done_pl_o  (lvds_phy_n_link_training_done_pl),
    // .lvds_phy_training_ongoing_o         (lvds_phy_training_ongoing),

    // Inputs
    .clk                                 (clk),
    .reset_n                             (reset_n),
    .start_lvds_phy_n_link_training_pl_i (start_lvds_phy_n_link_training_pl),
    .common_reg_info_i                   (common_reg_info_i));


// ------------------------------------------
//
// Initial Sequence
//
// ------------------------------------------

init_thread_seq_fsm
  #
  (
   // Parameters
   .ADDR_MANAGED_BY_FPGA_I            (ADDR_MANAGED_BY_FPGA_I))
  itsf
   (
    // Outputs
    .init_thread_seq_completed_pl_o   (init_thread_seq_completed_pl),
    .its_data_byte_o                  (its_data_byte[7:0]),
    .its_ctrl_byte_o                  (its_ctrl_byte[7:0]),
    .its_data_byte_valid_o            (its_data_byte_valid),
    .its_ctrl_byte_valid_o            (its_ctrl_byte_valid),
    // Inputs
    .clk                              (clk),
    .reset_n                          (reset_n),
    .sel_d_reset_or_stop_stream_req_i (sel_d_reset_or_stop_stream_req_o),
    .tx_thread_init_seq_pl_i          (tx_thread_init_seq_pl),
    .fxn_buffer_ready_i               (fxn_buffer_ready_i),
    .sel_d_reg_info_st_i              (sel_d_reg_info_st_o),
    .common_reg_info_i                (common_reg_info_i));


// ------------------------------------------
//
// Frame Header
//
// ------------------------------------------

frame_header_info_fsm
  #
  (
   // Parameters
   .NO_OF_SUPPORTED_DEV_I                  (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I                     (SEL_DEV_NUM_BITS_I)
   )
  fhif
   (
    // Outputs
    .fh_ctrl_byte_o                   (fh_ctrl_byte[7:0]),
    .fh_ctrl_byte_valid_o             (fh_ctrl_byte_valid),
    .frame_header_info_sent_pl_o      (frame_header_info_sent_pl),
    // Inputs
    .clk                              (clk),
    .reset_n                          (reset_n),
    .sel_d_reset_or_stop_stream_req_i (sel_d_reset_or_stop_stream_req_o),
    .tx_frame_header_info_pl_i        (tx_frame_header_info_pl),
    .cam_config_done_i                (cam_config_done_i),
    .fxn_buffer_ready_i               (fxn_buffer_ready_i),
    .full_frame_sent_pl_i             (full_frame_sent_pl),
    .vsync_i                          (vsync_i),
    .sel_device_num_i                 (sel_device_num_o[(SEL_DEV_NUM_BITS_I-1):0]),
    .sel_d_reg_info_st_i              (sel_d_reg_info_st_o));


// ------------------------------------------
//
// Data Packet Manager
//
// ------------------------------------------

data_pkt_manager_fsm
  #
  (
   // Parameters
   .ADDR_MANAGED_BY_FPGA_I             (ADDR_MANAGED_BY_FPGA_I),
   .TOTAL_LVDS_DATA_LANES_I            (TOTAL_DATA_LANES_I),
   .LVDS_TX_GEAR_RATIO_I               (LVDS_TX_GEAR_RATIO_I),
   .NO_OF_SUPPORTED_DEV_I              (NO_OF_SUPPORTED_DEV_I),
   .SEL_DEV_NUM_BITS_I                 (SEL_DEV_NUM_BITS_I))
  dpmf
   (
    // Outputs
    .frame_data_sent_pl_o              (frame_data_sent_pl),
    .data_packet_sent_pl_o             (data_packet_sent_pl),
    .change_thread_addr_pl_o           (change_thread_addr_pl_o),
    .slfifo_rd_req_o                   (slfifo_ctrl_req_st_arr_o[sel_device_num_o].rd_req),
    .dp_ctrl_byte_o                    (dp_ctrl_byte[7:0]),
    .dp_data_byte_o                    (dp_data_byte[7:0]),
    .dp_ctrl_byte_valid_o              (dp_ctrl_byte_valid),
    .dp_data_byte_valid_o              (dp_data_byte_valid),
    .tx_eop_control_byte_pl_n_o        (tx_eop_control_byte_pl_n_o),
    .slfifo_reset_req_o                (slfifo_ctrl_req_st_arr_o[sel_device_num_o].reset_req),
    .l_zlp_sent_o                      (l_zlp_sent_o),
    .uvc_header_data_valid_o           (uvc_header_data_valid),
    .uvc_frame_header_data_o           (uvc_frame_header_data),
    .u3v_header_data_valid_o           (u3v_header_data_valid),
    .no_of_frame_bytes_yet_to_be_sent_o   (no_of_frame_bytes_yet_to_be_sent),
    .u3v_frame_header_data_o           (u3v_frame_header_data),
    .full_buffer_sent_o                (full_buffer_sent_o),
    .wait_for_new_buffer_o             (wait_for_new_buffer_o),

    // Inputs
    .clk                               (clk),
    .reset_n                           (reset_n),
    .all_devices_served_pl_i           (all_devices_served_pl),
    .sel_d_reset_or_stop_stream_req_i  (sel_d_reset_or_stop_stream_req_o),
    .sel_device_num_i                  (sel_device_num_o[(SEL_DEV_NUM_BITS_I-1):0]),
    .tx_data_pkt_pl_i                  (tx_data_pkt_pl),
    .fxn_buffer_ready_i                (fxn_buffer_ready_i),
    .new_thread_addr_available_pl_i     (new_thread_addr_available_pl_i),
    .slfifo_almost_empty_i             (slfifo_data_nd_status_st_arr_i[sel_device_num_o].almost_empty),
    .frame_size_info_i                 (sel_d_frame_size_in_bytes[31:0]),
    .common_reg_info_i                 (common_reg_info_i),
    .sel_d_reg_info_st_i               (sel_d_reg_info_st_o));

// ------------------------------------------
//
// Data Packet Manager
//
// ------------------------------------------

frame_end_seq_fsm
  fesf
   (
    // Outputs
    .frame_end_seq_sent_pl_o          (frame_end_seq_sent_pl),
    .fe_ctrl_byte_o                   (fe_ctrl_byte[7:0]),
    .fe_ctrl_byte_valid_o             (fe_ctrl_byte_valid),
    // Inputs
    .clk                              (clk),
    .reset_n                          (reset_n),
    .sel_d_reset_or_stop_stream_req_i (sel_d_reset_or_stop_stream_req_o),
    .tx_frame_end_seq_pl_i            (tx_frame_end_seq_pl),
    .sel_d_reg_info_st_i              (sel_d_reg_info_st_o));


// ------------------------------------------
//
// Data & Control Byte Generator
//
// ------------------------------------------

data_n_ctrl_byte_generator
  #
  (
   // Parameters
   .TOTAL_LVDS_DATA_LANES_I       (TOTAL_DATA_LANES_I),
   .ACTIVE_LVDS_DATA_LANE_MASK_MSB_I  (ACTIVE_LVDS_DATA_LANE_MASK_MSB_I),
   .ACTIVE_LVDS_DATA_LANE_MASK_LSB_I  (ACTIVE_LVDS_DATA_LANE_MASK_LSB_I),
   .LVDS_TX_GEAR_RATIO_I          (LVDS_TX_GEAR_RATIO_I),
   .TX_SERIALIZER_LSB_FIRST_I     (TX_SERIALIZER_LSB_FIRST_I))
  dncbg
   (
    // Outputs
    .ctrl_byte_o                  (ctrl_byte_o),
    .wr_data_o                    (wr_data_o),

    // Inputs
    .clk                          (clk),
    .reset_n                      (reset_n),
    .fe_ctrl_byte_i               (fe_ctrl_byte),
    .dp_ctrl_byte_i               (dp_ctrl_byte),
    .pnl_ctrl_byte_i              (pnl_ctrl_byte),
    .fh_ctrl_byte_i               (fh_ctrl_byte),
    .its_ctrl_byte_i              (its_ctrl_byte),
    .dp_data_byte_i               (dp_data_byte),
    .its_data_byte_i              (its_data_byte),
    .pnl_data_byte_i              (pnl_data_byte),
    .fm_ctrl_byte_i               (fm_ctrl_byte),
    .fm_ctrl_byte_valid_i         (fm_ctrl_byte_valid),
    .fe_ctrl_byte_valid_i         (fe_ctrl_byte_valid),
    .dp_ctrl_byte_valid_i         (dp_ctrl_byte_valid),
    .pnl_ctrl_byte_valid_i        (pnl_ctrl_byte_valid),
    .fh_ctrl_byte_valid_i         (fh_ctrl_byte_valid),
    .its_ctrl_byte_valid_i        (its_ctrl_byte_valid),
    .its_data_byte_valid_i        (its_data_byte_valid),
    .pnl_data_byte_valid_i        (pnl_data_byte_valid),
    // .lvds_phy_training_ongoing_i  (lvds_phy_training_ongoing),
    .dp_data_byte_valid_i         (dp_data_byte_valid),
    .slfifo_rd_data_valid_i       (slfifo_data_nd_status_st_arr_i[sel_device_num_o].rd_data_valid),
    .uvc_frame_header_data_i      (uvc_frame_header_data),
    .uvc_header_data_valid_i      (uvc_header_data_valid),
    .u3v_header_data_valid_i      (u3v_header_data_valid),
    .u3v_frame_header_data_i      (u3v_frame_header_data),
    .slfifo_rd_data_i             (slfifo_data_nd_status_st_arr_i[sel_device_num_o].rd_data)
   );

endmodule
