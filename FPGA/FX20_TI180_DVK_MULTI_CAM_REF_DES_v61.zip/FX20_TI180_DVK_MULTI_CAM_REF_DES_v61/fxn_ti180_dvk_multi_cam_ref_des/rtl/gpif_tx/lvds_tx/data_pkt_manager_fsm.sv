//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    data_pkt_manager_fsm
// Target Devices: All
//
// Description: This module manages to transmit UVC and U3V data packets. It
//              supports UVC header insertion as a payload and metadata. However,
//              in U3V, only ZLP transmission is supported to indicate FX10/20 to
//              insert leader or trailer.
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module data_pkt_manager_fsm
  #
  (
   // Address to be managed by FPGA or not
   parameter ADDR_MANAGED_BY_FPGA_I  = "TRUE",

   // LVDS Data Lanes
   parameter TOTAL_LVDS_DATA_LANES_I = 16,

   // Gear Ratio for LVDS
   parameter LVDS_TX_GEAR_RATIO_I = 4'd8,

   // No. of devices/ FIFOs needed
   parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
   parameter SEL_DEV_NUM_BITS_I = 3
  )
 (
  input               clk,
  input               reset_n,

  // Outputs
  output logic        frame_data_sent_pl_o,
  output logic        data_packet_sent_pl_o,
  output logic        change_thread_addr_pl_o,
  output logic        slfifo_rd_req_o,
  output logic [ 7:0] dp_ctrl_byte_o,
  output logic [ 7:0] dp_data_byte_o,
  output logic        dp_ctrl_byte_valid_o,
  output logic        dp_data_byte_valid_o,
  output logic        tx_eop_control_byte_pl_n_o, // PKTEND
  output logic        slfifo_reset_req_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0] l_zlp_sent_o,
  output logic        uvc_header_data_valid_o,
  output logic        u3v_header_data_valid_o,
  output logic [(NO_OF_SUPPORTED_DEV_I-1):0][31:0] no_of_frame_bytes_yet_to_be_sent_o,
  output logic [(TOTAL_LVDS_DATA_LANES_I * 8)-1:0]  uvc_frame_header_data_o,
  output logic [(TOTAL_LVDS_DATA_LANES_I * 8)-1:0]  u3v_frame_header_data_o,

  output logic        full_buffer_sent_o,
  output logic        wait_for_new_buffer_o,

  // Inputs
  input               all_devices_served_pl_i,
  input               tx_data_pkt_pl_i,
  input               fxn_buffer_ready_i,
  input               new_thread_addr_available_pl_i,
  input               sel_d_reset_or_stop_stream_req_i,
  input        [(SEL_DEV_NUM_BITS_I-1):0] sel_device_num_i,
  input        [ 0:0] slfifo_almost_empty_i,
  input        [31:0] frame_size_info_i,

  input common_reg_info_st_t common_reg_info_i,    // Common Register Information
  input dev_reg_info_st_t    sel_d_reg_info_st_i   // Device Specific Register Information
 );


// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // Total number of bytes in a transfer
  localparam [4:0] NO_OF_BYTES_PER_XFER = TOTAL_LVDS_DATA_LANES_I;

  // Number of IDLE conrol bytes required after training
  localparam       NO_OF_IDLE_CONTROL_BYTES_REQ_AFTER_METADATA = 8'd200;

  // Total flags per thread
  localparam       NO_OF_FLAGS_FOR_EACH_THREAD = 3'd4;

  // Total Bits per thread
  localparam       NO_OF_BITS_FOR_EACH_THREAD = 2'd2;

  // Metadata Control Byte
  localparam [3:0] METADATA_CONTROL_BYTE = 4'b1100;

  // IDLE Control Byte
  localparam       IDLE_CONTROL_BYTE = 8'd1;

  // Parity bit initial value
  localparam [0:0] PARITY_BIT = 1'b0;

  // LSbit of Control Byte
  localparam [0:0] CONTROL_BYTE_LS_BIT = 1'b1;

  // LSbit of Data Byte
  localparam [0:0] DATA_CONTROL_BYTE_LS_BIT = 1'b0;

  // Set Thread Address Control Byte
  localparam [3:0] SET_THREAD_ADDR_CONTROL_BYTE = 4'b0001;

  // Set Socket Address Control Byte
  localparam [2:0] SET_SOCKET_ADDR_CONTROL_BYTE = 3'b001;

  // EPC Control Byte
  localparam [7:0] EPC_CONTROL_BYTE = 8'b0101_0001;

  // HPC Control Byte
  localparam [7:0] HPC_CONTROL_BYTE = 8'b1101_0011;

  // EOP Control Byte
  localparam [7:0] EOP_CONTROL_BYTE = 8'b1110_1111;

  // Set any flag of a particular thread
  localparam [3:0] SET_FLAG_CONTROL_BYTE = 4'b1000;

  // Clear any flag of a particular thread
  localparam [3:0] CLEAR_FLAG_CONTROL_BYTE = 4'b1001;

  // Set Variable Higher Word
  localparam [4:0] SET_VARIABLE_HW_CONTROL_BYTE = 5'b010_10;

  // Set Variable Lower Word
  localparam [4:0] SET_VARIABLE_LW_CONTROL_BYTE = 5'b010_01;

  // UVC Header Information
  localparam UVC_HEADER_BYTES_MAX_COUNT = ( ( UVC_HEADER_LENGTH_IN_BYTES - 1'b1 ) / NO_OF_BYTES_PER_XFER );

  // Even Frame Number
  localparam [7:0] EVEN_FRAME_NO          = 8'h8C;
  localparam [7:0] ODD_FRAME_NO           = 8'h8D;
  localparam [7:0] ODD_FRAME_LAST_PKT_NO  = 8'h8F;
  localparam [7:0] EVEN_FRAME_LAST_PKT_NO = 8'h8E;

  localparam [0:0] LAST_PKT_INDICATOR_BIT = 1'b1;

  // U3V Header Information
  // Leader Length
  localparam LEADER_SIZE_IN_BYTES_LSB = 8'd56;
  localparam LEADER_SIZE_IN_BYTES_MSB = 8'd0;

  localparam TRAILER_SIZE_IN_BYTES_LSB = 8'd32;
  localparam TRAILER_SIZE_IN_BYTES_MSB = 8'd0;

  // No of clock cycles needed for full leader
  localparam U3V_LEADER_BYTES_MAX_COUNT = ( ( LEADER_SIZE_IN_BYTES_LSB - 1'b1 ) / NO_OF_BYTES_PER_XFER );

  // No of clock cycles needed for full trailer
  localparam U3V_TRAILER_BYTES_MAX_COUNT = ( ( TRAILER_SIZE_IN_BYTES_LSB - 1'b1 ) / NO_OF_BYTES_PER_XFER );

  // Magic Key
  localparam LEADER_MAGIC_KEY  = 32'h4C563355;
  localparam TRAILER_MAGIC_KEY = 32'h54563355;

  // Payload Type
  localparam PAYLOAD_TYPE_IMAGE = 16'h0001;

  // Reserved Byte
  localparam RESERVED_BYTE = 8'd0;

  // Pixel Format With LSByte First
  localparam IMAGE_FORMAT = 32'h02100032;

  // How many time INMD should be sent for U3V leader?
  // Why divide by 32? Because, single INMD control byte is used to add 32 bytes of Information.
  localparam INMD_CTRL_BYTE_DIVISOR_FOR_LEADER_U3V = ( LEADER_SIZE_IN_BYTES_LSB / 32 );
  localparam INMD_CTRL_BYTE_COUNT_FOR_LEADER_U3V   = ( ( (LEADER_SIZE_IN_BYTES_LSB % 32) == 0 ) ? (INMD_CTRL_BYTE_DIVISOR_FOR_LEADER_U3V) : (INMD_CTRL_BYTE_DIVISOR_FOR_LEADER_U3V + 1) );

  // How many time INMD should be sent for U3V trailer?
  localparam INMD_CTRL_BYTE_DIVISOR_FOR_TRAILER_U3V = ( TRAILER_SIZE_IN_BYTES_LSB / 32 );
  localparam INMD_CTRL_BYTE_COUNT_FOR_TRAILER_U3V   = ( ( (TRAILER_SIZE_IN_BYTES_LSB % 32) == 0 ) ? (INMD_CTRL_BYTE_DIVISOR_FOR_TRAILER_U3V) : (INMD_CTRL_BYTE_DIVISOR_FOR_TRAILER_U3V + 1) );

  // How many time INMD should be sent for UVC header?
  localparam INMD_CTRL_BYTE_DIVISOR_FOR_HEADER_UVC = ( UVC_HEADER_LENGTH_IN_BYTES / 32 );
  localparam INMD_CTRL_BYTE_COUNT_FOR_HEADER_UVC   = ( ( (UVC_HEADER_LENGTH_IN_BYTES % 32) == 0 ) ? (INMD_CTRL_BYTE_DIVISOR_FOR_HEADER_UVC) : (INMD_CTRL_BYTE_DIVISOR_FOR_HEADER_UVC + 1) );


  // Adress to FLAGA assertion delay
  // Why 10 clocks?
  // After sending thread and socket address from
  // this FSM, it takes around 4 clocks to be on
  // control lane. And after that it may take 3
  // clocks to update FLAGA status. For safer side,
  // here, it is taken 10.
  localparam ADDR_TO_FLAGA_DELAY_CLK = 50;

  // No of States
  localparam NO_OF_FSM_STATES = 8'd42;

  enum logic [(NO_OF_FSM_STATES-1):0] {
    IDLE                              = 42'h1,
    IS_BUFFER_AVAILABLE               = 42'h2,
    IS_U3V_MODE_EN                    = 42'h4,
    IS_U3V_LEADER_DATA_ENABLED        = 42'h8,
    DECIDE_U3V_FRAME_HEADER_METHOD    = 42'h10,
    TX_U3V_LEADER_DATA                = 42'h20,
    TX_U3V_LEADER_ZLP                 = 42'h40,
    IS_UVC_FRAME_HEADER_ENABLED       = 42'h80,
    DECIDE_UVC_FRAME_HEADER_METHOD    = 42'h100,
    TX_FRAME_HEADER_INFO_AS_METADATA  = 42'h200,
    TX_FRAME_HEADER_INFO_AS_PAYLOAD   = 42'h400,
    TX_METADATA_CTRL_BYTE             = 42'h800,
    TX_IDLE_CTRL_BYTES                = 42'h1000,
    IS_METADATA_CTRL_BYTE_COMPLETED   = 42'h2000,
    IS_PC_ENABLED                     = 42'h4000,
    TX_EPC_CTRL_BYTE                  = 42'h8000,
    IS_FLAG_ENABLED                   = 42'h10000,
    TX_SET_FLAG_CTRL_BYTE             = 42'h20000,
    START_TX_DATA                     = 42'h40000,
    WAIT_DATA_SENT                    = 42'h80000,
    WAIT_READY_FLAG_DEASSERTED        = 42'h100000,
    IS_FIRST_FLAG_ENABLED             = 42'h200000,
    TX_CLR_FLAG_CTRL_BYTE             = 42'h400000,
    IS_HPC_ENABLED                    = 42'h800000,
    TX_HPC_CTRL_BYTE                  = 42'h1000000,
    IS_IT_EOF                         = 42'h2000000,
    TX_EOP_CTRL_BYTE                  = 42'h4000000,
    WAIT_EOP_ACK                      = 42'h8000000,
    IS_ADDR_MANAGED_BY_FPGA           = 42'h10000000,
    INCR_THREAD_ADDR                  = 42'h20000000,
    WAIT_NEW_THREAD_ADDR_AVAILABLE    = 42'h40000000,
    TX_NEW_THREAD_ADDR                = 42'h80000000,
    IS_SOCKET_ADDR_CHANGED            = 42'h100000000,
    TX_NEW_SOCKET_ADDR                = 42'h200000000,
    IS_FRAME_END                      = 42'h400000000,
    WAIT_BUFFER_AVAILABLE             = 42'h800000000,
    IS_U3V_TRAILER_REQUIRED           = 42'h1000000000,
    IS_U3V_TRAILER_DATA_ENABLED       = 42'h2000000000,
    WAIT_FULL_FLAG_ASSERTED           = 42'h4000000000,
    TX_U3V_TRAILER_DATA               = 42'h8000000000,
    TX_U3V_TRAILER_ZLP                = 42'h10000000000,
    INFORM_DATA_PKT_SENT              = 42'h20000000000
  } dp_cs, dp_ns;



// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic        tx_u3v_block_id_info;
  logic        tx_u3v_block_id_info_f1;
  logic        uvc_header_data_valid;
  logic        u3v_leader_data_valid;
  logic        u3v_trailer_data_valid;
  logic        u3v_trailer_sent;
  logic        u3v_trailer_sent_pl;
  logic        tx_metadata_ctrl_byte_pl;
  logic        tx_idle_control_byte;
  logic        tx_epc_control_byte_pl;
  logic        start_pkt_flag_control_byte_pl;
  logic        fifo_rd_req;
  logic        clr_start_pkt_flag_control_byte_pl;
  logic        tx_hpc_control_byte_pl;
  logic        tx_eop_control_byte_pl;
  logic        change_thread_addr_pl;
  logic        inform_frame_sent_pl;
  logic        inform_data_packet_sent_pl;
  logic        tx_new_thread_addr_pl;
  logic        tx_new_socket_addr_pl;
  logic        tx_frame_header_info_pl;
  logic        fxn_buffer_ready_f1;
  logic        fxn_buffer_ready_f2;
  logic        fxn_buffer_ready_pe_pl;
  logic        dual_thread_already_served;
  logic        incr_flaga_sample_count;
  logic        fxn_buf_wr_en;
  logic [ 2:0] fxn_buf_wr_count;
  logic [ 7:0] flaga_sample_count;
  logic [ 7:0] idle_ctrl_byte_counter;
  logic [23:0] sel_buffer_size_info;
  logic [ 5:0] frame_xfer_len_in_bytes;
  logic [ 2:0] uvc_header_cnt;
  logic [ 3:0] u3v_leader_data_cnt;
  logic [ 3:0] u3v_trailer_data_cnt;
  logic [63:0] u3v_block_id;
  logic [23:0] data_byte_counter;

  logic [(NO_OF_SUPPORTED_DEV_I-1):0][7:0] frame_header_info_uw;
  logic [(NO_OF_SUPPORTED_DEV_I-1):0] uvc_frame_header_sent;
  // logic [(NO_OF_SUPPORTED_DEV_I-1):0][31:0] no_of_frame_bytes_yet_to_be_sent_o;
  logic [3:0] bit_counter;
  logic [2:0] inmd_counter;

// ------------------------------------------
//
// Buffer Size Info
//
// ------------------------------------------

// If UVC header data is sent by FPGA, that value must be
// deducted from the size received from FX10.
// In case of U3V, header data length does not affect the
// buffer size.

// For 24 bits pixel, FPGA can't add header as of now and buffer size must be
// divisible by 3.
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        sel_buffer_size_info  <= 16'b0;
      end
    else if ( sel_d_reg_info_st_i.image_pixel_width == 8'd24 ) // RGB8 or YUV444. It will be treated as 32 bit
      begin
        sel_buffer_size_info <= ((sel_d_reg_info_st_i.buffer_size_info / 2'd3) << 2);
      end
    else if ( ( ( common_reg_info_i.tx_header_info_as_metadata == 1'b1 ) | ( common_reg_info_i.tx_header_info_as_payload == 1'b1 ) ) &
              ( uvc_frame_header_sent[sel_device_num_i] == 1'b0 )  &
              ( common_reg_info_i.uvc_stream_mode_en )
            )
      begin
        sel_buffer_size_info <= ( sel_d_reg_info_st_i.buffer_size_info - UVC_HEADER_LENGTH_IN_BYTES );
      end
    else
      begin
        sel_buffer_size_info <= sel_d_reg_info_st_i.buffer_size_info;
      end
  end

// ------------------------------------------
//
// FSM
//
// ------------------------------------------

// Current State
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        dp_cs <= IDLE;
      end
    else if ( sel_d_reset_or_stop_stream_req_i )
      begin
        dp_cs <= IDLE;
      end
    else
      begin
        dp_cs <= dp_ns;
      end
  end

// Next State
always_comb
  begin
    dp_ns <= IDLE;
    unique case ( dp_cs )

      // Wait until Frame Manager informs to start
      // sending data.
      IDLE :
        begin
          if ( tx_data_pkt_pl_i )
            begin
              dp_ns <= IS_BUFFER_AVAILABLE;
            end
          else
            begin
              dp_ns <= IDLE;
            end
        end

      // Wait until READY signal is HIGH.
      IS_BUFFER_AVAILABLE :
        begin
          if ( fxn_buffer_ready_i )
            begin
              dp_ns <= IS_U3V_MODE_EN;
            end
          else
            begin
              dp_ns <= IS_BUFFER_AVAILABLE;
            end
        end

      // Check whether U3V mode is enabled or not
      IS_U3V_MODE_EN :
        begin
          if ( common_reg_info_i.uvc_stream_mode_en == 1'b1 ) // UVC Mode
            begin
              dp_ns <= IS_UVC_FRAME_HEADER_ENABLED;
            end
          else
            begin
              dp_ns <= IS_U3V_LEADER_DATA_ENABLED/* TX_U3V_LEADER_ZLP */;  // U3V Mode
            end
        end

      // Check whether U3V header data needs to be sent or not
      IS_U3V_LEADER_DATA_ENABLED :
        begin
          if ( ( ( common_reg_info_i.tx_header_info_as_payload == 1'b1 ) |
                 ( common_reg_info_i.tx_header_info_as_metadata == 1'b1 ) ) &
               ( l_zlp_sent_o[sel_device_num_i] == 1'b0 ) )
            begin
              dp_ns <= DECIDE_U3V_FRAME_HEADER_METHOD /* TX_U3V_LEADER_DATA */;
            end
          else
            begin
              dp_ns <= TX_U3V_LEADER_ZLP;
            end
        end

      // Header data should be sent by metadata or payload
      DECIDE_U3V_FRAME_HEADER_METHOD :
        begin
          if ( common_reg_info_i.tx_header_info_as_metadata == 1'b1 )
            begin
              dp_ns <= TX_METADATA_CTRL_BYTE /* TX_LEADER_BLOCK_ID */;
            end
          else
            begin
              dp_ns <= TX_U3V_LEADER_DATA;
            end
        end

 //     // Send Block ID for U3V Leader
 //     TX_LEADER_BLOCK_ID :
 //       begin
 //         if ( tx_u3v_block_id_info_f1 == 1'b1 )
 //           begin
 //             dp_ns <= TX_METADATA_CTRL_BYTE;
 //           end
 //         else
 //           begin
 //             dp_ns <= TX_LEADER_BLOCK_ID;
 //           end
 //       end

      // Transmit U3V Leader Data
      TX_U3V_LEADER_DATA :
        begin
          if ( u3v_leader_data_cnt == U3V_LEADER_BYTES_MAX_COUNT )
            begin
              dp_ns <= TX_U3V_LEADER_ZLP;
            end
          else
            begin
              dp_ns <= TX_U3V_LEADER_DATA;
            end
        end

      // Transmit U3V Leader ZLP
      TX_U3V_LEADER_ZLP :
        begin
          if ( l_zlp_sent_o[sel_device_num_i] == 1'b1 )
            begin
              dp_ns <= IS_PC_ENABLED;
            end
          else
            begin
              dp_ns <= WAIT_READY_FLAG_DEASSERTED;
            end
        end

      // Check whether metadata needs to be sent or not.
      IS_UVC_FRAME_HEADER_ENABLED :
        begin
          if ( ( ( common_reg_info_i.tx_header_info_as_metadata == 1'b1 ) |
                 ( common_reg_info_i.tx_header_info_as_payload == 1'b1 ) ) &
                 ( uvc_frame_header_sent[sel_device_num_i] == 1'b0 )
             )
            begin
              dp_ns <= DECIDE_UVC_FRAME_HEADER_METHOD;
            end
          else
            begin
              dp_ns <= IS_PC_ENABLED;
            end
        end

      // Header data should be sent by metadata or payload
      DECIDE_UVC_FRAME_HEADER_METHOD :
        begin
          if ( common_reg_info_i.tx_header_info_as_metadata == 1'b1 )
            begin
              dp_ns <= TX_FRAME_HEADER_INFO_AS_METADATA;
            end
          else
            begin
              dp_ns <= TX_FRAME_HEADER_INFO_AS_PAYLOAD;
            end
        end

      // Send frame header upper word
      TX_FRAME_HEADER_INFO_AS_METADATA :
        begin
          dp_ns <= TX_METADATA_CTRL_BYTE;
        end

      // Send frame header in payload
      TX_FRAME_HEADER_INFO_AS_PAYLOAD :
        begin
          if ( uvc_header_cnt == UVC_HEADER_BYTES_MAX_COUNT )
            begin
              dp_ns <= IS_PC_ENABLED;
            end
          else
            begin
              dp_ns <= TX_FRAME_HEADER_INFO_AS_PAYLOAD;
            end
        end

      // Send metadata control byte
      TX_METADATA_CTRL_BYTE :
        begin
          dp_ns <= TX_IDLE_CTRL_BYTES;
        end

      // Send IDLEs after metadata control byte.
      TX_IDLE_CTRL_BYTES :
        begin
          if ( idle_ctrl_byte_counter == ( NO_OF_IDLE_CONTROL_BYTES_REQ_AFTER_METADATA - 1'b1 ) )
            begin
              dp_ns <= IS_METADATA_CTRL_BYTE_COMPLETED;
        end
          else
             begin
              dp_ns <= TX_IDLE_CTRL_BYTES;
             end
        end

      // In UVC, only single INMD is required but in U3V, 2 are required.
      IS_METADATA_CTRL_BYTE_COMPLETED :
        begin
          if ( common_reg_info_i.uvc_stream_mode_en == 1'b1 ) // In UVC mode, single INMD is sent already
            begin
              dp_ns <= IS_PC_ENABLED;
            end
          else if ( inmd_counter == ( INMD_CTRL_BYTE_COUNT_FOR_TRAILER_U3V + INMD_CTRL_BYTE_COUNT_FOR_LEADER_U3V ) )
            begin
              dp_ns <= TX_U3V_TRAILER_ZLP;
            end
          else if ( ( inmd_counter < INMD_CTRL_BYTE_COUNT_FOR_LEADER_U3V ) |
                        ( ( inmd_counter < ( INMD_CTRL_BYTE_COUNT_FOR_TRAILER_U3V + INMD_CTRL_BYTE_COUNT_FOR_LEADER_U3V ) ) &
                      ( l_zlp_sent_o[sel_device_num_i] == 1'b1 ) )
                  )
            begin
              dp_ns <= TX_METADATA_CTRL_BYTE;
            end
          else
            begin
               dp_ns <= TX_U3V_LEADER_ZLP;
            end
        end

      // Is Payload Counter enabled?
      IS_PC_ENABLED :
        begin
          if ( sel_d_reg_info_st_i.c_n_crc_info[2] == 1'b1 )
            begin
              dp_ns <= TX_EPC_CTRL_BYTE;
            end
          else
            begin
              dp_ns <= IS_FLAG_ENABLED;
            end
        end

      // Enable Payload Counter
      TX_EPC_CTRL_BYTE :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          dp_ns <= IS_FLAG_ENABLED;
        end
          else
            begin
              dp_ns <= TX_EPC_CTRL_BYTE;
            end
        end

      // Is Packet Start Flag enabled?
      IS_FLAG_ENABLED :
        begin
          if ( sel_d_reg_info_st_i.flag_info[1] == 1'b1 )
            begin
              dp_ns <= TX_SET_FLAG_CTRL_BYTE;
            end
          else
            begin
              dp_ns <= START_TX_DATA;
            end
        end

      // Set Packet Start Flag
      TX_SET_FLAG_CTRL_BYTE :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          dp_ns <= START_TX_DATA;
        end
          else
            begin
              dp_ns <= TX_SET_FLAG_CTRL_BYTE;
            end
        end

      // Start sending data
      START_TX_DATA :
        begin
          if ( slfifo_almost_empty_i == 1'b0 )
            begin
              dp_ns <= WAIT_DATA_SENT;
            end
          else
            begin
              dp_ns <= START_TX_DATA;
            end
        end

      // Wait until data bytes are sent.
      WAIT_DATA_SENT :
        begin
          if ( ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] <= NO_OF_BYTES_PER_XFER ) & ( fifo_rd_req ) )
            begin
              dp_ns <= IS_FIRST_FLAG_ENABLED;
            end
          else if ( ( data_byte_counter == (sel_buffer_size_info - NO_OF_BYTES_PER_XFER) ) & ( fifo_rd_req ) )
            begin
              dp_ns <= WAIT_READY_FLAG_DEASSERTED; // Wait for buffer to be committed
            end
          else
            begin
              dp_ns <= WAIT_DATA_SENT;
            end
        end

      // Wait until READY flag is de-asserted
      WAIT_READY_FLAG_DEASSERTED :
        begin
          if (  fxn_buffer_ready_i == 1'b0  /* fxn_buffer_ready_pe_pl*/ )
            begin
              dp_ns <= IS_FIRST_FLAG_ENABLED;
            end
          else
            begin
              dp_ns <= WAIT_READY_FLAG_DEASSERTED;
            end
        end

      // Is Packet Start Flag enabled?
      IS_FIRST_FLAG_ENABLED :
        begin
          if ( sel_d_reg_info_st_i.flag_info[1] == 1'b1 )
            begin
              dp_ns <= TX_CLR_FLAG_CTRL_BYTE;
            end
          else
            begin
              dp_ns <= IS_HPC_ENABLED;
            end
        end

      // Clear Packet Start Flag
      TX_CLR_FLAG_CTRL_BYTE :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          dp_ns <= IS_HPC_ENABLED;
        end
          else
            begin
              dp_ns <= TX_CLR_FLAG_CTRL_BYTE;
            end
        end

      // Is Payload Counter enabled?
      IS_HPC_ENABLED :
        begin
          if ( sel_d_reg_info_st_i.c_n_crc_info[2] == 1'b1 )
            begin
              dp_ns <= TX_HPC_CTRL_BYTE;
            end
          else
            begin
              dp_ns <= IS_IT_EOF;
            end
        end

      // Send Hold Payload Counter
      TX_HPC_CTRL_BYTE :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          dp_ns <= IS_IT_EOF;
        end
          else
            begin
              dp_ns <= TX_HPC_CTRL_BYTE;
            end
        end

      // Is it end of frame? If last buffer is full, no need to send EOP.
      IS_IT_EOF :
        begin
          if ( ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] == 1'b0 ) &
               ( data_byte_counter != 1'b0 )
             )
            begin
              dp_ns <= TX_EOP_CTRL_BYTE;
            end
          else
            begin
              dp_ns <= IS_ADDR_MANAGED_BY_FPGA;
            end
        end

      // Send EOP Control Byte when READY FLAG is HIGH
      TX_EOP_CTRL_BYTE :
        begin
          if ( ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) ) & fxn_buffer_ready_i )
            begin
              dp_ns <=  WAIT_EOP_ACK /*IS_ADDR_MANAGED_BY_FPGA*/;
            end
          else
            begin
              dp_ns <= TX_EOP_CTRL_BYTE;
            end
        end

      // Once EOP is sent, wait until FLAGA is toggled.
      WAIT_EOP_ACK :
        begin
          if ( /*fxn_buffer_ready_pe_pl*/ fxn_buffer_ready_i == 1'b0  )
            begin
              dp_ns <= IS_ADDR_MANAGED_BY_FPGA;
            end
          else
            begin
              dp_ns <= WAIT_EOP_ACK;
            end
        end

      // Is thread address managed by FW or FPGA?
      // For buffer by buffer we are incrementing thread
      // bcoz we are sending 2 buffers at a time
      IS_ADDR_MANAGED_BY_FPGA :
        begin
          if ( ( ADDR_MANAGED_BY_FPGA_I == "TRUE" ) &
               ( sel_d_reg_info_st_i.active_thread == 2'd2 ) // Multiple threads for an EP
             )
            begin
              dp_ns <= INCR_THREAD_ADDR;
            end
          else
            begin
              `ifdef DEVICE_SEL_BASED_ON_FRAME
                dp_ns <= WAIT_BUFFER_AVAILABLE /*IS_FRAME_END*/;
              `else
                dp_ns <= IS_U3V_TRAILER_REQUIRED;
              `endif
            end
        end

      // Change thread number in I2C Register
      INCR_THREAD_ADDR :
        begin
          if ( ( ( ( dual_thread_already_served == 1'b1 ) |
                   ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] == 1'b0 ) ) &
                 ( common_reg_info_i.uvc_stream_mode_en == 1'b1 ) )  |
               ( u3v_trailer_sent == 1'b1 )
             )
            begin
              dp_ns <= IS_U3V_TRAILER_REQUIRED;
            end
          else
            begin
              dp_ns <= WAIT_NEW_THREAD_ADDR_AVAILABLE;
            end
        end

      // Is new address available to send?
      WAIT_NEW_THREAD_ADDR_AVAILABLE :
        begin
          if ( new_thread_addr_available_pl_i )
            begin
              dp_ns <= TX_NEW_THREAD_ADDR;
            end
          else
            begin
              dp_ns <= WAIT_NEW_THREAD_ADDR_AVAILABLE;
            end
        end

      // Send new thread address
      TX_NEW_THREAD_ADDR :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          dp_ns <= TX_NEW_SOCKET_ADDR /*IS_SOCKET_ADDR_CHANGED*/;
        end
          else
            begin
              dp_ns <= TX_NEW_THREAD_ADDR;
            end
        end

      // With new thread address, is socket address changed?
      IS_SOCKET_ADDR_CHANGED :
        begin
          if ( sel_d_reg_info_st_i.socket_addr_same_for_dev == 1'b1 ) // socket addresses are same for both threads
            begin
              dp_ns <= IS_FRAME_END;
            end
          else
            begin
              dp_ns <= TX_NEW_SOCKET_ADDR;
            end
        end

      // Send new socket address
      TX_NEW_SOCKET_ADDR :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
              dp_ns <= WAIT_BUFFER_AVAILABLE;
        end
          else
            begin
              dp_ns <= TX_NEW_SOCKET_ADDR;
            end
        end

      // Is frame ended?
      IS_FRAME_END :
        begin
          if ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] == 1'b0 )
            begin
              dp_ns <= IS_U3V_TRAILER_REQUIRED;
            end
          else
            begin
              dp_ns <= IS_BUFFER_AVAILABLE;
            end
        end

      // Wait for "ADDR_TO_FLAGA_DELAY_CLK" clocks to sample FLAGA
      WAIT_BUFFER_AVAILABLE :
        begin
          if ( flaga_sample_count == ADDR_TO_FLAGA_DELAY_CLK )
            begin
              `ifdef DEVICE_SEL_BASED_ON_FRAME
                  dp_ns <= IS_FRAME_END /*IS_BUFFER_AVAILABLE*/;
              `else
                   if ( fxn_buffer_ready_i & !slfifo_almost_empty_i )
                     begin
                       dp_ns <= IS_U3V_MODE_EN;
                     end
                   else // No need to serve selected device. Move to next device.
                     begin
                       dp_ns <= IS_U3V_TRAILER_REQUIRED;
                     end
               `endif
            end
          else
            begin
              dp_ns <= WAIT_BUFFER_AVAILABLE;
            end
        end

      // U3V or UVC?
      IS_U3V_TRAILER_REQUIRED :
        begin
          if ( ( common_reg_info_i.uvc_stream_mode_en == 1'b0 ) & ( u3v_trailer_sent == 1'b0 ) )
            begin
              if ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] == frame_size_info_i )
                begin
                  dp_ns <= IS_BUFFER_AVAILABLE;
                end
              else if ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] == 1'b0 )
                begin
                  dp_ns <= WAIT_FULL_FLAG_ASSERTED /* IS_U3V_TRAILER_DATA_ENABLED */;
                end
              else
                begin
                  dp_ns <= INFORM_DATA_PKT_SENT ;
                end
            end
          else
            begin
              dp_ns <= INFORM_DATA_PKT_SENT;  // UVC Mode
            end
        end

      // Check whether U3V header data needs to be sent or not
      IS_U3V_TRAILER_DATA_ENABLED :
        begin
          if ( common_reg_info_i.tx_header_info_as_payload == 1'b1 )
            begin
              dp_ns <= TX_U3V_TRAILER_DATA;
            end
          else if ( common_reg_info_i.tx_header_info_as_metadata == 1'b1 )
            begin
              dp_ns <= /* TX_TRAILER_BLOCK_ID */ TX_METADATA_CTRL_BYTE;
            end
          else
            begin
              dp_ns <= TX_U3V_TRAILER_ZLP;
            end
        end

      // Wait until READY signal is HIGH.
      WAIT_FULL_FLAG_ASSERTED :
        begin
          if ( fxn_buffer_ready_i )
            begin
              dp_ns <= IS_U3V_TRAILER_DATA_ENABLED;
            end
          else
            begin
              dp_ns <= WAIT_FULL_FLAG_ASSERTED;
            end
        end

      // Transmit U3V Trailer Data
      TX_U3V_TRAILER_DATA :
        begin
          if ( u3v_trailer_data_cnt == U3V_TRAILER_BYTES_MAX_COUNT )
            begin
              dp_ns <= TX_U3V_TRAILER_ZLP;
            end
          else
            begin
              dp_ns <= TX_U3V_TRAILER_DATA;
            end
        end

      // Transmit U3V Leader ZLP
      TX_U3V_TRAILER_ZLP :
        begin
          if ( fxn_buffer_ready_i )
            begin
              dp_ns <= TX_EOP_CTRL_BYTE;
            end
          else
            begin
              dp_ns <= TX_U3V_TRAILER_ZLP;
            end
        end

  //    // Send Block ID for U3V Trailer
  //    TX_TRAILER_BLOCK_ID :
  //      begin
  //        if ( tx_u3v_block_id_info_f1 == 1'b1 )
  //          begin
  //            dp_ns <= TX_TRAILER_METADATA_CTRL_BYTE;
  //          end
  //        else
  //          begin
  //            dp_ns <= TX_TRAILER_BLOCK_ID;
  //          end
  //      end

  //    // Send metadata control byte
  //    TX_TRAILER_METADATA_CTRL_BYTE :
  //      begin
  //        if ( inmd_counter == ( INMD_CTRL_BYTE_COUNT_FOR_TRAILER_U3V - 1'b1 ) )
  //           begin
  //             dp_ns <= INFORM_DATA_PKT_SENT;
  //           end
  //        else
  //           begin
  //             dp_ns <= TX_TRAILER_METADATA_CTRL_BYTE;
  //           end
  //      end

      // Full frame is sent
      INFORM_DATA_PKT_SENT :
        begin
          dp_ns <= IDLE;
        end

    endcase
  end


// Next State Signals
always_comb
  begin

    tx_metadata_ctrl_byte_pl           <= 1'b0;
    tx_idle_control_byte               <= 1'b0;
    tx_epc_control_byte_pl             <= 1'b0;
    start_pkt_flag_control_byte_pl     <= 1'b0;
    fifo_rd_req                        <= 1'b0;
    clr_start_pkt_flag_control_byte_pl <= 1'b0;
    tx_hpc_control_byte_pl             <= 1'b0;
    tx_eop_control_byte_pl             <= 1'b0;
    change_thread_addr_pl              <= 1'b0;
    inform_frame_sent_pl               <= 1'b0;
    tx_new_thread_addr_pl              <= 1'b0;
    tx_new_socket_addr_pl              <= 1'b0;
    tx_frame_header_info_pl            <= 1'b0;
    u3v_trailer_sent_pl                <= 1'b0;
    uvc_header_data_valid              <= 1'b0;
    u3v_leader_data_valid              <= 1'b0;
    u3v_trailer_data_valid             <= 1'b0;
    inform_data_packet_sent_pl         <= 1'b0;
    incr_flaga_sample_count            <= 1'b0;
    tx_u3v_block_id_info               <= 1'b0;

    unique case ( dp_cs )

      // Wait until Frame Manager informs to start
      // sending data.
      IDLE :
        begin

        end

      // Wait until READY signal is HIGH.
      IS_BUFFER_AVAILABLE :
        begin

        end

      // Check whether U3V mode is enabled or not
      IS_U3V_MODE_EN :
        begin

        end

      // Check whether U3V header data needs to be sent or not
      IS_U3V_LEADER_DATA_ENABLED :
        begin

        end

      // Header data should be sent by metadata or payload
      DECIDE_U3V_FRAME_HEADER_METHOD :
        begin

        end

 //     // Send Block ID for U3V Leader
 //     TX_LEADER_BLOCK_ID :
 //       begin
 //         tx_u3v_block_id_info <= 1'b1;
 //       end

      // Transmit U3V Leader Data
      TX_U3V_LEADER_DATA :
        begin
          u3v_leader_data_valid <= 1'b1;
        end

      // Transmit U3V Leader
      TX_U3V_LEADER_ZLP :
        begin
          tx_eop_control_byte_pl <= ( ( fxn_buffer_ready_i == 1'b1 ) & ( l_zlp_sent_o[sel_device_num_i] == 1'b0 ) );
        end

      // Check whether metadata needs to be sent or not.
      IS_UVC_FRAME_HEADER_ENABLED :
        begin

        end

      // Header data should be sent by metadata or payload
      DECIDE_UVC_FRAME_HEADER_METHOD :
        begin

        end

      // Send frame header upper word
      TX_FRAME_HEADER_INFO_AS_METADATA :
        begin
          tx_frame_header_info_pl <= 1'b1;
        end

      // Send frame header in payload
      TX_FRAME_HEADER_INFO_AS_PAYLOAD :
        begin
          uvc_header_data_valid <= ( ~( ( fxn_buf_wr_count < ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) ) & ( fxn_buf_wr_en ) ) );
        end

      // Send metadata control byte
      TX_METADATA_CTRL_BYTE :
        begin
          tx_metadata_ctrl_byte_pl <= 1'b1;
        end

      // Send IDLEs after metadata control byte.
      TX_IDLE_CTRL_BYTES :
        begin
          tx_idle_control_byte <= 1'b1;
        end

      // In UVC, only single INMD is required but in U3V, 2 are required.
      IS_METADATA_CTRL_BYTE_COMPLETED :
        begin

        end

      // Is Payload Counter enabled?
      IS_PC_ENABLED :
        begin

        end

      // Enable Payload Counter
      TX_EPC_CTRL_BYTE :
        begin
          tx_epc_control_byte_pl <= (bit_counter == 1'b0);
        end

      // Is Packet Start Flag enabled?
      IS_FLAG_ENABLED :
        begin

        end

      // Set Packet Start Flag
      TX_SET_FLAG_CTRL_BYTE :
        begin
          start_pkt_flag_control_byte_pl <= (bit_counter == 1'b0);
        end

      START_TX_DATA :
        begin
          // fifo_rd_req <= 1'b1;
        end

      // Wait until data bytes are sent.
      WAIT_DATA_SENT :
        begin
          // fifo_rd_req <= ~slfifo_almost_empty_i;
          fifo_rd_req <= ( ( ~slfifo_almost_empty_i ) & ( ~( ( fxn_buf_wr_count < ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) ) & ( fxn_buf_wr_en ) ) ) );
        end

      // Wait until READY flag is de-asserted
      WAIT_READY_FLAG_DEASSERTED :
        begin

        end

      // Is Packet Start Flag enabled?
      IS_FIRST_FLAG_ENABLED :
        begin

        end

      // Clear Packet Start Flag
      TX_CLR_FLAG_CTRL_BYTE :
        begin
          clr_start_pkt_flag_control_byte_pl <= (bit_counter == 1'b0);
        end

      // Is Payload Counter enabled?
      IS_HPC_ENABLED :
        begin

        end

      // Send Hold Payload Counter
      TX_HPC_CTRL_BYTE :
        begin
          tx_hpc_control_byte_pl <= (bit_counter == 1'b0);
        end

      // Is it end of frame?
      IS_IT_EOF :
        begin

        end

      // Send EOP Control Byte
      TX_EOP_CTRL_BYTE :
        begin
          tx_eop_control_byte_pl <= (fxn_buffer_ready_i & (bit_counter == 1'b0));
        end

      // Once EOP is sent, wait until FLAGA is toggled.
      WAIT_EOP_ACK :
        begin

        end

      // Is thread address managed by FW or FPGA?
      IS_ADDR_MANAGED_BY_FPGA :
        begin

        end

      // Change thread address
      INCR_THREAD_ADDR :
        begin
          change_thread_addr_pl <= 1'b1;
        end

      // Is new address available to send?
      WAIT_NEW_THREAD_ADDR_AVAILABLE :
        begin

        end

      // Send new thread address
      TX_NEW_THREAD_ADDR :
        begin
          tx_new_thread_addr_pl <= (bit_counter == 1'b0);
        end

      // With new thread address, is socket address changed?
      IS_SOCKET_ADDR_CHANGED :
        begin

        end

      // Send new socket address
      TX_NEW_SOCKET_ADDR :
        begin
          tx_new_socket_addr_pl <= (bit_counter == 1'b0);
        end

      // Is frame ended?
      IS_FRAME_END :
        begin

        end

      // Wait for "ADDR_TO_FLAGA_DELAY_CLK" clocks to sample FLAGA
      WAIT_BUFFER_AVAILABLE :
        begin
          incr_flaga_sample_count <= 1'b1;
        end

      // Transmit U3V Leader
      IS_U3V_TRAILER_REQUIRED :
        begin

        end

      // Check whether U3V header data needs to be sent or not
      IS_U3V_TRAILER_DATA_ENABLED :
        begin

        end

      // Wait until READY signal is HIGH.
      WAIT_FULL_FLAG_ASSERTED :
        begin

        end

      // Transmit U3V Trailer Data
      TX_U3V_TRAILER_DATA :
        begin
          u3v_trailer_data_valid <= 1'b1;
        end

      // Transmit U3V Leader ZLP
      TX_U3V_TRAILER_ZLP :
        begin
          // u3v_trailer_sent_pl    <= 1'b1;
          u3v_trailer_sent_pl <= fxn_buffer_ready_i;
        end

  //    // Send Block ID for U3V Trailer
  //    TX_TRAILER_BLOCK_ID :
  //      begin
  //        tx_u3v_block_id_info <= 1'b1;
  //      end

  //    // Send metadata control byte
  //    TX_TRAILER_METADATA_CTRL_BYTE :
  //      begin
  //        tx_metadata_ctrl_byte_pl <= 1'b1;
  //      end

      // Full frame/packet is sent
      INFORM_DATA_PKT_SENT :
        begin
          inform_frame_sent_pl       <= ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] == 1'b0 );
          inform_data_packet_sent_pl <= ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] != 1'b0 );
        end

    endcase
  end


// ------------------------------------------
//
// Register Outputs
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        frame_data_sent_pl_o       <= 1'b0;
        data_packet_sent_pl_o      <= 1'b0;
        change_thread_addr_pl_o    <= 1'b0;
        slfifo_rd_req_o            <= 1'b0;
        uvc_header_data_valid_o    <= 1'b0;
        u3v_header_data_valid_o    <= 1'b0;
        tx_eop_control_byte_pl_n_o <= 1'b1;
        // tx_u3v_block_id_info_f1    <= 1'b0;
      end
    else
      begin
        frame_data_sent_pl_o       <= inform_frame_sent_pl;
        data_packet_sent_pl_o      <= inform_data_packet_sent_pl;
        change_thread_addr_pl_o    <= change_thread_addr_pl;
        slfifo_rd_req_o            <= fifo_rd_req;
        uvc_header_data_valid_o    <= uvc_header_data_valid;
        u3v_header_data_valid_o    <= u3v_leader_data_valid | u3v_trailer_data_valid;
        tx_eop_control_byte_pl_n_o <= ~tx_eop_control_byte_pl; // Active low
        // tx_u3v_block_id_info_f1    <= tx_u3v_block_id_info;
      end
  end

// ------------------------------------------
//
// Whether trailer is sent or not
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        u3v_trailer_sent <= 1'd0;
      end
    else if ( ( tx_data_pkt_pl_i == 1'b1 ) | ( sel_d_reset_or_stop_stream_req_i == 1'b1 ) )
      begin
        u3v_trailer_sent <= 1'b0;
      end
    else if ( u3v_trailer_sent_pl )
      begin
        u3v_trailer_sent <= 1'b1;
      end
  end

// ------------------------------------------
//
// Slave FIFO Reset
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        slfifo_reset_req_o <= 1'd0;
      end
    else if ( ( tx_data_pkt_pl_i == 1'b1 ) | ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] != 32'b0 ) )
      begin
        slfifo_reset_req_o <= 1'b0;
      end
    else if ( tx_eop_control_byte_pl )
      begin
        slfifo_reset_req_o <= 1'b1;
      end
  end


// ------------------------------------------
//
// IDLE Control Bytes
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        idle_ctrl_byte_counter <= 8'd0;
      end
    else if ( idle_ctrl_byte_counter == ( NO_OF_IDLE_CONTROL_BYTES_REQ_AFTER_METADATA - 1'b1 ) )
      begin
        idle_ctrl_byte_counter <= 8'd0;
      end
    else if ( tx_idle_control_byte == 1'b1 )
      begin
        idle_ctrl_byte_counter <= idle_ctrl_byte_counter + 1'b1;
      end
  end

// ------------------------------------------
//
// FIFO Read Request
//
// ------------------------------------------

// FIFO Read Request
// always_ff @ ( posedge clk )
//   begin
//     if ( !reset_n )
//       begin
//         slfifo_rd_req_o <= 1'b0;
//       end
//     else if ( data_byte_counter == (sel_buffer_size_info - NO_OF_BYTES_PER_XFER) )
//       begin
//         slfifo_rd_req_o <= 1'b0;
//       end
//     else if (
//               ( fifo_rd_req == 1'b1) &
//               ( slfifo_almost_empty_i == 1'b0 )
//             )
//       begin
//         slfifo_rd_req_o <= 1'b1;
//       end
//   end

// Read data counter
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        data_byte_counter <= 16'b0;
      end
    else if ( ( ( data_byte_counter == (sel_buffer_size_info - NO_OF_BYTES_PER_XFER) ) &
                ( fifo_rd_req ) ) |
                ( tx_data_pkt_pl_i )
            )
      begin
        data_byte_counter <= 16'd0;
      end
    else if ( fifo_rd_req )
      begin
        if ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] < NO_OF_BYTES_PER_XFER )
          begin
            data_byte_counter <= data_byte_counter + no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i];
          end
        else
          begin
            data_byte_counter <= data_byte_counter + NO_OF_BYTES_PER_XFER;
          end
      end
  end

// Frame data counter
// It is initialized with frame size and will be decremented by data lane value.
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        no_of_frame_bytes_yet_to_be_sent_o <= {NO_OF_SUPPORTED_DEV_I{frame_size_info_i}};
      end
    else if ( /* tx_data_pkt_pl_i */ inform_frame_sent_pl | sel_d_reset_or_stop_stream_req_i )
      begin
        no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] <= frame_size_info_i;
      end
    else if ( fifo_rd_req )
      begin
        if ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] >= NO_OF_BYTES_PER_XFER )
          begin
            no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] <= no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] - NO_OF_BYTES_PER_XFER;
          end
        else
          begin
            no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] <= 32'd0;
          end
      end
  end

// Number of data bytes in a transfer
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        frame_xfer_len_in_bytes <= 6'd0;
      end
    else if ( fifo_rd_req )
      begin
        if ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] >= NO_OF_BYTES_PER_XFER )
          begin
            frame_xfer_len_in_bytes <= 6'd0;
          end
        else
          begin
            frame_xfer_len_in_bytes <= no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i];
          end
      end
  end

// ------------------------------------------
//
// Control Byte and Valid Signal
//
// ------------------------------------------

// Control Byte
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        dp_ctrl_byte_o <= 8'd0;
      end
    else
      begin
        case ( 1'b1 ) // Parallel case. All conditions are mutually exclusive.

          // tx_u3v_block_id_info               : dp_ctrl_byte_o <= { PARITY_BIT, SET_VARIABLE_LW_CONTROL_BYTE, 1'b0, CONTROL_BYTE_LS_BIT };

          // tx_u3v_block_id_info_f1            : dp_ctrl_byte_o <= { PARITY_BIT, SET_VARIABLE_HW_CONTROL_BYTE, 1'b0, CONTROL_BYTE_LS_BIT };

          tx_metadata_ctrl_byte_pl           : dp_ctrl_byte_o <= { PARITY_BIT, METADATA_CONTROL_BYTE, inmd_counter[1:0], CONTROL_BYTE_LS_BIT };

          tx_idle_control_byte               : dp_ctrl_byte_o <= IDLE_CONTROL_BYTE;

          tx_epc_control_byte_pl             : dp_ctrl_byte_o <= EPC_CONTROL_BYTE;

          start_pkt_flag_control_byte_pl     : dp_ctrl_byte_o <= { PARITY_BIT, SET_FLAG_CONTROL_BYTE, 2'd1, CONTROL_BYTE_LS_BIT };

          clr_start_pkt_flag_control_byte_pl : dp_ctrl_byte_o <= { PARITY_BIT, CLEAR_FLAG_CONTROL_BYTE, 2'd1, CONTROL_BYTE_LS_BIT };

          tx_hpc_control_byte_pl             : dp_ctrl_byte_o <= HPC_CONTROL_BYTE;

          tx_eop_control_byte_pl             : dp_ctrl_byte_o <= EOP_CONTROL_BYTE;

          tx_new_thread_addr_pl              : dp_ctrl_byte_o <= { PARITY_BIT, SET_THREAD_ADDR_CONTROL_BYTE, sel_d_reg_info_st_i.thread_addr, CONTROL_BYTE_LS_BIT };

          tx_new_socket_addr_pl              : dp_ctrl_byte_o <= { PARITY_BIT, SET_SOCKET_ADDR_CONTROL_BYTE, sel_d_reg_info_st_i.socket_addr, CONTROL_BYTE_LS_BIT };

          slfifo_rd_req_o                    : dp_ctrl_byte_o <= { PARITY_BIT, frame_xfer_len_in_bytes, DATA_CONTROL_BYTE_LS_BIT };

          uvc_header_data_valid              : dp_ctrl_byte_o <= { PARITY_BIT, 6'd0, DATA_CONTROL_BYTE_LS_BIT };

         (u3v_leader_data_valid &
          u3v_leader_data_cnt < U3V_LEADER_BYTES_MAX_COUNT)  : dp_ctrl_byte_o <= { PARITY_BIT, 6'd0, DATA_CONTROL_BYTE_LS_BIT };

         (u3v_leader_data_valid &
          u3v_leader_data_cnt == U3V_LEADER_BYTES_MAX_COUNT) : dp_ctrl_byte_o <= { PARITY_BIT, 6'd8, DATA_CONTROL_BYTE_LS_BIT };

         (u3v_trailer_data_valid &
          u3v_trailer_data_cnt < U3V_TRAILER_BYTES_MAX_COUNT)  : dp_ctrl_byte_o <= { PARITY_BIT, 6'd0, DATA_CONTROL_BYTE_LS_BIT };

         (u3v_trailer_data_valid &
          u3v_trailer_data_cnt == U3V_TRAILER_BYTES_MAX_COUNT) : dp_ctrl_byte_o <= { PARITY_BIT, 6'd8, DATA_CONTROL_BYTE_LS_BIT };

          tx_frame_header_info_pl            : dp_ctrl_byte_o <= { PARITY_BIT, SET_VARIABLE_HW_CONTROL_BYTE, 1'b0, CONTROL_BYTE_LS_BIT }; // Matadata0

          default                            : dp_ctrl_byte_o <= IDLE_CONTROL_BYTE;

        endcase
      end
  end


// Control Byte Valid
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        dp_ctrl_byte_valid_o <= 1'b0;
      end
    else
      begin
        dp_ctrl_byte_valid_o <= (
                                 /* tx_u3v_block_id_info               |
                                 tx_u3v_block_id_info_f1            | */
                                 tx_metadata_ctrl_byte_pl           |
                                 tx_epc_control_byte_pl             |
                                 start_pkt_flag_control_byte_pl     |
                                 clr_start_pkt_flag_control_byte_pl |
                                 tx_hpc_control_byte_pl             |
                                 tx_eop_control_byte_pl             |
                                 tx_new_thread_addr_pl              |
                                 tx_new_socket_addr_pl              |
                                 slfifo_rd_req_o                    |
                                 uvc_header_data_valid              |
                                 u3v_trailer_data_valid             |
                                 u3v_leader_data_valid              |
                                 tx_idle_control_byte               |
                                 tx_frame_header_info_pl
                                );
      end
  end

// ---------------------------------------------------
//
// Frame Header As a Payload
//
// ---------------------------------------------------
// UVC header
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        uvc_frame_header_data_o <= '0;
      end
    else if ( uvc_header_cnt == 3'd0 )
      begin
        uvc_frame_header_data_o <= (TOTAL_LVDS_DATA_LANES_I * 8)'( { 112'h0, frame_header_info_uw[sel_device_num_i], UVC_HEADER_LENGTH_IN_BYTES[7:0] } );
      end
    else
      begin
        uvc_frame_header_data_o <= '0;
      end
  end

// Leader/Trailer Data
generate
  if ( TOTAL_LVDS_DATA_LANES_I == 16 )
    begin : WIDELINK_U3V_MODE

      always_ff @ ( posedge clk )
        begin
          if ( !reset_n )
            begin
              u3v_frame_header_data_o <= 128'h0;
            end
          else
            begin
              case ( { u3v_leader_data_valid, u3v_trailer_data_valid } )

                2'b10 :
                  begin
                    case ( u3v_leader_data_cnt )

                      3'd0 : u3v_frame_header_data_o <= { u3v_block_id, LEADER_SIZE_IN_BYTES_MSB, LEADER_SIZE_IN_BYTES_LSB, {2{RESERVED_BYTE}}, LEADER_MAGIC_KEY };
                      3'd1 : u3v_frame_header_data_o <= { IMAGE_FORMAT, {4{RESERVED_BYTE}}, {4{RESERVED_BYTE}}, PAYLOAD_TYPE_IMAGE, {2{RESERVED_BYTE}} };
                      3'd2 : u3v_frame_header_data_o <= { {8{RESERVED_BYTE}}, {2{RESERVED_BYTE}}, sel_d_reg_info_st_i.image_height, {2{RESERVED_BYTE}}, sel_d_reg_info_st_i.image_width};
                      3'd3 : u3v_frame_header_data_o <= { 16{RESERVED_BYTE} };

                    endcase
                  end

                2'b01 :
                  begin
                    case ( u3v_trailer_data_cnt )

                      3'd0 : u3v_frame_header_data_o <= { u3v_block_id, TRAILER_SIZE_IN_BYTES_MSB, TRAILER_SIZE_IN_BYTES_LSB, {2{RESERVED_BYTE}}, TRAILER_MAGIC_KEY };
                      3'd1 : u3v_frame_header_data_o <= { {2{RESERVED_BYTE}}, sel_d_reg_info_st_i.image_height, {4{RESERVED_BYTE}}, frame_size_info_i, {4{RESERVED_BYTE}} };
                      3'd2 : u3v_frame_header_data_o <= {16{RESERVED_BYTE}};

                    endcase
                  end

                default :
                  begin
                    u3v_frame_header_data_o <= u3v_frame_header_data_o;
                  end

              endcase
            end
        end
    end
  else
    begin : NARROWLINK_U3V_MODE

      always_ff @ ( posedge clk )
        begin
          if ( !reset_n )
            begin
              u3v_frame_header_data_o <= 64'h0;
            end
          else
            begin
              case ( { u3v_leader_data_valid, u3v_trailer_data_valid } )

                2'b10 :
                  begin
                    case ( u3v_leader_data_cnt )

                      3'd0 : u3v_frame_header_data_o <= { LEADER_SIZE_IN_BYTES_MSB, LEADER_SIZE_IN_BYTES_LSB, {2{RESERVED_BYTE}}, LEADER_MAGIC_KEY };
                      3'd1 : u3v_frame_header_data_o <= u3v_block_id;
                      3'd2 : u3v_frame_header_data_o <= { {4{RESERVED_BYTE}}, PAYLOAD_TYPE_IMAGE, {2{RESERVED_BYTE}} };
                      3'd3 : u3v_frame_header_data_o <= { IMAGE_FORMAT, {4{RESERVED_BYTE}} };
                      3'd4 : u3v_frame_header_data_o <= { {2{RESERVED_BYTE}}, sel_d_reg_info_st_i.image_height, {2{RESERVED_BYTE}}, sel_d_reg_info_st_i.image_width};
                      3'd5 : u3v_frame_header_data_o <= {8{RESERVED_BYTE}};
                      3'd6 : u3v_frame_header_data_o <= {8{RESERVED_BYTE}};

                    endcase
                  end

                2'b01 :
                  begin
                    case ( u3v_trailer_data_cnt )

                      3'd0 : u3v_frame_header_data_o <= { TRAILER_SIZE_IN_BYTES_MSB, TRAILER_SIZE_IN_BYTES_LSB, {2{RESERVED_BYTE}}, TRAILER_MAGIC_KEY };
                      3'd1 : u3v_frame_header_data_o <= u3v_block_id;
                      3'd2 : u3v_frame_header_data_o <= { frame_size_info_i, {4{RESERVED_BYTE}} };
                      3'd3 : u3v_frame_header_data_o <= { {2{RESERVED_BYTE}}, sel_d_reg_info_st_i.image_height, {4{RESERVED_BYTE}} };
                      3'd4 : u3v_frame_header_data_o <= {8{RESERVED_BYTE}};
                      3'd5 : u3v_frame_header_data_o <= {8{RESERVED_BYTE}};

                    endcase
                  end

                default :
                  begin
                    u3v_frame_header_data_o <= u3v_frame_header_data_o;
                  end

              endcase
            end
        end
    end
endgenerate

// ------------------------------------------
//
// Is UVC frame header sent?
//
// ------------------------------------------

// Logic to find out whether UVC frame header is sent or not.
// To get the maximum throughput in UVC, header must be sent during
// the first buffer of the frame only with the last packet bit
// (LAST_PKT_INDICATOR_BIT) as HIGH. Hence, for even frames,
// it's 0x8E and for odd, it's 0x8F.
 always_ff @ ( posedge clk )
   begin
     if ( ~reset_n )
       begin
         uvc_frame_header_sent <= {NO_OF_SUPPORTED_DEV_I{1'b0}};
       end
     else if ( ( frame_data_sent_pl_o == 1'b1 ) | ( sel_d_reset_or_stop_stream_req_i == 1'b1 ) )
       begin
         uvc_frame_header_sent[sel_device_num_i] <= 1'b0;
       end
     else if ( ( data_byte_counter == (sel_buffer_size_info - NO_OF_BYTES_PER_XFER) ) & ( fifo_rd_req ) )
       begin
         uvc_frame_header_sent[sel_device_num_i] <= 1'b1;
       end
   end

// ------------------------------------------
//
// FX10 UVC header Count
//
// ------------------------------------------

 // UVC Header Count
 always_ff @ ( posedge clk )
   begin
     if ( !reset_n )
       begin
         uvc_header_cnt <= 3'd0;
       end
     else if ( uvc_header_data_valid )
       begin
         if ( uvc_header_cnt == UVC_HEADER_BYTES_MAX_COUNT )
           begin
             uvc_header_cnt <= 3'd0;
           end
         else
           begin
             uvc_header_cnt <= uvc_header_cnt + 1'd1;
           end
       end
   end

// ---------------------------------------------------
//
// MS Byte of Frame Header Length Word
//
// ---------------------------------------------------

// For even frame with last packet bit set = 0x8E
// For odd frame with last packet bit set  = 0x8F

// In UVC, FPGA sends header only single time per frame
// in first buffer. Hence, that must be the last packet.
// That's why, instead of 0x8C and 0x8D value, 0x8E and
// 0x8F is sent. It indicates the even or odd frame with
// last packet bit HIGH.

// Once, full frame is sent, this data will get changed.
 always_ff @ ( posedge clk )
   begin
     if ( !reset_n )
       begin
         frame_header_info_uw <= {NO_OF_SUPPORTED_DEV_I{EVEN_FRAME_LAST_PKT_NO}};
       end
     else if ( sel_d_reset_or_stop_stream_req_i )
       begin
         frame_header_info_uw[sel_device_num_i] <= EVEN_FRAME_LAST_PKT_NO;
       end
     else if ( frame_data_sent_pl_o )
       begin
         frame_header_info_uw[sel_device_num_i] <= {frame_header_info_uw[sel_device_num_i][7:1], ~frame_header_info_uw[sel_device_num_i][0]};
       end
   end

// ------------------------------------------
//
// Data Byte and Valid Signal
//
// ------------------------------------------

 // Data Byte
 always_ff @ ( posedge clk )
   begin
     if ( !reset_n )
       begin
         dp_data_byte_o <= 16'd0;
       end
     else if ( tx_frame_header_info_pl )
       begin
         dp_data_byte_o <= frame_header_info_uw[sel_device_num_i];
       end
   end

// // Data Byte
// always_ff @ ( posedge clk )
//   begin
//     if ( !reset_n )
//       begin
//         dp_data_byte_o <= 16'd0;
//       end
//     else
//       begin
//         case ( 1'b1 )
//
//           tx_frame_header_info_pl : dp_data_byte_o <= frame_header_info_uw[sel_device_num_i];
//           tx_u3v_block_id_info    : dp_data_byte_o <= u3v_block_id[15:0];
//           tx_u3v_block_id_info_f1 : dp_data_byte_o <= u3v_block_id[31:16];
//
//           default                 : dp_data_byte_o <= dp_data_byte_o;
//
//         endcase
//       end
//   end

 // Data Byte Valid
 always_ff @ ( posedge clk )
   begin
     if ( !reset_n )
       begin
         dp_data_byte_valid_o <= 1'b0;
       end
     else
       begin
         dp_data_byte_valid_o <= ( tx_frame_header_info_pl /* |
                                   tx_u3v_block_id_info |
                                   tx_u3v_block_id_info_f1 */
                                 );
       end
   end

// ------------------------------------------
//
// Is Leader ZLP sent?
//
// ------------------------------------------

// Logic to find out whether Leader is sent or not.
// Once leader is sent, FSM will start reading data from DDR.
// When trailer is sent or cam_app_en is low, this signal will be 0.

  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          l_zlp_sent_o <= {NO_OF_SUPPORTED_DEV_I{1'b0}};
        end
      else if ( ( common_reg_info_i.uvc_stream_mode_en ) |
                ( ( dp_cs == TX_U3V_LEADER_ZLP ) & ( tx_eop_control_byte_pl == 1'b1 ) )
              )
        begin
          l_zlp_sent_o[sel_device_num_i] <= 1'b1;
        end
      else if ( frame_data_sent_pl_o | sel_d_reset_or_stop_stream_req_i )
        begin
          l_zlp_sent_o[sel_device_num_i] <= 1'b0;
        end
    end

// ------------------------------------------
//
// FX10 U3V header Count
//
// ------------------------------------------

// U3V Leader Count
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        u3v_leader_data_cnt <= 4'd0;
      end
    else if ( u3v_leader_data_valid )
      begin
        if ( u3v_leader_data_cnt == U3V_LEADER_BYTES_MAX_COUNT )
          begin
            u3v_leader_data_cnt <= 4'd0;
          end
        else
          begin
            u3v_leader_data_cnt <= u3v_leader_data_cnt + 4'd1;
          end
      end
  end

// U3V Trailer Count
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        u3v_trailer_data_cnt <= 4'd0;
      end
    else if ( u3v_trailer_data_valid )
      begin
        if ( u3v_trailer_data_cnt == U3V_TRAILER_BYTES_MAX_COUNT )
          begin
            u3v_trailer_data_cnt <= 4'd0;
          end
        else
          begin
            u3v_trailer_data_cnt <= u3v_trailer_data_cnt + 4'd1;
          end
      end
  end

// U3V Block ID
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        u3v_block_id <= 64'd0;
      end
    else if ( sel_d_reset_or_stop_stream_req_i )
      begin
        u3v_block_id <= 64'd0;
      end
    else if ( frame_data_sent_pl_o )
      begin
        u3v_block_id <= u3v_block_id + 1'b1;
      end
  end


// FULL Flag Rising Edge
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fxn_buffer_ready_f1    <= 1'b0;
        fxn_buffer_ready_f2    <= 1'b0;
        fxn_buffer_ready_pe_pl <= 1'b0;
      end
    else
      begin
        fxn_buffer_ready_f1    <= fxn_buffer_ready_i;
        fxn_buffer_ready_f2    <= fxn_buffer_ready_f1;
        fxn_buffer_ready_pe_pl <= ( fxn_buffer_ready_f1 & ~fxn_buffer_ready_f2 );
      end
  end

// ------------------------------------------
//
// For debug purpose
//
// ------------------------------------------

// logic [15:0] fxn_buffer_unavailable_counter;
// logic [ 7:0] frame_counter;
//
// always_ff @ ( posedge clk )
//   begin
//     if ( !reset_n )
//       begin
//         fxn_buffer_unavailable_counter <= 16'b0;
//       end
//     else if ( fxn_buffer_ready_i )
//       begin
//         fxn_buffer_unavailable_counter <= 16'b0;
//       end
//     else if ( ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] != 1'b0 ) &
//               ( data_byte_counter == 1'b0 )
//             )
//       begin
//         fxn_buffer_unavailable_counter <= fxn_buffer_unavailable_counter + 1'b1;
//       end
//   end
//
// always_ff @ ( posedge clk )
//   begin
//     if ( !reset_n )
//       begin
//         frame_counter <= 8'b0;
//       end
//     else if ( sel_d_reset_or_stop_stream_req_i )
//       begin
//         frame_counter <= 8'b0;
//       end
//     else if ( tx_data_pkt_pl_i )
//       begin
//         frame_counter <= frame_counter + 1'b1;
//       end
//   end


// UVC Header Count
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        full_buffer_sent_o    <= 1'd0;
        wait_for_new_buffer_o <= 1'd0;
      end
    else
      begin
        full_buffer_sent_o    <= ( dp_cs == WAIT_READY_FLAG_DEASSERTED );
        wait_for_new_buffer_o <= ( dp_cs == IS_BUFFER_AVAILABLE );
      end
  end

// Sending dual buffer for single device at a time
// After that switching the device

`ifdef DEVICE_SEL_BASED_ON_FRAME
  assign dual_thread_already_served = 1'b0;
`else
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        dual_thread_already_served <= 1'b0;
      end
    else if ( inform_frame_sent_pl | inform_data_packet_sent_pl )
      begin
        dual_thread_already_served <= 1'b0;
      end
    else if ( ( tx_new_thread_addr_pl ) /*| ( no_of_frame_bytes_yet_to_be_sent_o[sel_device_num_i] == 1'b0 )*/ )
      begin
        dual_thread_already_served <= 1'b1;
      end
  end
`endif

// ----------------------------------------------
//
// Wait before sampling FLAGA
//
// ----------------------------------------------

// FLAGA may take 3 or 4 clocks to get updated
// once new address is available. Here, after
// 10 clock cycles, FLAGA will be sampled.
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        flaga_sample_count <= 8'd0;
      end
    else if ( incr_flaga_sample_count == 1'b0 )
      begin
        flaga_sample_count <= 8'd0;
      end
    else
      begin
        flaga_sample_count <= flaga_sample_count + 1'b1;
      end
  end

// ----------------------------------------------
//
// Gear Ratio Counter
//
// ----------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        fxn_buf_wr_en <= 1'b0;
      end
    else if ( fifo_rd_req | uvc_header_data_valid ) // Higher priority
      begin
        fxn_buf_wr_en <= 1'b1;
      end
    else if ( ( fxn_buf_wr_count == NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
      begin
        fxn_buf_wr_en <= 1'b0;
      end
  end

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        fxn_buf_wr_count <= 3'd0;
      end
    else if ( fifo_rd_req | uvc_header_data_valid )
      begin
        fxn_buf_wr_count <= 3'b0;
      end
    else if ( fxn_buf_wr_en == 1'b1 )
      begin
        fxn_buf_wr_count <= fxn_buf_wr_count + 1'b1;
      end
  end

// Bit Counter
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        bit_counter <= 3'd0;
      end
    else if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
      begin
        bit_counter <= 3'd0;
      end
    else if (  tx_epc_control_byte_pl             |
               start_pkt_flag_control_byte_pl     |
               clr_start_pkt_flag_control_byte_pl |
               tx_hpc_control_byte_pl             |
               tx_eop_control_byte_pl             |
               tx_new_thread_addr_pl              |
               tx_new_socket_addr_pl              |
              ( bit_counter != 1'b0 )
            )
      begin
        bit_counter <= bit_counter + 1'b1;
      end
  end

// ----------------------------------------------
//
// INMD Counter
//
// ----------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        inmd_counter <= '0;
      end
    else if ( ( sel_d_reset_or_stop_stream_req_i == 1'b1 ) |
              ( frame_data_sent_pl_o == 1'b1 ) )
      begin
        inmd_counter <= '0;
      end
    else if ( tx_metadata_ctrl_byte_pl == 1'b1 )
      begin
        inmd_counter <= inmd_counter + 1'b1;
      end
  end

endmodule
