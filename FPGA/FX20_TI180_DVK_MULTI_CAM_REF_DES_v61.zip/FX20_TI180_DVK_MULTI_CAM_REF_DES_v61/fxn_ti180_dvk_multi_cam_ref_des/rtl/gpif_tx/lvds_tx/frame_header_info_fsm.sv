//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    frame_header_info_fsm
// Target Devices: All
//
// Description: This module transmits the frame header information.
//
//
//////////////////////////////////////////////////////////////////////////////////


// Include the package file
`include "package/user_define_pkg.sv"


module frame_header_info_fsm
 #
 (
   // No. of devices/ FIFOs needed
   parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
   parameter SEL_DEV_NUM_BITS_I = 3
 )
 (
  input               clk,
  input               reset_n,

  // Outputs
  output logic [ 7:0] fh_ctrl_byte_o,
  output logic        fh_ctrl_byte_valid_o,
  output logic        frame_header_info_sent_pl_o,

  // Inputs
  input               tx_frame_header_info_pl_i,
  input               sel_d_reset_or_stop_stream_req_i,
  input               cam_config_done_i,         // Camera configuration is completed.
  input               fxn_buffer_ready_i,       // Buffer Ready
  input               full_frame_sent_pl_i,      // Full frame is sent
  input [(NO_OF_SUPPORTED_DEV_I-1):0]  vsync_i,
  input [(SEL_DEV_NUM_BITS_I-1):0] sel_device_num_i,

  input dev_reg_info_st_t sel_d_reg_info_st_i
 );


// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // IDLE Control Byte
  localparam       IDLE_CONTROL_BYTE = 8'd1;

  // Parity Bit: Will be added by "data_n_control_byte_manager"
  localparam [0:0] PARITY_BIT = 1'd0;

  // Even Frame Number
  // localparam [7:0] EVEN_FRAME_NO = 8'h8C;

  // PTS Control Byte
  localparam       PTS_CONTROL_BYTE = 8'hA1;

  // SCR Control Byte
  localparam       SCR_CONTROL_BYTE = 8'h23;

  // Set any flag of a particular thread
  localparam [3:0] SET_FLAG_CONTROL_BYTE = 4'b1000;

  // LSbit of Control Byte
  localparam [0:0] CONTROL_BYTE_LS_BIT = 1'b1;

  // Total flags per thread
  localparam NO_OF_FLAGS_FOR_EACH_THREAD = 3'd4;

  // No of States
  localparam NO_OF_FSM_STATES = 8'd9;

  enum logic [(NO_OF_FSM_STATES-1):0] {

    IDLE                     = 9'h1,
    TX_IDLE_BEFORE_PTS       = 9'h2,
    TX_PTS_CTRL_BYTE         = 9'h4,
    TX_IDLE_BEFORE_SCR       = 9'h8,
    TX_SCR_CTRL_BYTE         = 9'h10,
    WAIT_BUFFER_AVAILABLE    = 9'h20,
    IS_FLAG_ENABLED          = 9'h40,
    SET_FRAME_VALID_FLAG     = 9'h80,
    INFORM_FRAME_HEADER_SENT = 9'h100

  } fh_cs, fh_ns;


// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  logic  [3:0] bit_counter;
  logic  [2:0] fh_data_wr_count;
  logic        fh_data_wr_en;
  logic         tx_idle_control_byte;
  logic         tx_pts_control_byte_pl;
  logic         tx_scr_control_byte_pl;
  // logic         tx_frame_header_info_pl;
  logic         tx_frame_valid_flag_pl;
  logic         frame_header_info_sent_pl;

// ------------------------------------------
//
// FSM
//
// ------------------------------------------

// Current State
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fh_cs <= IDLE;
      end
    else if ( sel_d_reset_or_stop_stream_req_i )
      begin
        fh_cs <= IDLE;
      end
    else
      begin
        fh_cs <= fh_ns;
      end
  end

// Next State
always_comb
  begin
    fh_ns <= IDLE;
    unique case ( fh_cs )

      // Wait until Device Selection FSM informs to
      // transmit header information.
      IDLE :
        begin
          if ( tx_frame_header_info_pl_i )
            begin
              fh_ns <= TX_IDLE_BEFORE_PTS;
            end
          else
            begin
              fh_ns <= IDLE;
            end
        end

      // Tranmit IDLEs until camera is configured.
      TX_IDLE_BEFORE_PTS :
        begin
          if ( ( cam_config_done_i == 1'b1 ) &
               ( fh_data_wr_count == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
             )
            begin
              fh_ns <= TX_PTS_CTRL_BYTE;
            end
          else
            begin
              fh_ns <= TX_IDLE_BEFORE_PTS;
            end
        end

      // Send PTS Control Byte
      TX_PTS_CTRL_BYTE :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          fh_ns <= TX_IDLE_BEFORE_SCR;
        end
          else
            begin
              fh_ns <= TX_PTS_CTRL_BYTE;
            end
        end

      // Tranmit IDLEs until camera start sending data.
      TX_IDLE_BEFORE_SCR :
        begin
          if ( ( vsync_i[sel_device_num_i] == 1'b1 ) &
               ( fh_data_wr_count == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
             )
            begin
              fh_ns <= TX_SCR_CTRL_BYTE;
            end
          else
            begin
              fh_ns <= TX_IDLE_BEFORE_SCR;
            end
        end

      // Send SCR Control Byte
      TX_SCR_CTRL_BYTE :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          fh_ns <= WAIT_BUFFER_AVAILABLE;
        end
          else
            begin
              fh_ns <= TX_SCR_CTRL_BYTE;
            end
        end

      // Wait until READY signal is HIGH.
      WAIT_BUFFER_AVAILABLE :
        begin
          if ( fxn_buffer_ready_i )
            begin
              fh_ns <= IS_FLAG_ENABLED;
            end
          else
            begin
              fh_ns <= WAIT_BUFFER_AVAILABLE;
            end
        end

      // Send frame header upper word
/*       TX_FRAME_HEADER_INFO :
        begin
          fh_ns <= IS_FLAG_ENABLED;
        end */

      // Check whether first flag (frame valid) is enabled or not
      IS_FLAG_ENABLED :
        begin
          if ( sel_d_reg_info_st_i.flag_info[0] == 1'b1 )
            begin
              fh_ns <= SET_FRAME_VALID_FLAG;
            end
          else
            begin
              fh_ns <= INFORM_FRAME_HEADER_SENT;
            end
        end

      // Inform FX10 that new frame will be transmitted soon
      SET_FRAME_VALID_FLAG :
        begin
          if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
            begin
          fh_ns <= INFORM_FRAME_HEADER_SENT;
        end
          else
            begin
              fh_ns <= SET_FRAME_VALID_FLAG;
            end
        end

      // Frame header is sent
      INFORM_FRAME_HEADER_SENT :
        begin
          fh_ns <= IDLE;
        end

    endcase
  end

// Next State Signals
always_comb
  begin

    tx_idle_control_byte      <= 1'b0;
    tx_pts_control_byte_pl    <= 1'b0;
    tx_scr_control_byte_pl    <= 1'b0;
    // tx_frame_header_info_pl   <= 1'b0;
    tx_frame_valid_flag_pl    <= 1'b0;
    frame_header_info_sent_pl <= 1'b0;

    unique case ( fh_cs )

      // Wait until Device Selection FSM informs to
      // transmit header information.
      IDLE :
        begin

        end

      // Tranmit IDLEs until camera is configured.
      TX_IDLE_BEFORE_PTS :
        begin
          tx_idle_control_byte <= ( ~( ( fh_data_wr_count < ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) ) & ( fh_data_wr_en ) ) );
        end

      // Send PTS Control Byte
      TX_PTS_CTRL_BYTE :
        begin
          tx_pts_control_byte_pl <= (bit_counter == 1'b0);
        end

      // Tranmit IDLEs until camera start sending data.
      TX_IDLE_BEFORE_SCR :
        begin
          tx_idle_control_byte <= ( ~( ( fh_data_wr_count < ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) ) & ( fh_data_wr_en ) ) );
        end

      // Send SCR Control Byte
      TX_SCR_CTRL_BYTE :
        begin
          tx_scr_control_byte_pl <= (bit_counter == 1'b0);
        end

      // Wait until READY signal is HIGH.
      WAIT_BUFFER_AVAILABLE :
        begin

        end

      // Send frame header upper word
      // TX_FRAME_HEADER_INFO :
        // begin
          // tx_frame_header_info_pl <= 1'b1;
        // end

      // Check whether first flag (frame valid) is enabled or not
      IS_FLAG_ENABLED :
        begin

        end

      // Inform FX10 that new frame will be transmitted soon
      SET_FRAME_VALID_FLAG :
        begin
          tx_frame_valid_flag_pl <= (bit_counter == 1'b0);
        end

      // Frame header is sent
      INFORM_FRAME_HEADER_SENT :
        begin
          frame_header_info_sent_pl <= 1'b1;
        end

    endcase
  end

// ------------------------------------------
//
// Register Outputs
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        frame_header_info_sent_pl_o <= 1'b0;
      end
    else
      begin
        frame_header_info_sent_pl_o <= frame_header_info_sent_pl;
      end
  end

// ------------------------------------------
//
// Control Byte and Valid Signal
//
// ------------------------------------------

// Control Byte
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fh_ctrl_byte_o <= 8'd0;
      end
    else
      begin
        case ( 1'b1 ) // Parallel case. All conditions are mutually exclusive.

          tx_idle_control_byte       : fh_ctrl_byte_o <= IDLE_CONTROL_BYTE;

          tx_pts_control_byte_pl     : fh_ctrl_byte_o <= PTS_CONTROL_BYTE;

          tx_scr_control_byte_pl     : fh_ctrl_byte_o <= SCR_CONTROL_BYTE;

          // tx_frame_header_info_pl    : fh_ctrl_byte_o <= { PARITY_BIT, FRAME_HEADER_HW_CONTROL_BYTE, 1'b0, CONTROL_BYTE_LS_BIT }; // Matadata0

          tx_frame_valid_flag_pl     : fh_ctrl_byte_o <= { PARITY_BIT, SET_FLAG_CONTROL_BYTE, 2'b0, CONTROL_BYTE_LS_BIT }; //Set first flag (f0)

          default                    : fh_ctrl_byte_o <= IDLE_CONTROL_BYTE;

        endcase
      end
  end

// Control Byte Valid
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        fh_ctrl_byte_valid_o <= 1'b0;
      end
    else
      begin
        fh_ctrl_byte_valid_o <= (
                                 tx_pts_control_byte_pl    |
                                 tx_scr_control_byte_pl    |
                                 // tx_frame_header_info_pl   |
                                 tx_frame_valid_flag_pl    |
                                 tx_idle_control_byte
                                );
      end
  end


// ----------------------------------------------
//
// Gear Ratio Counter
//
// ----------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        fh_data_wr_en <= 1'b0;
      end
    else if ( tx_idle_control_byte == 1'b1 ) // Higher priority
      begin
        fh_data_wr_en <= 1'b1;
      end
    else if ( ( fh_data_wr_count == NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
      begin
        fh_data_wr_en <= 1'b0;
      end
  end

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        fh_data_wr_count <= 3'd0;
      end
    else if ( tx_idle_control_byte == 1'b1 )
      begin
        fh_data_wr_count <= 3'b0;
      end
    else if ( fh_data_wr_en == 1'b1 )
      begin
        fh_data_wr_count <= fh_data_wr_count + 1'b1;
      end
  end

// Bit Counter
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        bit_counter <= 3'd0;
      end
    else if ( bit_counter == ( NO_OF_CLK_REQ_FOR_BYTE - 1'b1 ) )
      begin
        bit_counter <= 3'd0;
      end
    else if ( ( tx_pts_control_byte_pl | tx_scr_control_byte_pl | tx_frame_valid_flag_pl ) |
              ( bit_counter != 1'b0 )
            )
      begin
        bit_counter <= bit_counter + 1'b1;
      end
  end

// ---------------------------------------------------
//
// Frame Header Upper Word
//
// ---------------------------------------------------

// For even frame, 0x8C
// For odd frame, 0x8D

// Once, full frame is sent on all devices, this data
// will get changed.
// always_ff @ ( posedge clk )
//   begin
//     if ( !reset_n )
//       begin
//         frame_header_info_uw <= EVEN_FRAME_NO;
//       end
//     else if ( all_devices_served_pl_i )
//       begin
//         frame_header_info_uw <= {frame_header_info_uw[7:1], ~frame_header_info_uw[0]};
//       end
//   end


// ------------------------------------------
//
// Data Byte and Valid Signal
//
// ------------------------------------------

// // Data Byte
// always_ff @ ( posedge clk )
//   begin
//     if ( !reset_n )
//       begin
//         fh_data_byte_o <= 8'd0;
//       end
//     else if ( tx_frame_header_info_pl )
//       begin
//         fh_data_byte_o <= frame_header_info_uw;
//       end
//   end
//
// // Data Byte Valid
// always_ff @ ( posedge clk )
//   begin
//     if ( !reset_n )
//       begin
//         fh_data_byte_valid_o <= 1'b0;
//       end
//     else
//       begin
//         fh_data_byte_valid_o <= tx_frame_header_info_pl;
//       end
//   end


endmodule