//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fxn_i2c_reg_intr
// Target Devices: All
//
// Description: This is a register module which supports I2C slave interface.
//              Any controller with I2C Master interface can access these
//              registers.
//
//              Format:
//              I2C Slave Address - Register Address - Write Data
//
//////////////////////////////////////////////////////////////////////////////////

// Include the package file
`include "package/user_define_pkg.sv"


module fxn_i2c_reg_intr
  #
  (
   // I2C Slave Address
   parameter [6:0] I2C_SLAVE_ADDR_I = 7'b000_1101,

   // Clock Value
   parameter GPIF_M_CLK_VALUE_I = 75_000_000,

   // No. of devices supported by fxn master I2C bus
   parameter NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I = 4,

   // No. of devices/ FIFOs needed
   parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
   parameter SEL_DEV_NUM_BITS_I = 3
  )
 (
  input              clk,
  input              reset_n,

  // Inputs
  input i2c_bus_in_st_t  i2c_bus_in_st_arr_i,

  input      [(NO_OF_SUPPORTED_DEV_I-1):0] vsync_i,
  input      [(SEL_DEV_NUM_BITS_I-1):0]    sel_device_num_i,
  input              change_thread_addr_pl_i,
  input              sel_d_reset_or_stop_stream_req_i,

  input              ddr_ctrl_data_path_idle_i,
  input              ddr_ctrl_cmd_queue_almost_full_i,
  input              ddr_ctrl_busy_i,
  input              ddr_cfg_done_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]  full_frame_wr_completed_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]  full_frame_rd_completed_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]  y_data_bufr_empty_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0]  y_data_bufr_full_i,
  input              fxn_gpif_m_full_flag_i,
  input      [(NO_OF_SUPPORTED_DEV_I-1):0] [14:0]  mipi_status_reg_i,
  input  slfifo_data_nd_status_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] slfifo_data_nd_status_st_arr_i,
  input  cam_i2c_bus_in_st_t    [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I-1):0] cam_i2c_bus_in_st_arr_i,


  // Outputs
  output i2c_bus_out_st_t    i2c_bus_out_st_arr_o,
  output cam_i2c_bus_out_st_t [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I-1):0] cam_i2c_bus_out_st_arr_o,
  output logic        new_thread_addr_available_pl_o,

  output common_reg_info_st_t    common_reg_o,
  output dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_o
 );

// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

// Common and Device Specific Register Offset
localparam [7:0] COMMON_REG_BASE_OFFSET_8   = 8'h00;
localparam [7:0] DEVICE_0_REG_BASE_OFFSET_8 = 8'h20;
localparam [7:0] DEVICE_1_REG_BASE_OFFSET_8 = 8'h3C;
localparam [7:0] DEVICE_2_REG_BASE_OFFSET_8 = 8'h58;
localparam [7:0] DEVICE_3_REG_BASE_OFFSET_8 = 8'h74;
localparam [7:0] DEVICE_4_REG_BASE_OFFSET_8 = 8'h90;
localparam [7:0] DEVICE_5_REG_BASE_OFFSET_8 = 8'hAC;
localparam [7:0] DEVICE_6_REG_BASE_OFFSET_8 = 8'hC8;
localparam [7:0] DEVICE_7_REG_BASE_OFFSET_8 = 8'hE4;

// Base Offset Difference
localparam DEV_REG_BASE_OFFSET_DIFF = 8'h1C;

// Base Offset for Common Registers
localparam [7:0] RTL_VERSION_OFFSET_8                    = 8'h00;
localparam [7:0] STREAMING_MODE_OFFSET_8                 = 8'h01;
localparam [7:0] FRAME_HEADER_INFO_OFFSET_8              = 8'h02;
localparam [7:0] LVDS_PHY_TS_OFFSET_8                    = 8'h03;
localparam [7:0] TRAINING_BLK_SEQ_BYTE_P0_OFFSET_8       = 8'h04;
localparam [7:0] TRAINING_BLK_SEQ_BYTE_P1_OFFSET_8       = 8'h05;
localparam [7:0] TRAINING_BLK_SEQ_BYTE_P2_OFFSET_8       = 8'h06;
localparam [7:0] TRAINING_BLK_SEQ_BYTE_P3_OFFSET_8       = 8'h07;
localparam [7:0] ACTIVE_DEV_MASK_OFFSET_8                = 8'h08;
localparam [7:0] LOW_POWER_SUPPORT_OFFSET_8              = 8'h09;
localparam [7:0] PHY_AND_LINK_TRAINING_CONTROL_OFFSET_8  = 8'h0A;
localparam [7:0] EXT_CNTLR_STATUS_OFFSET_8               = 8'h0B;

// Device Specific Registers
localparam [7:0] STREAM_ENABLE_OFFSET_8          = 8'h00;
localparam [7:0] MODE_ENABLE_OFFSET_8            = 8'h01;
localparam [7:0] IMAGE_HEIGHT_INFO_LB_OFFSET_8   = 8'h02;
localparam [7:0] IMAGE_HEIGHT_INFO_UB_OFFSET_8   = 8'h03;
localparam [7:0] IMAGE_WIDTH_INFO_LB_OFFSET_8    = 8'h04;
localparam [7:0] IMAGE_WIDTH_INFO_UB_OFFSET_8    = 8'h05;
localparam [7:0] IMAGE_FRAME_RATE_INFO_OFFSET_8  = 8'h06;
localparam [7:0] IMAGE_PIXEL_WIDTH_INFO_OFFSET_8 = 8'h07;
localparam [7:0] SOURCE_TYPE_INFO_OFFSET_8       = 8'h08;
localparam [7:0] STATUS_INFO_OFFSET_8            = 8'h09;
localparam [7:0] MIPI_STATUS_INFO_OFFSET_8       = 8'h0A;
localparam [7:0] HDMI_MIPI_SOURCE_INFO_OFFSET_8  = 8'h0B;
localparam [7:0] U3V_STREAM_MODE_OFFSET_8        = 8'h0C;
localparam [7:0] U3V_CHUNK_MODE_OFFSET_8         = 8'h0D;
localparam [7:0] U3V_TRIGGER_INFO_OFFSET_8       = 8'h0E;
localparam [7:0] ACTIVE_THREAD_INFO_OFFSET_8     = 8'h0F;
localparam [7:0] THREAD_1_INFO_OFFSET_8          = 8'h10;
localparam [7:0] THREAD_2_INFO_OFFSET_8          = 8'h11;
localparam [7:0] THREAD_1_SOCKET_INFO_OFFSET_8   = 8'h12;
localparam [7:0] THREAD_2_SOCKET_INFO_OFFSET_8   = 8'h13;
localparam [7:0] FLAG_INFO_OFFSET_8              = 8'h14;
localparam [7:0] COUNTERS_AND_CRC_INFO_OFFSET_8  = 8'h15;
localparam [7:0] BUFFER_SIZE_LB_INFO_OFFSET_8    = 8'h16;
localparam [7:0] BUFFER_SIZE_UB_INFO_OFFSET_8    = 8'h17;

// Misc
// Total flags, socket, PC and EC per thread
localparam       NO_OF_THREADS_OR_EC_BITS_FOR_EACH_DEV = 2'd2;
localparam       NO_OF_SOCKET_BITS_FOR_EACH_DEV        = 2'd3;
localparam       NO_OF_PC_BITS_FOR_EACH_DEV            = 1'd1;
localparam       NO_OF_FLAGS_BITS_FOR_EACH_DEV         = 3'd4;
localparam       UVC_MODE_EN                           = 8'd1;
localparam       U3V_MODE_EN                           = 8'd0;
localparam       FRAME_HEADER_BY_FW                    = 8'd0;
localparam       FRAME_HEADER_BY_FPGA                  = 8'd1;

// I2C Timeout in Milli Second
localparam I2C_SLAVE_TIME_OUT_IN_MILLI_SEC = 1;

// Number of clock cycle in time out
localparam NO_OF_I2C_SLAVE_TIME_OUT_CLKS = ( GPIF_M_CLK_VALUE * I2C_SLAVE_TIME_OUT_IN_MILLI_SEC / 1000 );

// SDA glitch filtering count
localparam NO_OF_SDA_GLITCH_FILTER_COUNT = 5;

// SCL glitch filtering count
localparam NO_OF_SCL_GLITCH_FILTER_COUNT = 5;

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

// packed array of structure
dev_reg_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_st_arr;
cam_i2c_bus_temp_var_st_t [(NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I-1):0] cam_i2c_bus_temp_var_st_arr;


//I2C Slave state
enum logic [8:0] {

  START_D         = 9'h1,
  SLAVE_D         = 9'h2,
  SL_ACK          = 9'h4,
  ADDR_D          = 9'h8,
  WRITE_D         = 9'h10,
  READ_D          = 9'h20,
  STOP_D          = 9'h40,
  MS_ACK          = 9'h80,
  SENSOR_SLAVE    = 9'h100
} state;

genvar       dev_num;
logic        sda;
logic        sda_f;
logic        sda_r1;
logic        sda_r2;
logic        sda_f1;
logic        sda_f2;
logic        scl_f;
logic        scl_r1;
logic        scl_r2;
logic        scl_f1;
logic        scl_f2;
logic        rd_wr;

logic        change_thread_addr_pl_f1;
logic        change_thread_addr_pl_f2;
logic        change_thread_addr_pl_f3;
logic [7:0]  clr_sel_d_flag_status_reg_pl;
logic        clr_cntlr_status_reg_pl;
logic        sel_cam_addr;
logic [ 3:0] sda_glitch_count;
logic [ 3:0] scl_glitch_count;
logic [ 7:0] sclk_cam_ct;
logic [ 7:0] fpga_reg [255:0];
logic [ 7:0] read_data;
logic [ 7:0] sclk_ct;
logic [ 4:0] read_ct;
logic [ 6:0] slave_addr;
logic [ 3:0] byte_ct;
logic [ 7:0] data_r;
logic [ 7:0] addr_r;
logic [15:0] addr;
logic [ 7:0] data;
logic [15:0] thread_num_map;
logic [ 4:0] ext_cntlr_status_reg;

logic        sclk_r;
logic        sclk_f;
logic        start_bit;
logic        stop_bit;
logic        sclk;
logic        i2c_s_time_out_counter_en;
logic [31:0] i2c_s_time_out_counter;

integer status_dev_num;

// ------------------------------------------
//
// Bidirectional I2C Ports
//
// ------------------------------------------

// Bidirectional Ports
// As this is slave, it doesn't transmit clock
assign i2c_bus_out_st_arr_o.scl_en_o = 1'b0;
assign i2c_bus_out_st_arr_o.scl_o    = 1'b0;

// if 'sda' is 0, it means, FSM wants to
// send ACK. At that time, 'sda_en_o' must be HIGH.
  generate

    if ( NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I == 1 )
      begin
        // assign i2c_bus_out_st_arr_o.sda_en_o =    cam_i2c_bus_temp_var_st_arr[0].addr ? !cam_i2c_bus_temp_var_st_arr[0].sda :
                                                // ( cam_i2c_bus_temp_var_st_arr[1].addr ? !cam_i2c_bus_temp_var_st_arr[1].sda : !sda );

        assign i2c_bus_out_st_arr_o.sda_en_o = ( sel_cam_addr ? ( !cam_i2c_bus_temp_var_st_arr[0].sda ) : !sda );

        assign i2c_bus_out_st_arr_o.sda_o    = ( sel_cam_addr ? (cam_i2c_bus_temp_var_st_arr[0].sda) : sda );

      end

    else if ( NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I == 2 )
      begin
        // assign i2c_bus_out_st_arr_o.sda_en_o =    cam_i2c_bus_temp_var_st_arr[0].addr ? !cam_i2c_bus_temp_var_st_arr[0].sda :
                                                // ( cam_i2c_bus_temp_var_st_arr[1].addr ? !cam_i2c_bus_temp_var_st_arr[1].sda : !sda );

        assign i2c_bus_out_st_arr_o.sda_en_o = ( sel_cam_addr ? ( !(cam_i2c_bus_temp_var_st_arr[0].sda & cam_i2c_bus_temp_var_st_arr[1].sda) ) : !sda );

        assign i2c_bus_out_st_arr_o.sda_o    = ( sel_cam_addr ? (cam_i2c_bus_temp_var_st_arr[0].sda & cam_i2c_bus_temp_var_st_arr[1].sda) : sda );

      end

    else if ( NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I == 3 )
      begin

        assign i2c_bus_out_st_arr_o.sda_en_o = ( sel_cam_addr ? ( !(cam_i2c_bus_temp_var_st_arr[0].sda &
                                                                    cam_i2c_bus_temp_var_st_arr[1].sda &
                                                                    cam_i2c_bus_temp_var_st_arr[2].sda ) ) : !sda );

        assign i2c_bus_out_st_arr_o.sda_o    = ( sel_cam_addr ? (cam_i2c_bus_temp_var_st_arr[0].sda &
                                                                 cam_i2c_bus_temp_var_st_arr[1].sda &
                                                                 cam_i2c_bus_temp_var_st_arr[2].sda ) : sda );
      end

    else
      begin

        assign i2c_bus_out_st_arr_o.sda_en_o = ( sel_cam_addr ? ( !(cam_i2c_bus_temp_var_st_arr[0].sda &
                                                                    cam_i2c_bus_temp_var_st_arr[1].sda &
                                                                    cam_i2c_bus_temp_var_st_arr[2].sda &
                                                                    cam_i2c_bus_temp_var_st_arr[3].sda) ) : !sda );

        assign i2c_bus_out_st_arr_o.sda_o    = ( sel_cam_addr ? (cam_i2c_bus_temp_var_st_arr[0].sda &
                                                                 cam_i2c_bus_temp_var_st_arr[1].sda &
                                                                 cam_i2c_bus_temp_var_st_arr[2].sda &
                                                                 cam_i2c_bus_temp_var_st_arr[3].sda) : sda );
      end
  endgenerate


// assign sensor_state_sel = { (state == SENSOR_SLAVE_D3), (state == SENSOR_SLAVE_D2), (state == SENSOR_SLAVE_D1), (state == SENSOR_SLAVE) };

genvar i;

generate
  for ( i = 0; i < NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I; i = i + 1 )
    begin : DEV_SUPPORT_PER_I2C

// FPGA to Sensor scl
assign   cam_i2c_bus_out_st_arr_o[i].scl_o = scl_f;
assign   cam_i2c_bus_out_st_arr_o[i].sda_o = sda_f;

// FPGA to Sensor SDA_OE
assign cam_i2c_bus_out_st_arr_o[i].sda_en_o = cam_i2c_bus_temp_var_st_arr[i].oe;

// fpga_cam0_sda is temporary signal to buffer input sda from sensor
assign cam_i2c_bus_temp_var_st_arr[i].sda = cam_i2c_bus_temp_var_st_arr[i].oe ? 1'b1 : cam_i2c_bus_in_st_arr_i[i].sda_i;

      // assign cam_i2c_bus_temp_var_st_arr[i].addr = sel_cam_addr[i];


// ------------------------------------------
//
// output_enable for sensor i2c writes
//
// ------------------------------------------

always_ff @(posedge clk)
  begin
    if (!reset_n)
      begin // for 16-BIT register Addressing
        cam_i2c_bus_temp_var_st_arr[i].oe <= 1'b1;
      end
          else if ( ( sel_cam_addr ) && ( ( sclk_cam_ct == 8'd9 ) ||
                    ( sclk_cam_ct == 8'd18 ) ||
                    ( sclk_cam_ct == 8'd27 ) ||
                    ( sclk_cam_ct == 8'd36 ) ) )
      begin // for 16-BIT register Addressing
        cam_i2c_bus_temp_var_st_arr[i].oe <= 1'b0;
      end
    else
      begin
        cam_i2c_bus_temp_var_st_arr[i].oe <= 1'b1;
      end
   end

// ------------------------------------------
//
// slave_sclk_count for sensor
//
// ------------------------------------------

always_ff @(posedge clk)
  begin
    if (!reset_n)
      begin
              sclk_cam_ct <= 8'd9;
      end
          else if (/* sensor_state_sel[i] */ sel_cam_addr)
      begin
        if (stop_bit)
          begin
                  sclk_cam_ct <= 8'd9;
          end
         else if (sclk_f)
           begin
                   sclk_cam_ct <= sclk_cam_ct + 1'b1;
           end
      end
  end

    end
endgenerate

// ------------------------------------------
//
// Rising and Falling Edges of SDA
//
// ------------------------------------------
// SDA Flops
always_ff @(posedge clk)
  begin
    if(!reset_n)
      begin
       sda_r1 <= 1'b1;
       sda_r2 <= 1'b1;
       sda_f1 <= 1'b1;
       sda_f2 <= 1'b1;

      end
    else
      begin
       sda_r1 <= i2c_bus_in_st_arr_i.sda_i;
       sda_r2 <= sda_r1;
       sda_f1 <= sda_f;
       sda_f2 <= sda_f1;
      end
  end

// Glitch Removal Counter
always_ff @ ( posedge clk )
  begin
    if(!reset_n)
      begin
       sda_glitch_count <= 4'd0;
      end
    else if ( sda_r2 == sda_f)
      begin
       sda_glitch_count <= 4'd0;
      end
    else
      begin
       sda_glitch_count <= sda_glitch_count + 1'b1;
      end
  end

// Glitch Removal Counter
always_ff @ ( posedge clk )
  begin
    if(!reset_n)
      begin
       sda_f <= 1'b1;
      end
    else if ( sda_glitch_count == NO_OF_SDA_GLITCH_FILTER_COUNT )
      begin
       sda_f <= sda_r2;
      end
  end

// Start Bit
assign start_bit = ((!sda_f1)&(sda_f2)&(scl_f));

// Stop Bit
assign stop_bit = ((sda_f1)&(!sda_f2)&(scl_f));

// ------------------------------------------
//
// Rising and Falling Edges of SCLK
//
// ------------------------------------------
// SCL flops
always_ff @ ( posedge clk )
  begin
    if(!reset_n)
      begin
       scl_r1 <= 1'b1;
       scl_r2 <= 1'b1;
       scl_f1 <= 1'b1;
       scl_f2 <= 1'b1;
      end
    else
      begin
       scl_r1 <= i2c_bus_in_st_arr_i.scl_i;
       scl_r2 <= scl_r1;
       scl_f1 <= scl_f;
       scl_f2 <= scl_f1;
      end
  end

// Glitch Removal Counter
always_ff @ ( posedge clk )
  begin
    if(!reset_n)
      begin
       scl_glitch_count <= 4'd0;
      end
    else if ( scl_r2 == scl_f )
      begin
       scl_glitch_count <= 4'd0;
      end
    else
      begin
       scl_glitch_count <= scl_glitch_count + 1'b1;
      end
  end

// Glitch Removal Counter
always_ff @ ( posedge clk )
  begin
    if(!reset_n)
      begin
       scl_f <= 1'b1;
      end
    else if ( scl_glitch_count == NO_OF_SCL_GLITCH_FILTER_COUNT )
      begin
       scl_f <= scl_r2;
      end
  end

// Falling Edge of Glitch free SCLK. Master launches the data on rising edge,
// while slave latches on falling edge.
assign sclk_f = (!scl_f1)&(scl_f2);

// Rising Edge of Glitch free SCLK. Master launches the data on rising edge,
// while slave latches on falling edge.
assign sclk_r = (scl_f1)&(!scl_f2);


// ------------------------------------------
//
// SCLK Rising Edge Counter
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if(!reset_n)begin
     sclk_ct <= 8'd0;
    end
    else if((stop_bit)||(start_bit))begin
     sclk_ct <= 8'd0;
    end
    else if((state == WRITE_D)||(state == READ_D))begin
     sclk_ct <= sclk_ct;
    end
    else if(sclk_f)begin
     sclk_ct <= sclk_ct + 1'b1;
    end
    else if((state == START_D)||(state == STOP_D))begin
     sclk_ct <= 8'd0;
    end
  end

// ------------------------------------------
//
// I2C Slave FSM
//
// ------------------------------------------

always_ff @ ( posedge clk or negedge reset_n )
  begin
    if(!reset_n)
      begin
        state                     <= START_D;
        addr                      <= 8'd0;
        data_r                    <= 8'd0;
        data                      <= 8'd0;
        read_data                 <= 8'd0;
        read_ct                   <= 5'd8;
        byte_ct                   <= 4'd0;
        addr_r                    <= 8'd0;
        sda                       <= 1'b1;
        slave_addr                <= 7'd0;
        sel_cam_addr              <= 1'd0;
        clr_sel_d_flag_status_reg_pl <= 8'b0;
        clr_cntlr_status_reg_pl   <= 1'b0;
        i2c_s_time_out_counter_en    <= 1'b0;
        fpga_reg[RTL_VERSION_OFFSET_8]                   <= {RTL_MAJOR_VERSION, RTL_MINOR_VERSION};
        fpga_reg[STREAMING_MODE_OFFSET_8]                <= UVC_MODE_EN;
        fpga_reg[FRAME_HEADER_INFO_OFFSET_8]             <= FRAME_HEADER_BY_FW;
        fpga_reg[LVDS_PHY_TS_OFFSET_8]                   <= 8'h53;
        fpga_reg[TRAINING_BLK_SEQ_BYTE_P0_OFFSET_8]      <= 8'hAA;
        fpga_reg[TRAINING_BLK_SEQ_BYTE_P1_OFFSET_8]      <= 8'h55;
        fpga_reg[TRAINING_BLK_SEQ_BYTE_P2_OFFSET_8]      <= 8'hAA;
        fpga_reg[TRAINING_BLK_SEQ_BYTE_P3_OFFSET_8]      <= 8'h55;
        fpga_reg[ACTIVE_DEV_MASK_OFFSET_8]               <= 8'h01; // Only D0 is active
        fpga_reg[LOW_POWER_SUPPORT_OFFSET_8]             <= 8'h00; // Low power is not supported yet
        fpga_reg[PHY_AND_LINK_TRAINING_CONTROL_OFFSET_8] <= 8'h02; // Training Control
        fpga_reg[EXT_CNTLR_STATUS_OFFSET_8]              <= 8'h00;
        fpga_reg[8'hFF:8'h20]                            <= '{default:0};
//        fpga_reg                  <= '{default:0};

      end
    else
      begin
        fpga_reg[RTL_VERSION_OFFSET_8]                                   <= {RTL_MAJOR_VERSION, RTL_MINOR_VERSION};
        fpga_reg[EXT_CNTLR_STATUS_OFFSET_8]                              <= {3'b0, ext_cntlr_status_reg};
     for ( status_dev_num = 0; status_dev_num < NO_OF_SUPPORTED_DEV_I; status_dev_num = status_dev_num + 1 )
       begin : STATUS_SIGNALS
        fpga_reg[((status_dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + STATUS_INFO_OFFSET_8] <= dev_reg_st_arr[status_dev_num].status_info;
        fpga_reg[((status_dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + MIPI_STATUS_INFO_OFFSET_8] <= dev_reg_st_arr[status_dev_num].mipi_status_info;
       end
        clr_sel_d_flag_status_reg_pl <= 8'b0;
        clr_cntlr_status_reg_pl   <= 1'b0;
        sel_cam_addr              <= 1'd0;
        i2c_s_time_out_counter_en    <= 1'b0;
        
        case (state)
          START_D :
            begin
              sda <= 1'b1;
              byte_ct <= 4'd0;
              if(start_bit)
                state <= SLAVE_D;
            end

          SLAVE_D :
            begin
              sda <= 1'b1;
              read_ct <= 5'd8;

              if(sclk_f)
                begin
                  byte_ct <= byte_ct + 1'b1;
                  if(byte_ct == 4'd8)
                    begin
                      rd_wr <= sda_f;
                      if (slave_addr == I2C_SLAVE_ADDR_I)
                        begin
                          state <= SL_ACK;
                        end
                      else
                        begin
                          state <= SENSOR_SLAVE /* START_D */;
                        end
                    end
                  else
                    begin
                      slave_addr <= {slave_addr[5:0],sda_f};
                    end
                end
            end

          SENSOR_SLAVE:
            begin
              sel_cam_addr <= 1'b1;
              byte_ct <= 4'd0;
              if (stop_bit)
                begin
                  state <= START_D;
                end
              else
                begin
                  state <= SENSOR_SLAVE;
                end
            end

          SL_ACK :
            begin
              sda <= 1'b0;
              byte_ct <= 4'd0;
              i2c_s_time_out_counter_en <= 1'b1;

               if ( i2c_s_time_out_counter == NO_OF_I2C_SLAVE_TIME_OUT_CLKS )
                begin
                  state <= START_D;
                end
               else if((rd_wr)&&(sclk_r)&&(sclk_ct == 8'd9))
                 begin
                   state <= READ_D;
                   // if(fpga_reg_ct > addr_r)
                     // begin
                       read_data <= fpga_reg[addr[7:0]];
                       addr_r <= addr[7:0] + 1'b1;
                       clr_sel_d_flag_status_reg_pl[0]  <= ( addr == (DEVICE_0_REG_BASE_OFFSET_8 + STATUS_INFO_OFFSET_8) );
                       clr_sel_d_flag_status_reg_pl[1]  <= ( addr == (DEVICE_1_REG_BASE_OFFSET_8 + STATUS_INFO_OFFSET_8) );
                       clr_sel_d_flag_status_reg_pl[2]  <= ( addr == (DEVICE_2_REG_BASE_OFFSET_8 + STATUS_INFO_OFFSET_8) );
                       clr_sel_d_flag_status_reg_pl[3]  <= ( addr == (DEVICE_3_REG_BASE_OFFSET_8 + STATUS_INFO_OFFSET_8) );
                       clr_sel_d_flag_status_reg_pl[4]  <= ( addr == (DEVICE_4_REG_BASE_OFFSET_8 + STATUS_INFO_OFFSET_8) );
                       clr_sel_d_flag_status_reg_pl[5]  <= ( addr == (DEVICE_5_REG_BASE_OFFSET_8 + STATUS_INFO_OFFSET_8) );
                       clr_sel_d_flag_status_reg_pl[6]  <= ( addr == (DEVICE_6_REG_BASE_OFFSET_8 + STATUS_INFO_OFFSET_8) );
                       clr_sel_d_flag_status_reg_pl[7]  <= ( addr == (DEVICE_7_REG_BASE_OFFSET_8 + STATUS_INFO_OFFSET_8) );

                       clr_cntlr_status_reg_pl   <= ( addr == EXT_CNTLR_STATUS_OFFSET_8 );
                     // end
                   // else
                     // begin
                       // read_data <= 8'd0;
                     // end
                 end
               else if((sclk_f)&&((sclk_ct == 8'd9)||(sclk_ct == 8'd18)))
                 begin // for 16-BIT register Addressing
                   state <= ADDR_D;
                 end
               else if((sclk_f)&&(sclk_ct == 8'd27))
                 begin // for 16-BIT register Addressing
                   state <= WRITE_D;
                   addr_r <= addr[7:0];
                 end
               else if((sclk_f)&&(sclk_ct > 8'd27))
                 begin // for 16-BIT register Addressing
                   state <= WRITE_D;
                   // if(fpga_reg_ct > addr_r)
                     // begin
                       fpga_reg[addr_r] <= data_r;
                       data <= data_r;
                       addr_r <= addr_r + 1'b1;
                     // end
                 end
            end

          MS_ACK :
            begin
              sda <= 1'b1;
              byte_ct <= 4'd0;
              if((sclk_r)&&(!sda_f))
                begin
                  state <= READ_D;
                  // if(fpga_reg_ct > addr_r)
                    // begin
                      addr_r <= addr_r + 1'b1;
                      read_data <= fpga_reg[addr_r];
                    // end
                  // else
                    // begin
                      // read_data <= 8'd0;
                    // end
                  read_ct <= 5'd8;
                end
              else if((sclk_r)&&(sda_f))
                begin
                  state <= STOP_D;
                end
            end

          ADDR_D :
            begin
              sda <= 1'b1;
              i2c_s_time_out_counter_en <= 1'b1;

              if( stop_bit | ( i2c_s_time_out_counter == NO_OF_I2C_SLAVE_TIME_OUT_CLKS ) )
                begin
                  state <= START_D;
                end
              if(sclk_f)
                begin
                  read_ct <= 5'd8;
                  byte_ct <= byte_ct + 1'b1;

                  if(byte_ct == 4'd7)
                    begin
                      addr <= {addr[14:0],sda_f}; // for 16-BIT register Addressing
                      state <= SL_ACK;
                    end
                  else
                    begin
                      addr <= {addr[14:0],sda_f}; // for 16-BIT register Addressing
                    end
                end
            end

          WRITE_D :
            begin
              sda <= 1'b1;
              if(start_bit)
                begin
                  state <= SLAVE_D;
                end
              else if(stop_bit)
                begin
                  state <= START_D;
                end
              if(sclk_f)
                begin
                  byte_ct <= byte_ct + 1'b1;
                  if(byte_ct == 4'd7)
                    begin
                      data_r <= {data_r[6:0],sda_f};
                      state <= SL_ACK;
                    end
                  else
                    begin
                      data_r <= {data_r[6:0],sda_f};
                    end
                end
            end

          READ_D :
            begin
              if(stop_bit)
                begin
                  state <= START_D;
                end

              if(sclk_f)
                begin
                  if(read_ct == 5'd0)
                    begin
                      sda <= 1'b1;
                      state <= MS_ACK;
                    end
                  else
                    begin
                      sda <= (read_data[(read_ct - 1'b1)])  ? 1'b1 : 1'b0;
                      read_ct <= read_ct - 1'b1;
                    end
                end
            end

          STOP_D :
            begin
              sda <= 1'b1;
              if(stop_bit)
                begin
                  state <= START_D;
                end
              read_ct <= 5'd8;
            end
        endcase
      end
  end

// ------------------------------------------
//
// Common Registers
//
// ------------------------------------------

// Register Assignments
always_ff @ ( posedge clk )
  begin
//    if ( ~reset_n )
//      begin
//        common_reg_o = '{1, 0, 0, 8'h53, 8'hAA, 8'h55, 8'hAA, 8'h55, 1, 0, 1, 1, 0, 0 };
//        common_reg_o = '{lvds_phy_training_en:1, link_training_en:1, default:0 };
//      end
//    else
//      begin
        common_reg_o.uvc_stream_mode_en          <= fpga_reg[STREAMING_MODE_OFFSET_8][0];
        common_reg_o.tx_header_info_as_payload   <= (fpga_reg[FRAME_HEADER_INFO_OFFSET_8] == 8'd1);
        common_reg_o.tx_header_info_as_metadata  <= (fpga_reg[FRAME_HEADER_INFO_OFFSET_8] == 8'd2);
        common_reg_o.lvds_phy_training_seq       <= fpga_reg[LVDS_PHY_TS_OFFSET_8];
        common_reg_o.training_block_seq_p0       <= fpga_reg[TRAINING_BLK_SEQ_BYTE_P0_OFFSET_8];
        common_reg_o.training_block_seq_p1       <= fpga_reg[TRAINING_BLK_SEQ_BYTE_P1_OFFSET_8];
        common_reg_o.training_block_seq_p2       <= fpga_reg[TRAINING_BLK_SEQ_BYTE_P2_OFFSET_8];
        common_reg_o.training_block_seq_p3       <= fpga_reg[TRAINING_BLK_SEQ_BYTE_P3_OFFSET_8];
        common_reg_o.acive_dev_mask              <= fpga_reg[ACTIVE_DEV_MASK_OFFSET_8];
        common_reg_o.low_power_mode_info         <= fpga_reg[LOW_POWER_SUPPORT_OFFSET_8][0];
        common_reg_o.lvds_phy_training_en        <= fpga_reg[PHY_AND_LINK_TRAINING_CONTROL_OFFSET_8][0];
        common_reg_o.link_training_en            <= fpga_reg[PHY_AND_LINK_TRAINING_CONTROL_OFFSET_8][1];
        common_reg_o.p0_link_training_completed  <= fpga_reg[PHY_AND_LINK_TRAINING_CONTROL_OFFSET_8][6];
        common_reg_o.p1_link_training_completed  <= fpga_reg[PHY_AND_LINK_TRAINING_CONTROL_OFFSET_8][7];
//      end
   end


generate
  for ( dev_num = 0; dev_num < NO_OF_SUPPORTED_DEV_I; dev_num = dev_num + 1 )
    begin : DEV_SIGNALS

      // Stream Enable Register
      assign dev_reg_info_st_arr_o[dev_num].fw_soft_reset         = dev_reg_st_arr[dev_num].stream_en[0];
      assign dev_reg_info_st_arr_o[dev_num].start_stream          = dev_reg_st_arr[dev_num].stream_en[1];
      assign dev_reg_info_st_arr_o[dev_num].stop_stream_immideate = dev_reg_st_arr[dev_num].stream_en[2];

      // Mode Enable register
      assign dev_reg_info_st_arr_o[dev_num].interleaved_mode_en           = dev_reg_st_arr[dev_num].mode_en[0];
      assign dev_reg_info_st_arr_o[dev_num].still_capture_mode_en         = dev_reg_st_arr[dev_num].mode_en[1];
      assign dev_reg_info_st_arr_o[dev_num].mono8_conversion_mode_en      = dev_reg_st_arr[dev_num].mode_en[2];
      assign dev_reg_info_st_arr_o[dev_num].yuv422_420_conversion_mode_en = dev_reg_st_arr[dev_num].mode_en[3];

      // Image Height
      assign dev_reg_info_st_arr_o[dev_num].image_height = dev_reg_st_arr[dev_num].image_height_info;

      // Image Width
      assign dev_reg_info_st_arr_o[dev_num].image_width = dev_reg_st_arr[dev_num].image_width_info;

      // Image FPS
      assign dev_reg_info_st_arr_o[dev_num].image_fps = dev_reg_st_arr[dev_num].frame_rate_info;

      // Image Pixel Width in Bits
      assign dev_reg_info_st_arr_o[dev_num].image_pixel_width = dev_reg_st_arr[dev_num].image_pixel_width_info;

      // Image Size in Bytes
      // assign dev_reg_info_st_arr_o[dev_num].image_size_in_bytes = (dev_reg_st_arr[dev_num].image_width_info * dev_reg_st_arr[dev_num].image_height_info);

      // Source Info: Internal TP, HDMI or MIPI
      assign dev_reg_info_st_arr_o[dev_num].internal_tp_en = ( dev_reg_st_arr[dev_num].source_type_info[1:0] == 2'd0 );
      assign dev_reg_info_st_arr_o[dev_num].hdmi_source_en = ( dev_reg_st_arr[dev_num].source_type_info[1:0] == 2'd1 );
      assign dev_reg_info_st_arr_o[dev_num].mipi_source_en = ( dev_reg_st_arr[dev_num].source_type_info[1:0] == 2'd2 );

      // HDMI/MIPI Source Info
      assign dev_reg_info_st_arr_o[dev_num].hdmi_source_connection = ( ( dev_reg_st_arr[dev_num].hdmi_mipi_source_info[0] & dev_reg_info_st_arr_o[dev_num].hdmi_source_en ) | ( !dev_reg_info_st_arr_o[dev_num].hdmi_source_en));
      assign dev_reg_info_st_arr_o[dev_num].hdmi_channel_info      = dev_reg_st_arr[dev_num].hdmi_mipi_source_info[1];
      assign dev_reg_info_st_arr_o[dev_num].hdmi_mode_rgb          = dev_reg_st_arr[dev_num].hdmi_mipi_source_info[2];
      assign dev_reg_info_st_arr_o[dev_num].mipi_isp_en            = dev_reg_st_arr[dev_num].hdmi_mipi_source_info[4];
      assign dev_reg_info_st_arr_o[dev_num].mipi_image_crop_en     = dev_reg_st_arr[dev_num].hdmi_mipi_source_info[5];

      // U3V Streaming Info
      assign dev_reg_info_st_arr_o[dev_num].u3v_continuous_mode                 = dev_reg_st_arr[dev_num].u3v_stream_mode[0];
      assign dev_reg_info_st_arr_o[dev_num].u3v_single_frame_mode               = dev_reg_st_arr[dev_num].u3v_stream_mode[1];
      assign dev_reg_info_st_arr_o[dev_num].u3v_multi_frame_mode                = dev_reg_st_arr[dev_num].u3v_stream_mode[2];
      assign dev_reg_info_st_arr_o[dev_num].u3v_no_of_frame_in_multi_frame_mode = dev_reg_st_arr[dev_num].u3v_stream_mode[7:3];

      // U3V Chunk Type Info
      assign dev_reg_info_st_arr_o[dev_num].u3v_chunk_mode_en         = dev_reg_st_arr[dev_num].u3v_chunk_mode[0];
      assign dev_reg_info_st_arr_o[dev_num].u3v_frame_id_chunk_type   = dev_reg_st_arr[dev_num].u3v_chunk_mode[1];
      assign dev_reg_info_st_arr_o[dev_num].u3v_time_stamp_chunk_type = dev_reg_st_arr[dev_num].u3v_chunk_mode[2];

      // U3V Trigger Info
      assign dev_reg_info_st_arr_o[dev_num].u3v_trigger_mode_en = dev_reg_st_arr[dev_num].u3v_trigger_info[0];
      assign dev_reg_info_st_arr_o[dev_num].u3v_trigger_type    = dev_reg_st_arr[dev_num].u3v_trigger_info[1];
      assign dev_reg_info_st_arr_o[dev_num].u3v_hw_trigger      = dev_reg_st_arr[dev_num].u3v_trigger_info[6:3];
      assign dev_reg_info_st_arr_o[dev_num].u3v_sw_trigger      = dev_reg_st_arr[dev_num].u3v_trigger_info[7];

      // Thread and Socket Info
      assign dev_reg_info_st_arr_o[dev_num].active_thread            = dev_reg_st_arr[dev_num].active_thread_info;
      assign dev_reg_info_st_arr_o[dev_num].thread_1_info            = dev_reg_st_arr[dev_num].thread_1_info;
      assign dev_reg_info_st_arr_o[dev_num].thread_2_info            = dev_reg_st_arr[dev_num].thread_2_info;
      assign dev_reg_info_st_arr_o[dev_num].c_n_crc_info             = dev_reg_st_arr[dev_num].c_n_crc_info;
      assign dev_reg_info_st_arr_o[dev_num].thread_1_socket_info     = dev_reg_st_arr[dev_num].thread_1_socket_info;
      assign dev_reg_info_st_arr_o[dev_num].thread_2_socket_info     = dev_reg_st_arr[dev_num].thread_2_socket_info;
      assign dev_reg_info_st_arr_o[dev_num].flag_info                = dev_reg_st_arr[dev_num].flag_info;
      assign dev_reg_info_st_arr_o[dev_num].thread_num               = thread_num_map[((dev_num<<1) + 1):(dev_num<<1)];
      assign dev_reg_info_st_arr_o[dev_num].buffer_size_info         = dev_reg_st_arr[dev_num].buffer_size_info;
      assign dev_reg_info_st_arr_o[dev_num].socket_addr_same_for_dev = ( dev_reg_st_arr[dev_num].thread_1_socket_info == dev_reg_st_arr[dev_num].thread_2_socket_info );

     // Selected thread address
     always_ff @ ( posedge clk )
      begin
        if ( !reset_n )
          begin
            dev_reg_info_st_arr_o[dev_num].thread_addr <= dev_reg_info_st_arr_o[dev_num].thread_1_info;
            dev_reg_info_st_arr_o[dev_num].socket_addr <= dev_reg_info_st_arr_o[dev_num].thread_1_socket_info;
          end
        else if ( dev_reg_info_st_arr_o[dev_num].thread_num[1] == 1'b1 )
          begin
            dev_reg_info_st_arr_o[dev_num].thread_addr <= dev_reg_info_st_arr_o[dev_num].thread_2_info;
            dev_reg_info_st_arr_o[dev_num].socket_addr <= dev_reg_info_st_arr_o[dev_num].thread_2_socket_info;
          end
        else
          begin
            dev_reg_info_st_arr_o[dev_num].thread_addr <= dev_reg_info_st_arr_o[dev_num].thread_1_info;
            dev_reg_info_st_arr_o[dev_num].socket_addr <= dev_reg_info_st_arr_o[dev_num].thread_1_socket_info;
         end
      end

    end
endgenerate


// -----------------------------------
//
// External Controller Status
//
// -----------------------------------

// FX10 Buffer Ready flag Status
always_ff @ (posedge clk)
  begin
    if ( ~reset_n )
      begin
        ext_cntlr_status_reg[0] <= 1'b0;
      end
    else
      begin
        ext_cntlr_status_reg[0] <= fxn_gpif_m_full_flag_i;
      end
  end

// DDR Controller Configuration Status
always_ff @ (posedge clk)
  begin
    if ( ~reset_n )
      begin
        ext_cntlr_status_reg[1] <= 1'b0;
      end
    else
      begin
        ext_cntlr_status_reg[1] <= ddr_cfg_done_i;
      end
  end

// DDR Controller Busy
always_ff @ (posedge clk)
  begin
    if ( ~reset_n )
      begin
        ext_cntlr_status_reg[2] <= 1'b0;
      end
    else
      begin
        ext_cntlr_status_reg[2] <= ddr_ctrl_busy_i;
      end
  end


// DDR Controller command queue almost full
always_ff @ (posedge clk)
  begin
    if ( ~reset_n )
      begin
        ext_cntlr_status_reg[3] <= 1'b0;
      end
    else if ( ddr_ctrl_cmd_queue_almost_full_i )
      begin
        ext_cntlr_status_reg[3] <= 1'b1;
      end
    else if ( clr_cntlr_status_reg_pl )
      begin
        ext_cntlr_status_reg[3] <= ddr_ctrl_cmd_queue_almost_full_i;
      end
  end


// DDR Controller Datapath IDLE
always_ff @ (posedge clk)
  begin
    if ( ~reset_n )
      begin
        ext_cntlr_status_reg[4] <= 1'b0;
      end
    else
      begin
        ext_cntlr_status_reg[4] <= ddr_ctrl_data_path_idle_i;
      end
  end


// -----------------------------------
//
// Device Specific Registers
//
// -----------------------------------
// Use assign statement if it isn't working
generate
  for ( dev_num = 0; dev_num < NO_OF_SUPPORTED_DEV_I ; dev_num = dev_num + 1 )
    begin : DEV_REG_LOOP

      always_ff @ ( posedge clk )
        begin
          // if ( !reset_n )
            // begin
              // dev_reg_st_arr[dev_num] <= '{default:0};
            // end
          // else
            // begin
              dev_reg_st_arr[dev_num].stream_en                   <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + STREAM_ENABLE_OFFSET_8];
              dev_reg_st_arr[dev_num].mode_en                     <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + MODE_ENABLE_OFFSET_8];
              dev_reg_st_arr[dev_num].image_height_info           <= {fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + IMAGE_HEIGHT_INFO_UB_OFFSET_8],
                                                                   fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + IMAGE_HEIGHT_INFO_LB_OFFSET_8]};
              dev_reg_st_arr[dev_num].image_width_info            <= {fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + IMAGE_WIDTH_INFO_UB_OFFSET_8],
                                                                   fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + IMAGE_WIDTH_INFO_LB_OFFSET_8]};
              dev_reg_st_arr[dev_num].frame_rate_info             <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + IMAGE_FRAME_RATE_INFO_OFFSET_8];
              dev_reg_st_arr[dev_num].image_pixel_width_info      <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + IMAGE_PIXEL_WIDTH_INFO_OFFSET_8];
              dev_reg_st_arr[dev_num].source_type_info            <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + SOURCE_TYPE_INFO_OFFSET_8];
              dev_reg_st_arr[dev_num].hdmi_mipi_source_info       <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + HDMI_MIPI_SOURCE_INFO_OFFSET_8];
              dev_reg_st_arr[dev_num].u3v_stream_mode             <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + U3V_STREAM_MODE_OFFSET_8];
              dev_reg_st_arr[dev_num].u3v_chunk_mode              <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + U3V_CHUNK_MODE_OFFSET_8];
              dev_reg_st_arr[dev_num].u3v_trigger_info            <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + U3V_TRIGGER_INFO_OFFSET_8];
              dev_reg_st_arr[dev_num].active_thread_info          <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + ACTIVE_THREAD_INFO_OFFSET_8][1:0];
              dev_reg_st_arr[dev_num].thread_1_info               <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + THREAD_1_INFO_OFFSET_8][1:0];
              dev_reg_st_arr[dev_num].thread_2_info               <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + THREAD_2_INFO_OFFSET_8][1:0];
              dev_reg_st_arr[dev_num].c_n_crc_info                <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + COUNTERS_AND_CRC_INFO_OFFSET_8][4:0];
              dev_reg_st_arr[dev_num].thread_1_socket_info        <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + THREAD_1_SOCKET_INFO_OFFSET_8][2:0];
              dev_reg_st_arr[dev_num].thread_2_socket_info        <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + THREAD_2_SOCKET_INFO_OFFSET_8][2:0];
              dev_reg_st_arr[dev_num].flag_info                   <= fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + FLAG_INFO_OFFSET_8][3:0];

              dev_reg_st_arr[dev_num].buffer_size_info            <= {fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + BUFFER_SIZE_UB_INFO_OFFSET_8],
                                                                   fpga_reg[((dev_num * DEV_REG_BASE_OFFSET_DIFF)+DEVICE_0_REG_BASE_OFFSET_8) + BUFFER_SIZE_LB_INFO_OFFSET_8]};


        end

// -----------------------------------
//
// Buffer Status Register
//
// -----------------------------------

// Slave FIFO Almost Empty Status
    always_ff @ (posedge clk)
      begin
        if ( ~reset_n )
          begin
            dev_reg_st_arr[dev_num].status_info[0] <= 1'b0;
          end
        else if ( slfifo_data_nd_status_st_arr_i[dev_num].almost_empty == 1'b0 )
          begin
            dev_reg_st_arr[dev_num].status_info[0] <= 1'b0;
          end
        else if ( clr_sel_d_flag_status_reg_pl[dev_num] )
          begin
            dev_reg_st_arr[dev_num].status_info[0] <= slfifo_data_nd_status_st_arr_i[dev_num].almost_empty;
    end
  end

// Intermediate FIFO Empty Status
    always_ff @ (posedge clk)
      begin
        if ( ~reset_n )
          begin
            dev_reg_st_arr[dev_num].status_info[1] <= 1'b0;
          end
        else if ( y_data_bufr_empty_i[dev_num] == 1'b0 )
          begin
            dev_reg_st_arr[dev_num].status_info[1] <= 1'b0;
          end
        else if ( clr_sel_d_flag_status_reg_pl[dev_num] )
          begin
            dev_reg_st_arr[dev_num].status_info[1] <= y_data_bufr_empty_i[dev_num];
          end
      end

// Intermediate FIFO Full Status
    always_ff @ (posedge clk)
      begin
        if ( ~reset_n )
          begin
            dev_reg_st_arr[dev_num].status_info[2] <= 1'b0;
          end
        else if ( y_data_bufr_full_i[dev_num] )
          begin
            dev_reg_st_arr[dev_num].status_info[2] <= 1'b1;
          end
        else if ( clr_sel_d_flag_status_reg_pl[dev_num] )
          begin
            dev_reg_st_arr[dev_num].status_info[2] <= y_data_bufr_full_i[dev_num];
          end
      end

// Full Frame is written or not into DDR
    always_ff @ (posedge clk)
      begin
        if ( ~reset_n )
          begin
            dev_reg_st_arr[dev_num].status_info[4] <= 1'b0;
          end
        else if ( full_frame_wr_completed_i[dev_num] )
          begin
            dev_reg_st_arr[dev_num].status_info[4] <= 1'b1;
          end
        else if ( clr_sel_d_flag_status_reg_pl[dev_num] )
          begin
            dev_reg_st_arr[dev_num].status_info[4] <= full_frame_wr_completed_i[dev_num];
          end
      end

// Full Frame is read or not from DDR
    always_ff @ (posedge clk)
      begin
        if ( ~reset_n )
          begin
            dev_reg_st_arr[dev_num].status_info[5] <= 1'b0;
          end
        else if ( full_frame_rd_completed_i[dev_num] )
          begin
            dev_reg_st_arr[dev_num].status_info[5] <= 1'b1;
          end
        else if ( clr_sel_d_flag_status_reg_pl[dev_num] )
          begin
            dev_reg_st_arr[dev_num].status_info[5] <= full_frame_rd_completed_i[dev_num];
          end
      end


// MIPI status logic:
    always_ff @ (posedge clk)
      begin
        if ( ~reset_n )
          begin
            dev_reg_st_arr[dev_num].mipi_status_info <= 8'd0;
          end
        else
          begin
            dev_reg_st_arr[dev_num].mipi_status_info <= { mipi_status_reg_i[dev_num][14],mipi_status_reg_i[dev_num][10],
                                                          mipi_status_reg_i[dev_num][6:5],mipi_status_reg_i[dev_num][3:0]
                                                         };
          end
      end

  end
endgenerate

// ------------------------------------------
//
// Thread Address Manaegement
//
// ------------------------------------------

// Thread Number Map:
// Based on selected device number, thread number is updated when particular thread
// is served. The next thread number will be updated when "change_thread_addr_pl_i"
// is HIGH from "data_pkt_manager_fsm".
always_ff @ ( posedge clk or negedge reset_n )
  begin
    if ( !reset_n )
      begin
        thread_num_map <= /* 16'h5555 */ {8{2'b01}};
      end
    else if ( sel_d_reset_or_stop_stream_req_i )
      begin
        case ( sel_device_num_i )

          3'd0 : thread_num_map <= { thread_num_map[15:2], 2'd1 };
          3'd1 : thread_num_map <= { thread_num_map[15:4], 2'd1, thread_num_map[1:0] };
          3'd2 : thread_num_map <= { thread_num_map[15:6], 2'd1, thread_num_map[3:0] };
          3'd3 : thread_num_map <= { thread_num_map[15:8], 2'd1, thread_num_map[5:0] };
          3'd4 : thread_num_map <= { thread_num_map[15:10], 2'd1, thread_num_map[7:0] };
          3'd5 : thread_num_map <= { thread_num_map[15:12], 2'd1, thread_num_map[9:0] };
          3'd6 : thread_num_map <= { thread_num_map[15:14], 2'd1, thread_num_map[11:0] };
          3'd7 : thread_num_map <= { 2'd1, thread_num_map[13:0] };

        endcase
      end
    else if ( change_thread_addr_pl_i )
      begin
        case ( sel_device_num_i )

          3'd0 : thread_num_map <= { thread_num_map[15:2], ~thread_num_map[1], ~thread_num_map[0] };
          3'd1 : thread_num_map <= { thread_num_map[15:4], ~thread_num_map[3], ~thread_num_map[2], thread_num_map[1:0] };
          3'd2 : thread_num_map <= { thread_num_map[15:6], ~thread_num_map[5], ~thread_num_map[4], thread_num_map[3:0] };
          3'd3 : thread_num_map <= { thread_num_map[15:8], ~thread_num_map[7], ~thread_num_map[6], thread_num_map[5:0] };
          3'd4 : thread_num_map <= { thread_num_map[15:10], ~thread_num_map[9], ~thread_num_map[8], thread_num_map[7:0] };
          3'd5 : thread_num_map <= { thread_num_map[15:12], ~thread_num_map[11], ~thread_num_map[10], thread_num_map[9:0] };
          3'd6 : thread_num_map <= { thread_num_map[15:14], ~thread_num_map[13], ~thread_num_map[12], thread_num_map[11:0] };
          3'd7 : thread_num_map <= { ~thread_num_map[15], ~thread_num_map[14], thread_num_map[13:0] };

        endcase
      end
  end


// Simple Flops
always_ff @ (posedge clk)
  begin
    if ( !reset_n )
      begin
        change_thread_addr_pl_f1 <= 1'd0;
        change_thread_addr_pl_f2 <= 1'd0;
        change_thread_addr_pl_f3 <= 1'd0;
      end
    else
      begin
        change_thread_addr_pl_f1 <= change_thread_addr_pl_i;
        change_thread_addr_pl_f2 <= change_thread_addr_pl_f1;
        change_thread_addr_pl_f3 <= change_thread_addr_pl_f2;
      end
  end

// New thread address is available to send
assign new_thread_addr_available_pl_o = change_thread_addr_pl_f3;

// ------------------------------------------
//
// I2C Time Out Counter
//
// ------------------------------------------
always_ff @ (posedge clk)
  begin
    if ( !reset_n )
      begin
        i2c_s_time_out_counter <= 32'd0;
      end
    else if ( i2c_s_time_out_counter_en == 1'b1 )
      begin
        i2c_s_time_out_counter <= i2c_s_time_out_counter + 1'b1;
      end
    else
      begin
        i2c_s_time_out_counter <= 32'd0;
      end
  end

endmodule

