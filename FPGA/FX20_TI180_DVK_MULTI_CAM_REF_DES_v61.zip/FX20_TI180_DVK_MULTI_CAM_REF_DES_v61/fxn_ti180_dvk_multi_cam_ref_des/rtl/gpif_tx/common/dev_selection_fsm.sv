//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    dev_selection_fsm
// Target Devices: All
//
// Description: On power up, this module trains FXn LVDS PHY and link. It serves
//              the connected devices in a round robin manner based on Active
//              Device map. Here, device means peripheral link connected with FPGA
//              from which FPGA needs to receive data and transmit to FX10. If
//              single device supports audio and video both, it is treated as
//              different devices.
//
//              Low power modes are not supported as of now.
//
//////////////////////////////////////////////////////////////////////////////////

// Include the package file
`include "package/user_define_pkg.sv"

module dev_selection_fsm
 #
 (
   // GPIF Master Mode: LVDS or LVCMOS
   parameter GPIF_MASTER_MODE_I = "LVCMOS_DDR",

   // LVDS Data Lanes
   parameter TOTAL_DATA_LANES_I = 16,

   // No. of devices/ FIFOs needed
   parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
   parameter SEL_DEV_NUM_BITS_I = 3
 )
 (
  input               clk,
  input               reset_n,

  // Output
  output logic        all_devices_served_pl_o,
  output logic        start_lvds_phy_n_link_training_pl_o,
  output logic        start_serving_device_pl_o,
  output logic [(SEL_DEV_NUM_BITS_I-1):0] sel_device_num_o,
  output logic        enter_l1_lp_mode_o,
  output logic        enter_l2_lp_mode_o,
  output logic        exit_l1_lp_mode_o,
  output logic        exit_l2_lp_mode_o,

  output logic        sel_d_reset_or_stop_stream_req_o,
  output logic [31:0] sel_d_frame_size_in_bytes_o,
  output dev_reg_info_st_t sel_d_reg_info_st_o,

  // Input
  input               fxn_buffer_ready_i,
  input               fxn_lvds_rx_link_ready_i,            // LVDS PHY is ready to be trained - from FXn
  input               lvds_phy_n_link_training_done_pl_i,   // From PHY & Link Training Module

  // Low Power Mode
  input               enter_l1_mode_i,  // Low Power Mode Entry.
  input               enter_l2_mode_i,  // Low Power Mode Entry.
  input               exit_l1_mode_i,   // Low Power Mode Exit.
  input               exit_l2_mode_i,   // Low Power Mode Exit.

  // Register Info
  input               full_frame_sent_pl_i, // Full frame is sent. Move to next Device.
  input               data_pkt_sent_pl_i,

  input slfifo_data_nd_status_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] slfifo_data_nd_status_st_arr_i,
  input common_reg_info_st_t common_reg_info_i,
  input dev_reg_info_st_t          [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr_i
 );

// ------------------------------------------
//
// Parameters
//
// ------------------------------------------

  // Device switching delay clocks
  localparam NO_OF_DEVICE_SWITCH_DELAY_CLOCKS = 3;

  // Sampling clocks
  localparam NO_OF_BUFFER_ND_DATA_SAMPLE_CLOCKS = 50;

  // No of States
  localparam NO_OF_FSM_STATES = 14;

  // FSM States
  enum logic [(NO_OF_FSM_STATES-1):0] {
    IDLE                                    = 14'h1,
    IS_PHY_TRAINING_COMPLETED               = 14'h2,
    START_LVDS_PHY_N_LINK_TRAINING          = 14'h4,
    WAIT_LVDS_PHY_N_LINK_TRAINING_COMPLETES = 14'h8,
    WAIT_LVDS_PHY_N_LINK_TRAINING_RESULT    = 14'h10,
    IS_SEL_DEV_ACTIVE                       = 14'h20,
    SERVE_SEL_DEV                           = 14'h40,
    WAIT_SEL_DEV_SERVED                     = 14'h80,
    INCR_DEV_NUMBER                         = 14'h100,
    L1_ENTER                                = 14'h200,
    L1_EXIT                                 = 14'h400,
    L2_ENTER                                = 14'h800,
    L2_EXIT                                 = 14'h1000,
    WAIT_INCR_DEV_NUMBER                    = 14'h2000

  } dev_s_cs, dev_s_ns;

// ------------------------------------------
//
// Local Variables
//
// ------------------------------------------

  // FSM Signals
  logic        start_lvds_phy_n_link_training_pl;
  logic        start_serving_device_pl;
  logic        incr_dev_num_pl;
  logic        enter_l1_lp_mode;
  logic        enter_l2_lp_mode;
  logic        exit_l1_lp_mode;
  logic        exit_l2_lp_mode;
  logic        atleast_single_dev_served;
  logic [(SEL_DEV_NUM_BITS_I-1):0] sel_int_device_num;
  logic [(SEL_DEV_NUM_BITS_I-1):0] sel_device_num;
  logic [(SEL_DEV_NUM_BITS_I-1):0] sel_device_num_f1;
  logic [31:0] sel_d_frame_size_in_pixels;
  logic        incr_misc_count;
  logic [5:0]  misc_count;
  logic        confirm_frame_completion_after_immediate_stop;
  logic        sel_dev_available_to_serve;
  logic        sel_dev_not_available_to_serve;
  logic        fxn_lvds_rx_link_ready_f1;
  logic        fxn_lvds_rx_link_ready_f2;
  logic        fxn_lvds_rx_link_ready_pe_pl;

// ------------------------------------------
//
// FSM
//
// ------------------------------------------

// Current State
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        dev_s_cs <= IDLE;
      end
    else if ( enter_l1_mode_i ) // As of now, low power mode is not supported.
      begin
        dev_s_cs <= L1_ENTER;
      end
    else if ( enter_l2_mode_i )
      begin
        dev_s_cs <= L2_ENTER;
      end
    else
      begin
        dev_s_cs <= dev_s_ns;
      end
  end


// Next State
always_comb
  begin
    dev_s_ns <= IDLE;
    unique case ( dev_s_cs )

      // Wait until LINK_RDY is asserted from FX10.
      IDLE :
        begin
          if ( ( GPIF_MASTER_MODE_I == "LVCMOS_SDR" ) |
               ( ( GPIF_MASTER_MODE_I == "LVCMOS_DDR" ) & ( TOTAL_DATA_LANES_I <= 16 ) ) | // DDR narrow link mode
               ( ( common_reg_info_i.lvds_phy_training_en | common_reg_info_i.link_training_en ) == 1'b0 )
             )
            begin
              dev_s_ns <= IS_SEL_DEV_ACTIVE;
            end
          else if ( fxn_lvds_rx_link_ready_i ) // Once PHY training is completed, it remains HIGH.
            begin
              dev_s_ns <= IS_PHY_TRAINING_COMPLETED;
            end
          else
            begin
              dev_s_ns <= IDLE;
            end
        end

      // Checks whether PHY training is already completed or not.
      // FX10 asserts "fxn_rx_p0_link_training_completed_i" and
      // "fxn_rx_p1_link_training_completed_i" if respective port
      // is trained.
      IS_PHY_TRAINING_COMPLETED :
        begin
          if ( ( common_reg_info_i.p0_link_training_completed == 1'b0 ) &
               ( common_reg_info_i.p1_link_training_completed == 1'b0 )
             )
            begin
              dev_s_ns <= START_LVDS_PHY_N_LINK_TRAINING;
            end
          else
            begin
              dev_s_ns <= IS_SEL_DEV_ACTIVE;
            end
        end

      // Start PHY training.
      START_LVDS_PHY_N_LINK_TRAINING :
        begin
          dev_s_ns <= WAIT_LVDS_PHY_N_LINK_TRAINING_COMPLETES;
        end

      // Wait until PHY training is completed.
      WAIT_LVDS_PHY_N_LINK_TRAINING_COMPLETES :
        begin
          if ( lvds_phy_n_link_training_done_pl_i )
            begin
              dev_s_ns <= WAIT_LVDS_PHY_N_LINK_TRAINING_RESULT;
            end
          else
            begin
              dev_s_ns <= WAIT_LVDS_PHY_N_LINK_TRAINING_COMPLETES;
            end
        end

      // Wait until training result is updated through I2C.
      WAIT_LVDS_PHY_N_LINK_TRAINING_RESULT :
        begin
          if ( ( ( common_reg_info_i.p0_link_training_completed == 1'b1 )   &
                 ( common_reg_info_i.p1_link_training_completed == 1'b1 ) ) |
               ( ( ( common_reg_info_i.p0_link_training_completed == 1'b1 )   |
                   ( common_reg_info_i.p1_link_training_completed == 1'b1 ) ) &
                   ( TOTAL_DATA_LANES_I < 16 ) )
             )
            begin
              dev_s_ns <= IS_SEL_DEV_ACTIVE;
            end
          else if ( fxn_lvds_rx_link_ready_pe_pl )
            begin
              dev_s_ns <= START_LVDS_PHY_N_LINK_TRAINING;  // Retry the training
            end
          else
            begin
              dev_s_ns <= WAIT_LVDS_PHY_N_LINK_TRAINING_RESULT;
            end
        end

      // Is selected device active?
      // Sampling for 50 clock cycles if almost empty
      // remains high or flag a remains low for
      // particular device then switch device
      IS_SEL_DEV_ACTIVE :
        begin
          if ( sel_dev_available_to_serve )
            begin
              dev_s_ns <= SERVE_SEL_DEV;
            end
          else /* if ( sel_dev_not_available_to_serve ) */
            begin
              dev_s_ns <= INCR_DEV_NUMBER;
            end
          // else
            // begin
              // dev_s_ns <= IS_SEL_DEV_ACTIVE;
            // end
        end

      // Device is active. Let's serve it.
      SERVE_SEL_DEV :
        begin
          dev_s_ns <= WAIT_SEL_DEV_SERVED;
        end

      // Wait until device is served or stream stop/reset request
      // is received for selected device, move to next one.
      WAIT_SEL_DEV_SERVED :
        begin
          if ( full_frame_sent_pl_i |
               data_pkt_sent_pl_i   |
               sel_d_reset_or_stop_stream_req_o
             )
            begin
              dev_s_ns <= INCR_DEV_NUMBER;
            end
          else
            begin
              dev_s_ns <= WAIT_SEL_DEV_SERVED;
            end
        end

      // Move to next device
      INCR_DEV_NUMBER :
        begin
          dev_s_ns <= WAIT_INCR_DEV_NUMBER;
        end

      // Wait incr device
      WAIT_INCR_DEV_NUMBER :
        begin
          if ( misc_count == NO_OF_DEVICE_SWITCH_DELAY_CLOCKS )
            begin
              dev_s_ns <= IS_SEL_DEV_ACTIVE;
            end
          else
            begin
              dev_s_ns <= WAIT_INCR_DEV_NUMBER;
            end
        end

      // Low Power Mode L1
      L1_ENTER :
        begin
          if ( exit_l1_mode_i )
            begin
              dev_s_ns <= L1_EXIT;
            end
          else
            begin
              dev_s_ns <= L1_ENTER;
            end
        end

      // Exit L1
      L1_EXIT :
        begin
          dev_s_ns <= START_LVDS_PHY_N_LINK_TRAINING;
        end

      // Low Power Mode L2
      L2_ENTER :
        begin
          if ( exit_l2_mode_i )
            begin
              dev_s_ns <= L2_EXIT;
            end
          else
            begin
              dev_s_ns <= L2_ENTER;
            end
        end

      // Exit L2
      L2_EXIT :
        begin
          dev_s_ns <= START_LVDS_PHY_N_LINK_TRAINING;
        end

    endcase
  end


// Next State: Signals
always_comb
  begin

    start_lvds_phy_n_link_training_pl <= 1'b0;
    start_serving_device_pl           <= 1'b0;
    incr_dev_num_pl                   <= 1'b0;
    enter_l1_lp_mode                  <= 1'b0;
    enter_l2_lp_mode                  <= 1'b0;
    exit_l1_lp_mode                   <= 1'b0;
    exit_l2_lp_mode                   <= 1'b0;
    incr_misc_count                   <= 1'b0;

    unique case ( dev_s_cs )

      // Wait until LINK_RDY is asserted from FX10.
      IDLE :
        begin

        end

      // Checks whether PHY training is already completed or not.
      // FX10 asserts "fxn_rx_p0_link_training_completed_i" and
      // "fxn_rx_p1_link_training_completed_i" if respective port
      // is trained.
      IS_PHY_TRAINING_COMPLETED :
        begin

        end

      // Start PHY training.
      START_LVDS_PHY_N_LINK_TRAINING :
        begin
          start_lvds_phy_n_link_training_pl <= 1'b1;
        end

      // Wait until PHY training is completed.
      WAIT_LVDS_PHY_N_LINK_TRAINING_COMPLETES :
        begin

        end

      // Wait until training result is updated through I2C.
      WAIT_LVDS_PHY_N_LINK_TRAINING_RESULT :
        begin

        end

      // Is selected device active?
      IS_SEL_DEV_ACTIVE :
        begin
          // incr_misc_count <= 1'b1;
        end

      // Device is active. Let's serve it.
      SERVE_SEL_DEV :
        begin
          start_serving_device_pl <= 1'b1;
        end

      // Wait until device is served.
      WAIT_SEL_DEV_SERVED :
        begin

        end

      // Move to next device
      INCR_DEV_NUMBER :
        begin
          incr_dev_num_pl <= 1'b1;
        end

      // Waiting for the variables to get updated
      // structure updation will take one more clock cycle
      WAIT_INCR_DEV_NUMBER :
        begin
          incr_misc_count <= 1'b1;
        end

      // Low Power Mode L1
      L1_ENTER :
        begin
          enter_l1_lp_mode <= 1'b1;
        end

      // Exit L1
      L1_EXIT :
        begin
          exit_l1_lp_mode <= 1'b1;
        end

      // Low Power Mode L2
      L2_ENTER :
        begin
          enter_l2_lp_mode <= 1'b1;
        end

      // Exit L2
      L2_EXIT :
        begin
          exit_l2_lp_mode <= 1'b1;
        end

    endcase
  end


// ------------------------------------------
//
// Register Outputs
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        start_lvds_phy_n_link_training_pl_o <= 1'b0;
        start_serving_device_pl_o           <= 1'b0;
        enter_l1_lp_mode_o                  <= 1'b0;
        enter_l2_lp_mode_o                  <= 1'b0;
        exit_l1_lp_mode_o                   <= 1'b0;
        exit_l2_lp_mode_o                   <= 1'b0;
      end
    else
      begin
        start_lvds_phy_n_link_training_pl_o <= start_lvds_phy_n_link_training_pl;
        start_serving_device_pl_o           <= start_serving_device_pl;
        enter_l1_lp_mode_o                  <= enter_l1_lp_mode;
        enter_l2_lp_mode_o                  <= enter_l2_lp_mode;
        exit_l1_lp_mode_o                   <= exit_l1_lp_mode;
        exit_l2_lp_mode_o                   <= exit_l2_lp_mode;
      end
  end

// As we are switching based on buffer so
// we will make sure it will write complete frame
// Confirm Frame_completion
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        confirm_frame_completion_after_immediate_stop <= 1'b0;
      end
    else if ( sel_d_reg_info_st_o.stop_stream_immideate == 1'b0 )
      begin
        confirm_frame_completion_after_immediate_stop <= 1'b1;
      end
	else if ( full_frame_sent_pl_i )
      begin
        confirm_frame_completion_after_immediate_stop <= 1'b0;
      end
  end

// ------------------------------------------
//
// Selected Device
//
// ------------------------------------------

// Internal Device Number
// It is used by FSM to check whether device is active or not.
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_int_device_num <= '0;
      end
    else if ( incr_dev_num_pl )
      begin
        if ( sel_int_device_num == ( NO_OF_SUPPORTED_DEV_I - 1'b1 ) )
          begin
            sel_int_device_num <= '0;
          end
        else
          begin
        sel_int_device_num <= sel_int_device_num + 1'b1;
      end
  end
  end

// Actual Device Number
// It is used by Register Module.
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        sel_device_num <= '0;
      end
    else if ( incr_dev_num_pl )
      begin
        if ( sel_int_device_num == ( NO_OF_SUPPORTED_DEV_I - 1'b1 ) )
          begin
            if ( common_reg_info_i.acive_dev_mask[0] == 1'b1 )
              begin
                sel_device_num <= '0;
              end
          end
        else if ( common_reg_info_i.acive_dev_mask[sel_int_device_num + 1] == 1'b1 )
          begin
            sel_device_num <= sel_int_device_num + 1'b1;
          end
      end
  end

// Simple Flops
// As "sel_d_reset_or_stop_stream_req_o" is updated after 2 clock cycles,
// "sel_device_num_o" is the 2nd flop and used by the other modules.
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        sel_device_num_f1 <= '0;
        sel_device_num_o  <= '0;
        fxn_lvds_rx_link_ready_f1    <= '0;
        fxn_lvds_rx_link_ready_f2    <= '0;
        fxn_lvds_rx_link_ready_pe_pl <= '0;
      end
    else
      begin
        sel_device_num_f1 <= sel_device_num;
        sel_device_num_o  <= sel_device_num_f1;
        fxn_lvds_rx_link_ready_f1    <= fxn_lvds_rx_link_ready_i;
        fxn_lvds_rx_link_ready_f2    <= fxn_lvds_rx_link_ready_f1;
        fxn_lvds_rx_link_ready_pe_pl <= ( (fxn_lvds_rx_link_ready_f1) & (!fxn_lvds_rx_link_ready_f2) );
      end
  end

// ----------------------------------------------
//
// Inform whether all devices are served or not
//
// ----------------------------------------------

// At least single device is served.
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        atleast_single_dev_served <= 1'b0;
      end
    else if ( all_devices_served_pl_o )
      begin
        atleast_single_dev_served <= 1'b0;
      end
    else if ( full_frame_sent_pl_i )
      begin
        atleast_single_dev_served <= 1'b1;
      end
  end


// All devices are served or not.
always_ff @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        all_devices_served_pl_o <= 3'd0;
      end
    else
      begin
        all_devices_served_pl_o <= ( ( incr_dev_num_pl ) &
                                     ( atleast_single_dev_served ) &
                                     ( sel_int_device_num == (NO_OF_SUPPORTED_DEV_I-1) ) &
                                     ( common_reg_info_i.acive_dev_mask[sel_int_device_num] != 7'd0 )
                                   );
      end
  end

// ------------------------------------------
//
// Selected Device Information
//
// ------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_d_reg_info_st_o <= '{default:0};
      end
    else
      begin
        sel_d_reg_info_st_o <= dev_reg_info_st_arr_i[sel_device_num];
      end
  end


// ------------------------------------------
//
// Stream Start/Stop and FW Soft Reset
//
// ------------------------------------------

// Soft reset or stop stream request from FW or
// HDMI Source is not connected
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_d_reset_or_stop_stream_req_o <= 1'b0;
      end
    else
      begin
        sel_d_reset_or_stop_stream_req_o <= ( ( sel_d_reg_info_st_o.fw_soft_reset == 1'b1 ) |
                                              ( sel_d_reg_info_st_o.start_stream == 1'b0 ) |
                                              ( sel_d_reg_info_st_o.hdmi_source_connection == 1'b0 )
                                            );
      end
  end


// ------------------------------------------
//
// Selecting thread address
//
// ------------------------------------------
/*
// Selected thread address
always @ ( posedge clk )
  begin
    if ( !reset_n )
      begin
        sel_thread_addr_o <= sel_d_reg_info_st_o.thread_1_info;
        sel_socket_addr_o <= sel_d_reg_info_st_o.thread_1_socket_info;
      end
    else if ( sel_d_reg_info_st_o.thread_num[1] == 1'b1 )
      begin
        sel_thread_addr_o <= sel_d_reg_info_st_o.thread_2_info;
        sel_socket_addr_o <= sel_d_reg_info_st_o.thread_2_socket_info;
      end
    else
      begin
        sel_thread_addr_o <= sel_d_reg_info_st_o.thread_1_info;
        sel_socket_addr_o <= sel_d_reg_info_st_o.thread_1_socket_info;
      end
  end
*/

// ------------------------------------------
//
// Frame Size In Bytes
//
// ------------------------------------------

// Soft reset or stop stream request from FW or
// HDMI Source is not connected
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_d_frame_size_in_pixels <= 32'd0;
      end
    else
      begin
        sel_d_frame_size_in_pixels <= ( sel_d_reg_info_st_o.image_height *
                                        sel_d_reg_info_st_o.image_width );
      end
  end

// Image Size in bytes
always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_d_frame_size_in_bytes_o <= '0;
      end
    else
      begin
        case (sel_d_reg_info_st_o.image_pixel_width)

          8'd8    : sel_d_frame_size_in_bytes_o <= sel_d_frame_size_in_pixels;

          8'd12,
          8'd16   : sel_d_frame_size_in_bytes_o <= sel_d_frame_size_in_pixels << 1'b1;

          8'd24,
          8'd32   : sel_d_frame_size_in_bytes_o <= (sel_d_frame_size_in_pixels << 2'd2);
          default : sel_d_frame_size_in_bytes_o <= sel_d_frame_size_in_pixels << 1'b1;

        endcase
      end
  end

// ----------------------------------------------
//
// Switching device requires a 2 or 3 clock cycles to update
// variables.
//
// ----------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        misc_count <= '0;
      end
    else if ( incr_misc_count == 1'b0 )
      begin
        misc_count <= '0;
      end
    else
      begin
        misc_count <= misc_count + 1'b1;
      end
  end

// ----------------------------------------------
// Based on acive_dev_mask and immediate stop
// and buffer ready and almost empty decide
// whether to serve selected device or not
// ----------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_dev_available_to_serve <= 1'b0;
      end
    else if ( ( common_reg_info_i.acive_dev_mask[sel_int_device_num] == 1'b1 ) &
              ( confirm_frame_completion_after_immediate_stop ) &
              ( slfifo_data_nd_status_st_arr_i[sel_int_device_num].almost_empty == 1'b0 ) /* &
              ( fxn_buffer_ready_i ) */
            )
      begin
        sel_dev_available_to_serve <= 1'b1;
      end
    else
      begin
        sel_dev_available_to_serve <= 1'b0;
      end
  end

// ----------------------------------------------
// Sampling for 50 clock cycles if almost empty
// remains high or flag a remains low for
// particular device then switch device
// ----------------------------------------------

always_ff @ ( posedge clk )
  begin
    if ( ~reset_n )
      begin
        sel_dev_not_available_to_serve <= 1'b0;
      end
    else if ( ( ( common_reg_info_i.acive_dev_mask[sel_int_device_num] == 1'b0 ) &
              ( confirm_frame_completion_after_immediate_stop == 1'b0 ) ) |
              ( ( ( slfifo_data_nd_status_st_arr_i[sel_int_device_num].almost_empty == 1'b1 ) |
                ( fxn_buffer_ready_i == 1'b0 ) ) &
                ( misc_count == NO_OF_BUFFER_ND_DATA_SAMPLE_CLOCKS )
              )
            )
      begin
        sel_dev_not_available_to_serve <= 1'b1;
      end
    else
      begin
        sel_dev_not_available_to_serve <= 1'b0;
      end
  end

endmodule
