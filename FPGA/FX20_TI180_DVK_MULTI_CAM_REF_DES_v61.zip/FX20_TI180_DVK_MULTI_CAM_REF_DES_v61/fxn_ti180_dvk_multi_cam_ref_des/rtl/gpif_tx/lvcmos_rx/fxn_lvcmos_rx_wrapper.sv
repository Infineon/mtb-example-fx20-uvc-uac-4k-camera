//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2024, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:    FX10/20 Design
// Module Name:    fxn_lvcmos_rx_wrapper
// Target Devices: T120 and Ti180
//
// Description: This is a wrapper which includes following modules,
//
//                 1. LVCMOS Receiver IP
//                 2. I2C Slave Register Interface
//
//////////////////////////////////////////////////////////////////////////////////

// Include the package files
`include "package/user_define_pkg.sv"

module fxn_lvcmos_rx_wrapper
  #
  (
   // Clock Value
   parameter GPIF_M_CLK_VALUE_I = 75_000_000,

   // GPIF Master Mode: LVDS or LVCMOS
   parameter GPIF_MASTER_MODE_I = "LVCMOS_DDR",

   // LVDS PHY Training Interval in micro seconds
   parameter LVDS_PHY_TS_TIME_IN_US_I = 50,

   // Data Lanes in LVCMOS Mode
   parameter TOTAL_LVCMOS_DATA_LANES_I = 32,

   // Number of threads supported by GPIF
   // parameter NO_OF_THREADS_SUPPORTED_I = 4,

   // No. of devices/ FIFOs needed
   parameter NO_OF_SUPPORTED_DEV_I = 8,

   // Sel device num Data Width in Bits
   parameter SEL_DEV_NUM_BITS_I = 3,

   // I2C Slave Address
   parameter [6:0] I2C_SLAVE_ADDR_I = 7'b000_1101,

   // Number of address bits
   parameter NO_OF_ADDRESS_BITS_I = 2,

   // Slave FIFO Data Width. In case of DDR, it is double.
   localparam SLFIFO_RD_DATA_WIDTH_IN_BITS = ( ( GPIF_MASTER_MODE_I == "LVCMOS_DDR" ) ?
                                               ( TOTAL_LVCMOS_DATA_LANES_I * 2 ) :
                                               ( TOTAL_LVCMOS_DATA_LANES_I ) )
  )
  (
   input              clk,
   input              reset_n,

   // Inputs
   input              slf_m_full_flag_i,
   input              slf_m_par_flag_i,
   input              fxn_lvds_rx_link_ready_i,
   input              enter_l1_mode_i,
   input              enter_l2_mode_i,
   input              exit_l1_mode_i,
   input              exit_l2_mode_i,
   input              ddr_ctrl_data_path_idle_i,
   input              ddr_ctrl_cmd_queue_almost_full_i,
   input              ddr_ctrl_busy_i,
   input              ddr_cfg_done_i,
   input              fifo_almost_full_i,
   input  [14:0]      mipi_status_reg_i,
   input  [(NO_OF_SUPPORTED_DEV_I-1):0] vsync_i,
   input  [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_wr_completed_i,
   input  [(NO_OF_SUPPORTED_DEV_I-1):0] full_frame_rd_completed_i,
   input  [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_empty_i,
   input  [(NO_OF_SUPPORTED_DEV_I-1):0] y_data_bufr_full_i,
   input  [(NO_OF_SUPPORTED_DEV_I-1):0] slfifo_almost_empty_i,
   input  [(TOTAL_LVCMOS_DATA_LANES_I-1):0] slf_m_rd_data_pe_i,
   input  [(TOTAL_LVCMOS_DATA_LANES_I-1):0] slf_m_rd_data_ne_i,
   input i2c_bus_in_st_t     [0:0] i2c_bus_in_st_arr_i,

   // Outputs
   output             slf_m_rd_req_n_o,
   output             slf_m_cs_n_o,
   output             slf_m_oe_n_o,
   output             fifo_wr_req_o,

   output [(SLFIFO_RD_DATA_WIDTH_IN_BITS-1):0] fifo_wr_data_o,
   output [(NO_OF_ADDRESS_BITS_I-1):0] slf_m_addr_o,
   output [(TOTAL_LVCMOS_DATA_LANES_I-1):0] slf_m_wr_data_pe_o,
   output [(TOTAL_LVCMOS_DATA_LANES_I-1):0] slf_m_wr_data_ne_o,
   output i2c_bus_out_st_t     [0:0] i2c_bus_out_st_arr_o
  );

// --------------------------
//
// Local Variables
//
// --------------------------

// Type Defined
common_reg_info_st_t common_reg_info;
dev_reg_info_st_t [(NO_OF_SUPPORTED_DEV_I-1):0] dev_reg_info_st_arr;

logic                            sel_d_reset_or_stop_stream_req;
logic                            change_thread_addr_pl;
logic                            new_thread_addr_available_pl;
logic [(SEL_DEV_NUM_BITS_I-1):0] sel_device_num;

// --------------------------
//
// LVCMOS RX
//
// --------------------------

fxn_lvcmos_rx_top
  #
  (
   // Parameters
   .GPIF_M_CLK_VALUE_I                 (GPIF_M_CLK_VALUE_I),
   .GPIF_MASTER_MODE_I                 (GPIF_MASTER_MODE_I),
   .LVDS_PHY_TS_TIME_IN_US_I           (LVDS_PHY_TS_TIME_IN_US_I),
   .TOTAL_LVCMOS_DATA_LANES_I          (TOTAL_LVCMOS_DATA_LANES_I),
   .NO_OF_SUPPORTED_DEV_I              (NO_OF_SUPPORTED_DEV_I),
   .NO_OF_ADDRESS_BITS_I               (NO_OF_ADDRESS_BITS_I),
   .SEL_DEV_NUM_BITS_I                 (SEL_DEV_NUM_BITS_I))
  flrt
    (
     // Interfaces
     .common_reg_info_i                (common_reg_info),
     // Outputs
     .slf_m_rd_req_n_o                 (slf_m_rd_req_n_o),
     .slf_m_cs_n_o                     (slf_m_cs_n_o),
     .slf_m_oe_n_o                     (slf_m_oe_n_o),
     .change_thread_addr_pl_o          (change_thread_addr_pl),
     .sel_d_reset_or_stop_stream_req_o (sel_d_reset_or_stop_stream_req),
     .sel_device_num_o                 (sel_device_num[(SEL_DEV_NUM_BITS_I-1):0]),
     .slf_m_addr_o                     (slf_m_addr_o[(NO_OF_ADDRESS_BITS_I-1):0]),
     .slf_m_wr_data_pe_o               (slf_m_wr_data_pe_o[(TOTAL_LVCMOS_DATA_LANES_I-1):0]),
     .slf_m_wr_data_ne_o               (slf_m_wr_data_ne_o[(TOTAL_LVCMOS_DATA_LANES_I-1):0]),
     .fifo_wr_data_o			                (fifo_wr_data_o),
     .fifo_wr_req_o			                 (fifo_wr_req_o),

     // Inputs
     .clk                              (clk),
     .reset_n                          (reset_n),
     .slf_m_par_flag_i                 (slf_m_par_flag_i),
     .slf_m_full_flag_i                (slf_m_full_flag_i),
     .fx10_lvds_rx_link_ready_i        (fxn_lvds_rx_link_ready_i),
     .enter_l1_mode_i                  (enter_l1_mode_i),
     .enter_l2_mode_i                  (enter_l2_mode_i),
     .exit_l1_mode_i                   (exit_l1_mode_i),
     .exit_l2_mode_i                   (exit_l2_mode_i),
     .new_thread_addr_available_pl_i   (new_thread_addr_available_pl),
     .fifo_almost_full_i               (fifo_almost_full_i),
     .slf_m_rd_data_pe_i               (slf_m_rd_data_pe_i[(TOTAL_LVCMOS_DATA_LANES_I-1):0]),
     .slf_m_rd_data_ne_i               (slf_m_rd_data_ne_i[(TOTAL_LVCMOS_DATA_LANES_I-1):0]),
     .dev_reg_info_st_arr_i            (dev_reg_info_st_arr));


// --------------------------
//
// I2C Register Interface
//
// --------------------------

fxn_i2c_reg_intr
  #
  (
   // Parameters
   .I2C_SLAVE_ADDR_I                         ( I2C_SLAVE_ADDR_I ),
   .NO_OF_SUPPORTED_DEV_BY_FXN_MASTER_I2C_I  ( 4 ),
   .NO_OF_SUPPORTED_DEV_I                    ( NO_OF_SUPPORTED_DEV_I ),
   .SEL_DEV_NUM_BITS_I                       ( SEL_DEV_NUM_BITS_I )
  )
  reg_interface
    (
      // Outputs
      .i2c_bus_out_st_arr_o               (i2c_bus_out_st_arr_o),
      .cam_i2c_bus_out_st_arr_o           (),
      .new_thread_addr_available_pl_o     (new_thread_addr_available_pl),
      .common_reg_o                       (common_reg_info),
      .dev_reg_info_st_arr_o              (dev_reg_info_st_arr),
      // Inputs
      .clk                                (clk),
      .reset_n                            (reset_n),
      .vsync_i                            (vsync_i),
      .i2c_bus_in_st_arr_i                (i2c_bus_in_st_arr_i),
      .cam_i2c_bus_in_st_arr_i            (1'b0),
      .sel_device_num_i                   (sel_device_num),
      .sel_d_reset_or_stop_stream_req_i   (sel_d_reset_or_stop_stream_req),
      .change_thread_addr_pl_i            (change_thread_addr_pl),
      .y_data_bufr_empty_i                (y_data_bufr_empty_i),
      .y_data_bufr_full_i                 (y_data_bufr_full_i),
      .fxn_gpif_m_full_flag_i             (slf_m_full_flag_i),
      .slfifo_almost_empty_i              (slfifo_almost_empty_i),
      .mipi_status_reg_i                  (mipi_status_reg_i),
      .ddr_ctrl_data_path_idle_i          (ddr_ctrl_data_path_idle_i),
      .ddr_ctrl_cmd_queue_almost_full_i   (ddr_ctrl_cmd_queue_almost_full_i),
      .ddr_ctrl_busy_i                    (ddr_ctrl_busy_i),
      .ddr_cfg_done_i                     (ddr_cfg_done_i),
      .full_frame_wr_completed_i          (full_frame_wr_completed_i),
      .full_frame_rd_completed_i          (full_frame_rd_completed_i)
     );


endmodule
