//////////////////////////////////////////////////////////////////////////////////
//(c) 2020-2022, Cypress Semiconductor Corporation (an Infineon company) or
// an affiliate of Cypress Semiconductor Corporation.  All rights reserved.
//
// This software, including source code, documentation and related materials
// ("Software") is owned by Cypress Semiconductor Corporation or one of its
// affiliates ("Cypress") and is protected by and subject to worldwide patent
// protection (United States and foreign), United States copyright laws and
// international treaty provisions.  Therefore, you may use this Software only
// as provided in the license agreement accompanying the software package from
// which you obtained this Software ("EULA"). If no EULA applies, Cypress hereby
// grants you a personal, non-exclusive, non-transferable license to copy, modify,
// and compile the Software source code solely for use in connection with Cypress's
// integrated circuit products.  Any reproduction, modification, translation,
// compilation, or representation of this Software except as specified above is
// prohibited without the express written permission of Cypress.
//
// Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
// Cypress reserves the right to make changes to the Software without notice.
// Cypress does not assume any liability arising out of the application or use
// of the Software or any product or circuit described in the Software.
// Cypress does not authorize its products for use in any products where a
// malfunction or failure of the Cypress product may reasonably be expected to
// result in significant property damage, injury or death ("High Risk Product").
// By including Cypress's product in a High Risk Product, the manufacturer of
// such system or application assumes all risk of such use and in doing so agrees
// to indemnify Cypress against all liability.
//
// Design Name:  FX10/20 Design
// Module Name:  data_width_manager
// Target Devices: T120 and Ti180
//
// Description: This module converts input 32 bit data to 64 bit word. In 1080p
//              or lower resolutions, HDMI receiver sends data on single lane
//              but on dual edge. It means, at every clock, it sends 32 bits.
//              Whereas in case of 4K, the data width is 64 bits only.
//
//////////////////////////////////////////////////////////////////////////////////

// Include the package file
`include "package/user_define_pkg.sv"

module data_width_manager
  #
  (
   // Parameter to define the data width of input data.
   parameter IN_DATA_WIDTH_I = 128
  )
  (
   input                                clk,
   input                                reset_n,
   input                                hsync_i,
   input        [(IN_DATA_WIDTH_I-1):0] sdr_data_i,
   input  dev_reg_info_st_t dev_reg_info_st_arr_i,

   output logic                         hsync_o,
   output logic [(IN_DATA_WIDTH_I-1):0] sdr_data_o
  );

// -------------------------------------
//
// Local Parameters
//
// -------------------------------------

  // No of States
  localparam NO_OF_FSM_STATES = 4'd4;

  // FSM States
  enum logic [(NO_OF_FSM_STATES-1):0] {
    IDLE                                = 4'h1,
    SEL_LSW                             = 4'h2,
    SEL_MSW                             = 4'h4,
    SEL_FULL_WIDTH                      = 4'h8
  } cs, ns;

// -------------------------------------
//
// Local Variables
//
// -------------------------------------

  logic [(IN_DATA_WIDTH_I-1):0] sdr_data_f1;
  logic                         hsync_f1;
  logic                         sel_msw;
  logic                         sel_lsw;
  logic                         sel_full_data;

// -------------------------------------
//
// FSM
//
// -------------------------------------

  // Current State
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          cs <= IDLE;
        end
      else if ( hsync_i == 1'b0 )
        begin
          cs <= IDLE;
        end
      else
        begin
          cs <= ns;
        end
    end


  // Next State
  always_comb
    begin
      case ( cs )

        IDLE :
          begin
            if ( hsync_i == 1'b1 )
              begin
                if ( dev_reg_info_st_arr_i.hdmi_mode_rgb == 1'b1 )
                  begin
                    ns <= SEL_FULL_WIDTH;
                  end
                else
                  begin
                    ns <= SEL_LSW;
                  end
              end
          end

        SEL_LSW :
          begin
            ns <= SEL_MSW;
          end

        SEL_MSW :
          begin
            if ( hsync_i == 1'b1 )
              begin
                ns <= SEL_LSW;
              end
            else
              begin
                ns <= IDLE;
              end
          end

        SEL_FULL_WIDTH :
          begin
            if ( hsync_i == 1'b0 )
              begin
                ns <= IDLE;
              end
            else
              begin
                ns <= SEL_FULL_WIDTH;
              end
          end

      endcase
    end

// -------------------------------------
//
// Next State Signals
//
// -------------------------------------


  // Next State
  always_comb
    begin

      sel_lsw       <= 1'b0;
      sel_msw       <= 1'b0;
      sel_full_data <= 1'b0;

      case ( cs )

        IDLE :
          begin

          end

        SEL_LSW :
          begin
            sel_lsw <= 1'b1;
          end

        SEL_MSW :
          begin
            sel_msw <= 1'b1;
          end

        SEL_FULL_WIDTH :
          begin
            sel_full_data <= 1'b1;
          end

      endcase
    end


// -------------------------------------
//
// Simple Register
//
// -------------------------------------

  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          hsync_f1    <= '0;
          sdr_data_f1 <= '0;
          hsync_o     <= '0;
        end
      else
        begin
          hsync_f1    <= hsync_i;
          sdr_data_f1 <= sdr_data_i;
          hsync_o     <= ( sel_msw | sel_full_data );
        end

    end

  // Select LSW or MSW
  always_ff @ ( posedge clk )
    begin
      if ( ~reset_n )
        begin
          sdr_data_o <= '0;
        end
      else
        begin
          case ( {sel_lsw, sel_msw, sel_full_data} )

            3'b100 : sdr_data_o <= {sdr_data_o[((IN_DATA_WIDTH_I/2)-1):0], sdr_data_f1[((IN_DATA_WIDTH_I/2)-1):0]};

            3'b010 : sdr_data_o <= {sdr_data_f1[((IN_DATA_WIDTH_I/2)-1):0], sdr_data_o[((IN_DATA_WIDTH_I/2)-1):0]};

            3'b001 : sdr_data_o <= sdr_data_f1;

          endcase

        end

    end



//  // Debugger Module
//     edb_top edb_top_inst (
//
//        .bscan_CAPTURE                    ( jtag_inst1_CAPTURE ),
//        .bscan_DRCK                       ( jtag_inst1_DRCK ),
//        .bscan_RESET                      ( jtag_inst1_RESET ),
//        .bscan_RUNTEST                    ( jtag_inst1_RUNTEST ),
//        .bscan_SEL                        ( jtag_inst1_SEL ),
//        .bscan_SHIFT                      ( jtag_inst1_SHIFT ),
//        .bscan_TCK                        ( jtag_inst1_TCK ),
//        .bscan_TDI                        ( jtag_inst1_TDI ),
//        .bscan_TMS                        ( jtag_inst1_TMS ),
//        .bscan_UPDATE                     ( jtag_inst1_UPDATE ),
//        .bscan_TDO                        ( jtag_inst1_TDO ),
//        .la0_clk                          ( clk ),
//
//        // .la0_img_width_hdmi_i             (img_width_hdmi_i),
//        .la0_hsync_i                      (hsync_i)
//        // .la0_sdr_data_i                   (sdr_data_i),
//        // .la0_hsync_o                      (hsync_o),
//        // .la0_sdr_data_o                   (sdr_data_o),
//        // .la0_cs                           (cs),
//        // .la0_ns                           (ns),
//        // .la0_sel_msw                      (sel_msw),
//        // .la0_sel_lsw                      (sel_lsw),
//        // .la0_sel_full_data                (sel_full_data),
//        // .la0_hsync_f1                     (hsync_f1),
//        // .la0_sdr_data_f1                  (sdr_data_f1)
//
//
//     );

endmodule
