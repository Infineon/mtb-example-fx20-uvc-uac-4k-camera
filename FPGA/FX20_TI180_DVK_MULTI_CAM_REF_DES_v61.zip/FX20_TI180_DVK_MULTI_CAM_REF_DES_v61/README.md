# FX20 Ti180 DVK Multi Camera Reference Design
## Overview
The goal of this reference design is to capture uncompressed 4K@15 fps video from four different camera sensors over MIPI and transmit to the Host PC over USB using FX20.
## Applications Supported
- [x] 4 Sony IMX715 sensors, each simultaneously streaming at 4K@15fps (RAW12 Format).
- [x] 4 THine (THSCG101) sensors, each simultaneously streaming at 4K@15fps (YUV422 Format).
- [x] 4 Internal Colorbar, each simultaneously streaming at 4K@15fps.

Refer to  __Ti180 FPGA Based EZ-USB™ FX20 DVK Multi Camera User Manual__ to validate the above mentioned applications.

 ## Files Included
- ### Ti180 FPGA Based EZ-USB™ FX20 DVK Multi Camera User Manual
   - Procedure for hardware modifications, programming FPGA, FX10 and stream video.
- ### fxn_ti180_dvk_multi_cam_ref_des
   - This reference design demonstrates four parallel instances streaming from internally generated colorbar,
      4K@30 THine (THSCG101) and 4K@60 Sony IMX715 Camera Sensors. As of now, Sony IMX715 sensors are configured for RAW12,
      hence, only greenish color will be observed in the output. THine (THSCG101) sensors are configured to give output YUV422.
-  ### demo
    #### [1]  documents
      -  Schematic files of FPGA and FX20 DVK along with pin description.
    #### [2]  cyusb3
      - Driver related files.
    #### [3]  CyUSBSerial_driver_3.13.0.84
      - Serial Driver related files.
    #### [4]  fpga_bin
      - HEX file for programming FPGA.
    #### [5]  program_fx20_bootloader
      -  BAT file to program FX20 DVK.
    #### [6]  fx20_bootloader_hex
      -  HEX file to enable bootloader in FX20 FVK
    #### [7]  fx20_hex_with_usbboot
      -  HEX files for FX20 DVK
    #### [8]  openocd
      - OpenOCD application files for programming bootloader HEX file to FX20 DVK.
    #### [9]  ez_usb_fx20_control_center
      - FX10 control center utility to program FX20 DVK.
    #### [10] Infineon_uvc_streamer_multi_camera
      - UVC streamer application for multi camera.

































